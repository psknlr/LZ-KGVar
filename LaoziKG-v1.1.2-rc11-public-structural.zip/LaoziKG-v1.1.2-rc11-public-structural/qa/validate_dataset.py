"""LaoziKG — automated dataset validation.

Checks primary-key uniqueness, referential integrity, enum conformance, and
cross-table count consistency, then writes qa/validation_report.json.

Exit status is 1 if any check fails, so this can gate a release.

Usage: python qa/validate_dataset.py --data data --out qa/validation_report.json
"""
import argparse
import datetime
import json
import os

# Single source for the release version string. The cross-file guard below
# compares this against every publication-facing document, INCLUDING the version
# it stamps into its own report — which drifted to 1.1.0 while the docs said
# 1.1.1-rc, because the guard originally scanned only markdown/cff files.
_VP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "VERSION")
RELEASE_VERSION = (open(_VP, encoding="utf-8").read().strip()
                   if os.path.exists(_VP) else "1.1.2-rc6")
import re
import sys

import pandas as pd

RESULTS = []


def check(name, passed, detail="", severity="error"):
    RESULTS.append({"check": name, "passed": bool(passed),
                    "detail": detail, "severity": severity})
    return passed


def load(data_dir, filename):
    path = os.path.join(data_dir, filename)
    if not os.path.exists(path):
        return None
    return pd.read_parquet(path) if filename.endswith(".parquet") else \
        pd.read_csv(path, encoding="utf-8-sig")


def pk_unique(df, col, table):
    if df is None:
        return check(f"{table}: present", False, f"{table} missing")
    dup = int(df[col].duplicated().sum())
    return check(f"{table}: primary key '{col}' unique", dup == 0,
                 f"{dup} duplicate keys")


def fk_valid(child, child_col, parent_ids, label, allow_missing=False):
    if child is None:
        return check(f"{label}: source present", False, "table missing")
    vals = child[child_col].dropna().astype(str)
    orphans = sorted(set(vals) - parent_ids)
    ok = len(orphans) == 0
    return check(f"{label}: foreign key '{child_col}' resolves", ok,
                 f"{len(orphans)} orphan value(s); examples {orphans[:5]}",
                 severity="warning" if allow_missing else "error")


def enum_ok(df, col, allowed, label):
    if df is None or col not in df.columns:
        return check(f"{label}: column '{col}' present", False, "missing")
    bad = sorted(set(df[col].dropna().astype(str)) - allowed)
    return check(f"{label}: '{col}' values in enum", len(bad) == 0,
                 f"unexpected: {bad[:8]}")




# ---------------------------------------------------------------------------
# Clean-room regeneration smoke test — EXECUTED, not asserted.
# v1.1.1 wrote rebuild_smoke_test.status = "PASS" as a literal, so the QA report
# could not serve as reproducibility evidence. This runs the regeneration
# pipeline into a temporary directory and compares every table against the
# shipped data: row count, key set, column set, and full content equality after
# sorting by key. PASS only if the subprocess exits 0 AND every table agrees;
# NOT_TESTED if the inputs are absent; FAIL otherwise, with the diff.
# ---------------------------------------------------------------------------
REBUILD_KEYS = {
    "versions.csv": ["version_id"], "persons.csv": ["person_id"],
    "person_aliases.csv": ["person_id", "alias"],
    "authorship_edges.csv": ["version_id", "person_id", "edge_type"],
    "concepts.csv": ["concept_id"], "concept_relations.csv": None,
    "concept_canonical_chapters.csv": ["concept_id", "chapter_num"],
    "chapter_instances.parquet": ["instance_id"], "sentences.parquet": ["sentence_id"],
    "variants.parquet": ["variant_id"], "commentary.csv": ["commentary_id"],
    "commentary_concept_links.csv": ["commentary_id", "concept_id"],
    "evidence.parquet": ["evidence_id"],
    "concept_chapter_mentions.csv": ["instance_id", "concept_id"],
    "concept_unaligned_mentions.csv": ["instance_id", "concept_id"],
    "concept_sentence_mentions.parquet": ["sentence_id", "concept_id"],
    "concept_sentence_unaligned_mentions.parquet": ["sentence_id", "concept_id"],
    "concept_mention_statistics.csv": ["concept_id"],
    "provenance_assertions.csv": ["pa_id"],
    "alignment_failure_diagnosis.csv": ["version_id"],
    "source_rights.csv": ["version_id"], "alignment_recovery_report.csv": ["version_id"],
    "concept_recovered_mentions.csv": ["instance_id", "concept_id"],
    "concept_sentence_recovered_mentions.parquet": ["sentence_id", "concept_id"],
}


def _read_any(path):
    return pd.read_parquet(path) if path.endswith(".parquet") else \
        pd.read_csv(path, encoding="utf-8-sig")


def run_rebuild_smoke_test(data_dir, root):
    import subprocess, sys, tempfile, time
    src = os.path.join(root, "legacy", "v1.0.0_inputs")
    script = os.path.join(root, "src", "regenerate_tables.py")
    if not (os.path.isdir(src) and os.path.exists(script)):
        return {"status": "NOT_TESTED",
                "detail": "legacy/v1.0.0_inputs or src/regenerate_tables.py absent; "
                          "regeneration was not executed"}
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="laozikg_rebuild_") as tmp:
        res = subprocess.run([sys.executable, script, "--src", src, "--out", tmp],
                             capture_output=True, text=True)
        if res.returncode != 0:
            return {"status": "FAIL", "detail": "regeneration subprocess exited "
                    f"{res.returncode}: {(res.stderr or '')[-400:]}"}
        problems, compared = [], 0
        for fname, key in REBUILD_KEYS.items():
            a_p, b_p = os.path.join(data_dir, fname), os.path.join(tmp, fname)
            if not os.path.exists(a_p):
                continue  # not a shipped table
            if not os.path.exists(b_p):
                problems.append(f"{fname}: not produced"); continue
            A, B = _read_any(a_p), _read_any(b_p)
            compared += 1
            if len(A) != len(B):
                problems.append(f"{fname}: rows {len(A)} vs {len(B)}"); continue
            if set(A.columns) != set(B.columns):
                problems.append(f"{fname}: columns differ "
                                f"{sorted(set(A.columns) ^ set(B.columns))}"); continue
            cols = list(A.columns)
            a, b = A[cols].astype(str), B[cols].astype(str)
            if key:
                ka = set(map(tuple, a[key].values)); kb = set(map(tuple, b[key].values))
                if ka != kb:
                    problems.append(f"{fname}: key sets differ ({len(ka ^ kb)} keys)"); continue
                a = a.sort_values(key).reset_index(drop=True)
                b = b.sort_values(key).reset_index(drop=True)
            else:
                a = a.sort_values(cols).reset_index(drop=True)
                b = b.sort_values(cols).reset_index(drop=True)
            if not a.equals(b):
                nd = int((a != b).any(axis=1).sum())
                bad_cols = [c for c in cols if (a[c] != b[c]).any()]
                problems.append(f"{fname}: {nd} rows differ in {bad_cols[:4]}")
    elapsed = round(time.time() - t0, 1)
    if compared == 0:
        return {"status": "FAIL", "detail": "no tables compared (anti-vacuity guard)"}
    if problems:
        return {"status": "FAIL", "detail": f"{compared} tables compared in {elapsed}s; "
                f"{len(problems)} disagree: " + "; ".join(problems[:6])}
    return {"status": "PASS", "detail": f"regeneration executed from legacy/v1.0.0_inputs "
            f"in {elapsed}s; all {compared} REGENERATED canonical tables identical in rows, "
            f"keys, columns and content. Not content-compared: files copied through "
            f"unchanged (wangbi_exegesis_source.parquet, candidate_concepts_oov.csv) and "
            f"derived reports (alignment_recovery_segments_S06453.csv). LLM-assigned labels "
            f"are joined from src/shipped_labels/ and are not themselves regenerated"}

def _validation_status(root):
    """NOT_PERFORMED / PARTIALLY_VALIDATED / VALIDATED, from the metrics file
    the scorer writes on every run. Absent file == nothing has been scored."""
    p = os.path.join(root, "expert_validation", "validation_metrics.json")
    if not os.path.exists(p):
        return "NOT_PERFORMED"
    return json.load(open(p, encoding="utf-8")).get("status", "NOT_PERFORMED")



def _vm(root):
    """Live validation metrics. The scorer owns these numbers; this report must
    not carry its own copy of them (rc7 did, and the two disagreed)."""
    p = os.path.join(root, "expert_validation", "validation_metrics.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}


def _n_align_diag(root):
    p = os.path.join(root, "data", "alignment_failure_diagnosis.csv")
    try:
        return len(pd.read_csv(p, encoding="utf-8-sig"))
    except Exception:
        return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--no-rebuild", action="store_true",
                    help="skip the executed clean-room regeneration (status NOT_TESTED)")
    ap.add_argument("--out", default=os.path.join("qa", "validation_report.json"))
    args = ap.parse_args()
    d = args.data

    versions = load(d, "versions.csv")
    persons = load(d, "persons.csv")
    authorship = load(d, "authorship_edges.csv")
    concepts = load(d, "concepts.csv")
    loci = load(d, "concept_canonical_chapters.csv")
    relations = load(d, "concept_relations.csv")
    chapters = load(d, "chapter_instances.parquet")
    sentences = load(d, "sentences.parquet")
    variants = load(d, "variants.parquet")
    commentary = load(d, "commentary.csv")
    comm_links = load(d, "commentary_concept_links.csv")
    evidence = load(d, "evidence.parquet")
    mentions = load(d, "concept_chapter_mentions.csv")
    claims = load(d, os.path.join("..", "derived_unverified",
                                  "candidate_scholarly_claims.csv"))

    # ---- primary keys ----
    pk_unique(versions, "version_id", "versions")
    pk_unique(persons, "person_id", "persons")
    pk_unique(concepts, "concept_id", "concepts")
    pk_unique(chapters, "instance_id", "chapter_instances")
    pk_unique(sentences, "sentence_id", "sentences")
    pk_unique(variants, "variant_id", "variants")
    pk_unique(commentary, "commentary_id", "commentary")
    pk_unique(evidence, "evidence_id", "evidence")
    pk_unique(claims, "sc_id", "candidate_scholarly_claims")

    vids = set(versions["version_id"].astype(str))
    pids = set(persons["person_id"].astype(str))
    cids = set(concepts["concept_id"].astype(str))
    iids = set(chapters["instance_id"].astype(str))
    mids = set(commentary["commentary_id"].astype(str))

    # ---- referential integrity ----
    fk_valid(chapters, "version_id", vids, "chapter_instances -> versions")
    fk_valid(sentences, "instance_id", iids, "sentences -> chapter_instances")
    fk_valid(sentences, "version_id", vids, "sentences -> versions")
    fk_valid(authorship, "version_id", vids, "authorship -> versions")
    fk_valid(authorship, "person_id", pids, "authorship -> persons")
    fk_valid(commentary, "version_id", vids, "commentary -> versions")
    fk_valid(commentary, "concept_id", cids, "commentary -> concepts")
    fk_valid(comm_links, "commentary_id", mids, "commentary_links -> commentary")
    fk_valid(comm_links, "concept_id", cids, "commentary_links -> concepts")
    fk_valid(mentions, "concept_id", cids, "mentions -> concepts")
    fk_valid(mentions, "instance_id", iids, "mentions -> chapter_instances")
    fk_valid(loci, "concept_id", cids, "concept_loci -> concepts")
    fk_valid(evidence, "source_ref", mids, "evidence -> commentary")
    if relations is not None:
        fk_valid(relations, "concept_id_a", cids, "concept_relations -> concepts (a)")
        fk_valid(relations, "concept_id_b", cids, "concept_relations -> concepts (b)")

    # ---- enum conformance ----
    enum_ok(versions, "alignment_status",
            {"aligned_full", "aligned_partial", "unaligned"}, "versions")
    enum_ok(versions, "unresolved_reason",
            {"not_applicable", "expected_no_ddj_chapter_structure",
             "possible_alignment_failure_review_needed",
             # refined by data/alignment_failure_diagnosis.csv in v1.1.1
             "confirmed_alignment_failure_recovery_pending",
             "commentary_only_no_base_text_to_align",
             "catalogue_mismatch_expert_review_required",
             # v1.1.2 recovery outcomes
             "recovered_v1.1.2", "recovered_v1.1.2_residual_unanchored_text"}, "versions")
    enum_ok(versions, "work_type",
            {"canonical_ddj", "ddj_commentary", "fragment", "related_laozi_text",
             "ritual_text", "apocryphal_text", "biography_text",
             "manuscript_composite", "unclassified"}, "versions")
    enum_ok(commentary, "text_provenance",
            {"verbatim_contiguous", "spliced_from_source", "not_located"},
            "commentary")
    enum_ok(evidence, "quote_kind",
            {"attested_source_quote", "llm_spliced_excerpt",
             "llm_paraphrase_unlocated", "unknown"}, "evidence")
    enum_ok(mentions, "match_specificity", {"high", "medium", "low"}, "mentions")
    enum_ok(concepts, "node_type",
            {"OntologicalConcept", "CosmologicalConcept", "EthicalConcept",
             "PoliticalConcept", "CultivationConcept", "EpistemicConcept",
             "Proposition", "Phrase", "Metaphor", "Practice",
             "unclassified"}, "concepts")

    # ---- cross-table consistency ----
    recomputed = (chapters[chapters["chapter_num"] != -1]
                  .groupby("version_id").size())
    declared = versions.set_index("version_id")["alignment_success_count"]
    joined = declared.to_dict()
    bad = [v for v, n in recomputed.items() if joined.get(v, 0) != n]
    check("versions.alignment_success_count matches chapter_instances",
          len(bad) == 0, f"{len(bad)} mismatched version(s)")

    unresolved_declared = int(versions["unresolved_unit_count"].sum())
    unresolved_actual = int((chapters["chapter_num"] == -1).sum())
    check("versions.unresolved_unit_count matches chapter_instances",
          unresolved_declared == unresolved_actual,
          f"declared {unresolved_declared} vs actual {unresolved_actual}")

    check("no version lacks an authorship edge",
          len(vids - set(authorship["version_id"].astype(str))) == 0,
          f"{len(vids - set(authorship['version_id'].astype(str)))} version(s) unlinked")

    # commentary->concept links must be self-consistent (the v1.0.0 defect)
    merged = comm_links.merge(commentary[["commentary_id", "concept_id"]],
                              on=["commentary_id", "concept_id"], how="left",
                              indicator=True)
    inconsistent = int((merged["_merge"] != "both").sum())
    check("commentary_concept_links agree with commentary.concept_id",
          inconsistent == 0, f"{inconsistent} link(s) not self-consistent")

    # ---- AI-content labelling must be present and honest ----
    check("all candidate claims marked unverified",
          bool((claims["claim_status"] == "AI_GENERATED_UNVERIFIED").all()),
          "some claim lacks AI_GENERATED_UNVERIFIED")
    check("no candidate claim marked citable",
          not bool(claims["citable_as_scholarship"].any()),
          "a claim is marked citable_as_scholarship")
    check("citable_as_quote implies verbatim provenance",
          bool((commentary.loc[commentary["citable_as_quote"] == True,
                               "text_provenance"] == "verbatim_contiguous").all()),
          "a citable quote is not verbatim_contiguous")

    # ---- concept coverage ----
    covered = mentions["concept_id"].nunique()
    unattested = int((~concepts["is_textually_attested"].astype(bool)).sum()) \
        if "is_textually_attested" in concepts.columns else 0
    check("every textually-attested concept has >=1 mention",
          covered + unattested >= len(concepts),
          f"{covered} concepts with mentions + {unattested} flagged unattested "
          f"vs {len(concepts)} total")

    # ---- release metadata self-consistency -------------------------------
    # Every publication-facing doc must state the SAME version and release
    # date. A divergence here is how a package ends up shipping two different
    # release dates for one version, which is not catchable by eye.
    root = os.path.dirname(os.path.abspath(args.data))
    version_re = re.compile(
        r'(?:^version:\s*|^\*\*Version:\*\*\s*|—\s*LaoziKG\s*v|##\s*v)([0-9]+\.[0-9]+\.[0-9]+)',
        re.M)
    # A release CANDIDATE has no publication date: CITATION.cff omits
    # date-released and the dataset card says "not published". So the date these
    # documents must agree on is the BUILD date, which is declared in the
    # BUILD_DATE file and rendered as `build_date`. Matching on
    # "**Publication date:**" as well would have swept up the literal phrase
    # "not published" once that line stopped carrying a date.
    date_re = re.compile(
        r'(?:^date-released:\s*"?|^\*\*Build date:\*\*\s*|^##\s*v[0-9.]+\s*—\s*)'
        r'([0-9]{4}-[0-9]{2}-[0-9]{2})', re.M)

    meta_files = ["CITATION.cff", "CHANGELOG.md",
                  os.path.join("docs", "DATASET_CARD.md"),
                  os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                  os.path.join("docs", "ZENODO_UPLOAD_METADATA.md")]
    versions_found, dates_found = {}, {}
    scanned = []
    for rel in meta_files:
        path = os.path.join(root, rel)
        if not os.path.exists(path):
            continue
        scanned.append(rel)
        text = open(path, encoding="utf-8").read()
        if rel == "CHANGELOG.md":
            # a changelog legitimately lists past versions; only its TOP entry
            # declares the current release
            m = re.search(r"^## v?(\d+\.\d+\.\d+)", text, re.M)
            found = {m.group(1)} if m else set()
        else:
            found = set(version_re.findall(text))
        for v in found:
            versions_found.setdefault(v, []).append(rel)
        for dt in set(date_re.findall(text)):
            dates_found.setdefault(dt, []).append(rel)

    # Guard against a vacuous pass: if the metadata files were not located, the
    # two checks below would report success having read nothing.
    check("release metadata files located for consistency check",
          len(scanned) == len([f for f in meta_files
                               if os.path.exists(os.path.join(root, f))])
          and len(scanned) >= 4,
          f"scanned {len(scanned)} of {len(meta_files)} metadata files")
    check("release metadata yielded a version and a date to compare",
          bool(versions_found) and bool(dates_found),
          f"versions={list(versions_found)}, dates={list(dates_found)}")

    # The title is long enough to wrap: CITATION.md breaks it across two lines,
    # and a line-bounded pattern reads the first half as a second, shorter
    # title. Whitespace is collapsed per document before matching — the same
    # wrapping trap that has now caught three guards in this suite.
    TITLE_RE = re.compile(r"LaoziKG: A [^\"*`|]{10,130}")
    titles, title_docs = {}, 0
    for rel in ["CITATION.cff", "CITATION.md", "README.md",
                os.path.join("docs", "DATASET_CARD.md"),
                os.path.join("docs", "ZENODO_UPLOAD_METADATA.md")]:
        path = os.path.join(root, rel)
        if not os.path.exists(path):
            continue
        title_docs += 1
        # Drop markdown blockquote markers first: CITATION.md puts the title in
        # a quoted citation block, so a bare whitespace collapse folds the "> "
        # of the continuation line into the middle of the title.
        raw = open(path, encoding="utf-8").read()
        flat = re.sub(r"\s+", " ", re.sub(r"(?m)^\s*>\s?", "", raw))
        for t in set(TITLE_RE.findall(flat)):
            # cut at the first sentence end so trailing prose is not part of it
            t = re.split(r"(?<=\))[\s.,;].*$|\. ", t)[0]
            titles.setdefault(t.strip().rstrip("."), []).append(rel)
    check("publication documents name a single dataset title",
          title_docs >= 4 and len(titles) == 1,
          f"docs_scanned={title_docs}; "
          + ("; ".join(f"{t[:60]}... in {v}" for t, v in titles.items())
             if len(titles) != 1 else f"one title across {title_docs} documents"))

    check("release metadata declares a single version",
          len(versions_found) <= 1,
          f"conflicting versions: { {k: v for k, v in versions_found.items()} }")
    # A candidate must not carry a publication date anywhere. rc9 shipped
    # date-released: 2026-09-13 in CITATION.cff while the dataset card said
    # "not published" — two shipped files disagreeing about whether the dataset
    # exists as a publication.
    _cff = os.path.join(root, "CITATION.cff")
    _cff_txt = open(_cff, encoding="utf-8").read() if os.path.exists(_cff) else ""
    _status_np = "not published" in open(
        os.path.join(root, "docs", "DATASET_CARD.md"), encoding="utf-8").read() \
        if os.path.exists(os.path.join(root, "docs", "DATASET_CARD.md")) else False
    _has_dr = bool(re.search(r'^date-released:', _cff_txt, re.M))
    check("an unpublished release declares no publication date",
          bool(_cff_txt) and not (_status_np and _has_dr),
          "CITATION.cff carries date-released while the dataset card says "
          "'not published'" if (_status_np and _has_dr) else
          f"card says not published={_status_np}; CITATION.cff has "
          f"date-released={_has_dr}")

    check("release metadata declares a single release date",
          len(dates_found) <= 1,
          f"conflicting dates: { {k: v for k, v in dates_found.items()} }")

    # ---- three-state alignment review status and default-include gating ------
    ok_enum = set(chapters["alignment_review_status"].unique()) <= {
        "original_deterministic", "auto_recovered_unreviewed", "expert_confirmed",
        "expert_corrected", "not_aligned"}
    check("alignment_review_status uses the five-value enum", ok_enum,
          str(chapters["alignment_review_status"].value_counts().to_dict()))
    unrev = chapters["alignment_review_status"] == "auto_recovered_unreviewed"
    check("unreviewed automatic recoveries are excluded from analysis_default_include",
          not bool(chapters.loc[unrev, "analysis_default_include"].any()),
          f"{int(chapters.loc[unrev, 'analysis_default_include'].sum())} recovered instances default-included")
    check("analysis_default_include == aligned AND not unreviewed-recovered",
          bool((chapters["analysis_default_include"] ==
                (chapters["is_chapter_aligned"] & ~unrev)).all()))
    rec_ids = set(chapters.loc[unrev, "instance_id"])
    check("default mention file contains no unreviewed-recovered instances",
          not mentions["instance_id"].isin(rec_ids).any(),
          f"{int(mentions['instance_id'].isin(rec_ids).sum())} rows")
    recm_p = os.path.join(d, "concept_recovered_mentions.csv")
    if os.path.exists(recm_p):
        recm = pd.read_csv(recm_p, encoding="utf-8-sig")
        check("recovered mention file contains only unreviewed-recovered instances",
              bool(recm["instance_id"].isin(rec_ids).all()), f"{len(recm)} rows")

    # ---- aligned instances should have sentence rows (warning) ---------------
    no_sent = set(chapters.loc[chapters["chapter_num"] != -1, "instance_id"]) - set(sentences["instance_id"])
    check("every aligned chapter instance has >= 1 sentence row", not no_sent,
          f"{len(no_sent)} aligned instance(s) without sentences: {sorted(no_sent)[:3]}")

    # ---- every LLM-derived table carries an explicit review flag -------------
    for tbl, col in (("commentary", "gloss_reviewed"), ("versions", "work_type_reviewed"),
                     ("versions", "textual_scope_reviewed"), ("versions", "witness_era_reviewed"),
                     ("concepts", "node_type_reviewed"), ("concepts", "concept_reviewed"),
                     ("concepts", "definition_reviewed"), ("persons", "era_reviewed")):
        df_ = {"commentary": commentary, "versions": versions, "concepts": concepts,
               "persons": persons}[tbl]
        check(f"{tbl}.{col} present and uniformly FALSE (nothing expert-reviewed yet)",
              col in df_.columns and not bool(df_[col].astype(str).str.lower().eq("true").any()),
              f"{col} missing or some rows claim review")

    # ---- person names are real names ------------------------------------------
    dbl = [n for n in persons["canonical_name"].astype(str)
           if len(n) >= 4 and n[: len(n) // 2] == n[len(n) // 2:]]
    check("no canonical_name is a doubled parse artefact", not dbl, f"doubled: {dbl}")
    named = persons[persons["entity_status"] == "canonical"]
    check("every canonical person has a historical era",
          bool(named["person_historical_era"].fillna("").astype(str).str.len().gt(0).all()),
          f"missing: {named[named['person_historical_era'].isna()]['canonical_name'].tolist()[:5]}")

    # ---- unaligned units are structurally excluded at BOTH granularities ----
    # v1.1.1 split the chapter-level aggregate but left chapter_num == -1 rows in
    # the sentence-level file, so "structurally excluded" held only for the
    # aggregate. Both granularities are now asserted.
    sm = load(d, "concept_sentence_mentions.parquet")
    su = load(d, "concept_sentence_unaligned_mentions.parquet")
    check("sentence-level mentions contain no unaligned units",
          sm is not None and int((sm["chapter_num"] == -1).sum()) == 0,
          f"rows with chapter_num=-1: {int((sm['chapter_num'] == -1).sum()) if sm is not None else 'file missing'}")
    check("sentence-level unaligned mentions are shipped separately",
          su is not None and len(su) > 0 and bool((su["chapter_num"] == -1).all()),
          "concept_sentence_unaligned_mentions.parquet missing, empty, or contains aligned rows")
    check("chapter-level aggregate agrees with sentence-level evidence",
          sm is not None and int(sm["mention_count"].sum()) == int(mentions["mention_count"].sum()),
          f"sentence sum {int(sm['mention_count'].sum()) if sm is not None else '?'} vs chapter sum {int(mentions['mention_count'].sum())}")

    # ---- load-bearing documented figures must match the data ---------------
    # Four rounds of audit caught the same failure mode: a figure written into a
    # document from an intermediate computation, then never updated when the
    # data changed underneath it (a mean labelled median; an overstated coverage
    # range; a dispersion range generalized from printed rows; mention-tier
    # counts left at pre-exclusion values; a `not_ddj` label that never existed).
    # Fixing those by eye kept producing the next one, so the load-bearing
    # figures are now asserted against the tables mechanically.
    st = load(d, "concept_mention_statistics.csv")
    tier = {t: int(st[f"mentions_specificity_{t}"].sum())
            for t in ("high", "medium", "low")} if st is not None else {}
    raw_total = int(st["raw_lexical_mentions"].sum()) if st is not None else 0
    ddj_labels = {"canonical_ddj", "ddj_commentary"}
    non_ddj = int((~versions["work_type"].isin(ddj_labels)).sum())

    FIGURES = [
        ("docs/provenance.md", f"{tier.get('high', 0):,}", "high-specificity mentions"),
        ("docs/provenance.md", f"{tier.get('medium', 0):,}", "medium-specificity mentions"),
        ("docs/provenance.md", f"{tier.get('low', 0):,}", "low-specificity mentions"),
        ("docs/provenance.md", f"{raw_total:,}", "raw mention total"),
        ("docs/provenance.md", f"{len(mentions):,}", "aligned mention rows"),
        ("docs/provenance.md", f"{non_ddj}", "non-DDJ-genre resource count"),
        ("docs/provenance.md", f"{int(versions['is_source_witness'].sum())}",
         "historical source witnesses"),
        ("docs/provenance.md", f"{commentary['concept_id'].nunique()} of {len(concepts)}",
         "commentary concept coverage"),
        # schema.md carries its own per-tier EDGE table (rows, not mention sums);
        # it was left at pre-exclusion values while provenance.md was corrected.
        ("docs/schema.md", f"{len(mentions):,}", "MENTIONS_CONCEPT edge total"),
        # v1.1.2: figures that changed with alignment recovery / the split
        ("README.md", f"{len(chapters):,}", "chapter instance total"),
        ("README.md", f"{len(sentences):,}", "sentence total"),
        ("README.md", f"{int(mentions['mention_count'].sum()):,}", "aligned occurrence total"),
        ("CITATION.cff", f"{len(chapters):,}", "chapter instance total in citation"),
        ("CITATION.cff", f"{len(sentences):,}", "sentence total in citation"),
        ("CITATION.cff", f"{len(persons)}", "person total in citation"),
        ("docs/schema.md", f"{len(persons)}", "Person node count"),
        ("docs/provenance.md", f"{int(sm['mention_count'].sum()):,}" if sm is not None else "-", "sentence-level occurrence sum (aligned)"),
    ]
    missing_figures = []
    docs_read = 0
    for rel, literal, label in FIGURES:
        path = os.path.join(os.path.dirname(d), rel)
        if not os.path.exists(path):
            missing_figures.append(f"{rel} absent")
            continue
        body = open(path, encoding="utf-8").read()
        docs_read += 1
        if literal not in body:
            missing_figures.append(f"{label}: '{literal}' not found in {rel}")
    # anti-vacuity: a guard that read nothing must not pass
    check("documented figures match the data",
          docs_read > 0 and not missing_figures,
          f"docs_read={docs_read}; " + ("; ".join(missing_figures[:6])
                                        if missing_figures else "no document read"))

    # ---- every large number in a rendered document must be a CURRENT fact -----
    # The guard above asks "does the right value appear somewhere?"; this one asks
    # the converse: "is any value present that is NOT a current fact?" — the
    # failure mode of three consecutive release candidates (60,096 surviving in
    # the dataset card after the true value became 59,648).
    facts_p = os.path.join(root, "metadata", "release_facts.json")
    stale_numbers, docs_scanned_n = [], 0
    if os.path.exists(facts_p):
        facts = json.load(open(facts_p, encoding="utf-8"))
        current = set()
        def walk(x):
            if isinstance(x, bool):
                return
            if isinstance(x, int):
                current.add(x)
            elif isinstance(x, dict):
                for v_ in x.values():
                    walk(v_)
        walk(facts)
        # also derived sums that documents legitimately quote
        current |= {facts["mention_edges_default"] + facts["mention_edges_recovered"],
                    facts["mention_occurrences_default"] + facts["mention_occurrences_unaligned"],
                    facts["mention_occurrences_default"] + facts["mention_occurrences_recovered"]
                    + facts["mention_occurrences_unaligned"]}
        HIST = re.compile(r"v1\.0\.0|v1\.1\.0|v1\.1\.1|\bwas\b|\bwere\b|previously|formerly|earlier|"
                          r"before|\u2192|->|old|stale|inflated|corrected from|not \d|instead of", re.I)
        NUM = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+|\d{3,})(?![\w.%])")
        for rel in ["README.md", "CITATION.cff", "LICENSE_DATA.md",
                    os.path.join("docs", "DATASET_CARD.md"), os.path.join("docs", "ZENODO_UPLOAD_METADATA.md"),
                    os.path.join("docs", "schema.md"), os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                    os.path.join("docs", "REPRODUCIBILITY.md")]:
            pth = os.path.join(root, rel)
            if not os.path.exists(pth):
                continue
            docs_scanned_n += 1
            lines_ = open(pth, encoding="utf-8").read().split("\n")
            for i, line in enumerate(lines_):
                # a historical marker on this line OR the previous one exempts the
                # line (sentences wrap; the marker is often one line up)
                ctx = (lines_[i - 1] if i else "") + " " + line
                if HIST.search(ctx) or line.strip().startswith(("|---", "#")):
                    continue
                for tok in NUM.findall(line):
                    n = int(tok.replace(",", ""))
                    if "," not in tok and (600 <= n <= 2100 or n >= 100000 or tok.startswith("0")):
                        continue  # years; phone/email/postcode digit strings (facts render with commas)
                    if n in current:
                        continue
                    stale_numbers.append(f"{rel}:{i + 1}: {tok}")
    check("no number in a rendered document is a non-current fact",
          docs_scanned_n > 0 and not stale_numbers,
          f"docs_scanned={docs_scanned_n}; " + ("; ".join(stale_numbers[:8]) if stale_numbers else "release_facts.json missing"))

    # ---- the aligned-instance total may not stand alone ----------------------
    # "N aligned chapter instances" folds unreviewed automatic recoveries into an
    # analysis-ready-sounding number. Wherever the aligned total appears, the
    # default-set and recovered-unreviewed counts must appear in the same paragraph.
    bare_aligned, docs_al = [], 0
    if os.path.exists(facts_p):
        _f = json.load(open(facts_p, encoding="utf-8"))
        tot = f"{_f['aligned_instances']:,}"
        need = (f"{_f['default_include_instances']:,}", str(_f["recovered_unreviewed_instances"]))
        for rel in ["README.md", "CITATION.cff", os.path.join("docs", "DATASET_CARD.md"),
                    os.path.join("docs", "ZENODO_UPLOAD_METADATA.md"),
                    os.path.join("docs", "DATA_QUALITY_REPORT.md"), os.path.join("docs", "provenance.md")]:
            pth = os.path.join(root, rel)
            if not os.path.exists(pth):
                continue
            docs_al += 1
            for pi, para in enumerate(open(pth, encoding="utf-8").read().split("\n\n")):
                if tot in para and not all(n in para for n in need):
                    bare_aligned.append(f"{rel} para {pi + 1}: aligned total {tot} without the "
                                        f"default/recovered split")
    check("the aligned-instance total never appears without the default/recovered split",
          docs_al > 0 and not bare_aligned,
          f"docs_scanned={docs_al}; " + ("; ".join(bare_aligned[:4]) if bare_aligned else "no document scanned"))

    # ---- forbidden stale vocabulary ---------------------------------------
    # Labels that were documented but never existed in the data.
    NEVER_EXISTED = ["not_ddj", "match_reliability", "is_verified_contiguous_quote",
                     "base_text_share_est", "ver.era", "Version.era", "Person.era",
                     "python_requires", "36 resources",
                     "ChapterInstance.confidence", "chapter_instances.confidence",
                     "alignment confidence", "source_provider",
                     # variant-layer overclaims: nothing in this layer is confirmed
                     "validated variants", "confirmed variants", "verified variants",
                     "minimum_publishable_set", "minimum publishable set", "mps_",
                     "fully reproducible", "wholly reproducible",
                     "expert-curated knowledge graph", "validated knowledge graph",
                     "curated knowledge graph", "verified knowledge graph",
                     "SAME_WORK_EDITION", "ScholaryClaimEvidence"]
    doc_files = [os.path.join(os.path.dirname(d), p) for p in
                 ("README.md", "CHANGELOG.md", "docs/provenance.md",
                  "docs/schema.md", "docs/DATASET_CARD.md")]
    offenders, scanned_docs = [], 0
    for path in doc_files:
        if not os.path.exists(path):
            continue
        scanned_docs += 1
        body = open(path, encoding="utf-8").read()
        for tok in NEVER_EXISTED:
            lines = body.splitlines()
            for i, line in enumerate(lines):
                if tok not in line:
                    continue
                # A mention is fine when marked as historical/renamed. The marker
                # may sit on the previous line (wrapped prose), so judge a window.
                window = " ".join(lines[max(0, i - 1):i + 2])
                if not re.search(
                        r'no |never |removed|renamed|earlier draft|v1\.0\.0|v1\.1\.0|'
                        r'deprecated|does not exist|wrong|\bwas\b|\bwere\b|inherited|\u2192|->|vocabulary guard|added to the guard|forbidden', window, re.I):
                    offenders.append(f"{os.path.basename(path)}:{i + 1}: {tok}")
                    break
    check("no stale schema vocabulary presented as current",
          scanned_docs > 0 and not offenders,
          f"scanned={scanned_docs}; " + ("; ".join(sorted(set(offenders))[:6])
                                         if offenders else "no document scanned"))

    rebuild_result = ({"status": "NOT_TESTED", "detail": "skipped via --no-rebuild"}
                      if args.no_rebuild else
                      run_rebuild_smoke_test(d, os.path.dirname(os.path.abspath(d))))
    check("clean-room regeneration reproduces the shipped tables",
          rebuild_result["status"] == "PASS", rebuild_result["detail"])

    # ---- documented S06453 chapter-order blocks must match the recovery report --
    rep_p = os.path.join(d, "alignment_recovery_report.csv")
    if os.path.exists(rep_p):
        rep = pd.read_csv(rep_p, encoding="utf-8-sig")
        row = rep[rep["version_id"] == "S06453"]
        if len(row):
            seq = [int(x) for x in str(row["chapters_recovered_in_manuscript_order"].iloc[0]).split(";")]
            blocks, s0, prev = [], seq[0], seq[0]
            for c in seq[1:]:
                if c != prev + 1:
                    blocks.append((s0, prev)); s0 = c
                prev = c
            blocks.append((s0, prev))
            want = ", ".join(f"{a}\u2013{b}" for a, b in blocks)
            bad = []
            for rel in ["CHANGELOG.md", os.path.join("docs", "provenance.md"),
                        os.path.join("docs", "ZENODO_UPLOAD_METADATA.md")]:
                pth = os.path.join(root, rel)
                if os.path.exists(pth):
                    txt = open(pth, encoding="utf-8").read()
                    if re.search(r"\b8\u2013\d+, 57\u2013", txt) and want not in txt:
                        bad.append(rel)
            check("documented S06453 chapter-order blocks match the recovery report", not bad,
                  f"expected '{want}'; stale in: {bad}")

    # ---- no shipped file's own header names a different release version ------
    # The declaration guard above only reads formal version fields; rc3 shipped
    # requirements.txt headed "LaoziKG v1.1.1-rc" and a provenance doc headed
    # "v1.1.0" because neither matches a version-field pattern.
    hdr_bad, hdr_scanned = [], 0
    hdr_re = re.compile(r"LaoziKG\s+v(1\.\d+\.\d+(?:-rc\d*)?)")
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [x for x in dirnames
                       if x not in ("__pycache__", ".git", "legacy", "output", "dist")]
        for fn in filenames:
            if not fn.endswith((".md", ".txt", ".cff", ".py")):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), root)
            if rel in ("CHANGELOG.md",) or rel.startswith("docs/templates"):
                continue          # a changelog and the templates legitimately name old versions
            head = "".join(open(os.path.join(dirpath, fn), encoding="utf-8", errors="replace").readlines()[:3])
            hdr_scanned += 1
            for v in hdr_re.findall(head):
                if v != RELEASE_VERSION:
                    hdr_bad.append(f"{rel}: header says v{v}")
    check("no shipped file header names a release version other than the current one",
          hdr_scanned > 0 and not hdr_bad,
          f"files_scanned={hdr_scanned}; " + ("; ".join(sorted(set(hdr_bad))[:6]) if hdr_bad else "no file scanned"))

    # ---- documented validation status must match the adjudication counts ----
    vm_p = os.path.join(root, "expert_validation", "validation_metrics.json")
    if os.path.exists(vm_p):
        vm = json.load(open(vm_p, encoding="utf-8"))
        derived = vm["status"]
        stale = []
        others = {"NOT_PERFORMED", "PARTIALLY_VALIDATED", "VALIDATED"} - {derived}
        for rel in ["README.md", "CITATION.md", os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                    os.path.join("docs", "DATASET_CARD.md"), os.path.join("docs", "provenance.md")]:
            pth = os.path.join(root, rel)
            if not os.path.exists(pth):
                continue
            txt = open(pth, encoding="utf-8").read()
            # Judge a line at a time and skip lines that describe a TRANSITION to
            # a status ("completing it moves the dataset to X", "X is what Y
            # requires") rather than asserting the dataset currently holds it.
            transition = re.compile(
                r"moves the dataset to|what .* requires|becomes|would become|"
                r"once (?:the|it|this)|upon completion|threshold|"
                r"is what `?VALIDATED|target status", re.I)
            for i, line in enumerate(txt.split("\n")):
                for other in others:
                    if other in line or other.replace("_", " ") in line:
                        if transition.search(line):
                            continue
                        stale.append(f"{rel}:{i + 1}: says {other}, data says {derived}")
        check("documented expert-validation status matches the adjudication counts",
              not stale,
              f"derived={derived} ({vm['items_adjudicated']}/{vm['items_total']}); "
              + ("; ".join(sorted(set(stale))[:4]) if stale else "consistent"))

    # ---- documents must not assert a full row count as retained by the profile ----
    # The profile is now generated AFTER this suite runs (so that each
    # distribution gets its own QA), so this compares against the counts DERIVED
    # from the tables in release_facts.json rather than the profile's own report.
    # The report cross-check lives in qa/validate_public_profile.py.
    fx_p0 = os.path.join(root, "metadata", "release_facts.json")
    rp_bad, rp_scanned = [], 0
    if os.path.exists(fx_p0):
        fx0 = json.load(open(fx_p0, encoding="utf-8"))
        retained = fx0.get("public_profile_mention_edges")
        full_ct = fx0.get("mention_edges_default")
        if retained is not None and full_ct is not None and retained != full_ct:
            full_s = f"{full_ct:,}"
            for rel in [os.path.join("metadata", "source_license_resolution.md"),
                        os.path.join("docs", "rights_review_summary.md"),
                        os.path.join("docs", "DATA_AVAILABILITY.md"),
                        "CITATION.md"]:
                pth = os.path.join(root, rel)
                if not os.path.exists(pth):
                    continue
                rp_scanned += 1
                txt = open(pth, encoding="utf-8").read()
                for m in re.finditer(r"(?:all|keeping|keeps|retains)\s+" + re.escape(full_s), txt):
                    rp_bad.append(f"{rel}: asserts the full mention-edge count {full_s} "
                                  f"as retained (profile keeps {retained:,})")
    check("no document asserts a full row count as retained by the public profile",
          rp_scanned > 0 and not rp_bad,
          f"docs_scanned={rp_scanned}; " + ("; ".join(sorted(set(rp_bad))[:4]) if rp_bad
                                            else "no document scanned"))

    # ---- the named Zenodo upload object must be the publishable one ----
    # The availability statement says the public structural release is what may
    # be deposited; rc6's upload instructions named the full archive. A reader
    # following them would have published unreviewed third-party transcriptions.
    zp = os.path.join(root, "docs", "ZENODO_UPLOAD_METADATA.md")
    if os.path.exists(zp):
        ztxt = open(zp, encoding="utf-8").read()
        sec = ztxt[ztxt.find("## Recommended files to upload"):] if \
            "## Recommended files to upload" in ztxt else ""
        names_public = "public-structural" in sec
        names_full_as_object = bool(re.search(
            r"^\s*\d+\.\s+`[^`]*full-internal", sec, re.M)) or bool(re.search(
            r"^\s*\d+\.\s+`LaoziKG-v[^`]*_Zenodo\.zip`", sec, re.M))
        check("the named Zenodo upload object is the public structural release",
              bool(sec) and names_public and not names_full_as_object,
              f"names public profile={names_public}; names full package as an "
              f"upload item={names_full_as_object}")

    # ---- publication-facing documents must be rendered, not hand-maintained ----
    # CITATION.md shipped once with a stale version and a stale adjudication
    # total because it was written by hand from the facts of the moment. Any
    # document that quotes release figures has to come from a template.
    tdir = os.path.join(root, "docs", "templates")
    rendered = set()
    if os.path.isdir(tdir):
        for t in os.listdir(tdir):
            if t.endswith(".tmpl"):
                rendered.add(t[:-len(".tmpl")])
    PUBLICATION_DOCS = ["README.md", "CITATION.md", "CITATION.cff", "LICENSE_DATA.md",
                        os.path.join("docs", "DATASET_CARD.md"),
                        os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                        os.path.join("docs", "ZENODO_UPLOAD_METADATA.md"),
                        os.path.join("docs", "schema.md"),
                        os.path.join("docs", "DATA_AVAILABILITY.md"),
                        os.path.join("docs", "rights_review_summary.md"),
                        os.path.join("expert_validation", "README.md"),
                        os.path.join("expert_validation", "SAMPLING_DESIGN.md")]
    # templates that render somewhere other than their own basename
    rendered |= {"DATA_AVAILABILITY.md", "rights_review_summary.md",
                 "SAMPLING_DESIGN.md"}
    if "expert_validation_README.md" in rendered:
        rendered.add("README.md")
    unrendered = [rel for rel in PUBLICATION_DOCS
                  if os.path.exists(os.path.join(root, rel))
                  and os.path.basename(rel) not in rendered]
    check("every publication-facing document is rendered from a template",
          bool(rendered) and not unrendered,
          f"templates={len(rendered)}; " + ("not rendered: " + ", ".join(unrendered)
                                            if unrendered else "all rendered"))

    # ---- stated breakdowns must sum to the total they break down -----------
    # A reviewer found a changelog sentence reading "Of the 750 rows, 598 were X
    # and 150 were Y" — 748, because the third term was dropped. The text was not
    # wrong about any single figure; it was wrong in presenting two terms as a
    # partition. Catch the shape: "of the N ..., a ... and b ..." where a + b != N.
    part_re = re.compile(
        r"[Oo]f the ([\d,]{2,})\b[^.]{0,160}?\b([\d,]{2,})\b[^.]{0,120}?\band ([\d,]{2,})\b[^.]{0,80}?\.",
        re.S)
    nonsum = []
    scanned_docs = 0
    for rel in ("CHANGELOG.md", "README.md", os.path.join("docs", "provenance.md"),
                os.path.join("docs", "DATASET_CARD.md"),
                os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                os.path.join("metadata", "source_license_resolution.md")):
        pth = os.path.join(root, rel)
        if not os.path.exists(pth):
            continue
        scanned_docs += 1
        txt = open(pth, encoding="utf-8").read()
        for m in part_re.finditer(txt):
            tot, a, b = (int(x.replace(",", "")) for x in m.groups())
            # only flag when the two parts are plainly meant to exhaust the total:
            # they under-sum by a small remainder rather than being unrelated counts
            if a + b != tot and 0 < tot - (a + b) <= max(5, tot * 0.02) and a < tot and b < tot:
                nonsum.append(f"{rel}: {a} + {b} != {tot} ({m.group(0)[:70].strip()}...)")
    check("stated two-part breakdowns sum to their total",
          not nonsum and scanned_docs > 0,
          "; ".join(nonsum[:4]) if nonsum else f"scanned {scanned_docs} documents")

    # ---- the manifest describes the tree, not the previous build ----------
    # final_release_verification.json is written in the LAST release stage,
    # after every manifest, so any copy present while a manifest is being built
    # is necessarily the previous build's. Hashing one makes the manifest depend
    # on build residue: the same tree produced 351 entries from clean and 352 on
    # an uncleaned re-run, because the exclusion was anchored to the top-level
    # metadata/ and the full package walked into the profile nested under dist/.
    # The invariant is cheaper to check than idempotency and catches the same
    # defect: no manifest may contain that filename, in any tree.
    residue = []
    for rel in ("metadata/checksums.sha256",
                "dist/public_structural_release/metadata/checksums.sha256"):
        path = os.path.join(root, rel)
        if not os.path.exists(path):
            continue
        for line in open(path, encoding="utf-8"):
            if line.strip() and line.split("  ", 1)[1].strip().endswith(
                    "final_release_verification.json"):
                residue.append(f"{rel} hashes {line.split('  ', 1)[1].strip()}")
    check("no manifest hashes a previous build's verification record",
          not residue,
          "; ".join(residue) if residue else
          "neither manifest contains final_release_verification.json")

    # ---- documented check count must match the real one -------------------
    # The suite's size is advertised in the release docs. When a check is added,
    # those mentions go stale silently. This is the LAST check registered, so the
    # final total is len(RESULTS) + 1 (itself).
    documented_total = len(RESULTS) + 1
    count_re = re.compile(r'(\d+)[ -]?checks?\b|\b(\d+)/(\d+) checks?\b')
    stale_counts = []
    for rel in ["CHANGELOG.md", os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                os.path.join("docs", "ZENODO_UPLOAD_METADATA.md"),
                "README.md", os.path.join("docs", "provenance.md")]:
        path = os.path.join(root, rel)
        if not os.path.exists(path):
            continue
        text = open(path, encoding="utf-8").read()
        for m in count_re.finditer(text):
            # There are now TWO suites. A count in a sentence about the
            # public-profile suite is that suite's count, not this one's.
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.end())
            line = text[line_start: line_end if line_end != -1 else len(text)]
            window = text[max(0, line_start - 200): line_end if line_end != -1 else len(text)]
            if re.search(r"validate_public_profile|public[- ]profile suite|"
                         r"public_profile_report", window, re.I):
                continue
            nums = [int(g) for g in m.groups() if g]
            for n in nums:
                if n != documented_total:
                    stale_counts.append(f"{rel}: '{m.group(0).strip()}' in: {line.strip()[:60]}")
    check("documented validation-check count matches the suite",
          not stale_counts,
          f"expected {documented_total}; stale mentions: {sorted(set(stale_counts))[:6]}")

    failed = [r for r in RESULTS if not r["passed"] and r["severity"] == "error"]
    warned = [r for r in RESULTS if not r["passed"] and r["severity"] == "warning"]


    # ---- tiered status -------------------------------------------------
    # A single "N/N PASS, 0 warnings" invites reading the whole dataset as
    # validated. These checks are STRUCTURAL only; semantic correctness, expert
    # validation and rights review are separate and are NOT all passing.
    rights = pd.read_csv(os.path.join(d, "source_rights.csv"), encoding="utf-8-sig", keep_default_na=False)
    n_not_rev = int((rights["redistribution_status"] == "not_reviewed").sum())
    n_cleared = int((rights["redistribution_status"] == "cleared").sum())
    _st = chapters["alignment_review_status"].astype(str)
    n_recovered = int((_st == "auto_recovered_unreviewed").sum())
    n_expert = int(_st.isin(["expert_confirmed", "expert_corrected"]).sum())
    tiers = {
        "structural_qa": {
            "status": "PASS" if not failed else "FAIL",
            "detail": f"{len([r for r in RESULTS if r['passed']])}/{len(RESULTS)} "
                      f"automated checks (keys, foreign keys, enums, cross-table counts)",
        },
        "semantic_qa": {
            "status": "PARTIAL",
            "detail": (f"person historical eras corrected and cross-checked against a "
                       f"37-figure reference set (81% agreement, 7 disputed and flagged); "
                       f"witness_era retained as the source's own claim and known to be "
                       f"unreliable per row; the 5 previously confirmed alignment failures "
                       f"were automatically recovered ({n_recovered} instances, "
                       f"alignment_review_status=auto_recovered_unreviewed) and are EXCLUDED "
                       f"from analysis_default_include until an expert confirms them; "
                       f"{n_expert} instance(s) expert-confirmed/corrected so far"),
        },
        "expert_validation": {
            # derived from the adjudication counts in validation_metrics.json,
            # never a literal: the status and the data cannot disagree
            "status": _validation_status(root),
            # Every figure here is READ, not embedded. rc7 hardcoded the protocol
            # total and the relation/diagnosis counts, so this report contradicted
            # the metrics file sitting beside it after the recovered-alignment
            # frame was added.
            "detail": (f"no domain scholar has reviewed any label. {len(versions)} work_type/"
                       f"textual_scope, {len(concepts)} node_type, {len(relations)} "
                       f"concept_relations, "
                       f"{int((persons['entity_status'] == 'canonical').sum())} person eras and "
                       f"{_n_align_diag(root)} alignment diagnoses all carry reviewed=FALSE; "
                       f"expert_validation/ frames ({_vm(root).get('items_total', 0):,} items) "
                       f"have {_vm(root).get('items_adjudicated', 0)} adjudicated"),
        },
        "rights_review": {
            "status": "PENDING",
            "detail": (f"data/source_rights.csv: {n_not_rev}/{len(rights)} rows redistribution_status="
                       f"not_reviewed, {n_cleared} cleared. Publication is gated on this"),
        },
        "rebuild_smoke_test": rebuild_result,
    }
    # TWO INDEPENDENT GATES. One blocked status for both misdescribed the public
    # distribution: it does not wait on the rights review, it withheld the
    # undetermined layer instead, so the rights gate applies to the FULL package.
    # Scientific validation gates the manuscript, and applies to both.
    engineering_ok = (all(t["status"] not in ("FAIL",) for t in tiers.values())
                      and tiers["rebuild_smoke_test"]["status"] == "PASS"
                      and not any(not r["passed"] for r in RESULTS))
    rights_ok = tiers["rights_review"]["status"] not in ("PENDING", "FAIL")
    validation_ok = tiers["expert_validation"]["status"] == "VALIDATED"

    # Whether the FULL package — which carries the third-party transcriptions —
    # may be distributed. Not a legal determination; the authors' own policy.
    full_distribution_status = ("BLOCKED_PENDING_RIGHTS_REVIEW" if not rights_ok
                                else "CLEARED_BY_AUTHORS" if engineering_ok
                                else "BLOCKED_ENGINEERING")
    # Whether the public structural release may be distributed. It contains no
    # third-party character stream, so the rights ledger does not gate it; the
    # authors and their institution make the final determination.
    public_distribution_status = ("READY_FOR_AUTHOR_SIGN_OFF" if engineering_ok
                                  else "BLOCKED_ENGINEERING")
    # Whether the dataset's annotation layers have been validated by domain
    # experts. This is what gates a Data Descriptor, and it gates both profiles.
    scientific_validation_status = ("VALIDATED" if validation_ok
                                    else tiers["expert_validation"]["status"])

    overall = ("READY" if (engineering_ok and rights_ok and validation_ok)
               else "NOT_READY_FOR_PUBLICATION")

    report = {
        "qa_tiers": tiers,
        "overall_release_status": overall,
        "full_distribution_status": full_distribution_status,
        "public_distribution_status": public_distribution_status,
        "scientific_validation_status": scientific_validation_status,
        "status_note": ("overall_release_status is the conjunction of all three and is "
                        "retained for consumers that read it. The three below are the "
                        "gates that actually differ: the rights review gates the FULL "
                        "package only, because the public structural release withheld the "
                        "undetermined layer rather than waiting on it; scientific "
                        "validation gates the manuscript and both profiles. Neither "
                        "distribution status is a legal determination."),
        "validated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "dataset_version": RELEASE_VERSION,
        "checks_total": len(RESULTS),
        "checks_passed": sum(1 for r in RESULTS if r["passed"]),
        "errors": len(failed),
        "warnings": len(warned),
        "results": RESULTS,
    }
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)

    for r in RESULTS:
        if not r["passed"]:
            print(f"[{r['severity'].upper()}] {r['check']}: {r['detail']}")
    print(f"\n{report['checks_passed']}/{report['checks_total']} checks passed "
          f"({report['errors']} errors, {report['warnings']} warnings)")
    print("\nQA tiers:")
    for name, t in tiers.items():
        print(f"  {name:22s} {t['status']}")
    print(f"  {'OVERALL':22s} {overall}")
    print(f"report -> {args.out}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
