"""
LaoziKG — QA for the PUBLIC STRUCTURAL RELEASE profile.

The full package has its own suite (qa/validate_dataset.py). This one asks the
three questions that are specific to the distribution that will actually be
published, and that the full-package suite cannot ask because it never looks
inside dist/:

  1. Does the profile still contain transcribed source text it was supposed to
     withhold? (v1.1.2-rc6 shipped ~109,000 characters of it, because the
     validation frames and diagnostics were copied verbatim after the data
     tables had been cleaned.)
  2. Does any foreign key in the profile point at a row the profile removed?
     (rc6 left 249 commentary_concept_links referencing dropped commentary.)
  3. Does the profile's own manifest verify against the profile's own files?
     (rc6's was a copy of the previous run's, made before the profile existed.)

Exits 1 on any error so it can gate a release.

Usage:
  python qa/validate_public_profile.py --profile dist/public_structural_release \
      --full-root . --out dist/public_structural_release/qa/public_profile_qa_report.json
"""
import argparse
import datetime
import hashlib
import json
import os
import re

import pandas as pd

# Columns holding transcribed source characters. Kept in step with
# src/make_public_profile.py:SANITIZE_COLUMNS — the check below asserts that.
# Columns that must be empty on any row whose resource is not full_text. The
# check below is already per-resource, which is what makes it safe to include
# llm_interpretation: the authors' own cleared compilation keeps its text and
# everything else is held to the zero-character promise.
#
# llm_interpretation was deliberately EXCLUDED here through rc10 on the grounds
# that it is the project's own machine output — and that is exactly why the
# suite passed 15/15 while the profile shipped 963 spliced records carrying
# 33,709 characters drawn verbatim from third-party transcriptions. A validator
# that inherits the generator's assumption cannot catch the generator being
# wrong about it; this is the third time that pattern has produced a defect
# here, after the evidence cascade key and the absent-facts skip.
SOURCE_TEXT_COLUMNS = {
    "original_text", "normalized_text", "raw_heading",
    "source_quote", "normalized_quote", "quote",
    "old_text", "new_text",
    "jingwen", "wangbi_commentary", "quanjie_interpretation",
    "recovered_text", "canonical_chapter_text",
    "segment_text_as_transmitted", "canonical_wangbi_text",
    "llm_interpretation",
}

RESULTS = []


def check(name, passed, detail=""):
    RESULTS.append({"check": name, "passed": bool(passed), "detail": detail})
    if not passed:
        print(f"[ERROR] {name}: {detail}")


def read_any(path):
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False)


def as_str(series):
    return pd.Series([("" if v is None else str(v)) for v in series.tolist()])


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True)
    ap.add_argument("--full-root", default=".")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    P = os.path.abspath(a.profile)
    if not os.path.isdir(P):
        raise SystemExit(f"no profile at {P}")

    rights = pd.read_csv(os.path.join(P, "data", "source_rights.csv"),
                         encoding="utf-8-sig", keep_default_na=False)
    may_keep_text = set(rights.loc[rights["release_disposition"] == "full_text",
                                   "version_id"].astype(str))
    withheld = set(rights.loc[rights["release_disposition"] == "reference_only",
                              "version_id"].astype(str))

    # ---- 1. no transcribed source text outside the resources that may carry it ----
    offenders, files_scanned = [], 0
    for dirpath, dirs, files in os.walk(P):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for f in sorted(files):
            if not f.endswith((".csv", ".parquet")):
                continue
            path = os.path.join(dirpath, f)
            rel = os.path.relpath(path, P)
            try:
                df = read_any(path)
            except Exception:
                continue
            files_scanned += 1
            for col in df.columns:
                if col not in SOURCE_TEXT_COLUMNS:
                    continue
                vals = as_str(df[col])
                nonempty = (vals.str.len() > 0).values
                if not nonempty.any():
                    continue
                if "version_id" in df.columns:
                    allowed = df["version_id"].astype(str).isin(may_keep_text).values
                    n = int((nonempty & ~allowed).sum())
                    chars = int(vals[nonempty & ~allowed].str.len().sum())
                else:
                    n = int(nonempty.sum())
                    chars = int(vals[nonempty].str.len().sum())
                if n:
                    offenders.append(f"{rel}:{col}: {n} rows, {chars} chars")
    check("no transcribed source text outside full_text resources",
          files_scanned > 0 and not offenders,
          f"files_scanned={files_scanned}; " + ("; ".join(offenders[:6]) if offenders
                                                else "clean"))

    # ---- 1b. the withheld resources appear nowhere but the rights ledger ----
    present = []
    for fn in sorted(os.listdir(os.path.join(P, "data"))):
        if not fn.endswith((".csv", ".parquet")) or fn in ("source_rights.csv", "versions.csv"):
            continue
        df = read_any(os.path.join(P, "data", fn))
        if "version_id" in df.columns:
            n = int(df["version_id"].astype(str).isin(withheld).sum())
            if n:
                present.append(f"{fn}: {n} rows")
    check("no data table carries rows for a reference_only resource",
          not present, "; ".join(present[:6]) if present else f"withheld={len(withheld)}, clean")

    # ---- 2. referential integrity after the cascade ----
    D = os.path.join(P, "data")
    ci = read_any(os.path.join(D, "chapter_instances.parquet"))
    se = read_any(os.path.join(D, "sentences.parquet"))
    cm = read_any(os.path.join(D, "commentary.csv"))
    inst = set(ci["instance_id"].astype(str))
    sent = set(se["sentence_id"].astype(str))
    comm = set(cm["commentary_id"].astype(str))
    fk = [("commentary.csv", "instance_id", inst),
          ("concept_chapter_mentions.csv", "instance_id", inst),
          ("concept_recovered_mentions.csv", "instance_id", inst),
          ("concept_unaligned_mentions.csv", "instance_id", inst),
          ("variants.parquet", "instance_id", inst),
          ("concept_sentence_mentions.parquet", "sentence_id", sent),
          ("concept_sentence_recovered_mentions.parquet", "sentence_id", sent),
          ("concept_sentence_unaligned_mentions.parquet", "sentence_id", sent),
          ("commentary_concept_links.csv", "commentary_id", comm),
          # evidence's FK is source_ref; rc7 declared commentary_id here, which
          # the table does not have, and the loop skipped the check silently.
          ("evidence.parquet", "source_ref", comm)]
    # A DECLARED relationship whose key column is absent is a BUG in this suite,
    # not a relationship to skip. rc7 skipped exactly that case and reported a
    # clean pass over 249 orphan evidence rows: the generator and this validator
    # had copied the same wrong column name, so they agreed with each other and
    # neither agreed with the data. Absent key -> hard failure.
    orphans, missing, checked_rel = [], [], 0
    for fn, key, allowed in fk:
        path = os.path.join(D, fn)
        if not os.path.exists(path):
            missing.append(f"{fn}: table absent")
            continue
        df = read_any(path)
        if key not in df.columns:
            missing.append(f"{fn}: declared key '{key}' is not a column "
                           f"(has: {', '.join(list(df.columns)[:6])})")
            continue
        checked_rel += 1
        n = int((~df[key].astype(str).isin(allowed)).sum())
        if n:
            orphans.append(f"{fn}.{key}: {n} orphan(s)")
    check("every declared foreign key exists as a column",
          not missing, "; ".join(missing[:4]) if missing
          else f"all {len(fk)} declared keys present")
    check("no foreign key references a row the profile removed",
          checked_rel == len(fk) and not orphans,
          "; ".join(orphans[:6]) if orphans
          else f"{checked_rel}/{len(fk)} relationships actually checked")

    # The generator's cascade and this suite must name the SAME key per table —
    # agreeing on a wrong name is how rc7 passed.
    gen_p = os.path.join(a.full_root, "src", "make_public_profile.py")
    if os.path.exists(gen_p):
        gsrc = open(gen_p, encoding="utf-8").read()
        disagree = []
        for fn, key, _ in fk:
            m = re.search(r'\(\s*"' + re.escape(fn) + r'"\s*,\s*"([^"]+)"', gsrc)
            if m and m.group(1) != key:
                disagree.append(f"{fn}: generator uses '{m.group(1)}', suite uses '{key}'")
        check("generator and validator agree on every cascade key",
              not disagree, "; ".join(disagree[:4]) if disagree
              else f"{len(fk)} keys in step")

    # ---- 3. the profile's own manifest verifies against the profile's own files ----
    cp = os.path.join(P, "metadata", "checksums.sha256")
    if os.path.exists(cp):
        bad, verified = [], 0
        for line in open(cp, encoding="utf-8"):
            line = line.rstrip("\n")
            if not line.strip():
                continue
            digest, rel = line.split("  ", 1)
            full = os.path.join(P, rel)
            if not os.path.exists(full):
                bad.append(f"MISSING {rel}")
                continue
            verified += 1
            if sha256_file(full) != digest:
                bad.append(f"MISMATCH {rel}")
        check("the profile's manifest verifies against the profile's own files",
              verified > 0 and not bad,
              f"verified={verified}; " + ("; ".join(bad[:6]) if bad else "all match"))
        stale = sum(1 for l in open(cp, encoding="utf-8")
                    if "dist/restricted" in l or "restricted_profile_report" in l)
        check("the profile's manifest names no superseded path",
              stale == 0, f"superseded path lines={stale}")
    else:
        check("the profile's manifest verifies against the profile's own files",
              False, "metadata/checksums.sha256 absent (generate it after the profile)")

    # ---- 4. the withholding column list has not drifted from the generator ----
    gen = os.path.join(a.full_root, "src", "make_public_profile.py")
    if os.path.exists(gen):
        src = open(gen, encoding="utf-8").read()
        missing = [c for c in SOURCE_TEXT_COLUMNS if f'"{c}"' not in src]
        check("every column this suite checks is one the generator withholds",
              not missing, f"not named in the generator: {missing}" if missing
              else f"{len(SOURCE_TEXT_COLUMNS)} columns in step")

    # ---- 5. the count documents render must equal the profile's own report ----
    # Documents render a count DERIVED from the tables (the profile does not exist
    # when facts are computed); the profile reports what it actually kept. If the
    # cascade changes, these diverge and the documents become wrong.
    # A STANDALONE public archive has no full-package facts file — it ships
    # public_release_facts.json instead. rc10 guarded this with
    # `if os.path.exists(full_facts)` and nothing else, so a reader following the
    # public README got 14 checks where the release run produced 15, and the
    # missing one was silent. That is the same absent-input skip already removed
    # from the evidence cascade and the profile facts; the third time, so it is
    # fixed the same way: fall back to the profile's own facts, and FAIL rather
    # than skip when neither is present.
    fx_p = os.path.join(a.full_root, "metadata", "release_facts.json")
    pf_fx_p = os.path.join(P, "metadata", "public_release_facts.json")
    rp_p = os.path.join(P, "public_profile_report.json")
    facts_src = fx_p if os.path.exists(fx_p) else pf_fx_p
    if os.path.exists(rp_p) and os.path.exists(facts_src):
        fx = json.load(open(facts_src, encoding="utf-8"))
        rp = json.load(open(rp_p, encoding="utf-8"))
        # The full facts name the profile's edge count with a public_profile_
        # prefix; inside the profile's own facts it is simply the edge count.
        rendered = (fx.get("public_profile_mention_edges")
                    if facts_src == fx_p else
                    fx.get("public_profile_mention_edges",
                           fx.get("mention_edges_default")))
        check("the edge count documents render equals what the profile kept",
              rendered == rp.get("mention_edges_retained"),
              f"facts={os.path.relpath(facts_src, P if facts_src == pf_fx_p else a.full_root)}; "
              f"documents render {rendered}; profile kept {rp.get('mention_edges_retained')}")
    else:
        check("the edge count documents render equals what the profile kept",
              False,
              f"cannot compare: profile report present={os.path.exists(rp_p)}, "
              f"facts present={os.path.exists(facts_src)} — this check must never "
              f"be skipped, since skipping is how a standalone run silently "
              f"reported fewer checks than the release")

    # ---- reference_only means WITNESS RECORD ONLY, everywhere ----
    # The disposition says: keep the bibliographic record, keep nothing else. A
    # sanitized-but-present row is still a derived assertion about a resource we
    # are withholding, so the policy is checked over the WHOLE tree, resolving
    # instance- and sentence-keyed files through the full tables.
    LEDGER = {os.path.join("data", "source_rights.csv"), os.path.join("data", "versions.csv")}
    fci = os.path.join(a.full_root, "data", "chapter_instances.parquet")
    fse = os.path.join(a.full_root, "data", "sentences.parquet")
    i_own = (dict(zip(pd.read_parquet(fci)["instance_id"].astype(str),
                      pd.read_parquet(fci)["version_id"].astype(str)))
             if os.path.exists(fci) else {})
    s_own = (dict(zip(pd.read_parquet(fse)["sentence_id"].astype(str),
                      pd.read_parquet(fse)["version_id"].astype(str)))
             if os.path.exists(fse) else {})
    viol = []
    for dirpath, _d, files in os.walk(P):
        if "__pycache__" in dirpath:
            continue
        for fn in sorted(files):
            if not fn.endswith((".csv", ".parquet")):
                continue
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, P)
            if rel in LEDGER:
                continue
            try:
                df = read_any(fp)
            except Exception:
                continue
            if "version_id" in df.columns:
                own = df["version_id"].astype(str)
            elif "instance_id" in df.columns:
                own = df["instance_id"].astype(str).map(i_own)
            elif "sentence_id" in df.columns:
                own = df["sentence_id"].astype(str).map(s_own)
            else:
                continue
            n = int(own.isin(withheld).sum())
            if n:
                viol.append(f"{rel}: {n} row(s)")
    check("reference_only resources appear only as witness records",
          not viol, "; ".join(viol[:6]) if viol
          else f"no derived row for any of the {len(withheld)} reference_only "
               f"resources outside the rights ledger and version table")

    # ---- the profile's DOCUMENTS must agree with the profile's FACTS ---------
    # rc8's public suite passed while every publication document printed
    # full-corpus figures, because it checked the data and the packaging and
    # never the numbers in the prose. The cause was a silent fallback in
    # rendering; these two checks are what would have caught it regardless.
    PUB_DOCS = ["README.md", os.path.join("docs", "DATASET_CARD.md"),
                os.path.join("docs", "DATA_QUALITY_REPORT.md"),
                os.path.join("docs", "schema.md"), "CITATION.md", "CITATION.cff",
                os.path.join("expert_validation", "README.md")]
    # documents that legitimately quote BOTH profiles' numbers, and must be excluded
    # Documents that legitimately quote BOTH distributions' numbers. They are
    # exempt from the full-corpus leak check and are instead held to the
    # dual-profile collapse check below, which is the stricter requirement:
    # naming both values, each correctly. CITATION.md belongs here because it
    # tells a citing author which profile's counts they used.
    DUAL = [os.path.join("docs", "DATA_AVAILABILITY.md"), "PROFILE_NOTICE.md",
            "CHANGELOG.md", os.path.join("docs", "provenance.md"),
            "CITATION.md"]

    pf_p = os.path.join(P, "metadata", "public_release_facts.json")
    pf = json.load(open(pf_p, encoding="utf-8")) if os.path.exists(pf_p) else {}

    # (1) load-bearing public values must actually appear in the public documents
    LOADBEARING = ["chapter_instances", "default_include_instances", "sentences",
                   "variants", "commentary", "mention_edges_default",
                   "validation_frames_items"]
    seen_docs, absent = 0, []
    blob = ""
    for rel in PUB_DOCS:
        p = os.path.join(P, rel)
        if os.path.exists(p):
            seen_docs += 1
            blob += open(p, encoding="utf-8").read()
    for k in LOADBEARING:
        if k in pf and isinstance(pf[k], int):
            if f"{pf[k]:,}" not in blob and str(pf[k]) not in blob:
                absent.append(f"{k}={pf[k]:,}")
    check("public documents quote the profile's own load-bearing figures",
          bool(pf) and seen_docs >= 5 and not absent,
          f"facts={len(pf)} keys; docs_scanned={seen_docs}; "
          + ("missing from every public document: " + "; ".join(absent)
             if absent else f"all {len(LOADBEARING)} figures present"))

    # (2) no FULL-CORPUS value may appear where a public one belongs. The
    # _full_corpus companions in the facts are exactly the values at risk.
    comp = {k[: -len("_full_corpus")]: pf[k] for k in pf
            if k.endswith("_full_corpus") and isinstance(pf[k], int)}
    leaks, scanned = [], 0
    for rel in PUB_DOCS:
        p = os.path.join(P, rel)
        if not os.path.exists(p) or rel in DUAL:
            continue
        scanned += 1
        for i, line in enumerate(open(p, encoding="utf-8").read().split("\n")):
            low = line.lower()
            if any(w in low for w in ("v1.0.0", "v1.1.0", "v1.1.1", "history",
                                      "internal", "full corpus", "full-corpus",
                                      "past-version", "earlier")):
                continue          # deliberate historical / cross-profile reference
            for base, fullval in comp.items():
                if base in pf and pf[base] == fullval:
                    continue      # identical in both profiles; nothing to confuse
                # word-boundary, else "400" matches inside "2,400"
                if re.search(rf"(?<![\d,]){fullval:,}(?![\d,])", line):
                    # A companion whose base key is ABSENT from the profile facts is
                    # the rc8 failure itself: the value can only have come from the
                    # full package. Report it, never crash and never skip.
                    own = f"{pf[base]:,}" if base in pf else "NO PROFILE VALUE — key absent"
                    leaks.append(f"{rel}:{i + 1}: {base}={fullval:,} "
                                 f"(this profile has {own})")
                    break
    check("no full-corpus figure appears in a public document",
          scanned >= 5 and bool(comp) and not leaks,
          f"companions={len(comp)}; docs_scanned={scanned}; "
          + ("; ".join(sorted(set(leaks))[:6]) if leaks else "no leak"))

    # (3) No FULL-PACKAGE artifact may be present in the profile, and no public
    # document may send a reader to one. The leak check above scans numeric
    # values, which cannot catch either: rc9 initially shipped the root
    # release_facts.json inside the profile (reading chapter_instances 4,009) and
    # REPRODUCIBILITY.md told readers to verify a claim in that exact path.
    FULL_ONLY_FILES = [os.path.join("metadata", "release_facts.json"),
                       os.path.join("qa", "validation_report.json"),
                       os.path.join("data", "graph", "laozi_kg.kuzu")]
    present = [f for f in FULL_ONLY_FILES if os.path.exists(os.path.join(P, f))]
    check("no full-package artifact is present in the profile",
          not present and bool(FULL_ONLY_FILES),
          f"candidates={len(FULL_ONLY_FILES)}; "
          + ("present but should not be: " + "; ".join(present) if present
             else "none present"))

    # every path a public document points a reader at must exist HERE
    # (4) A DUAL-PROFILE cell must not collapse. The documents in DUAL are the
    # ones allowed to quote both distributions, so the leak check above skips
    # them — which is exactly where rc9's bug lived: the full-profile cell was
    # keyed to the same fact as the public cell, so in this rendering both read
    # the public value ("51,648 default edges in the full profile"; variants
    # 18,334 against 18,334). For every pair whose two values genuinely differ,
    # a line naming both must contain the full value, not the public one twice.
    pairs = [(k[len("public_profile_"):], k) for k in pf
             if k.startswith("public_profile_")]
    collapsed, dual_scanned, cells = [], 0, 0
    for rel in DUAL:
        p = os.path.join(P, rel)
        if not os.path.exists(p):
            continue
        dual_scanned += 1
        raw = open(p, encoding="utf-8").read().split("\n")
        # A TABLE ROW must be self-contained — it is one line and a reader reads
        # it as one. PROSE wraps, so it is judged as the whole paragraph: the
        # citation sentence puts "58,619 … in the full internal package" on one
        # line and "51,648 in the public …" on the next, and judging those lines
        # separately would flag a correct sentence.
        units = []
        buf, buf_start = [], 0
        for i, line in enumerate(raw):
            if line.lstrip().startswith("|"):
                if buf:
                    units.append((buf_start, " ".join(buf))); buf = []
                units.append((i, line))
            elif line.strip():
                if not buf:
                    buf_start = i
                buf.append(line)
            else:
                if buf:
                    units.append((buf_start, " ".join(buf))); buf = []
        if buf:
            units.append((buf_start, " ".join(buf)))

        for i, line in units:
            for base, pub_key in pairs:
                full_key = f"{base}_full_corpus"
                if full_key not in pf or not isinstance(pf[full_key], int):
                    continue
                fv, pv = pf[full_key], pf[pub_key]
                if fv == pv:
                    continue          # identical in both; nothing to collapse
                # A one- or two-digit public value cannot be attributed to a
                # key by pattern: `commentary_reference_only` is 0 in the
                # profile, and matching a bare "0" flagged four paragraphs of
                # unrelated changelog prose. Only values distinctive enough to
                # identify themselves are compared; the rest are left to the
                # full-corpus leak check, which looks for the FULL value and so
                # has no such ambiguity.
                if pv < 100:
                    continue
                pub_s, full_s = f"{pv:,}", f"{fv:,}"
                # a line that quotes the public value TWICE, or quotes it while
                # claiming to give the full package's, and never names the full value
                n_pub = len(re.findall(rf"(?<![\d,]){pub_s}(?![\d,])", line))
                has_full = re.search(rf"(?<![\d,]){full_s}(?![\d,])", line)
                if n_pub and not has_full and (n_pub > 1 or re.search(
                        r"full (internal|profile|package|corpus)", line, re.I)):
                    collapsed.append(f"{rel}:{i + 1}: {base} reads {pub_s} "
                                     f"where the full package has {full_s}")
                elif n_pub and has_full:
                    cells += 1
    check("dual-profile comparison lines name both profiles' own values",
          dual_scanned >= 2 and bool(pairs) and not collapsed,
          f"dual_docs={dual_scanned}; pairs={len(pairs)}; both-value lines={cells}; "
          + ("; ".join(sorted(set(collapsed))[:6]) if collapsed
             else "no collapsed cell"))

    # Written by THIS run (the QA report) or by the final release stage after
    # QA (the verification record), so neither can exist while QA is checking.
    # Their presence in the shipped archive is covered by the manifest instead.
    SELF_WRITTEN = {"qa/public_profile_qa_report.json",
                    "metadata/final_release_verification.json"}
    SELF_REPORT = "qa/public_profile_qa_report.json"
    bad_ref, ref_docs, refs_seen = [], 0, 0
    PATH_RE = re.compile(r"`((?:metadata|data|qa|docs|expert_validation|src|figures)"
                         r"/[A-Za-z0-9_./-]+\.(?:json|csv|parquet|md|py|sha256))`")
    for rel in PUB_DOCS + [os.path.join("docs", "REPRODUCIBILITY.md"),
                           "PROFILE_NOTICE.md"]:
        p = os.path.join(P, rel)
        if not os.path.exists(p):
            continue
        ref_docs += 1
        for i, line in enumerate(open(p, encoding="utf-8").read().split("\n")):
            low = line.lower()
            if any(w in low for w in ("internal", "full package", "full-package",
                                      "not in this", "not carried", "absent",
                                      "cannot", "v1.0.0", "v1.1.0")):
                continue          # deliberately naming something not shipped here
            for m in PATH_RE.finditer(line):
                # This suite's OWN report is written by this run, so it cannot
                # exist while the run is checking. That is the one structurally
                # unavoidable exception; the release flow re-hashes the profile
                # afterwards (stage 7b) and stage 9 verifies the file is present
                # and hashed, so its existence in the shipped archive IS checked
                # — just not here, where it could not be.
                if m.group(1) in SELF_WRITTEN:
                    continue
                refs_seen += 1
                if not os.path.exists(os.path.join(P, m.group(1))):
                    bad_ref.append(f"{rel}:{i + 1}: {m.group(1)} not in this profile")
    check("public documents only point readers at paths that exist here",
          ref_docs >= 5 and refs_seen >= 10 and not bad_ref,
          f"docs={ref_docs}; refs_checked={refs_seen}; "
          + ("; ".join(sorted(set(bad_ref))[:6]) if bad_ref else "all resolve"))

    # ---- rights status must read the same in every document ----------------
    # rc10's ledger said 1 cleared / 175 not_reviewed while six documents still
    # said nothing was cleared, and LICENSE_DATA.md said both within one file.
    # The load-bearing-figure check could not catch it: it asserts that the
    # profile's own numbers APPEAR somewhere, not that a contradicting rights
    # claim is absent. This reads the ledger and holds the documents to it.
    rights_p = os.path.join(P, "data", "source_rights.csv")
    RIGHTS_DOCS = ["LICENSE_DATA.md",
                   os.path.join("docs", "DATA_AVAILABILITY.md"),
                   os.path.join("docs", "rights_review_summary.md"),
                   os.path.join("metadata", "source_license_resolution.md"),
                   os.path.join("expert_validation", "RIGHTS_WORKSHEET.md"),
                   os.path.join("docs", "ZENODO_UPLOAD_METADATA.md")]
    rights_off, rights_scanned = [], 0
    if os.path.exists(rights_p):
        rdf = pd.read_csv(rights_p, encoding="utf-8-sig", keep_default_na=False)
        n_cleared = int((rdf["redistribution_status"] == "cleared").sum())
        n_notrev = int((rdf["redistribution_status"] == "not_reviewed").sum())
        n_rows = len(rdf)
        # Phrasings that assert a cleared / reviewed count, each capturing the
        # number so it is compared against the ledger rather than matched as a
        # fixed string.
        # "reviewed" must not match inside "not_reviewed" — a sentence saying
        # 175 of 176 rows are not_reviewed is about the OTHER count, and an
        # earlier draft of this check flagged a correct sentence for it.
        PATS = [(re.compile(r"(\d+)\s+of\s+" + str(n_rows) + r"\b[^.\n]{0,60}(?:cleared|rights-cleared|completed a rights review|(?<!not_)\breviewed)", re.I), n_cleared),
                # No "(\d+) of N ... not_reviewed" pattern: a correct sentence
                # states both counts in one breath ("1 of 176 rows are cleared;
                # the remaining 175 are not_reviewed") and a window wide enough
                # to be useful reaches across the semicolon and compares the
                # wrong number. The adjacent-number pattern below covers it.
                (re.compile(r"(?:resources reviewed|cleared for redistribution)\D{0,12}(\d+)", re.I), n_cleared),
                (re.compile(r"(\d+)\s*/\s*" + str(n_rows) + r"\b[^.\n]{0,30}cleared", re.I), n_cleared),
                (re.compile(r"cleared\s*[:=]\s*(\d+)\b", re.I), n_cleared),
                (re.compile(r"(\d+)\s+(?:rows?|resources?)\s+(?:are\s+)?(?:currently\s+)?`?not_reviewed", re.I), n_notrev)]
        ABSOLUTE = re.compile(r"(?:no row is\s+`?cleared|nothing (?:here )?is cleared|"
                              r"nothing on this sheet has been answered|"
                              r"none (?:of them )?(?:is|are) cleared|"
                              r"all rows not_reviewed|"
                              r"`?redistribution_status`?\s*=\s*`?not_reviewed`?\s+on all(?:\s+" + str(n_rows) + r")?|"
                              r"all " + str(n_rows) + r" (?:rows|resources) are (?:currently )?`?not_reviewed)", re.I)

        def units(text):
            """Table rows judged individually; prose judged as the wrapped
            paragraph. LICENSE_DATA.md splits "no row / is `cleared`" across two
            lines, so per-line judgement would miss the very contradiction this
            check exists for."""
            out, buf, start = [], [], 0
            for i, line in enumerate(text.split("\n")):
                if line.lstrip().startswith("|"):
                    if buf:
                        out.append((start, " ".join(buf))); buf = []
                    out.append((i, line))
                elif line.strip():
                    if not buf:
                        start = i
                    buf.append(line)
                else:
                    if buf:
                        out.append((start, " ".join(buf))); buf = []
            if buf:
                out.append((start, " ".join(buf)))
            return out

        for rel in RIGHTS_DOCS:
            fp = os.path.join(P, rel)
            if not os.path.exists(fp):
                continue
            rights_scanned += 1
            for i, line in units(open(fp, encoding="utf-8").read()):
                low = line.lower()
                if any(w in low for w in ("v1.0.0", "v1.1.0", "v1.1.1", "earlier",
                                          "previously", "history", "changelog",
                                          "once the worksheet", "after sign-off",
                                          "achievable only")):
                    continue
                if ABSOLUTE.search(line) and n_cleared:
                    rights_off.append(f"{rel}:{i + 1}: asserts nothing is cleared "
                                      f"(ledger has {n_cleared})")
                    continue
                for pat, expect in PATS:
                    m = pat.search(line)
                    if m and int(m.group(1)) != expect:
                        rights_off.append(f"{rel}:{i + 1}: says {m.group(1)}, "
                                          f"ledger says {expect}")
                        break
        # the statistics table states the ledger's purpose in prose too
        ds_p = os.path.join(P, "metadata", "dataset_statistics.csv")
        if os.path.exists(ds_p):
            rights_scanned += 1
            ds = pd.read_csv(ds_p, encoding="utf-8-sig", keep_default_na=False)
            for _, r_ in ds[ds.iloc[:, 0].astype(str).str.contains("source_rights")].iterrows():
                txt = " ".join(str(v) for v in r_.values)
                if ABSOLUTE.search(txt) and n_cleared:
                    rights_off.append(f"dataset_statistics.csv: asserts nothing is "
                                      f"cleared (ledger has {n_cleared})")
    check("rights status reads the same in every document as in the ledger",
          rights_scanned >= 5 and not rights_off,
          f"docs_scanned={rights_scanned}; " + ("; ".join(sorted(set(rights_off))[:6])
                                                if rights_off else "all agree with the ledger"))

    passed = sum(1 for r in RESULTS if r["passed"])
    errors = len(RESULTS) - passed
    report = {"generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "profile": os.path.basename(P), "checks_total": len(RESULTS),
              "checks_passed": passed, "errors": errors, "checks": RESULTS}
    if a.out:
        out = os.path.join(a.full_root, a.out) if not os.path.isabs(a.out) else a.out
        os.makedirs(os.path.dirname(out), exist_ok=True)
        json.dump(report, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{passed}/{len(RESULTS)} public-profile checks passed ({errors} errors)")
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
