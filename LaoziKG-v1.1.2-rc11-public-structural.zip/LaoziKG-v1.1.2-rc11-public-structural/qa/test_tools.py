"""LaoziKG — tool-module tests that assert RESULTS, not just "no exception".

v1.1.1 verified the tool modules by calling every method and checking nothing
raised. That missed a direction mismatch between the PA_ASSERTS_* schema and
the query_api traversal, which had returned an empty provenance chain for every
version since v1.1.0. Each test here asserts a non-empty, correctly shaped
result against the shipped graph. Exit 1 on any failure.

Usage: python qa/test_tools.py --db data/graph/laozi_kg.kuzu
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import query_api            # noqa: E402
import variant_comparison   # noqa: E402
import concept_browser      # noqa: E402
import qa_agent             # noqa: E402

FAILS = []


def expect(name, cond, detail=""):
    print(f"[{'ok  ' if cond else 'FAIL'}] {name}" + (f"  — {detail}" if detail and not cond else ""))
    if not cond:
        FAILS.append(name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=os.path.join("data", "graph", "laozi_kg.kuzu"))
    ap.add_argument("--data", default="data")
    a = ap.parse_args()

    kg = query_api.LaoziKG(a.db)
    pa = pd.read_csv(os.path.join(a.data, "provenance_assertions.csv"), encoding="utf-8-sig")

    st = kg.stats()
    expect("stats enumerates PersonAlias", "PersonAlias" in st["node_counts"])
    expect("stats Version count == 176", st["node_counts"].get("Version") == 176, str(st["node_counts"].get("Version")))

    v = kg.get_versions()
    expect("get_versions returns 176 rows with witness_era", len(v) == 176 and any("witness_era" in c for c in v.columns), str(v.shape))

    p = kg.get_persons()
    expect("get_persons has canonical_name and historical era", any("canonical_name" in c for c in p.columns)
           and any("person_historical_era" in c for c in p.columns), str(list(p.columns)[:6]))

    chain = kg.get_provenance_chain(pa["version_a"].iloc[0])
    expect("provenance chain non-empty for an asserted version", len(chain) >= 1, str(chain.shape))
    total = sum(len(kg.get_provenance_chain(x)) for x in set(pa["version_a"]))
    expect("provenance chains cover all 19 assertions", total >= 19, str(total))
    expect("get_provenance_assertions returns 19", len(kg.get_provenance_assertions()) == 19)

    var = kg.get_variants(chapter_num=1)
    expect("get_variants(ch1) non-empty with variant_detection_score",
           len(var) > 0 and any("variant_detection_score" in c for c in var.columns), str(var.shape))

    ch = kg.get_concept_history("无为")
    g = ch["glosses"] if isinstance(ch, dict) else ch
    expect("concept history 无为 has glosses", len(g) > 0, str(getattr(g, "shape", None)))

    cm = kg.get_chapter_commentaries(1)
    expect("chapter-1 commentary carries commentator_historical_era and source_quote",
           len(cm) > 0 and any("commentator_historical_era" in c for c in cm.columns)
           and any("source_quote" in c for c in cm.columns), str(list(cm.columns)[:8]))
    kg.close()

    vc = variant_comparison.VariantComparator(a.db)
    t = vc.compare_chapter(1)
    expect("compare_chapter(1) non-empty, witness_era populated",
           len(t) > 0 and "witness_era" in t.columns and t["witness_era"].notna().all(), str(t.shape))
    expect("compare_chapter_html(1) renders", len(vc.compare_chapter_html(1)) > 1000)
    vc.close()

    cb = concept_browser.ConceptBrowser(a.db) if hasattr(concept_browser, "ConceptBrowser") else None
    if cb is not None:
        m = [x for x in dir(cb) if not x.startswith("_") and callable(getattr(cb, x)) and x != "close"]
        expect("concept_browser exposes public methods", len(m) > 0, str(m))
        cb.close()

    ag = qa_agent.LaoziQAAgent(a.db) if hasattr(qa_agent, "LaoziQAAgent") else None
    if ag is not None:
        r = ag.answer("无为 在哪些章出现？")
        expect("qa_agent answers a concept question", bool(r.get("answer_text")), str(r.get("intent")))
        ag.close()

    print(f"\n{len(FAILS)} failure(s)")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
