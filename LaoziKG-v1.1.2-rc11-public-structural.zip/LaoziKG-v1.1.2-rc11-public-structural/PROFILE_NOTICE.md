# PUBLIC STRUCTURAL RELEASE profile

This copy withholds the transcribed character streams of every resource whose
`release_disposition` in `data/source_rights.csv` is not `full_text`
(157 resources as `metadata_and_offsets`,
18 as `reference_only`), because those transcriptions came from
third-party platforms whose terms are not established. Only
1 resource carries its text here: the dataset authors' own compilation.

**What is present:** every structural and derived layer — identifiers, chapter and
sentence structure, offsets, character counts (`*_char_count` columns preserve the
withheld lengths so statistics remain reproducible), concept mentions, commentary
metadata and provenance flags, variant positions and edit operations, the graph
inputs, all documentation, the QA suite and the validation frames.

Rows belonging to `reference_only` resources are dropped from the version-keyed
tables, so the restricted profile carries **51,648 of the
58,619 default concept-mention edges**
(6,971 dropped with those witnesses) — every edge belonging to a
resource that is still represented here, but not every edge in the full profile.

**What is withheld:** `original_text` / `normalized_text` (sentences),
`raw_heading` (chapter instances), `source_quote` / `normalized_quote`
(commentary), `quote` (evidence), `old_text` / `new_text` (variants), and the
Wang Bi exegesis source text. Rows belonging to `reference_only` resources are
dropped from the version-keyed tables entirely; those witnesses survive in
`versions.csv` and `source_rights.csv` as citable records.

**Why it exists and why it is named this way:** this profile is *publishable*,
not access-restricted. "Restricted" (its name up to v1.1.2-rc5) suggested a gated
or embargoed copy; in fact it is the openly distributable one, and the FULL
profile is the copy that must wait for the rights review. It is publishable
without clearing a single third-party transcription, so the rights review is not
a blocker for releasing the dataset authors' own contribution. It is not a rights determination:
`redistribution_status` is `not_reviewed` on every row in both profiles.

## What this distribution can reproduce, and what it cannot

Stated precisely, because "fully reproducible" would be false for this profile:

| Path | Here |
|---|---|
| Rebuild the graph from the shipped tables (`src/build_graph.py`) | **yes** |
| Re-run the QA suites and the validation scorer | **yes** |
| Recompute every derived statistic from the shipped tables | **yes** |
| Audit the expert-validation framework and scorer (frames keep every identifier, stratum and question) | **yes** |
| Perform text-dependent adjudication of record | **no** — the source text, the commentary quotes, the variant strings and the recovered chapter text are withheld, so faithfulness, philosophical-use, variant-genuineness and alignment judgements cannot be made from this copy. Requires the full internal package. |
| Regenerate tables from raw inputs (`src/regenerate_tables.py --src legacy/…`) | **no** — `legacy/` is not included |
| Load a prebuilt graph without building it | **no** — the database `data/graph/laozi_kg.kuzu` is not included; `data/graph/build_report.json` is, so you can diff your build against ours |
| Any analysis over the withheld character streams | **no**, by design |

The full internal package contains `legacy/`, the built `data/graph/laozi_kg.kuzu` and `output/`. If you
need table regeneration from raw inputs, that is the distribution to ask the
authors for; it cannot be published until the rights review in
`data/source_rights.csv` is complete.

## The validation frames are smaller here, and that is the policy working

`reference_only` means *keep the bibliographic record, keep nothing else*. rc7
withheld the text from the copied validation frames but left the rows, so 18
resources we are withholding still contributed row-level derived records. A
sanitized row is still an assertion about a withheld resource, so those rows are
now removed too:

| File | Rows dropped | Rows kept |
|---|---:|---:|
| `derived_diagnostics/structural_mismatches.parquet` | 310 | 3493 |
| `expert_validation/frame_commentary.csv` | 22 | 307 |
| `expert_validation/frame_mentions.csv` | 150 | 600 |
| `expert_validation/frame_variants.csv` | 25 | 375 |
| `expert_validation/frame_work_type.csv` | 18 | 158 |
| `expert_validation/priority_validation_set/pvs_commentary.csv` | 7 | 93 |
| `expert_validation/priority_validation_set/pvs_mentions.csv` | 34 | 116 |
| `expert_validation/priority_validation_set/pvs_variants.csv` | 3 | 47 |
| `src/shipped_labels/version_work_types.csv` | 18 | 158 |

**587 rows** in total. The consequence a reviewer should know: the
validation frames in this distribution are smaller than those in the full internal
package (1,816 items here against 2,031 there), and the scorer's
denominators follow the frames it is given. **This distribution is not the
validation corpus of record.** Judgements that require reading the source text
cannot be made here at all, because that text is withheld; and the strata that
survive rights filtering are unequal, so a rate computed from them is not the
estimator the sampling design supports. Adjudicate in the full internal package
and cite the result for both. Use this copy to audit the design, check which
records were selected by id, read the question schema and run the scorer. Both
frame totals are recorded in `expert_validation/validation_metrics.json`
(`items_total` for this copy) and in `metadata/public_release_facts.json`
(`validation_frames_items` here, `validation_frames_items_full_corpus` for the
internal protocol).

Regenerate with `python src/make_public_profile.py --root . --out dist/public_structural_release`.
Per-table effect: `public_profile_report.json`.
