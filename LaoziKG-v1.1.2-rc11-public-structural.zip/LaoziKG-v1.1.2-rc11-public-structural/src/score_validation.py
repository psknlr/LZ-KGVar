"""LaoziKG — score filled expert-validation frames.

Reports, per frame:
  commentary : P_concept and P_faithfulness per text_provenance × reliability ×
               extraction_method stratum (the 19 sampling strata) and per
               text_provenance marginal; Wilson 95% CIs; κ and α per question.
  mentions   : precision per match_specificity tier.
  variants   : P(genuine | variant_detection_score) per score level, the class
               distribution (orthographic / commentary_bleed / OCR / lacuna),
               and layer accuracy AMONG genuine variants.
  ontology   : per-frame agreement (κ, α) and share confirmed, for the
               full-population label frames.
Nothing is pooled across tiers or strata: they were designed to differ.

Usage: python src/score_validation.py --frames expert_validation [--json out.json]
"""
import argparse
import datetime
import json
import math
import os

import pandas as pd


# share of items adjudicated at or above which the release may call itself
# VALIDATED rather than PARTIALLY_VALIDATED
# VALIDATED requires EVERY mandatory frame to reach its own threshold. The two
# smallest populations are reviewed in full because a sample of them supports
# nothing: concept relations is the layer the audits call weakest (67 edges), and
# the recovered alignments are gated out of the default analysis set precisely
# until they are confirmed.
DEFAULT_FRAME_THRESHOLD_PCT = 80.0
# Per-frame adjudication thresholds for VALIDATED. A FULL-POPULATION frame is
# one where every item in the population is present rather than a sample, so
# "full-population validation" that accepts the 80% default would leave a fifth
# of the population unreviewed while claiming complete coverage. Those frames
# require 100%. Sampled frames keep the default.
FRAME_THRESHOLDS = {
    # full-population frames over the LLM-assigned ontology and metadata labels
    "frame_concept_relations.csv": 100.0,     # 67 relation labels
    "frame_work_type.csv": 100.0,             # 176 work_type / textual_scope labels
    "frame_node_type.csv": 100.0,             # 111 concept node_type labels
    "frame_person_eras.csv": 100.0,           # 75 person_historical_era assignments
    # full-population frames over the v1.1.2 alignment work
    "frame_recovered_alignment.csv": 100.0,   # 116 auto-recovered instances
    "frame_alignment_diagnosis.csv": 100.0,   # 7 diagnosed alignment failures
}
PARTIAL_THRESHOLD_PCT = DEFAULT_FRAME_THRESHOLD_PCT   # retained name for consumers


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (round(c - h, 3), round(c + h, 3))


def cohen_kappa(a, b):
    pairs = [(x, y) for x, y in zip(a, b) if x != "" and y != ""]
    n = len(pairs)
    if n == 0:
        return float("nan")
    a, b = zip(*pairs)
    cats = sorted(set(a) | set(b))
    po = sum(1 for x, y in pairs if x == y) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in cats)
    return float("nan") if pe == 1 else round((po - pe) / (1 - pe), 3)


def kripp_alpha_nominal(cols):
    units = list(zip(*cols))
    vals = [v for u in units for v in u if v != ""]
    if not vals:
        return float("nan")
    cats = sorted(set(vals))
    n_c = {c: vals.count(c) for c in cats}
    n = len(vals)
    Do = 0.0
    for u in units:
        u = [v for v in u if v != ""]
        m = len(u)
        if m < 2:
            continue
        Do += sum(1 for i in range(m) for j in range(m) if i != j and u[i] != u[j]) / (m - 1)
    Do /= n
    De = sum(n_c[c] * n_c[k] for c in cats for k in cats if c != k) / (n * (n - 1))
    return float("nan") if De == 0 else round(1 - Do / De, 3)


def precision_table(done, group_cols, q, positive):
    rows = []
    for key, sub in done.groupby(group_cols, dropna=False):
        key = key if isinstance(key, tuple) else (key,)
        sub = sub[sub[f"adjudicated_{q}"] != "NA"]
        k = int(sub[f"adjudicated_{q}"].isin(positive).sum())
        lo, hi = wilson(k, len(sub))
        rows.append({**dict(zip(group_cols, key)), "n": len(sub), "positive": k,
                     "precision": round(k / len(sub), 3) if len(sub) else float("nan"),
                     "ci95_low": lo, "ci95_high": hi})
    return pd.DataFrame(rows)


def agreement(df, q):
    return {"kappa": cohen_kappa(df[f"annotator_A_{q}"].tolist(), df[f"annotator_B_{q}"].tolist()),
            "alpha": kripp_alpha_nominal([df[f"annotator_A_{q}"].tolist(), df[f"annotator_B_{q}"].tolist()]),
            "n_double_annotated": int(((df[f"annotator_A_{q}"] != "") & (df[f"annotator_B_{q}"] != "")).sum())}


def load(path):
    return pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False, dtype=str)


RESULTS = []   # tidy accumulator: one row per frame x question x stratum


def record(frame, question, stratum, n, k, extra=None):
    """One tidy result row. Written even when n == 0, so the absence of a
    review is a visible zero rather than a missing file."""
    lo, hi = wilson(k, n) if n else ("", "")
    row = {"frame": frame, "question": question, "stratum": stratum,
           "n_adjudicated": n, "n_positive": k,
           "rate": round(k / n, 4) if n else "", "ci95_low": lo, "ci95_high": hi}
    row.update(extra or {})
    RESULTS.append(row)


def show(title, df):
    print(f"\n   {title}")
    print("   " + df.to_string(index=False).replace("\n", "\n   ") if len(df) else "   (none)")




def rows_fully_adjudicated(df):
    """Rows where EVERY adjudicated_* field is answered.

    Not the per-question maximum, which is what v1.1.2-rc6 used: with two
    questions, answering one of them on every row reported the frame as fully
    adjudicated while the other was untouched, and at scale that let a frame read
    as VALIDATED with half its questions unreviewed. An explicit "NA" counts as an
    answer (the scorer drops it from rate denominators separately); blank does not.
    """
    adj = [c for c in df.columns if c.startswith("adjudicated_")]
    if not adj:
        return 0, []
    filled = None
    for c in adj:
        col = df[c].fillna("").astype(str).str.strip() != ""
        filled = col if filled is None else (filled & col)
    return int(filled.sum()), adj


def _pvs_progress(frames_dir):
    """Completion of the priority validation set, counted on its OWN sheets.

    Reported separately from the full protocol because it is the milestone that
    makes per-stratum reporting possible; the full protocol remains the denominator
    for VALIDATED.
    """
    mdir = os.path.join(frames_dir, "priority_validation_set")
    if not os.path.isdir(mdir):
        return {"present": False}
    per, total, done = {}, 0, 0
    for fn in sorted(os.listdir(mdir)):
        if not (fn.startswith("pvs_") and fn.endswith(".csv")):
            continue
        df = pd.read_csv(os.path.join(mdir, fn), encoding="utf-8-sig",
                         keep_default_na=False)
        n_done, adj = rows_fully_adjudicated(df)
        partial = 0
        if adj:
            any_filled = None
            for c in adj:
                col = df[c].fillna("").astype(str).str.strip() != ""
                any_filled = col if any_filled is None else (any_filled | col)
            partial = int(any_filled.sum()) - n_done
        per[fn[len("pvs_"):-len(".csv")]] = {"items": len(df), "adjudicated": n_done,
                                             "partially_answered": partial,
                                             "questions": len(adj)}
        total += len(df)
        done += n_done
    pct = round(done / total * 100, 2) if total else 0.0
    return {"present": True, "items": total, "adjudicated": done,
            "pct_adjudicated": pct, "complete": total > 0 and done == total,
            "frames": per}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", default="expert_validation")
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    out = {}

    # ---------------- commentary ----------------
    p = os.path.join(a.frames, "frame_commentary.csv")
    if os.path.exists(p):
        df = load(p); done = df[df["adjudicated_concept_correct"] != ""]
        print(f"\n== commentary: {len(done)}/{len(df)} adjudicated ==")
        if len(done):
            strata = ["text_provenance", "reliability", "extraction_method"]
            t1 = precision_table(done, strata, "concept_correct", {"Y"})
            t2 = precision_table(done, strata, "gloss_faithful", {"Y"})
            show("P_concept per stratum (text_provenance × reliability × extraction_method)", t1)
            show("P_faithfulness per stratum", t2)
            show("P_concept marginal by text_provenance", precision_table(done, ["text_provenance"], "concept_correct", {"Y"}))
            show("P_faithfulness marginal by text_provenance", precision_table(done, ["text_provenance"], "gloss_faithful", {"Y"}))
            ag = {q: agreement(df, q) for q in ("concept_correct", "gloss_faithful")}
            print("   agreement:", ag)
            out["commentary"] = {"P_concept_strata": t1.to_dict("records"), "P_faithfulness_strata": t2.to_dict("records"), "agreement": ag}

    # ---------------- mentions ----------------
    p = os.path.join(a.frames, "frame_mentions.csv")
    if os.path.exists(p):
        df = load(p); done = df[df["adjudicated_philosophical_use"] != ""]
        print(f"\n== mentions: {len(done)}/{len(df)} adjudicated ==")
        if len(done):
            t = precision_table(done, ["match_specificity"], "philosophical_use", {"Y"})
            show("precision per specificity tier", t)
            ag = agreement(df, "philosophical_use"); print("   agreement:", ag)
            out["mentions"] = {"precision_tier": t.to_dict("records"), "agreement": ag}

    # ---------------- variants ----------------
    p = os.path.join(a.frames, "frame_variants.csv")
    if os.path.exists(p):
        df = load(p); done = df[df["adjudicated_variant_class"] != ""]
        print(f"\n== variants: {len(done)}/{len(df)} adjudicated ==")
        if len(done):
            key = ("variant_detection_score_bin" if "variant_detection_score_bin" in done.columns
                   else "variant_detection_score")
            t = precision_table(done, [key], "variant_class", {"genuine_variant"})
            show(f"P(genuine | {key})  [equal allocation per bin — do NOT pool]", t)
            dist = done["adjudicated_variant_class"].value_counts().rename_axis("class").reset_index(name="n")
            show("class distribution", dist)
            gen = done[done["adjudicated_variant_class"] == "genuine_variant"]
            t2 = precision_table(gen, ["change_type"], "layer_correct", {"Y"}) if len(gen) else pd.DataFrame()
            show("layer accuracy among genuine variants, by change_type", t2)
            ag = {q: agreement(df, q) for q in ("variant_class", "layer_correct")}; print("   agreement:", ag)
            out["variants"] = {"P_genuine_by_score": t.to_dict("records"), "class_distribution": dist.to_dict("records"),
                               "layer_accuracy": t2.to_dict("records") if len(t2) else [], "agreement": ag}

    # ---------------- ontology / metadata full-population frames ----------------
    for name, q in [("frame_work_type.csv", "work_type_correct"), ("frame_node_type.csv", "node_type_correct"),
                    ("frame_concept_relations.csv", "relation_correct"), ("frame_person_eras.csv", "era_correct"),
                    ("frame_alignment_diagnosis.csv", "diagnosis_correct")]:
        p = os.path.join(a.frames, name)
        if not os.path.exists(p):
            continue
        df = load(p); done = df[df[f"adjudicated_{q}"] != ""]
        print(f"\n== {name}: {len(done)}/{len(df)} adjudicated ==")
        if len(done):
            k = int((done[f"adjudicated_{q}"] == "Y").sum()); lo, hi = wilson(k, len(done))
            ag = agreement(df, q)
            print(f"   confirmed {k}/{len(done)} = {k/len(done):.3f}  95% CI [{lo}, {hi}]  agreement {ag}")
            out[name] = {"confirmed": k, "n": len(done), "ci95": [lo, hi], "agreement": ag}

    # ---------------- tidy results + citable metrics ----------------
    # Written on every run, including a run over entirely unfilled frames: a
    # reviewer must be able to see "0 adjudicated" as data, not infer it from a
    # missing file. Populations come from the frames themselves.
    import csv as _csv
    frames_seen, total_items, total_done = {}, 0, 0
    for fn in sorted(os.listdir(a.frames)):
        if not (fn.startswith("frame_") and fn.endswith(".csv")) or "strata" in fn:
            continue
        df = load(os.path.join(a.frames, fn))
        qs = [c[len("adjudicated_"):] for c in df.columns if c.startswith("adjudicated_")]
        n_done, _adj = rows_fully_adjudicated(df)
        for q in qs:
            d = int((df[f"adjudicated_{q}"] != "").sum())
            if not any(r["frame"] == fn and r["question"] == q for r in RESULTS):
                k = int((df[f"adjudicated_{q}"].isin(["Y", "genuine_variant", "correct"])).sum())
                record(fn, q, "ALL", d, k if d else 0)
        frames_seen[fn] = {"items": len(df), "questions": qs, "adjudicated": n_done,
                           "per_question_adjudicated": {q: int((df[f"adjudicated_{q}"] != "").sum()) for q in qs}}
        total_items += len(df)
        total_done += n_done

    res_path = os.path.join(a.frames, "results.csv")
    cols = ["frame", "question", "stratum", "n_adjudicated", "n_positive", "rate",
            "ci95_low", "ci95_high"]
    extra_cols = sorted({k for r in RESULTS for k in r} - set(cols))
    with open(res_path, "w", encoding="utf-8-sig", newline="") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols + extra_cols)
        w.writeheader()
        for r in RESULTS:
            w.writerow(r)

    pct = round(total_done / total_items * 100, 2) if total_items else 0.0

    # ---- status from PER-FRAME coverage, not one global percentage ----
    # A single global threshold lets whole layers go unreviewed: at 80% of 2,031
    # items you could skip commentary (329) and concept relations (67) entirely
    # and still read as VALIDATED. Every mandatory frame must now meet its own
    # threshold, and the per-frame counts are reported next to the label so a
    # reader never has to trust the label alone.
    mps = _pvs_progress(a.frames)
    frame_status = {}
    for fn, info in frames_seen.items():
        thr = FRAME_THRESHOLDS.get(fn, DEFAULT_FRAME_THRESHOLD_PCT)
        pct_f = round(info["adjudicated"] / info["items"] * 100, 2) if info["items"] else 0.0
        frame_status[fn] = {"items": info["items"], "adjudicated": info["adjudicated"],
                            "pct": pct_f, "threshold_pct": thr, "meets": pct_f >= thr}
    unmet = sorted(fn for fn, v in frame_status.items() if not v["meets"])
    if total_done == 0:
        status = "NOT_PERFORMED"
    elif not unmet:
        status = "VALIDATED"
    else:
        status = "PARTIALLY_VALIDATED"

    metrics = {
        "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "status": status,
        "default_frame_threshold_pct": DEFAULT_FRAME_THRESHOLD_PCT,
        # per-frame overrides, so a consumer can see WHICH frames must be
        # complete rather than inferring it from the unmet list
        "frame_thresholds_pct": dict(sorted(FRAME_THRESHOLDS.items())),
        "frame_thresholds": FRAME_THRESHOLDS,
        "frame_status": frame_status,
        "frames_below_threshold": unmet,
        "items_total": total_items, "items_adjudicated": total_done,
        "pct_adjudicated": pct,
        "priority_validation_set": mps,
        "frames": frames_seen,
        "results": RESULTS,
        "detail": out,
        # The packet size is read from the packet this run actually scored, not
        # written in. The literal "400" was correct for the full package and
        # wrong inside the public profile, whose filtered mirror holds fewer —
        # so that copy's metrics file stated 400 beside its own count.
        "note": (f"No item in any frame has been adjudicated. Every rate below is "
                 f"undefined, not zero. The prioritized "
                 f"{mps.get('items', 0):,}-item packet in "
                 f"expert_validation/priority_validation_set/ is the intended "
                 f"starting point." if total_done == 0 else
                 "Rates are per stratum/tier/bin. Do not pool across strata: the "
                 "frames use equal allocation where the design calls for it "
                 "(see SAMPLING_DESIGN.md)."),
    }
    m_path = os.path.join(a.frames, "validation_metrics.json")
    json.dump(metrics, open(m_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\nstatus: {status}  ({total_done}/{total_items} adjudicated = {pct}%)")
    print(f"wrote {res_path} and {m_path}")

    if a.json:
        json.dump(out, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"wrote {a.json}")


if __name__ == "__main__":
    main()
