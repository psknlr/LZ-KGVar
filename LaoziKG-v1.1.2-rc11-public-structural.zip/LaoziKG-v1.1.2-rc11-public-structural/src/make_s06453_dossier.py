"""LaoziKG — per-segment review dossier for the S06453 colophon recovery.

One row per segment with everything a Dunhuang specialist needs to confirm or
correct the chapter identification without running code: the segment text as
transmitted (lacunae kept), the scribe's stated character count vs the actual
count, the identified chapter, the canonical Wang Bi text of that chapter, the
identification score and runner-up, and empty reviewer columns.

Usage: python src/make_s06453_dossier.py --data data --out expert_validation
"""
import argparse
import os
import re

import pandas as pd
from rapidfuzz import fuzz
from opencc import OpenCC

CC = OpenCC("t2s")
PUNCT = re.compile(r"[，。；：？！、\s,\.;:\?!\"“”‘’「」『』（）()\[\]【】]")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="expert_validation")
    a = ap.parse_args()
    d = a.data
    seg = pd.read_csv(os.path.join(d, "alignment_recovery_segments_S06453.csv"), encoding="utf-8-sig", keep_default_na=False)
    ci = pd.read_parquet(os.path.join(d, "chapter_instances.parquet"))
    se = pd.read_parquet(os.path.join(d, "sentences.parquet"))
    ref = pd.read_parquet(os.path.join(d, "wangbi_exegesis_source.parquet"))
    canon = {int(r.chapter_num): str(r.jingwen) for r in ref.itertuples()}
    canon_n = {k: CC.convert(PUNCT.sub("", v)) for k, v in canon.items()}

    inst = ci[(ci["version_id"] == "S06453")].set_index("instance_id")
    rows = []
    for _, s in seg.iterrows():
        ident = str(s["identified_chapter"])
        chs = [int(x) for x in re.findall(r"\d+", ident)] if ident != "-1" else []
        for ch in (chs or [None]):
            iid = f"S06453-CH{ch:03d}" if ch else "S06453-UNSEG"
            txt = "".join(se[se["instance_id"] == iid].sort_values("seq")["original_text"].fillna("").astype(str)) if iid in inst.index or ch is None else ""
            if ch is None:
                txt = "(see residual sentences below)"
            rows.append({
                "segment_order": s["segment_order"],
                "identified_chapter": ch if ch else "",
                "instance_id": iid if ch else "",
                "scribal_colophon_count": s["stated_count"],
                "actual_char_count": s["actual_count"],
                "count_delta": s["count_delta"],
                "identification_score": s["ident_score"],
                "runner_up_score": s["runner_up_score"],
                "near_threshold": "YES" if (s["ident_score"] not in ("", None) and float(s["ident_score"]) < 60 and ch) else "",
                "segment_text_as_transmitted": txt,
                "canonical_wangbi_text": canon.get(ch, "") if ch else "",
                "reviewer_chapter": "", "reviewer_verdict": "", "reviewer_note": "",
            })
    doss = pd.DataFrame(rows)
    doss.to_csv(os.path.join(a.out, "S06453_review_dossier.csv"), index=False, encoding="utf-8-sig")

    # residual sentences
    resid = se[se["instance_id"] == "S06453-UNSEG"].sort_values("seq")[["sentence_id", "original_text"]]
    resid.to_csv(os.path.join(a.out, "S06453_residual_sentences.csv"), index=False, encoding="utf-8-sig")

    # one-page summary
    order = [int(c) for c in inst[inst["chapter_num"] != -1].sort_values("order_in_doc")["chapter_num"]]
    blocks, s0, prev = [], order[0], order[0]
    for c in order[1:]:
        if c != prev + 1:
            blocks.append((s0, prev)); s0 = c
        prev = c
    blocks.append((s0, prev))
    near = doss[doss["near_threshold"] == "YES"]
    md = f"""# S06453 — chapter-order review (for a Dunhuang specialist)

**What was done.** S06453 (Stein collection, British Library) is a scripture-only
Laozi copy in which the scribe wrote a character-count colophon after every
chapter. `src/recover_alignment.py` cut the text at those colophons and
identified each segment against the 81 Wang Bi chapters. **Nothing here has been
checked by a human.**

**Result.** {len(order)} chapters identified; missing: {sorted(set(range(1, 82)) - set(order))}
(scroll head lost). Manuscript order in blocks: **{", ".join(f"{x}–{y}" for x, y in blocks)}**.

**Internal evidence.** Scribal counts agree with actual counts within ±2 on
{int((seg['count_delta'].replace('', pd.NA).dropna().astype(float).abs() <= 2).sum())} of
{int((seg['stated_count'] != '').sum())} colophon segments. Median identification
score {seg[seg['identified_chapter'] != '-1']['ident_score'].replace('', pd.NA).dropna().astype(float).median():.1f};
runner-up scores are far lower on nearly every segment.

**Please look at in particular.**
1. Near-threshold identifications (score < 60): {", ".join(f"segment {int(r.segment_order)} → ch.{r.identified_chapter} ({r.identification_score})" for r in near.itertuples()) or "none"}.
2. The merged segment split into ch.36 + ch.57 (the scribe omitted 36's colophon).
3. The non-standard block order — is it a known 系师定本 / 河上公 arrangement or a rebound scroll?
4. The residual (`S06453_residual_sentences.csv`): dated colophon transmitted as 大唐天寶千載 歳次辛卯 正月乙酉朔 廿六日庚戌
   燉煌郡燉煌縣玉関鄉 — we read 千載 as 十載 (Tianbao 10 = 751 CE) because 辛卯 fits 751; please confirm — "五千文上下二合八十一章四千九百九十九字", and the title line
   太极左仙公序系师定河上真人章句. These are our reading of the text, not a catalogue
   determination.

**How to record.** Fill `reviewer_chapter` / `reviewer_verdict`
(confirm / correct / reject) / `reviewer_note` in `S06453_review_dossier.csv`.
Confirmed or corrected rows are then entered in `src/shipped_labels/alignment_review.csv`
(`expert_confirmed` / `expert_corrected`) and the pipeline flips those instances
into the default analysis set.
"""
    open(os.path.join(a.out, "S06453_review_summary.md"), "w", encoding="utf-8").write(md)
    print(f"dossier rows: {len(doss)}; near-threshold: {len(near)}; residual sentences: {len(resid)}")


if __name__ == "__main__":
    main()
