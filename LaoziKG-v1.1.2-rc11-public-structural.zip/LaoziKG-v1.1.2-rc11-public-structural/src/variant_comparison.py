"""
VariantComparator — Multi-version variant comparison engine for the Laozi KG.

Provides chapter-level side-by-side comparison of textual variants across
all versions in the knowledge graph, with HTML rendering and version clustering.

Usage:
    from variant_comparison import VariantComparator
    vc = VariantComparator("path/to/laozi_kg.kuzu")
    html = vc.compare_chapter_html(chapter_num=1)
    vc.close()
"""
import kuzu
import pandas as pd
import os
import html
from typing import Optional, List, Dict
from collections import defaultdict


class VariantComparator:
    """Compare textual variants across Laozi versions at chapter level."""

    DEFAULT_DB = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "graph", "laozi_kg.kuzu"
    )

    # Era ordering for display
    ERA_ORDER = ["春秋", "春秋战国", "西汉", "东汉", "三国", "东晋",
                 "南北朝", "南朝宋", "南朝陈", "唐", "北宋", "南宋",
                 "宋", "元", "明", "清"]

    def __init__(self, db_path: str = None):
        self.db_path = db_path or self.DEFAULT_DB
        self.db = kuzu.Database(self.db_path)
        self.conn = kuzu.Connection(self.db)

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _query(self, cypher: str) -> pd.DataFrame:
        result = self.conn.execute(cypher)
        cols = result.get_column_names()
        rows = []
        while result.has_next():
            row = result.get_next()
            flat = {}
            for i, col in enumerate(cols):
                val = row[i] if i < len(row) else None
                if isinstance(val, dict):
                    for k, v in val.items():
                        if k.startswith("_"):
                            continue
                        flat[k] = v
                elif isinstance(val, list):
                    flat[col] = str(val)
                else:
                    flat[col] = val
            rows.append(flat)
        return pd.DataFrame(rows)

    def _era_sort_key(self, era: str) -> int:
        try:
            return self.ERA_ORDER.index(era)
        except (ValueError, AttributeError):
            return 99

    def compare_chapter(self, chapter_num: int) -> pd.DataFrame:
        """Return all variants for a chapter, joined with version metadata."""
        cypher = f"""
            MATCH (v:Variant) WHERE v.chapter_num = {chapter_num}
            OPTIONAL MATCH (ver:Version) WHERE ver.version_id = v.version_b
            RETURN v.variant_id AS variant_id, v.version_b AS version_id,
                   v.position AS position, v.change_type AS change_type,
                   v.edit_op AS edit_op, v.old_text AS old_text,
                   v.new_text AS new_text, v.length_ratio AS length_ratio,
                   v.variant_detection_score AS variant_detection_score,
                   v.semantic_explanation AS semantic_explanation,
                   v.manual_status AS manual_status,
                   ver.title AS version_title, ver.witness_era AS witness_era,
                   ver.author_raw AS author, ver.edition AS edition
            ORDER BY v.position, v.change_type
        """
        return self._query(cypher)

    def compare_chapter_html(self, chapter_num: int,
                             max_versions: int = 20) -> str:
        """Generate HTML with side-by-side variant comparison for a chapter."""
        df = self.compare_chapter(chapter_num)
        canonical_text = self._get_canonical_chapter(chapter_num)

        if len(df) == 0 and canonical_text.empty:
            return f"<p>No data found for chapter {chapter_num}</p>"

        # Group variants by position
        by_pos = defaultdict(list)
        for _, row in df.iterrows():
            by_pos[row["position"]].append(row)

        # Sort positions
        positions = sorted(by_pos.keys())

        rows_html = []
        for pos in positions:
            entries = by_pos[pos]
            canonical_seg = self._get_canonical_segment(canonical_text, pos)
            canonical_cell = html.escape(str(canonical_seg)) if canonical_seg else "(无对应)"

            variant_cells = []
            for e in entries:
                ver_label = f"{e.get('version_title', e['version_id'])}"
                if e.get("witness_era"):
                    ver_label += f" [{e['witness_era']}]"
                change_desc = f"{e['change_type']}/{e['edit_op']}"
                if pd.notna(e.get("old_text")) and e["old_text"]:
                    variant_text = f"<del>{html.escape(str(e['old_text']))}</del> → "
                else:
                    variant_text = ""
                if pd.notna(e.get("new_text")) and e["new_text"]:
                    variant_text += f"<ins>{html.escape(str(e['new_text']))}</ins>"
                else:
                    variant_text += "(删除)"
                conf = e.get("variant_detection_score", 0)
                conf_cls = "high" if conf and conf > 0.7 else ("mid" if conf and conf > 0.4 else "low")
                variant_cells.append(
                    f'<div class="variant-entry">'
                    f'<span class="ver-label">{html.escape(ver_label)}</span> '
                    f'<span class="change-type">{html.escape(change_desc)}</span> '
                    f'<span class="variant-text">{variant_text}</span> '
                    f'<span class="conf-{conf_cls}">置信度 {conf:.2f}</span>'
                    f'</div>'
                )

            rows_html.append(
                f'<tr><td class="pos">{pos}</td>'
                f'<td class="canonical">{canonical_cell}</td>'
                f'<td class="variants">{"".join(variant_cells)}</td></tr>'
            )

        table_rows = "\n".join(rows_html)
        variant_count = len(df)
        version_count = df["version_id"].nunique() if len(df) > 0 else 0

        return f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="UTF-8">
<title>第{chapter_num}章 异文对比</title>
<style>
body {{ font-family: 'Noto Serif SC', 'Source Han Serif SC', 'SimSun', 'STSong', 'Microsoft YaHei', serif; margin: 2em; background: #faf8f5; }}
h1 {{ color: #2c3e50; }}
.meta {{ color: #666; margin-bottom: 1em; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ddd; padding: 8px; vertical-align: top; }}
th {{ background: #2c3e50; color: white; }}
td.pos {{ text-align: center; font-family: monospace; width: 60px; }}
td.canonical {{ font-family: 'KaiTi', 'STKaiti', 'AR PL UKai CN', 'SimSun', serif; background: #fffde0; }}
.variant-entry {{ margin: 4px 0; padding: 4px; border-bottom: 1px dashed #eee; }}
.ver-label {{ font-weight: bold; color: #2c3e50; font-size: 0.9em; }}
.change-type {{ font-size: 0.8em; color: #e74c3c; }}
del {{ color: #c0392b; text-decoration: line-through; }}
ins {{ color: #27ae60; text-decoration: underline; }}
.conf-high {{ color: #27ae60; font-size: 0.8em; }}
.conf-mid {{ color: #f39c12; font-size: 0.8em; }}
.conf-low {{ color: #95a5a6; font-size: 0.8em; }}
</style></head><body>
<h1>第{chapter_num}章 异文对比</h1>
<div class="meta">异文总数: {variant_count} | 涉及版本: {version_count} | 参照: 王弼本 canonical</div>
<table><thead><tr>
<th>位置</th><th>王弼本原文</th><th>异文</th>
</tr></thead><tbody>
{table_rows}
</tbody></table>
</body></html>"""

    def _get_canonical_chapter(self, chapter_num: int) -> pd.DataFrame:
        """Get the canonical (Wang Bi) text for a chapter."""
        for vid in ["WANGBI_TONGSHI_2026", "SK2153"]:
            instance_id = f"{vid}-CH{chapter_num:03d}"
            cypher = f"""
                MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence)
                WHERE ci.instance_id = '{instance_id}'
                RETURN s.original_text AS text, s.seq AS seq
                ORDER BY s.seq
            """
            df = self._query(cypher)
            if len(df) > 0:
                return df
            # try without zero-pad
            instance_id = f"{vid}-CH{chapter_num}"
            cypher = f"""
                MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence)
                WHERE ci.instance_id = '{instance_id}'
                RETURN s.original_text AS text, s.seq AS seq
                ORDER BY s.seq
            """
            df = self._query(cypher)
            if len(df) > 0:
                return df
        return pd.DataFrame()

    def _get_canonical_segment(self, canonical_df: pd.DataFrame, position: int) -> str:
        """Extract a segment of the canonical text at a given position."""
        if canonical_df.empty:
            return ""
        texts = canonical_df["text"].tolist()
        if position < len(texts):
            return str(texts[position])
        if texts:
            return str(texts[0])
        return ""

    def build_version_distance_matrix(self, chapter_nums: List[int] = None) -> pd.DataFrame:
        """Build a version×version distance matrix based on shared variant patterns."""
        if chapter_nums is None:
            cypher = "MATCH (v:Variant) RETURN DISTINCT v.version_b AS version_id"
            versions_df = self._query(cypher)
            chapter_nums = list(range(1, 82))

        # Get variant counts per version per chapter
        cypher = """
            MATCH (v:Variant)
            RETURN v.version_b AS version_id, v.chapter_num AS chapter_num,
                   count(v) AS variant_count
        """
        df = self._query(cypher)
        if df.empty:
            return pd.DataFrame()

        pivot = df.pivot_table(index="version_id", columns="chapter_num",
                              values="variant_count", fill_value=0)

        # Compute pairwise distance (simple Euclidean on variant count vectors)
        from itertools import combinations
        versions = pivot.index.tolist()
        matrix = pd.DataFrame(0.0, index=versions, columns=versions)
        for a, b in combinations(versions, 2):
            vec_a = pivot.loc[a].values
            vec_b = pivot.loc[b].values
            dist = sum((vec_a - vec_b) ** 2) ** 0.5
            matrix.loc[a, b] = dist
            matrix.loc[b, a] = dist

        return matrix

    def get_chapter_variant_summary(self, chapter_num: int) -> pd.DataFrame:
        """Summary statistics: variant counts by version and type for a chapter."""
        cypher = f"""
            MATCH (v:Variant) WHERE v.chapter_num = {chapter_num}
            RETURN v.version_b AS version_id, v.change_type AS change_type,
                   v.edit_op AS edit_op, count(v) AS count
            ORDER BY count DESC
        """
        return self._query(cypher)
