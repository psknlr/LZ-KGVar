"""
LaoziKG — merge completed minimum-publishable-set sheets back into the full frames.

The packet in expert_validation/priority_validation_set/ is a subset of the full
frames. Once annotators have filled the pvs_*.csv sheets, this copies their
answers onto the matching rows of frame_*.csv so score_validation.py — which
reads the full frames — picks them up with no special case.

Answers already present in a full frame are never overwritten; a conflict is
reported and left for a human. Idempotent.

Usage: python src/merge_priority_set.py --frames expert_validation
"""
import argparse
import os

import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", default="expert_validation")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    mps = os.path.join(a.frames, "priority_validation_set")
    if not os.path.isdir(mps):
        raise SystemExit(f"no packet at {mps}")

    total_written, conflicts = 0, []
    for fn in sorted(os.listdir(mps)):
        if not (fn.startswith("pvs_") and fn.endswith(".csv")):
            continue
        frame = fn[len("pvs_"):-len(".csv")]
        sub = pd.read_csv(os.path.join(mps, fn), encoding="utf-8-sig", keep_default_na=False)
        full_p = os.path.join(a.frames, f"frame_{frame}.csv")
        full = pd.read_csv(full_p, encoding="utf-8-sig", keep_default_na=False)
        keycols = sub["parent_key_column"].iloc[0].split("+")
        ans = [c for c in sub.columns
               if c.startswith(("annotator_", "adjudicated_", "corrected_"))]
        idx = {tuple(str(r[k]) for k in keycols): i for i, r in full.iterrows()}
        written = 0
        for _, r in sub.iterrows():
            i = idx.get(tuple(str(r[k]) for k in keycols))
            if i is None:
                continue
            for c in ans:
                new = str(r.get(c, "")).strip()
                if not new:
                    continue
                old = str(full.at[i, c]).strip() if c in full.columns else ""
                if old and old != new:
                    conflicts.append(f"{frame}:{keycols}={tuple(str(r[k]) for k in keycols)}:"
                                     f"{c}: frame has {old!r}, packet has {new!r}")
                    continue
                if not old:
                    full.at[i, c] = new
                    written += 1
        if written and not a.dry_run:
            full.to_csv(full_p, index=False, encoding="utf-8-sig")
        total_written += written
        print(f"{frame}: {written} answer cells merged into frame_{frame}.csv")

    print(f"\ntotal cells merged: {total_written}")
    if conflicts:
        print(f"CONFLICTS (left untouched, resolve by hand): {len(conflicts)}")
        for c in conflicts[:10]:
            print("  " + c)


if __name__ == "__main__":
    main()
