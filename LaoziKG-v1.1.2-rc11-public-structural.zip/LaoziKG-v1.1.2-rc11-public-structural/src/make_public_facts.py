"""
LaoziKG — compute release facts for a DISTRIBUTION PROFILE.

Design note, because the first version of this file was the bug:

rc8 hand-wrote ~42 profile keys and let render_docs fall back to the full
package's facts for anything missing. 94 of 117 keys fell back silently, so the
public README printed 3,643 chapter instances beside 3,846 "default" ones —
arithmetically impossible, and produced by a fallback that was working exactly as
written. A partial facts file plus a silent default is strictly worse than no
profile facts at all, because the result looks computed.

So this script does not compute anything itself. make_release_facts.py is already
parameterized by root and reads only from <root>/{data,derived_*,metadata,
expert_validation,VERSION}, all of which a profile has. We run THAT code against
the profile, which yields every key by construction, then:

  * restore the keys that describe the RELEASE rather than the distribution
    (version, date, title, rights ledger, the full protocol's gate figures) from
    the full facts, listed explicitly below rather than inherited by default;
  * add *_full_corpus companions so a reader can see both numbers without
    either being implied;
  * record which keys came from where, in facts_provenance.

Usage: python src/make_public_facts.py --profile dist/public_structural_release --full-root .
"""
import argparse
import json
import os
import subprocess
import sys

# Keys that describe the RELEASE, not the distribution: identity, the rights
# ledger (which lists every resource including the withheld ones, by design), and
# the full validation protocol's gate figures. Taken from the full facts.
SHARED_WITH_RELEASE = (
    "release_version", "release_date", "release_year", "dataset_title",
    "rights_rows", "rights_cleared", "rights_not_reviewed",
    "rights_redistribution_unknown", "rights_original_text_public_domain",
    "rights_digitization_undetermined", "rights_ocr_undetermined",
    "rights_license_basis_unestablished", "rights_provider_low_confidence",
    "rights_provider_buckets", "provider_bucket_rows",
    "data_availability_statement",
    # The three gates describe the RELEASE, not one distribution: each names
    # a decision about a specific tree and must read the same in both, so a
    # reader of either archive sees the same three statuses.
    "full_distribution_status", "public_distribution_status",
    "scientific_validation_status", "overall_release_status",
)

# Counts whose full-corpus value is worth showing beside the profile's own.
# The companion set is NOT redefined here: it is the same vocabulary the full
# facts generator declares, imported so the two cannot drift apart.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from make_release_facts import DUAL as COMPANION


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True)
    ap.add_argument("--full-root", default=".")
    a = ap.parse_args()

    out = os.path.join(a.profile, "metadata", "public_release_facts.json")
    # 1. same computation, profile's tables
    subprocess.run([sys.executable, os.path.join(a.full_root, "src", "make_release_facts.py"),
                    "--root", a.profile, "--out", out],
                   check=True, stdout=subprocess.DEVNULL)
    F = json.load(open(out, encoding="utf-8"))
    full = json.load(open(os.path.join(a.full_root, "metadata", "release_facts.json"),
                          encoding="utf-8"))

    shared, companions = [], []
    for k in SHARED_WITH_RELEASE:
        if k in full:
            F[k] = full[k]
            shared.append(k)
    for k in COMPANION:
        if k in full:
            F[f"{k}_full_corpus"] = full[k]
            companions.append(f"{k}_full_corpus")

    # the profile's own frame total, under the name the public templates use
    F["validation_frames_items_public"] = F.get("validation_frames_items")
    # Same dual-profile vocabulary as the full facts: public_profile_* is this
    # distribution's own value, *_full_corpus (set above from the full facts) is
    # the full internal dataset's. A dual-profile template is then correct in
    # either rendering.
    for k in COMPANION:
        if k in F:
            F[f"public_profile_{k}"] = F[k]
    F["profile"] = "public_structural_release"
    F["scope_note"] = (
        "Every count here is measured in THIS distribution, by running "
        "src/make_release_facts.py against its own tables. Keys ending "
        "_full_corpus describe the complete internal dataset and are provided for "
        "context only; they are not reproducible from the files present here.")
    F["facts_provenance"] = {
        "computed_from_profile_tables": sorted(
            k for k in F if k not in shared and k not in companions
            and k not in ("profile", "scope_note", "facts_provenance")),
        "shared_with_release": shared,
        "full_corpus_companions": companions,
    }
    # Recompose the count-dependent sentences AFTER the *_full_corpus overrides
    # above: they must quote the full internal package's validation counts, which
    # only became correct on the line above. Same module the full facts use, so
    # the wording cannot diverge between profiles.
    sys.path.insert(0, os.path.join(a.full_root, "src"))
    import scoped_claims
    scoped_claims.apply(F, has_raw=False)

    json.dump(F, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    prov = F["facts_provenance"]
    print(json.dumps({
        "keys_total": len(F),
        "computed_from_profile_tables": len(prov["computed_from_profile_tables"]),
        "shared_with_release": len(prov["shared_with_release"]),
        "full_corpus_companions": len(prov["full_corpus_companions"]),
    }, indent=1))


if __name__ == "__main__":
    main()
