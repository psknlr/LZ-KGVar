"""
LaoziKG — generate the six release figures from a facts file and a data directory.

Until v1.1.2-rc9 the figures were produced in an interactive session and copied
into the package, which had two consequences. They were not reproducible from the
release (no script in src/ could remake them), and the public distribution's
figures were byte-identical copies of the full package's, so they displayed
full-corpus counts under a dataset card claiming they came from the shipped public
tables. Both are fixed by generating them here, twice, from each distribution's
own facts and tables.

Usage:
  python src/make_figures.py --root . --out figures
  python src/make_figures.py --root dist/public_structural_release \
      --facts dist/public_structural_release/metadata/public_release_facts.json \
      --out dist/public_structural_release/figures
"""
import argparse
import collections
import itertools
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

BLUE, AMBER, RED, GREY = "#3B6E8F", "#C08A3E", "#C46A5A", "#8A8F98"
ERA_ORDER = ['春秋', '春秋战国', '战国', '西汉', '东汉', '三国', '吴', '西晋', '东晋',
             '南朝宋', '南朝陈', '南北朝', '隋', '唐', '五代', '宋', '北宋', '南宋',
             '金', '元', '明', '明末清初', '清', '清末民初', '现代', '日本江户', '不详']


def era_key(e):
    return ERA_ORDER.index(e) if e in ERA_ORDER else len(ERA_ORDER)


def style():
    plt.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 300, "font.size": 9,
        "axes.titlesize": 9.5, "axes.labelsize": 9, "xtick.labelsize": 8,
        "ytick.labelsize": 8, "legend.fontsize": 7.5,
        "axes.spines.top": False, "axes.spines.right": False,
        "font.family": ["Heiti SC", "DejaVu Sans"], "axes.grid": False,
    })


def panel(ax, letter):
    ax.text(-0.06, 1.06, letter, transform=ax.transAxes, fontsize=11,
            fontweight="bold", va="bottom", ha="right")


def fig1(D, F, out):
    v = pd.read_csv(f"{D}/versions.csv", encoding="utf-8-sig", keep_default_na=False)
    r = pd.read_csv(f"{D}/source_rights.csv", encoding="utf-8-sig", keep_default_na=False)
    v = v.assign(era=v["witness_era_normalized"].replace("", "不详"))
    piv = (v.pivot_table(index="era", columns="work_type", values="version_id",
                         aggfunc="count", fill_value=0))
    piv = piv.reindex(sorted(piv.index, key=era_key))
    order = piv.sum().sort_values(ascending=False).index.tolist()
    cols = {c: (BLUE if c == "ddj_commentary"
                else plt.cm.Greys(0.30 + 0.45 * i / max(len(order) - 1, 1)))
            for i, c in enumerate(order)}
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.9),
                             gridspec_kw={"width_ratios": [2.05, 1], "wspace": 0.30})
    ax = axes[0]
    base = np.zeros(len(piv))
    for c in order:
        ax.bar(range(len(piv)), piv[c].values, bottom=base, color=cols[c],
               width=0.78, linewidth=0.4, edgecolor="white", label=c)
        base += piv[c].values
    ax.set_xticks(range(len(piv)))
    ax.set_xticklabels(piv.index, rotation=45, ha="right")
    ax.set_ylabel("witnesses")
    ax.set_xlabel("witness era (the edition's own bibliographic claim, chronological)")
    ax.set_title(f"Corpus composition: {F['resources']} resources by edition era and genre",
                 loc="left")
    ax.legend(ncol=2, frameon=False, loc="upper left")

    ax2 = axes[1]
    disp = r["release_disposition"].value_counts()
    lab = {"metadata_and_offsets": "metadata + offsets\n(third-party text)",
           "reference_only": "reference only\n(provider unknown)",
           "full_text": "full text\n(authors' own)"}
    keys = [k for k in ("metadata_and_offsets", "reference_only", "full_text") if k in disp]
    vals = [int(disp[k]) for k in keys]
    colr = {"metadata_and_offsets": GREY, "reference_only": RED, "full_text": BLUE}
    span = max(vals) if vals else 1
    for i, (k, n) in enumerate(zip(keys, vals)):
        ax2.barh(i, max(n, span * 0.012), color=colr[k], height=0.55)
        ax2.text(max(n, span * 0.012) + span * 0.03, i, f"{n}", va="center", fontsize=8.5)
    ax2.set_yticks(range(len(keys)))
    ax2.set_yticklabels([lab[k] for k in keys])
    ax2.invert_yaxis()
    ax2.set_xlabel("resources")
    ax2.set_xlim(0, span * 1.32)
    ax2.set_title(f"Proposed release disposition\n({F['rights_cleared']} of "
                  f"{F['rights_rows']} rights-cleared)", loc="left")
    panel(axes[0], "a"); panel(ax2, "b")
    fig.savefig(f"{out}/fig1_source_distribution.png", bbox_inches="tight")
    plt.close(fig)


def fig2(D, F, out):
    import networkx as nx
    me = pd.read_csv(f"{D}/concept_chapter_mentions.csv", encoding="utf-8-sig")
    hs = me[me["match_specificity"].isin(["high", "medium"])]
    by_inst = hs.groupby("instance_id")["concept_name"].apply(set)
    pairs = collections.Counter()
    for s in by_inst:
        for a, b in itertools.combinations(sorted(s), 2):
            pairs[(a, b)] += 1
    top = hs.groupby("concept_name")["mention_count"].sum().nlargest(22)
    keep = set(top.index)
    thr = 120
    edges = [(a, b, w) for (a, b), w in pairs.items()
             if a in keep and b in keep and w >= thr]
    G = nx.Graph()
    for c in keep:
        G.add_node(c, w=float(top[c]))
    wmax = max((w for *_, w in edges), default=1)
    for a, b, w in edges:
        G.add_edge(a, b, weight=w, lw=w / wmax)
    iso = [n for n in G if G.degree(n) == 0]
    G.remove_nodes_from(iso)
    pos = nx.spring_layout(G, seed=3, k=1.5, weight="lw", iterations=600)
    fig, ax = plt.subplots(figsize=(6.8, 5.6))
    if G.number_of_edges():
        ws = np.array([G[a][b]["weight"] for a, b in G.edges()])
        rng = ws.max() - ws.min() or 1
        nx.draw_networkx_edges(G, pos, ax=ax, width=0.2 + 2.2 * (ws - ws.min()) / rng,
                               edge_color=GREY, alpha=0.5)
    sz = np.array([G.nodes[n]["w"] for n in G.nodes()])
    nx.draw_networkx_nodes(G, pos, ax=ax, node_color=BLUE,
                           node_size=120 + 1500 * sz / (sz.max() or 1), alpha=0.92)
    nx.draw_networkx_labels(G, pos, ax=ax, font_size=8,
                            font_family=plt.rcParams["font.family"][0])
    ax.set_title("Concept co-occurrence across chapter instances\n"
                 "node size = occurrences  ·  edge width = instances containing both",
                 loc="left")
    note = ("high- and medium-specificity matches only (names ≥2 characters), "
            f"default analysis set;\nedge drawn where ≥{thr} instances contain both concepts")
    if iso:
        note += f"; {len(iso)} concept ({', '.join(iso)}) has no edge at this threshold and is omitted"
    ax.text(0.0, -0.02, note, transform=ax.transAxes, ha="left", va="top",
            fontsize=6.5, color="#555")
    ax.axis("off"); ax.margins(0.10)
    fig.savefig(f"{out}/fig2_concept_network.png", bbox_inches="tight")
    plt.close(fig)


def fig3(D, F, out):
    cm = pd.read_csv(f"{D}/commentary.csv", encoding="utf-8-sig", keep_default_na=False)
    both = cm[(cm["commentator_historical_era"] != "") & (cm["commentary_witness_era"] != "")]
    ct = (both.pivot_table(index="commentator_historical_era",
                           columns="commentary_witness_era",
                           values="commentary_id", aggfunc="count", fill_value=0))
    ct = ct.reindex(sorted(ct.index, key=era_key))
    ct = ct[sorted(ct.columns, key=era_key)]
    M = ct.values.astype(float)
    fig, ax = plt.subplots(figsize=(7.4, 4.8))
    im = ax.imshow(np.where(M > 0, M, np.nan), cmap="YlGnBu", aspect="auto",
                   norm=mcolors.LogNorm(vmin=max(M[M > 0].min(), 1), vmax=M.max()))
    ax.set_xticks(range(ct.shape[1])); ax.set_xticklabels(ct.columns, rotation=45, ha="right")
    ax.set_yticks(range(ct.shape[0])); ax.set_yticklabels(ct.index)
    ax.set_xlabel("witness era  (era of the edition the gloss was read from)")
    ax.set_ylabel("commentator era\n(the annotator's own lifetime)")
    for i, ridx in enumerate(ct.index):
        if ridx in ct.columns:
            j = list(ct.columns).index(ridx)
            ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fill=False,
                                       edgecolor=RED, linewidth=1.6))
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if M[i, j] > 0:
                ax.text(j, i, int(M[i, j]), ha="center", va="center", fontsize=6.5,
                        color="white" if M[i, j] > M.max() * 0.35 else "#1b2a3a")
    diag = sum(M[i, list(ct.columns).index(r)] for i, r in enumerate(ct.index)
               if r in ct.columns)
    pct = (1 - diag / M.sum()) * 100
    ax.set_title(f"Commentator era ≠ edition era for {pct:.1f}% of {int(M.sum()):,} glosses\n"
                 "red cells mark the diagonal, where the two coincide", loc="left")
    fig.colorbar(im, ax=ax, label="commentary records (log scale)", shrink=0.85)
    fig.savefig(f"{out}/fig3_commentary_lineage.png", bbox_inches="tight")
    plt.close(fig)


def fig4(D, F, out):
    cm = pd.read_csv(f"{D}/commentary.csv", encoding="utf-8-sig", keep_default_na=False)
    known = cm[cm["commentator_historical_era"] != ""]
    top6 = known["concept_name"].value_counts().nlargest(6).index.tolist()
    denom = known.groupby("commentator_historical_era").size()
    tev = (known[known["concept_name"].isin(top6)]
           .groupby(["commentator_historical_era", "concept_name"]).size()
           .unstack(fill_value=0))
    share = (tev.div(denom, axis=0) * 100)
    keep = [e for e in share.index if denom.get(e, 0) >= 25 and e != "不详"]
    ts = share.loc[sorted(keep, key=era_key)]
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    pal = [BLUE if c == "无为" else plt.cm.tab20b(0.15 + 0.7 * i / 5)
           for i, c in enumerate(top6)]
    cmap = dict(zip(top6, pal))
    x = np.arange(len(ts))
    for c in top6:
        if c not in ts.columns:
            continue
        ax.plot(x, ts[c].values, marker="o", ms=4.5,
                lw=1.9 if c == "无为" else 1.2, color=cmap[c],
                alpha=1.0 if c == "无为" else 0.8, zorder=3 if c == "无为" else 2)
    ends = sorted(((ts[c].values[-1], c) for c in top6 if c in ts.columns), reverse=True)
    prev = None
    for val, c in ends:
        y = val if prev is None or abs(val - prev) > 0.9 else prev - 0.9
        ax.text(len(x) - 1 + 0.12, y, c, color=cmap[c], fontsize=8.5, va="center")
        prev = y
    ax.set_xticks(x)
    ax.set_xticklabels([f"{e}\nn={int(denom[e])}" for e in ts.index])
    ax.set_ylabel("share of that era's glosses (%)")
    ax.set_xlabel("commentator era (the annotator's own lifetime), chronological")
    ax.set_title("Which concepts commentators glossed, by their own era", loc="left")
    ax.set_xlim(-0.4, len(x) - 0.4 + 0.9)
    n_unk = int((cm["commentator_historical_era"] == "").sum())
    ax.text(0.0, -0.30, "eras with ≥25 glosses; denominator is all glosses by "
            f"commentators of that era.\n{n_unk} glosses whose commentator era is "
            "unknown are excluded, not plotted at a position.",
            transform=ax.transAxes, fontsize=6.5, color="#555")
    fig.savefig(f"{out}/fig4_temporal_evolution.png", bbox_inches="tight")
    plt.close(fig)


def fig5(D, F, out):
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    layers = [
        ("Source layer", [(f"Version {F['resources']}",
                           "witness_era_raw / _normalized\nwork_type · resource_class"),
                          (f"Person {F['persons']}",
                           f"person_historical_era\n+ {F['aliases']} aliases")],
         "bibliographic record", BLUE),
        ("Text layer", [(f"ChapterInstance {F['chapter_instances']:,}",
                         "alignment_review_status\n"
                         f"{F['default_include_instances']:,} default · "
                         f"{F['recovered_unreviewed_instances']} gated · "
                         f"{F['unaligned_instances']} unaligned"),
                        (f"Sentence {F['sentences']:,}", "offsets · character counts")],
         "deterministic from source", BLUE),
        ("Derived layer", [(f"Variant {F['variants']:,}",
                            "candidate detections\nvariant_detection_score"),
                           (f"Mention {F['mention_edges_default']:,}",
                            "match_specificity tiers"),
                           (f"Commentary {F['commentary']:,}",
                            "text_provenance\ncitable_as_quote")],
         "machine-detected, unreviewed", AMBER),
        ("Interpretive", [(f"Concept {F['concepts']}", "node_type · is_seed"),
                          (f"Relation {F['concept_relations']}", "relation_category"),
                          ("Candidate claims", "derived_unverified/ — never cite")],
         "LLM-generated, unreviewed", RED),
    ]
    fig, ax = plt.subplots(figsize=(8.8, 6.6))
    y, band_h, gap = 0.0, 1.0, 0.72
    for name, boxes, tag, col in layers:
        n = len(boxes)
        w = 8.0 / n - 0.18
        ax.add_patch(FancyBboxPatch((-0.30, y - 0.14), 8.6, band_h + 0.28,
                                    boxstyle="round,pad=0.02", fc="#f5f6f8",
                                    ec="none", zorder=0))
        ax.text(-0.24, y + band_h + 0.22, name, fontsize=9.5, fontweight="bold",
                va="bottom", color="#16202b")
        ax.text(8.30, y + band_h + 0.22, tag, fontsize=7.5, va="bottom",
                ha="right", color=col)
        for i, (hd, sub) in enumerate(boxes):
            x0 = i * (8.0 / n)
            ax.add_patch(FancyBboxPatch((x0, y + 0.06), w, band_h - 0.12,
                                        boxstyle="round,pad=0.03", fc="white",
                                        ec=col, linewidth=1.3, zorder=1))
            ax.text(x0 + w / 2, y + band_h - 0.30, hd, fontsize=9.5, ha="center",
                    color=col, zorder=2)
            ax.text(x0 + w / 2, y + 0.30, sub, fontsize=7.2, ha="center",
                    va="center", color="#333", zorder=2, linespacing=1.45)
        y -= band_h + gap
    for k in range(len(layers) - 1):
        yy = -k * (band_h + gap)
        ax.add_patch(FancyArrowPatch((4.0, yy - 0.16), (4.0, yy - gap + 0.10),
                                     arrowstyle="-|>", mutation_scale=11,
                                     color="#7b828c", linewidth=1.1))
    bottom = y + band_h + gap
    ax.text(-0.30, bottom - 0.55,
            "Provenance is recorded at every step: each assertion carries the witness it came "
            "from and its own *_reviewed flag.\n"
            f"Gating: the {F['recovered_unreviewed_instances']} auto-recovered chapter instances "
            f"and the {F['unaligned_instances']} unaligned units are excluded from "
            "`analysis_default_include`\nuntil an expert confirms them, and candidate claims sit "
            "outside `data/` entirely — so a default query returns\nonly deterministic structure "
            "plus layers whose machine origin is declared.",
            fontsize=7, color="#444", va="top", linespacing=1.55)
    ax.set_xlim(-0.5, 8.6); ax.set_ylim(bottom - 1.35, 1.0 + band_h + 0.30)
    ax.axis("off")
    ax.set_title("LaoziKG architecture: four layers, each gated by how it was produced",
                 loc="left", pad=8)
    fig.savefig(f"{out}/fig5_architecture.png", bbox_inches="tight")
    plt.close(fig)


def fig6(D, F, out):
    v = pd.read_csv(f"{D}/versions.csv", encoding="utf-8-sig", keep_default_na=False)
    ci = pd.read_parquet(f"{D}/chapter_instances.parquet")
    pa = pd.read_csv(f"{D}/provenance_assertions.csv", encoding="utf-8-sig",
                     keep_default_na=False)
    ci2 = ci.merge(v[["version_id", "lineage_branch"]], on="version_id", how="left")
    st = (ci2.groupby(["lineage_branch", "alignment_review_status"]).size()
          .unstack(fill_value=0)
          .reindex(columns=["original_deterministic", "auto_recovered_unreviewed",
                            "not_aligned"], fill_value=0))
    nver = v.groupby("lineage_branch").size()
    st = st.loc[[b for b in nver.sort_values(ascending=False).index if b in st.index]]
    EN = {'明清注本系统': 'Ming–Qing commentary editions', '敦煌吐鲁番写本系统': 'Dunhuang–Turfan manuscripts',
          '道藏收录系统': 'Daozang canon', '河上公注系统': 'Heshanggong commentary',
          '王弼注系统': 'Wang Bi commentary', '帛书系统': 'Mawangdui silk manuscripts',
          '郭店楚简': 'Guodian bamboo slips'}
    SH = {'明清注本系统': 'Ming–Qing', '敦煌吐鲁番写本系统': 'Dunhuang', '道藏收录系统': 'Daozang',
          '河上公注系统': 'Heshanggong', '王弼注系统': 'Wang Bi', '郭店楚简': 'Guodian',
          '帛书系统': 'Mawangdui'}
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.4),
                             gridspec_kw={"width_ratios": [1.65, 1], "wspace": 0.42})
    ax = axes[0]
    yy = np.arange(len(st))
    left = np.zeros(len(st))
    for c, col, lab in (("original_deterministic", BLUE, "aligned, in default set"),
                        ("auto_recovered_unreviewed", AMBER, "auto-recovered, gated out"),
                        ("not_aligned", GREY, "unaligned")):
        ax.barh(yy, st[c].values, left=left, color=col, height=0.62, label=lab)
        left += st[c].values
    for i, b in enumerate(st.index):
        ax.text(left[i] + st.values.max() * 0.02, i,
                f"{int(left[i]):,} instances  ·  {int(nver[b])} witnesses",
                va="center", fontsize=7.5, color="#333")
    ax.set_yticks(yy)
    ax.set_yticklabels([f"{EN.get(b, b)}\n{b}" for b in st.index], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("chapter instances")
    ax.set_xlim(0, left.max() * 1.42)
    ax.set_title("Chapter instances by lineage branch and alignment status", loc="left")
    ax.legend(frameon=False, loc="lower right", fontsize=7.5)

    b2v = dict(zip(v["version_id"].astype(str), v["lineage_branch"]))
    lc = collections.Counter()
    for _, r in pa.iterrows():
        a_, b_ = b2v.get(str(r.get("version_a")), None), b2v.get(str(r.get("version_b")), None)
        if a_ and b_:
            lc[(a_, b_)] += 1
    order = list(st.index)
    M = np.zeros((len(order), len(order)))
    for (a_, b_), n in lc.items():
        if a_ in order and b_ in order:
            i, j = order.index(a_), order.index(b_)
            M[min(i, j), max(i, j)] += n
    keepi = [i for i in range(len(order)) if M[i, :].sum() or M[:, i].sum()]
    Ms = M[np.ix_(keepi, keepi)]
    labs = [SH.get(order[i], order[i]) for i in keepi]
    ax2 = axes[1]
    if Ms.size:
        ax2.imshow(np.where(Ms > 0, Ms, np.nan), cmap="YlGnBu", aspect="auto")
        for i in range(len(labs)):
            for j in range(len(labs)):
                if Ms[i, j] > 0:
                    ax2.text(j, i, int(Ms[i, j]), ha="center", va="center", fontsize=8.5,
                             color="white" if Ms[i, j] > Ms.max() * 0.45 else "#1b2a3a")
    ax2.set_xticks(range(len(labs))); ax2.set_xticklabels(labs, rotation=45, ha="right", fontsize=7.5)
    ax2.set_yticks(range(len(labs))); ax2.set_yticklabels(labs, fontsize=7.5)
    ax2.set_title(f"Same-work assertions between branches\n({len(pa)} total, "
                  "every one evidence-backed)", loc="left")
    ax2.text(0, -0.42, "SAME_WORK_EDITION only — one work in two catalogue records.\n"
             "The dataset asserts no textual-descent relationship anywhere.",
             transform=ax2.transAxes, fontsize=6.6, color="#555", va="top", linespacing=1.5)
    panel(ax, "a"); panel(ax2, "b")
    fig.savefig(f"{out}/fig6_version_lineage.png", bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--facts", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    D = os.path.join(a.root, "data")
    F = json.load(open(a.facts or os.path.join(a.root, "metadata", "release_facts.json"),
                       encoding="utf-8"))
    out = a.out or os.path.join(a.root, "figures")
    os.makedirs(out, exist_ok=True)
    style()
    for fn in (fig1, fig2, fig3, fig4, fig5, fig6):
        fn(D, F, out)
    print(json.dumps({"figures": sorted(os.listdir(out)),
                      "facts": os.path.basename(a.facts or "release_facts.json"),
                      "scope": F.get("profile", "full_internal")}, indent=1))


if __name__ == "__main__":
    main()
