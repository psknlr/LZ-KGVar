"""
LaoziKG — claim sentences whose WORDING depends on the distribution and whose
NUMBERS depend on facts a distribution profile overrides after its own facts are
computed.

Why this is a separate module. The simple scoped claims (is this tree fully
reproducible, does it ship a graph snapshot) are decided by one predicate and
live in make_release_facts. These two are different: they must quote the FULL
internal package's validation counts even when rendering inside the profile, and
those `*_full_corpus` values are only correct after make_public_facts has
overridden the self-aliases. Composing them in make_release_facts alone would
quote the profile's own numbers as the internal ones — the same class of bug as
the dual-profile cells. So both generators call this, and the wording exists once.
"""


def _n(value):
    return f"{value:,}" if isinstance(value, int) else str(value)


def apply(facts, has_raw):
    """Set the count-dependent scoped sentences on `facts`, in place.

    `has_raw` distinguishes the full internal package (holds the raw inputs and
    the validation corpus of record) from a distribution profile (holds a
    filtered mirror of it).
    """
    pvs_here = facts.get("pvs_items")
    pvs_full = facts.get("pvs_items_full_corpus", pvs_here)
    frames_here = facts.get("validation_frames_items")
    frames_full = facts.get("validation_frames_items_full_corpus", frames_here)

    if has_raw:
        facts["priority_set_role_sentence"] = (
            f"`expert_validation/priority_validation_set/` is a prioritized subset "
            f"of the {_n(frames_full)}-item protocol, sized to support per-stratum "
            f"precision with a confidence interval and inter-annotator agreement — "
            f"the metrics a Data Descriptor must report. This is the validation "
            f"corpus of record: adjudicate here. Completing it moves the dataset to "
            f"`PARTIALLY_VALIDATED`; the full protocol is what `VALIDATED` requires.")
        facts["validation_target_sentence"] = (
            f"Adjudicate the {_n(pvs_full)}-item priority validation set in "
            f"`expert_validation/priority_validation_set/`, within the "
            f"{_n(frames_full)}-item protocol, and publish per-stratum precision "
            f"with Wilson CIs and κ.")
    else:
        facts["priority_set_role_sentence"] = (
            f"`expert_validation/priority_validation_set/` is a **filtered mirror** "
            f"of the full internal package's {_n(pvs_full)}-item priority validation "
            f"set: {_n(pvs_here)} of those items, with every row belonging to a "
            f"`reference_only` resource removed along with the resource. It is not "
            f"an independent sample and **must not be used to estimate precision** — "
            f"rights filtering removed rows unevenly, so the equal allocation the "
            f"design specifies no longer holds here (see "
            f"`expert_validation/priority_validation_set/mirror_allocation.csv` for "
            f"the strata actually present). Statistical estimates come from "
            f"adjudicating the full internal {_n(pvs_full)}-item sample; this copy is "
            f"for auditing the design, the record identifiers, the question schema "
            f"and the scorer.")
        facts["validation_target_sentence"] = (
            f"Adjudication of record happens on the **full internal package**: the "
            f"{_n(pvs_full)}-item priority validation set within the "
            f"{_n(frames_full)}-item protocol. Do not compute estimates from this "
            f"distribution's {_n(frames_here)}-item filtered mirror ({_n(pvs_here)} "
            f"priority items) — its strata are unequal by construction. Publish "
            f"per-stratum precision with Wilson CIs and κ from the internal "
            f"adjudication, and cite the result for both distributions.")
    # ---- the three gates, stated identically wherever they appear -----------
    # rc9 carried four different publication statuses across four shipped files
    # (README "do not publish yet", the availability table "may be published
    # today: yes", the licence "the rights review does not gate this
    # distribution", the Zenodo checklist "the package must not be public").
    # They were not all wrong — they were about different things. Separating the
    # gates makes each one true, and rendering them from here makes them agree.
    rights_cleared = facts.get("rights_cleared")
    rights_rows = facts.get("rights_rows")
    fds = facts.get("full_distribution_status", "unknown")
    pds = facts.get("public_distribution_status", "unknown")
    svs = facts.get("scientific_validation_status", "unknown")
    here = ("this distribution" if not has_raw else "this package")
    facts["three_gate_statement"] = (
        f"Three gates, separate because they are separate decisions:\n\n"
        f"1. **Public distribution.** The public structural release is technically "
        f"prepared for open distribution: it contains no third-party transcribed "
        f"character stream, so the per-provider rights review does not gate it. "
        f"Release remains subject to author and institutional sign-off. "
        f"Status: `{pds}`.\n"
        f"2. **Full internal package.** It carries the transcriptions and is not "
        f"redistributable until the rights review is complete "
        f"({_n(rights_cleared)} of {_n(rights_rows)} resources cleared). "
        f"Status: `{fds}`.\n"
        f"3. **Scientific validation / manuscript readiness.** No domain expert has "
        f"adjudicated any label ({_n(facts.get('validation_adjudicated'))} of "
        f"{_n(frames_here)} items in {here}; the corpus of record is the internal "
        f"protocol of {_n(frames_full)}). Status: `{svs}`. This gates a Data "
        f"Descriptor submission, not distribution.\n\n"
        f"Neither distribution status is a legal determination: that rests with the "
        f"authors and their institution. `overall_release_status` is the conjunction "
        f"of all three and is therefore "
        f"`{facts.get('overall_release_status', 'NOT_READY_FOR_PUBLICATION')}`.")
    return facts
