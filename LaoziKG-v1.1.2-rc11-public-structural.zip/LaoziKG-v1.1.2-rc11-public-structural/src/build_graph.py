"""LaoziKG — build the Kuzu graph from the released source tables.

Why this file was rewritten
---------------------------
The v1.0.0 build script did not work. Three independent defects:

  1. `load_data` emitted malformed Cypher. It joined every column name with
     commas, then a single colon, then a list of every value:
         CREATE (n:Version {version_id, title, era: ['DZ0682', '...', '...']})
     which is not valid property-map syntax.
  2. Every insert was wrapped in `except Exception: pass`, so all failures were
     silent while the script printed "Loading Version: 176 rows".
  3. Two of the six declared inputs (`chapters.parquet`, `commentary.parquet`)
     do not exist in the release; the loop `continue`d past them with only a
     "Skipping" notice.

Net effect: a clean rebuild produced a database with the full schema and ZERO
rows in every table, and exited 0. No relationship table was loaded at all.

This version loads all node AND relationship tables with Kuzu's COPY FROM,
fails loudly on any missing or empty input, and writes build_report.json
recording per-table counts, input checksums, and the environment, so a third
party can prove their rebuild matches the published graph.

Usage:
    python src/build_graph.py --data-dir data --db-path data/graph/laozi_kg.kuzu
"""
import argparse
import csv
import datetime
import hashlib
import json
import os
import platform
import shutil
import sys
import tempfile

import kuzu
import pandas as pd

SCHEMA_VERSION = "1.1.0"
COPY_OPTS = "(header=true, parallel=false)"


class BuildError(RuntimeError):
    pass


# ---------------------------------------------------------------- utilities
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_table(data_dir, filename, required=True):
    path = os.path.join(data_dir, filename)
    if not os.path.exists(path):
        if required:
            raise BuildError(
                f"required input missing: {filename}\n"
                f"  looked in: {data_dir}\n"
                f"  v1.0.0 silently skipped missing inputs and shipped an empty "
                f"graph; this build refuses to."
            )
        return None, None
    df = pd.read_parquet(path) if filename.endswith(".parquet") else \
        pd.read_csv(path, encoding="utf-8-sig")
    if required and len(df) == 0:
        raise BuildError(f"required input is empty: {filename}")
    return df, path


def copy_df(conn, table, df, columns, tmpdir):
    """Load a DataFrame into an existing Kuzu table via COPY FROM.

    Full quoting is mandatory: classical Chinese commentary contains commas,
    quotes and newlines that break unquoted CSV. parallel=false is required for
    embedded newlines to be parsed correctly.
    """
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise BuildError(f"{table}: source is missing column(s) {missing}; "
                         f"available: {list(df.columns)}")
    out = df[columns].copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].fillna("")
    csv_path = os.path.join(tmpdir, f"_{table}.csv")
    out.to_csv(csv_path, index=False, quoting=csv.QUOTE_ALL)
    conn.execute(f'COPY {table} FROM "{csv_path}" {COPY_OPTS}')
    os.remove(csv_path)


def count_rows(conn, name, is_node):
    q = f"MATCH (n:{name}) RETURN count(n)" if is_node \
        else f"MATCH ()-[r:{name}]->() RETURN count(r)"
    return conn.execute(q).get_next()[0]


# ---------------------------------------------------------------- schema
def create_schema(conn):
    conn.execute("""CREATE NODE TABLE Version(
        version_id STRING, title STRING, author_raw STRING, witness_era STRING,
        edition STRING, category_tags STRING, lineage_branch STRING,
        resource_class STRING, is_source_witness BOOLEAN,
        source_filename STRING, is_fragment BOOLEAN,
        source_structural_unit_count INT64, aligned_laozi_chapter_count INT64,
        alignment_success_count INT64, unresolved_unit_count INT64,
        work_type STRING, textual_scope STRING, alignment_status STRING,
        unresolved_reason STRING, work_type_reviewed BOOLEAN,
        PRIMARY KEY(version_id))""")

    conn.execute("""CREATE NODE TABLE Person(
        person_id STRING, canonical_name STRING, entity_status STRING,
        person_historical_era STRING, person_historical_era_alt STRING,
        person_era_dates STRING, era_source STRING, era_confidence STRING,
        era_disputed BOOLEAN, era_reviewed BOOLEAN,
        PRIMARY KEY(person_id))""")

    conn.execute("""CREATE NODE TABLE ChapterInstance(
        instance_id STRING, version_id STRING, chapter_num INT64,
        raw_heading STRING, char_count INT64, order_in_doc INT64,
        segmentation_method STRING, segmentation_score DOUBLE,
        is_chapter_aligned BOOLEAN, analysis_default_include BOOLEAN,
        alignment_review_status STRING, anchor_coverage_score DOUBLE, identification_score DOUBLE,
        variant_detection_eligible BOOLEAN, variant_detection_run BOOLEAN,
        base_text_share_upper_bound DOUBLE, text_composition STRING,
        PRIMARY KEY(instance_id))""")

    conn.execute("""CREATE NODE TABLE Sentence(
        sentence_id STRING, instance_id STRING, version_id STRING, seq INT64,
        original_text STRING, normalized_text STRING,
        PRIMARY KEY(sentence_id))""")

    conn.execute("""CREATE NODE TABLE Variant(
        variant_id STRING, reference_text_id STRING, version_b STRING,
        chapter_num INT64, instance_id STRING, position INT64,
        change_type STRING, edit_op STRING, old_text STRING, new_text STRING,
        length_ratio DOUBLE, variant_detection_score DOUBLE, semantic_explanation STRING,
        scholar_validation STRING, manual_status STRING, variant_status STRING,
        detection_method STRING, reference_version_id STRING, explanation_source STRING,
        PRIMARY KEY(variant_id))""")

    conn.execute("""CREATE NODE TABLE PersonAlias(
        alias_key STRING, person_id STRING, alias STRING,
        alias_type STRING, note STRING,
        PRIMARY KEY(alias_key))""")

    conn.execute("""CREATE NODE TABLE Concept(
        concept_id STRING, name STRING, category STRING, subcategory STRING,
        definition_core STRING, is_seed BOOLEAN, node_type STRING,
        is_textually_attested BOOLEAN, attestation_note STRING,
        node_type_reviewed BOOLEAN,
        PRIMARY KEY(concept_id))""")

    conn.execute("""CREATE NODE TABLE Commentary(
        commentary_id STRING, version_id STRING, instance_id STRING,
        chapter_num INT64, commentator_raw STRING,
        commentary_witness_era STRING, commentator_historical_era STRING,
        commentator_person_id STRING,
        concept_id STRING, concept_name STRING, reliability STRING,
        extraction_method STRING, source_quote STRING, normalized_quote STRING,
        llm_interpretation STRING, text_provenance STRING,
        source_char_overlap DOUBLE, citable_as_quote BOOLEAN,
        source_match_scope STRING,
        PRIMARY KEY(commentary_id))""")

    conn.execute("""CREATE NODE TABLE Evidence(
        evidence_id STRING, source_type STRING, source_ref STRING,
        quote STRING, reliability STRING, quote_kind STRING,
        quote_is_verbatim BOOLEAN,
        PRIMARY KEY(evidence_id))""")

    conn.execute("""CREATE NODE TABLE ProvenanceAssertion(
        pa_id STRING, version_a STRING, version_b STRING,
        relation_type STRING, confidence STRING, assertion_basis STRING,
        asserter STRING, reliability STRING, notes STRING,
        PRIMARY KEY(pa_id))""")

    # NOTE: v1.0.0's prebuilt graph spelled this ScholaryClaimEvidence while its
    # build script spelled it ScholarlyClaimEvidence. Standardized here.
    conn.execute("""CREATE NODE TABLE CandidateScholarlyClaim(
        sc_id STRING, claim_text STRING, domain STRING, proponents STRING,
        opponents STRING, scholarly_consensus STRING, confidence STRING,
        related_versions STRING, generated_by STRING, claim_status STRING,
        citable_as_scholarship BOOLEAN, review_required BOOLEAN,
        usage_restriction STRING,
        PRIMARY KEY(sc_id))""")

    conn.execute("""CREATE NODE TABLE CandidateScholarlyClaimEvidence(
        evidence_id STRING, sc_id STRING, side STRING,
        evidence_text STRING, reliability STRING, claim_status STRING,
        PRIMARY KEY(evidence_id))""")

    for stmt in [
        "CREATE REL TABLE HAS_INSTANCE(FROM Version TO ChapterInstance)",
        "CREATE REL TABLE HAS_SENTENCE(FROM ChapterInstance TO Sentence)",
        "CREATE REL TABLE HAS_VARIANT(FROM ChapterInstance TO Variant)",
        "CREATE REL TABLE VARIANT_AGAINST(FROM Variant TO Version)",
        "CREATE REL TABLE AUTHORED_BY(FROM Version TO Person, role_raw STRING, "
        "is_attributed BOOLEAN, attribution_status STRING)",
        "CREATE REL TABLE ANNOTATED_BY(FROM Version TO Person, role_raw STRING, "
        "is_attributed BOOLEAN, attribution_status STRING)",
        "CREATE REL TABLE MENTIONS_CONCEPT(FROM ChapterInstance TO Concept, "
        "mention_count INT64, sentence_count INT64, match_specificity STRING, "
        "alignment_review_status STRING)",
        "CREATE REL TABLE HAS_ALIAS(FROM Person TO PersonAlias)",
        "CREATE REL TABLE GLOSSES(FROM Commentary TO Concept)",
        "CREATE REL TABLE INTERPRETS(FROM Commentary TO ChapterInstance)",
        "CREATE REL TABLE COMMENTARY_OF(FROM Commentary TO Version)",
        "CREATE REL TABLE HAS_EVIDENCE(FROM Commentary TO Evidence)",
        "CREATE REL TABLE CONCEPT_LOCUS(FROM Concept TO ChapterInstance)",
        "CREATE REL TABLE RELATED_CONCEPT(FROM Concept TO Concept, "
        "relation_type STRING, relation_category STRING, source STRING, reviewed BOOLEAN)",
        "CREATE REL TABLE PA_ASSERTS_A(FROM ProvenanceAssertion TO Version)",
        "CREATE REL TABLE PA_ASSERTS_B(FROM ProvenanceAssertion TO Version)",
        "CREATE REL TABLE CLAIM_EVIDENCE(FROM CandidateScholarlyClaim "
        "TO CandidateScholarlyClaimEvidence)",
    ]:
        conn.execute(stmt)


# ---------------------------------------------------------------- build
def build(data_dir, db_path):
    if os.path.exists(db_path):
        shutil.rmtree(db_path) if os.path.isdir(db_path) else os.remove(db_path)
    for suffix in (".wal", ".lock", ".tmp"):
        side = db_path + suffix
        if os.path.exists(side):
            os.remove(side)
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)

    inputs = {}

    def load(filename, required=True):
        df, path = read_table(data_dir, filename, required=required)
        if path:
            inputs[filename] = sha256_file(path)
        return df

    versions = load("versions.csv")
    persons = load("persons.csv")
    authorship = load("authorship_edges.csv")
    concepts = load("concepts.csv")
    concept_loci = load("concept_canonical_chapters.csv")
    concept_rel = load("concept_relations.csv", required=False)
    chapters = load("chapter_instances.parquet")
    sentences = load("sentences.parquet")
    variants = load("variants.parquet")
    commentary = load("commentary.csv")
    comm_links = load("commentary_concept_links.csv")
    evidence = load("evidence.parquet")
    mentions = load("concept_chapter_mentions.csv")
    mentions["alignment_review_status"] = "original_deterministic"
    # mentions from unreviewed automatic recoveries are loaded too, but every
    # edge says so — a Cypher default should filter on the property
    rec = load("concept_recovered_mentions.csv", required=False)
    if rec is not None and len(rec):
        rec["alignment_review_status"] = "auto_recovered_unreviewed"
        mentions = pd.concat([mentions, rec], ignore_index=True)
    prov = load("provenance_assertions.csv")
    # version_provenance_edges.csv is deliberately NOT loaded. v1.1.0 read it and
    # hashed it into the build report but never wrote its edges to the graph,
    # while query_api queried a SAME_WORK_EDITION table that no build ever
    # created — an input that was read but unused, which makes the input hash
    # list misleading about what the graph actually depends on.
    # ProvenanceAssertion (PA_ASSERTS_A / PA_ASSERTS_B) is the supported
    # mechanism; the legacy file now lives under legacy/.
    claims = load(os.path.join("..", "derived_unverified", "candidate_scholarly_claims.csv"))
    claim_ev = load(os.path.join("..", "derived_unverified", "candidate_scholarly_claim_evidence.csv"))

    db = kuzu.Database(db_path)
    conn = kuzu.Connection(db)
    create_schema(conn)

    tmpdir = tempfile.mkdtemp(prefix="laozikg_build_")
    try:
        # ---- nodes ----
        copy_df(conn, "Version", versions, [
            "version_id", "title", "author_raw", "witness_era_normalized", "edition",
            "category_tags", "lineage_branch", "resource_class",
            "is_source_witness", "source_filename", "is_fragment",
            "source_structural_unit_count", "aligned_laozi_chapter_count",
            "alignment_success_count", "unresolved_unit_count", "work_type",
            "textual_scope", "alignment_status", "unresolved_reason",
            "work_type_reviewed"], tmpdir)

        copy_df(conn, "Person", persons,
                ["person_id", "canonical_name", "entity_status",
                 "person_historical_era", "person_historical_era_alt",
                 "person_era_dates", "era_source", "era_confidence",
                 "era_disputed", "era_reviewed"], tmpdir)

        aliases = load("person_aliases.csv")
        if aliases is not None and len(aliases):
            aliases = aliases.copy()
            aliases["alias_key"] = (aliases["person_id"].astype(str) + "|"
                                    + aliases["alias"].astype(str))
            copy_df(conn, "PersonAlias", aliases,
                    ["alias_key", "person_id", "alias", "alias_type", "note"], tmpdir)

        copy_df(conn, "ChapterInstance", chapters, [
            "instance_id", "version_id", "chapter_num", "raw_heading",
            "char_count", "order_in_doc", "segmentation_method", "segmentation_score",
            "is_chapter_aligned", "analysis_default_include", "alignment_review_status",
            "anchor_coverage_score", "identification_score",
            "variant_detection_eligible", "variant_detection_run",
            "base_text_share_upper_bound", "text_composition"], tmpdir)

        copy_df(conn, "Sentence", sentences, [
            "sentence_id", "instance_id", "version_id", "seq",
            "original_text", "normalized_text"], tmpdir)

        copy_df(conn, "Variant", variants, [
            "variant_id", "reference_text_id", "version_b", "chapter_num", "instance_id",
            "position", "change_type", "edit_op", "old_text", "new_text",
            "length_ratio", "variant_detection_score", "semantic_explanation",
            "scholar_validation", "manual_status", "variant_status",
            "detection_method", "reference_version_id", "explanation_source"], tmpdir)

        copy_df(conn, "Concept", concepts, [
            "concept_id", "name", "category", "subcategory", "definition_core",
            "is_seed", "node_type", "is_textually_attested", "attestation_note",
            "node_type_reviewed"], tmpdir)

        copy_df(conn, "Commentary", commentary, [
            "commentary_id", "version_id", "instance_id", "chapter_num",
            "commentator_raw", "commentary_witness_era",
            "commentator_historical_era", "commentator_person_id",
            "concept_id", "concept_name", "reliability",
            "extraction_method", "source_quote", "normalized_quote",
            "llm_interpretation", "text_provenance", "source_char_overlap",
            "citable_as_quote", "source_match_scope"], tmpdir)

        copy_df(conn, "Evidence", evidence, [
            "evidence_id", "source_type", "source_ref", "quote", "reliability",
            "quote_kind", "quote_is_verbatim"], tmpdir)

        copy_df(conn, "ProvenanceAssertion", prov, [
            "pa_id", "version_a", "version_b", "relation_type", "confidence",
            "assertion_basis", "asserter", "reliability", "notes"], tmpdir)

        copy_df(conn, "CandidateScholarlyClaim", claims, [
            "sc_id", "claim_text", "domain", "proponents", "opponents",
            "scholarly_consensus", "confidence", "related_versions",
            "generated_by", "claim_status", "citable_as_scholarship",
            "review_required", "usage_restriction"], tmpdir)

        copy_df(conn, "CandidateScholarlyClaimEvidence", claim_ev, [
            "evidence_id", "sc_id", "side", "evidence_text", "reliability",
            "claim_status"], tmpdir)

        # ---- relationships (filtered to existing endpoints) ----
        vids = set(versions["version_id"].astype(str))
        pids = set(persons["person_id"].astype(str))
        iids = set(chapters["instance_id"].astype(str))
        cids = set(concepts["concept_id"].astype(str))
        mids = set(commentary["commentary_id"].astype(str))

        def edge(table, df, a, b, extra=(), a_ok=None, b_ok=None):
            e = df[[a, b, *extra]].dropna(subset=[a, b]).copy()
            e[a] = e[a].astype(str)
            e[b] = e[b].astype(str)
            if a_ok is not None:
                e = e[e[a].isin(a_ok)]
            if b_ok is not None:
                e = e[e[b].isin(b_ok)]
            e = e.drop_duplicates(subset=[a, b] if not extra else None)
            copy_df(conn, table, e, [a, b, *extra], tmpdir)

        edge("HAS_INSTANCE", chapters, "version_id", "instance_id",
             a_ok=vids, b_ok=iids)
        edge("HAS_SENTENCE", sentences, "instance_id", "sentence_id",
             a_ok=iids)
        edge("HAS_VARIANT", variants, "instance_id", "variant_id", a_ok=iids)
        edge("VARIANT_AGAINST", variants, "variant_id", "version_b", b_ok=vids)

        auth = authorship.copy()
        if "attribution_status" not in auth.columns:
            auth["attribution_status"] = "named"
        # edge_type vocabulary is lowercase ('authored' / 'annotated'); v1.0.0
        # additionally contained uppercase variants, normalized upstream.
        edge_type_map = {"authored": "AUTHORED_BY", "annotated": "ANNOTATED_BY"}
        unknown = sorted(set(auth["edge_type"].dropna().astype(str)) - set(edge_type_map))
        if unknown:
            raise BuildError(
                f"authorship_edges.csv has unmapped edge_type value(s): {unknown}; "
                f"expected one of {sorted(edge_type_map)}")
        for etype, table in edge_type_map.items():
            sub = auth[auth["edge_type"] == etype]
            if len(sub):
                edge(table, sub, "version_id", "person_id",
                     extra=("role_raw", "is_attributed", "attribution_status"),
                     a_ok=vids, b_ok=pids)

        edge("MENTIONS_CONCEPT", mentions, "instance_id", "concept_id",
             extra=("mention_count", "sentence_count", "match_specificity", "alignment_review_status"),
             a_ok=iids, b_ok=cids)
        if aliases is not None and len(aliases):
            edge("HAS_ALIAS", aliases, "person_id", "alias_key",
                 a_ok=pids, b_ok=set(aliases["alias_key"].astype(str)))

        edge("GLOSSES", comm_links, "commentary_id", "concept_id",
             a_ok=mids, b_ok=cids)
        edge("INTERPRETS", commentary, "commentary_id", "instance_id",
             a_ok=mids, b_ok=iids)
        edge("COMMENTARY_OF", commentary, "commentary_id", "version_id",
             a_ok=mids, b_ok=vids)
        edge("HAS_EVIDENCE", evidence, "source_ref", "evidence_id", a_ok=mids)

        # Concept -> ChapterInstance loci, expanded from the canonical chapter table
        loci = concept_loci.merge(
            chapters[chapters["chapter_num"] != -1][["instance_id", "chapter_num"]],
            on="chapter_num", how="inner")
        edge("CONCEPT_LOCUS", loci, "concept_id", "instance_id",
             a_ok=cids, b_ok=iids)

        if concept_rel is not None and len(concept_rel):
            edge("RELATED_CONCEPT", concept_rel, "concept_id_a", "concept_id_b",
                 extra=("relation_type", "relation_category", "source", "reviewed"),
                 a_ok=cids, b_ok=cids)

        pa_ids = set(prov["pa_id"].astype(str))
        edge("PA_ASSERTS_A", prov, "pa_id", "version_a", a_ok=pa_ids, b_ok=vids)
        edge("PA_ASSERTS_B", prov, "pa_id", "version_b", a_ok=pa_ids, b_ok=vids)
        edge("CLAIM_EVIDENCE", claim_ev, "sc_id", "evidence_id",
             a_ok=set(claims["sc_id"].astype(str)))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    # ---- provenance report ----
    # Enumerate tables from the database rather than a hardcoded list. A literal
    # list silently omits any table added later: PersonAlias/HAS_ALIAS were
    # created and populated but absent from the report (and from the
    # empty-table check) until this was introspected instead.
    node_tables, rel_tables = [], []
    _t = conn.execute("CALL show_tables() RETURN *")
    while _t.has_next():
        _row = _t.get_next()
        _name = _row[1]
        _kind = str(_row[2]).upper()
        (node_tables if _kind.startswith("NODE") else rel_tables).append(_name)
    node_tables.sort()
    rel_tables.sort()
    if not node_tables or not rel_tables:
        raise BuildError("schema introspection returned no tables; refusing to "
                         "emit a build report that would look complete")

    counts = {t: int(count_rows(conn, t, True)) for t in node_tables}
    counts.update({t: int(count_rows(conn, t, False)) for t in rel_tables})

    empty_nodes = [t for t in node_tables if counts[t] == 0]
    conn.close()
    db.close()

    if empty_nodes:
        raise BuildError(
            "build produced empty node table(s): " + ", ".join(empty_nodes) +
            "\n  this is the v1.0.0 failure mode and is now treated as fatal.")

    report = {
        "schema_version": SCHEMA_VERSION,
        "built_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "db_path": os.path.relpath(db_path, start=os.path.dirname(
            os.path.abspath(os.path.join(data_dir, os.pardir)))),
        "node_counts": {t: counts[t] for t in node_tables},
        "relationship_counts": {t: counts[t] for t in rel_tables},
        "input_sha256": inputs,
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "kuzu": getattr(kuzu, "__version__", "unknown"),
            "pandas": pd.__version__,
        },
    }
    report_path = os.path.join(os.path.dirname(os.path.abspath(db_path)),
                               "build_report.json")
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)

    print(f"schema_version {SCHEMA_VERSION}  built {report['built_at_utc']}")
    print("nodes:")
    for t in node_tables:
        print(f"  {t:<34}{counts[t]:>9,}")
    print("relationships:")
    for t in rel_tables:
        print(f"  {t:<34}{counts[t]:>9,}")
    print(f"build report -> {report_path}")
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--db-path", default=os.path.join("data", "graph", "laozi_kg.kuzu"))
    args = ap.parse_args()
    try:
        build(args.data_dir, args.db_path)
    except BuildError as exc:
        print(f"BUILD FAILED: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
