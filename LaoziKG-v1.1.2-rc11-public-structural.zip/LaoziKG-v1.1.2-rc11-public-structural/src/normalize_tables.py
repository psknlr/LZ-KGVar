"""LaoziKG — Stage 1: schema & field normalization.

Reads the v1.0.0 release tables and emits normalized v1.1.0 tables.

Fixes applied here (see docs/provenance.md for the full audit trail):
  N1  strip `ci.` / `c.` column prefixes; one canonical name per table
  N2  drop duplicate siblings (chapters.csv == chapter_instances.parquet)
  N3  replace chapter_count_attested/_total with four unambiguous fields
  N4  canonical_chapters -> normalized concept_canonical_chapters.csv
  N5  mark long-numeric version_ids as string-unsafe for spreadsheet import
  N6  ScholaryClaimEvidence -> ScholarlyClaimEvidence (typo in v1.0.0)
  N7  rebuild commentary->concept links using ONLY self-consistent edges
      (v1.0.0's commentary_glosses.parquet fanned 2,635 records into 10,715
       rows, of which 8,080 asserted a gloss on a concept the record does
       not gloss; those edges are dropped, not carried forward)

Usage:  python src/normalize_tables.py --src <v1.0.0 data dir> --out <v1.1.0 data dir>
"""
import argparse
import json
import os
import re

import pandas as pd

PREFIX_RE = re.compile(r"^(ci|c|v|sc|pa)\.")


def strip_prefixes(df):
    """N1: remove table-alias column prefixes left over from Cypher exports."""
    df = df.copy()
    df.columns = [PREFIX_RE.sub("", col) for col in df.columns]
    return df


def normalize_versions(versions, chapter_instances):
    """
    N3: chapter_count_attested / chapter_count_total in v1.0.0 conflated two
    different quantities, which is why 132/176 rows disagreed with the actual
    chapter-instance counts. They are separated here:

      source_structural_unit_count  the source's OWN structural units (卷/節/章
                                    headings as recorded bibliographically).
                                    Carried over from v1.0.0 chapter_count_total.
      aligned_laozi_chapter_count   distinct canonical Laozi chapters (1-81)
                                    this witness was aligned to.
      alignment_success_count       chapter instances that resolved to a chapter.
      unresolved_unit_count         chapter instances that did NOT resolve
                                    (chapter_num == -1).

    None of these is a rename of another: the first is bibliographic, the rest
    are computed from the alignment output.
    """
    v = versions.copy()
    ci = chapter_instances

    aligned = ci[ci["chapter_num"] != -1]
    canonical = aligned[aligned["chapter_num"].between(1, 81)]

    stats = pd.DataFrame({
        "aligned_laozi_chapter_count": canonical.groupby("version_id")["chapter_num"].nunique(),
        "alignment_success_count": aligned.groupby("version_id").size(),
        "unresolved_unit_count": ci[ci["chapter_num"] == -1].groupby("version_id").size(),
    })

    v = v.rename(columns={"chapter_count_total": "source_structural_unit_count"})
    v = v.drop(columns=["chapter_count_attested"], errors="ignore")
    v = v.merge(stats, how="left", left_on="version_id", right_index=True)

    for col in ["aligned_laozi_chapter_count", "alignment_success_count", "unresolved_unit_count"]:
        v[col] = v[col].fillna(0).astype("int64")
    v["source_structural_unit_count"] = v["source_structural_unit_count"].fillna(0).astype("int64")

    # N5: 15+ digit ids lose precision in Excel/Sheets on import.
    v["id_is_numeric_string"] = v["version_id"].astype(str).str.fullmatch(r"\d{15,}")

    return v


def normalize_concepts(concepts):
    """
    N4: canonical_chapters arrived in two serializations ("[33, 44, 46]" and
    "15,19,28,32,37"). Parse both, drop the column, and return a tidy
    concept_id x chapter_num relation table alongside the cleaned concepts.
    """
    c = concepts.copy()
    rows = []
    for _, row in c.iterrows():
        raw = row.get("canonical_chapters")
        if raw is None or (isinstance(raw, float) and pd.isna(raw)):
            continue
        nums = [int(n) for n in re.findall(r"\d+", str(raw))]
        for n in nums:
            if 1 <= n <= 81:
                rows.append({
                    "concept_id": row["concept_id"],
                    "chapter_num": n,
                    "relation": "CANONICAL_LOCUS",
                    "evidence": "curated_concept_definition",
                })
    canonical_tbl = pd.DataFrame(rows).drop_duplicates()
    c = c.drop(columns=["canonical_chapters"], errors="ignore")
    return c, canonical_tbl


def rebuild_commentary_concept_links(commentary_glosses, commentary):
    """
    N7: v1.0.0 shipped commentary_glosses.parquet as the GLOSSES edge source.
    It contained 10,715 rows for 2,635 commentary records because each record
    was cross-joined against many concepts; only rows where
    glossed_concept_id == concept_id express what the record actually glosses.

    Returns (links, dropped_count) keeping only self-consistent edges.
    """
    cg = commentary_glosses
    if "glossed_concept_id" not in cg.columns:
        links = commentary[["commentary_id", "concept_id"]].drop_duplicates()
        return links, 0

    keep = cg[cg["glossed_concept_id"] == cg["concept_id"]]
    dropped = len(cg) - len(keep)
    links = (keep[["commentary_id", "glossed_concept_id"]]
             .rename(columns={"glossed_concept_id": "concept_id"})
             .drop_duplicates())
    return links, dropped


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="v1.0.0 data directory")
    ap.add_argument("--out", required=True, help="v1.1.0 data output directory")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    report = {}

    # ---- load (prefer parquet where CSV/parquet siblings are identical) ----
    versions = pd.read_csv(os.path.join(args.src, "versions.csv"), encoding="utf-8-sig")
    persons = pd.read_csv(os.path.join(args.src, "persons.csv"), encoding="utf-8-sig")
    authorship = pd.read_csv(os.path.join(args.src, "authorship_edges.csv"), encoding="utf-8-sig")
    concepts = pd.read_csv(os.path.join(args.src, "concepts.csv"), encoding="utf-8-sig")
    claims = pd.read_csv(os.path.join(args.src, "scholarly_claims.csv"), encoding="utf-8-sig")
    claim_ev = pd.read_csv(os.path.join(args.src, "scholarly_claim_evidence.csv"), encoding="utf-8-sig")
    prov = pd.read_csv(os.path.join(args.src, "provenance_assertions.csv"), encoding="utf-8-sig")
    ver_prov = pd.read_csv(os.path.join(args.src, "version_provenance_edges.csv"), encoding="utf-8-sig")

    chapter_instances = strip_prefixes(pd.read_parquet(os.path.join(args.src, "chapter_instances.parquet")))
    sentences = strip_prefixes(pd.read_parquet(os.path.join(args.src, "sentences.parquet")))
    variants = strip_prefixes(pd.read_parquet(os.path.join(args.src, "variants.parquet")))
    evidence = strip_prefixes(pd.read_parquet(os.path.join(args.src, "evidence.parquet")))
    commentary = strip_prefixes(pd.read_csv(os.path.join(args.src, "commentary.csv"), encoding="utf-8-sig"))
    commentary_glosses = strip_prefixes(pd.read_parquet(os.path.join(args.src, "commentary_glosses.parquet")))
    mentions = strip_prefixes(pd.read_csv(os.path.join(args.src, "concept_chapter_mentions.csv"), encoding="utf-8-sig"))

    # ---- N2: confirm the duplicate sibling really is a duplicate before dropping ----
    chapters_csv_path = os.path.join(args.src, "chapters.csv")
    if os.path.exists(chapters_csv_path):
        chapters_csv = strip_prefixes(pd.read_csv(chapters_csv_path, encoding="utf-8-sig"))
        same_shape = chapters_csv.shape == chapter_instances.shape
        same_ids = set(chapters_csv["instance_id"]) == set(chapter_instances["instance_id"])
        report["chapters_csv_is_duplicate_of_parquet"] = bool(same_shape and same_ids)

    # ---- N3 ----
    # N7  drop heading-only phantom instances: an ALIGNED chapter instance with
    # zero sentence rows carries no text, so it inflates alignment counts while
    # contributing nothing to mentions, variants or commentary. The one known
    # case is 7489099792547577906-CH006 (吳鼐《老子解》), whose heading
    # 谷神不死天長地久 (8 chars; CH007 is headed 谷神不死至天長地久) shows the edition
    # merges chapters 6–7 under one heading; the body sits in
    # CH007. Removed rows are logged to _dropped_phantom_instances.csv.
    has_text = set(sentences["instance_id"])
    phantom = (chapter_instances["chapter_num"] != -1) & ~chapter_instances["instance_id"].isin(has_text)
    if phantom.any():
        chapter_instances.loc[phantom, ["instance_id", "version_id", "chapter_num", "raw_heading",
                                        "char_count"]].to_csv(
            os.path.join(args.out, "_dropped_phantom_instances.csv"), index=False, encoding="utf-8-sig")
        print(f"  N7 dropped {int(phantom.sum())} heading-only phantom instance(s): "
              f"{chapter_instances.loc[phantom, 'instance_id'].tolist()}")
        chapter_instances = chapter_instances[~phantom].reset_index(drop=True)

    # The v1.0.0 segmenter's `confidence` is an uncalibrated heuristic (heading
    # match / content-anchor coverage), not P(correct). rc3 already stopped
    # writing it for recovered instances; rc4 renames it everywhere so no
    # consumer can read any instance-level score as a probability.
    if "confidence" in chapter_instances.columns:
        chapter_instances = chapter_instances.rename(columns={"confidence": "segmentation_score"})

    versions_n = normalize_versions(versions, chapter_instances)
    report["versions_rows"] = len(versions_n)
    report["chapter_count_fields_replaced"] = [
        "chapter_count_attested", "chapter_count_total"
    ]

    # ---- N4 ----
    concepts_n, concept_canonical = normalize_concepts(concepts)
    report["concepts_rows"] = len(concepts_n)
    report["concept_canonical_chapter_rows"] = len(concept_canonical)

    # ---- N7 ----
    links, dropped = rebuild_commentary_concept_links(commentary_glosses, commentary)
    report["commentary_concept_links_kept"] = len(links)
    report["spurious_glosses_edges_dropped"] = int(dropped)

    # ---- N6: table-name typo is fixed in build_graph.py; note it here ----
    report["renamed_table"] = {"ScholaryClaimEvidence": "ScholarlyClaimEvidence"}

    # ---- write ----
    def w(df, name):
        if name.endswith(".parquet"):
            df.to_parquet(os.path.join(args.out, name), index=False)
        else:
            df.to_csv(os.path.join(args.out, name), index=False, encoding="utf-8-sig")

    w(versions_n, "versions.csv")
    w(persons, "persons.csv")
    w(authorship, "authorship_edges.csv")
    w(concepts_n, "concepts.csv")
    w(concept_canonical, "concept_canonical_chapters.csv")
    w(chapter_instances, "chapter_instances.parquet")
    w(sentences, "sentences.parquet")
    # ---- variant layer: terminology and provenance (v1.1.2) -------------------
    # These are automatically detected CANDIDATE variant events from a difflib
    # comparison, not philologically confirmed 异文. The old `confidence` was a
    # 6-level heuristic score, not a probability; renamed accordingly.
    variants = variants.rename(columns={"confidence": "variant_detection_score",
                                        "version_a": "reference_text_id"})
    variants["variant_status"] = "candidate_auto_detected"
    variants["detection_method"] = "difflib_char_diff_v1.0.0"
    # reference_text_id == WANGBI_CANONICAL denotes the jingwen (base-text) layer
    # of WANGBI_TONGSHI_2026 (wangbi_exegesis_source.parquet), not a Version row.
    variants["reference_version_id"] = "WANGBI_TONGSHI_2026"
    variants["explanation_source"] = variants["semantic_explanation"].fillna("").map(
        lambda t: "minimax-m3_per_character_pair" if t else "")
    w(variants, "variants.parquet")

    # structural_mismatches.parquet: same generation-stage detector, same old
    # schema (version_a / confidence). Normalized identically so the two files
    # share one vocabulary, and flagged as a diagnostic (spans too long to be
    # character-level variants — commentary bleed / misalignment candidates).
    sm_p = os.path.join(args.src, "structural_mismatches.parquet")
    if os.path.exists(sm_p):
        sm = strip_prefixes(pd.read_parquet(sm_p))
        sm = sm.rename(columns={"confidence": "variant_detection_score", "version_a": "reference_text_id"})
        sm["variant_status"] = "structural_mismatch_diagnostic"
        sm["detection_method"] = "difflib_char_diff_v1.0.0"
        sm["reference_version_id"] = "WANGBI_TONGSHI_2026"
        sm["explanation_source"] = sm["semantic_explanation"].fillna("").map(
            lambda t: "minimax-m3_per_character_pair" if t else "") if "semantic_explanation" in sm.columns else ""
        # NOT a canonical data layer: same detector as variants, but the diff spans
        # are too long to be character-level variants. Kept out of data/ so it
        # cannot be mistaken for, or double-counted with, the variant layer.
        dd = os.path.join(os.path.dirname(os.path.abspath(args.out)), "derived_diagnostics")
        os.makedirs(dd, exist_ok=True)
        sm.to_parquet(os.path.join(dd, "structural_mismatches.parquet"), index=False)
    w(commentary, "commentary.csv")
    w(links, "commentary_concept_links.csv")
    w(evidence, "evidence.parquet")
    w(mentions, "concept_chapter_mentions.csv")
    # Epistemic-status flags: these are machine-generated summaries, never
    # reviewed. Every row says so in five separate fields so no single column
    # can be dropped and leave the table looking like scholarship.
    claims["claim_status"] = "AI_GENERATED_UNVERIFIED"
    claims["verified_by"] = ""
    claims["verified_date"] = ""
    claims["review_required"] = True
    claims["citable_as_scholarship"] = False
    claims["usage_restriction"] = ("Starting point for literature search only. Named "
                                   "proponents/opponents unchecked; do not cite.")
    claim_ev["claim_status"] = "AI_GENERATED_UNVERIFIED"
    w(claims, "candidate_scholarly_claims.csv")
    w(claim_ev, "candidate_scholarly_claim_evidence.csv")
    w(prov, "provenance_assertions.csv")
    # version_provenance_edges.csv is NOT a canonical graph input: build_graph
    # hashed it but never wrote its edges, and no SAME_WORK_EDITION table was
    # ever created. ProvenanceAssertion supersedes it. Kept as legacy only.
    _legacy = os.path.join(os.path.dirname(os.path.abspath(args.out)), "legacy")
    if os.path.isdir(_legacy):
        ver_prov.to_csv(os.path.join(_legacy, "version_provenance_edges.csv"),
                        index=False, encoding="utf-8-sig")
    # otherwise (clean-room run) the ghost input is simply not emitted

    with open(os.path.join(args.out, "_normalize_report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)

    for key, value in report.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
