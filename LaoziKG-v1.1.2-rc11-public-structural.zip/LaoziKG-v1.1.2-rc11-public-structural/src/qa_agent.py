#!/usr/bin/env python3
"""Laozi KG QA Agent - rule-based question answering over the knowledge graph."""

import os
import re
import sys
from typing import Dict, List, Optional, Tuple

import pandas as pd
import kuzu

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.query_api import LaoziKG


class LaoziQAAgent:
    """Rule-based QA agent for the Laozi knowledge graph."""

    DEFAULT_DB = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'data', 'graph', 'laozi_kg.kuzu'
    )

    SEED_CONCEPTS = list("道德无有自然玄虚静朴柔水谷母一反复知言信仁义礼智欲争常恒妙微圣民国兵法命性心") + \
                     ["无为", "大象", "天地", "阴阳", "气", "神", "恍惚", "窈冥", "冲", "盈"]

    INTENT_PATTERNS = [
        (r'第(\d+)章.*?(?:异文|差异|不同|版本|有哪些异)', 'variant_comparison'),
        (r'(?:异文|差异|版本差异|校勘|异体).*?第(\d+)章', 'variant_comparison'),
        (r'第(\d+)章.*?有哪些.*?(?:异文|差异|不同)', 'variant_comparison'),
        (r'([\u4e00-\u9fff]{1,4})(?:字)?(?:有哪些|的)?(?:异体|通假|古字|异文)', 'variant_comparison'),
        (r'([\u4e00-\u9fff]{1,4})[和与及]([\u4e00-\u9fff]{1,2})(?:有什么|的|之)?(?:关系|联系|区别|异同|怎样)', 'concept_relation'),
        (r'([\u4e00-\u9fff]{2,4})(?:怎么|如何)(?:注|解释|说|认为)([\u4e00-\u9fff]{1,4})', 'commentator_query'),
        (r'([\u4e00-\u9fff]{2,4})如何(?:注|解释|说|认为)', 'commentator_query'),
        (r'([\u4e00-\u9fff]{1,4})(?:是|的)什么(?:意思|含义|定义|概念)', 'concept_definition'),
        (r'([\u4e00-\u9fff]{1,4})(?:是|的)什么', 'concept_definition'),
        (r'什么(?:是|叫|叫做|称为)([\u4e00-\u9fff]{1,4})', 'concept_definition'),
        (r'(?:什么|是何|何为|含义|意思|定义|指的是).*?([\u4e00-\u9fff]{1,4})', 'concept_definition'),
        (r'([\u4e00-\u9fff]{1,4})(?:有|是)什么(?:意思|含义)', 'concept_definition'),
        (r'([\u4e00-\u9fff]{1,4})什么(?:意思|含义|定义)', 'concept_definition'),
        (r'(?:如何|怎样|怎么).*?(?:理解|解释|看待|认识).*?([\u4e00-\u9fff]{1,4})', 'concept_interpretation'),
        (r'([\u4e00-\u9fff]{1,4})(?:怎么|如何)(?:理解|解释|看待|认识)', 'concept_interpretation'),
        (r'(?:关于|对于)([\u4e00-\u9fff]{1,4}).*?(?:争议|分歧|不同看法)', 'scholarly_debate'),
        (r'(?:多少|几个|总数|统计)(?:版本|概念|章节|异文|注家|注释)', 'statistics'),
        (r'第(\d+)章.*?(?:原文|全文|内容)', 'chapter_text'),
        (r'(?:原文|全文|内容).*?第(\d+)章', 'chapter_text'),
        (r'([\u4e00-\u9fff]{1,4})的?(?:演变|流变|历史|发展)', 'concept_evolution'),
    ]

    def __init__(self, db_path: str = None, kg: LaoziKG = None):
        if kg is not None:
            self.kg = kg
            self.db_path = getattr(kg, 'db_path', db_path or self.DEFAULT_DB)
            self._owns_kg = False
        else:
            self.db_path = db_path or self.DEFAULT_DB
            self.kg = LaoziKG(self.db_path)
            self._owns_kg = True
        self._concept_cache = None

    def close(self):
        if self._owns_kg and self.kg:
            self.kg.close()

    @property
    def known_concepts(self) -> List[str]:
        if self._concept_cache is None:
            try:
                df = self.kg._query("MATCH (c:Concept) RETURN c.name AS name")
                self._concept_cache = df['name'].tolist() if len(df) > 0 else self.SEED_CONCEPTS
            except Exception:
                self._concept_cache = self.SEED_CONCEPTS
        return self._concept_cache

    def recognize_intent(self, question: str) -> Dict:
        question = question.strip()
        for pattern, intent in self.INTENT_PATTERNS:
            m = re.search(pattern, question)
            if m:
                entities = {}
                if intent in ('concept_definition', 'concept_interpretation', 'concept_evolution'):
                    matched = self._match_concept(m.group(1))
                    if matched:
                        entities['concept'] = matched
                elif intent == 'concept_relation':
                    matched_a = self._match_concept(m.group(1))
                    matched_b = self._match_concept(m.group(2))
                    if matched_a:
                        entities['concept_a'] = matched_a
                    if matched_b:
                        entities['concept_b'] = matched_b
                elif intent == 'variant_comparison':
                    if m.lastindex and m.lastindex >= 1:
                        try:
                            entities['chapter_num'] = int(m.group(1))
                        except (ValueError, IndexError):
                            entities['concept'] = self._match_concept(m.group(1))
                elif intent == 'commentator_query':
                    entities['commentator'] = m.group(1)
                    if m.lastindex and m.lastindex >= 2:
                        entities['concept'] = self._match_concept(m.group(2))
                    else:
                        entities['concept'] = self._extract_concept_from_question(question)
                elif intent == 'scholarly_debate':
                    entities['concept'] = self._match_concept(m.group(1))
                elif intent == 'chapter_text':
                    entities['chapter_num'] = int(m.group(1))
                elif intent == 'statistics':
                    entities['stat_type'] = question
                return {'intent': intent, 'entities': entities, 'raw_match': m.group(0)}
        return {'intent': 'unknown', 'entities': {}, 'raw_match': ''}

    def _match_concept(self, text: str) -> Optional[str]:
        if not text:
            return None
        for c in self.known_concepts:
            if text == c or text in c or c in text:
                return c
        if text in self.SEED_CONCEPTS:
            return text
        return None

    def _extract_concept_from_question(self, question: str) -> Optional[str]:
        for c in sorted(self.known_concepts, key=len, reverse=True):
            if c in question:
                return c
        return None

    def answer(self, question: str) -> Dict:
        parsed = self.recognize_intent(question)
        intent = parsed['intent']
        entities = parsed['entities']
        citations = []
        answer_text = ''
        dispatch = {
            'concept_definition': lambda: self._ans_concept(entities.get('concept', '')),
            'concept_interpretation': lambda: self._ans_concept(entities.get('concept', '')),
            'concept_evolution': lambda: self._ans_concept_evolution(entities.get('concept', '')),
            'concept_relation': lambda: self._ans_concept_relation(entities.get('concept_a', ''), entities.get('concept_b', '')),
            'variant_comparison': lambda: self._ans_variant(entities.get('chapter_num', 1)),
            'commentator_query': lambda: self._ans_commentator(entities.get('commentator', ''), entities.get('concept', '')),
            'scholarly_debate': lambda: self._ans_debate(entities.get('concept', '')),
            'statistics': lambda: self._ans_statistics(entities.get('stat_type', '')),
            'chapter_text': lambda: self._ans_chapter(entities.get('chapter_num', 1)),
        }
        h = dispatch.get(intent)
        if h:
            answer_text, citations = h()
        else:
            answer_text = (
                '抱歉，无法理解此问题。可尝试：概念定义/演变/异文对比/注家查询/争议/统计/原文'
            )
        return {
            'question': question,
            'intent': intent,
            'entities': entities,
            'answer_text': answer_text,
            'citations': citations
        }

    def _ans_concept(self, concept_name: str) -> Tuple[str, List[Dict]]:
        if not concept_name:
            return '未识别到概念名。', []
        history = self.kg.get_concept_history(concept_name)
        concept_df = history.get('concept', pd.DataFrame())
        glosses = history.get('glosses', pd.DataFrame())
        if len(concept_df) == 0:
            return f'未找到概念「{concept_name}」。', []
        parts = [f'## 概念：{concept_name}']
        row = concept_df.iloc[0]
        if 'description' in row and pd.notna(row.get('description')):
            parts.append(f'\n**释义**：{row["description"]}')
        if 'category' in row and pd.notna(row.get('category')):
            parts.append(f'\n**类别**：{row["category"]}')
        if len(glosses) > 0:
            show_n = min(10, len(glosses))
            parts.append(f'\n### 历代训解（共 {len(glosses)} 条，展示前 {show_n} 条）\n')
            for _, g in glosses.head(show_n).iterrows():
                era = g.get('commentator_historical_era', '')
                commentator = g.get('commentator', '')
                text = g.get('llm_interpretation', g.get('source_quote', ''))
                parts.append(f'- **{era}·{commentator}**：{text[:120]}{"..." if len(str(text)) > 120 else ""}')
        else:
            parts.append('\n暂无历代训解记录。')
        citations = self._build_citations(glosses) if len(glosses) > 0 else []
        return '\n'.join(parts), citations

    def _ans_concept_evolution(self, concept_name: str) -> Tuple[str, List[Dict]]:
        if not concept_name:
            return '未识别到概念名。', []
        history = self.kg.get_concept_history(concept_name)
        glosses = history.get('glosses', pd.DataFrame())
        if len(glosses) == 0:
            return f'概念「{concept_name}」暂无演变记录。', []
        eras = glosses['commentator_historical_era'].dropna().unique() if 'commentator_historical_era' in glosses.columns else []
        parts = [f'## 「{concept_name}」概念演变\n']
        parts.append(f'跨越 {len(eras)} 个时代，共 {len(glosses)} 条训解。\n')
        for era in eras:
            era_glosses = glosses[glosses['commentator_historical_era'] == era]
            parts.append(f'### {era}（{len(era_glosses)}条）')
            for _, g in era_glosses.iterrows():
                commentator = g.get('commentator', '')
                text = g.get('llm_interpretation', g.get('source_quote', ''))
                parts.append(f'- **{commentator}**：{text[:100]}{"..." if len(str(text)) > 100 else ""}')
            parts.append('')
        citations = self._build_citations(glosses)
        return '\n'.join(parts), citations

    def _ans_concept_relation(self, concept_a: str, concept_b: str) -> Tuple[str, List[Dict]]:
        if not concept_a or not concept_b:
            names = [n for n in [concept_a, concept_b] if n]
            if not names:
                return '未识别到概念名。', []
            return f'仅识别到概念「{names[0]}」，需要两个概念才能分析关系。', []
        history_a = self.kg.get_concept_history(concept_a)
        history_b = self.kg.get_concept_history(concept_b)
        glosses_a = history_a.get('glosses', pd.DataFrame())
        glosses_b = history_b.get('glosses', pd.DataFrame())
        parts = [f'## 「{concept_a}」与「{concept_b}」的关系\n']
        info_a = history_a.get('concept', pd.DataFrame())
        info_b = history_b.get('concept', pd.DataFrame())
        if not info_a.empty and 'definition_core' in info_a.columns:
            def_a = info_a.iloc[0].get('definition_core', '')
            if pd.notna(def_a) and def_a:
                parts.append(f'**{concept_a}**：{def_a}\n')
        if not info_b.empty and 'definition_core' in info_b.columns:
            def_b = info_b.iloc[0].get('definition_core', '')
            if pd.notna(def_b) and def_b:
                parts.append(f'**{concept_b}**：{def_b}\n')
        parts.append(f'\n### 「{concept_a}」训解（{len(glosses_a)}条）')
        if not glosses_a.empty:
            for _, g in glosses_a.head(10).iterrows():
                commentator = g.get('commentator', '')
                era = g.get('commentator_historical_era', '')
                text = g.get('llm_interpretation', g.get('source_quote', ''))
                parts.append(f'- **{era}·{commentator}**：{str(text)[:100]}{"..." if len(str(text)) > 100 else ""}')
        parts.append(f'\n### 「{concept_b}」训解（{len(glosses_b)}条）')
        if not glosses_b.empty:
            for _, g in glosses_b.head(10).iterrows():
                commentator = g.get('commentator', '')
                era = g.get('commentator_historical_era', '')
                text = g.get('llm_interpretation', g.get('source_quote', ''))
                parts.append(f'- **{era}·{commentator}**：{str(text)[:100]}{"..." if len(str(text)) > 100 else ""}')
        all_glosses = pd.concat([glosses_a, glosses_b], ignore_index=True) if not glosses_a.empty or not glosses_b.empty else pd.DataFrame()
        citations = self._build_citations(all_glosses) if not all_glosses.empty else []
        return '\n'.join(parts), citations

    def _ans_variant(self, chapter_num: int) -> Tuple[str, List[Dict]]:
        try:
            from src.variant_comparison import VariantComparator
            vc = VariantComparator(self.db_path)
            df = vc.compare_chapter(chapter_num)
            if len(df) == 0:
                return f'第{chapter_num}章暂无异文记录。', []
            parts = [f'## 第{chapter_num}章 异文对比\n']
            parts.append(f'共 {len(df)} 条异文。\n')
            parts.append('（自动检测的候选异文事件，未经校勘确认；对照文本为王弼本经文层）\n')
            for _, row in df.head(60).iterrows():
                era = f" [{row['witness_era']}]" if row.get("witness_era") else ""
                parts.append(
                    f'- **{row.get("version_id", "")}**{era}：'
                    f'「{row.get("old_text", "") or "∅"}」→「{row.get("new_text", "") or "∅"}」 '
                    f'(层次: {row.get("change_type", "")}; 操作: {row.get("edit_op", "")}; '
                    f'检测分: {row.get("variant_detection_score", "")})'
                )
            if len(df) > 60:
                parts.append(f'... 另有 {len(df) - 60} 条未列出。')
            citations = [
                {
                    'source': row.get('version_id', ''),
                    'chapter': chapter_num,
                    'text': f"{row.get('old_text', '')}→{row.get('new_text', '')}",
                    'type': 'candidate_variant_event'
                }
                for _, row in df.iterrows()
            ]
            return '\n'.join(parts), citations
        except Exception as e:
            return f'查询异文时出错：{e}', []

    def _ans_commentator(self, commentator: str, concept: str = '') -> Tuple[str, List[Dict]]:
        q = f"MATCH (com:Commentary) WHERE com.commentator_raw CONTAINS '{commentator}'"
        if concept:
            q += f" MATCH (com)-[:GLOSSES]->(c:Concept) WHERE c.name = '{concept}'"
        q += (" RETURN com.commentary_id AS id, com.version_id AS version_id,"
              " com.chapter_num AS chapter_num, com.commentator_raw AS commentator,"
              " com.commentator_historical_era AS commentator_historical_era,"
              " com.commentary_witness_era AS witness_era,"
              " com.source_quote AS source_quote,"
              " com.llm_interpretation AS llm_interpretation,"
              " com.citable_as_quote AS citable_as_quote,"
              " com.reliability AS reliability ORDER BY com.chapter_num")
        df = self.kg._query(q)
        if len(df) == 0:
            return f'未找到注家「{commentator}」的相关记录。', []
        parts = [f'## 注家：{commentator}（{len(df)}条）\n']
        for _, row in df.iterrows():
            text = str(row.get("source_quote") or row.get("llm_interpretation") or "")
            tag = "引文" if row.get("citable_as_quote") in (True, "True", "true") else "LLM释义"
            parts.append(
                f'- **第{row.get("chapter_num", "?")}章** '
                f'(注家时代: {row.get("commentator_historical_era", "") or "不详"}; '
                f'刊本时代: {row.get("witness_era", "") or "不详"}; {tag})：'
                f'{text[:120]}{"..." if len(text) > 120 else ""}'
            )
        citations = self._build_citations(df)
        return '\n'.join(parts), citations

    def _ans_debate(self, concept: str) -> Tuple[str, List[Dict]]:
        if not concept:
            return '未识别到争议概念。', []
        history = self.kg.get_concept_history(concept)
        glosses = history.get('glosses', pd.DataFrame())
        if len(glosses) < 2:
            return f'概念「{concept}」的训解记录不足，无法展示争议。', []
        parts = [f'## 关于「{concept}」的学术争议\n']
        by_commentator = glosses.groupby('commentator') if 'commentator' in glosses.columns else None
        if by_commentator is not None:
            for commentator, group in by_commentator:
                parts.append(f'### {commentator}（{len(group)}条）')
                for _, g in group.iterrows():
                    parts.append(f'- ({g.get("era", "")}) {g.get("llm_interpretation", "")[:100]}')
                parts.append('')
        citations = self._build_citations(glosses)
        return '\n'.join(parts), citations

    def _ans_statistics(self, stat_query: str) -> Tuple[str, List[Dict]]:
        tables = {
            '版本': ('Version', '版本'),
            '概念': ('Concept', '概念'),
            '章节': ('ChapterInstance', '章节实例'),
            '异文': ('Variant', '异文'),
            '注释': ('Commentary', '注释'),
            '句子': ('Sentence', '句子'),
        }
        results = []
        for keyword, (table, label) in tables.items():
            if keyword in stat_query or '所有' in stat_query or '全部' in stat_query:
                try:
                    df = self.kg._query(f"MATCH (n:{table}) RETURN count(*) AS cnt")
                    cnt = df.iloc[0]['cnt'] if len(df) > 0 else 0
                    results.append(f'- {label}：{cnt} 条')
                except Exception:
                    results.append(f'- {label}：查询失败')
        if not results:
            for keyword, (table, label) in tables.items():
                try:
                    df = self.kg._query(f"MATCH (n:{table}) RETURN count(*) AS cnt")
                    cnt = df.iloc[0]['cnt'] if len(df) > 0 else 0
                    results.append(f'- {label}：{cnt} 条')
                except Exception:
                    results.append(f'- {label}：查询失败')
        return '## 知识图谱统计\n\n' + '\n'.join(results), []

    def _ans_chapter(self, chapter_num: int) -> Tuple[str, List[Dict]]:
        q = f"""
        MATCH (v:Version)-[:HAS_CHAPTER]->(ch:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence)
        WHERE ch.chapter_num = {chapter_num}
        RETURN v.version_id AS version_id, v.short_name AS version_name,
               ch.chapter_num AS chapter_num, s.sentence_id AS sentence_id,
               s.text AS text, s.sentence_order AS sentence_order
        ORDER BY v.version_id, s.sentence_order
        """
        df = self.kg._query(q)
        if len(df) == 0:
            return f'第{chapter_num}章暂无原文记录。', []
        versions = df.groupby('version_id')
        parts = [f'## 第{chapter_num}章 原文\n']
        for version_id, group in versions:
            vname = group.iloc[0].get('version_name', version_id)
            text = ''.join(group.sort_values('sentence_order')['text'].tolist())
            parts.append(f'### {vname}\n{text}\n')
        citations = [
            {
                'source': version_id,
                'chapter': chapter_num,
                'text': ''.join(group.sort_values('sentence_order')['text'].tolist()),
                'type': 'chapter_text'
            }
            for version_id, group in versions
        ]
        return '\n'.join(parts), citations

    def _build_citations(self, df: pd.DataFrame) -> List[Dict]:
        if len(df) == 0:
            return []
        citations = []
        for _, row in df.iterrows():
            citations.append({
                'source': row.get('version_id', ''),
                'commentator': row.get('commentator', row.get('commentator_raw', '')),
                'commentator_historical_era': row.get('commentator_historical_era', ''),
                'chapter': row.get('chapter_num', ''),
                'text': str(row.get('llm_interpretation', row.get('source_quote', '')))[:200],
                'type': 'commentary'
            })
        return citations

    def interactive(self):
        print('=' * 60)
        print('  《老子》知识图谱问答系统')
        print('  输入问题进行查询，输入 quit/exit 退出')
        print('=' * 60)
        while True:
            try:
                q = input('\n问题> ').strip()
                if q.lower() in ('quit', 'exit', 'q'):
                    print('再见！')
                    break
                if not q:
                    continue
                result = self.answer(q)
                print(f'\n[意图: {result["intent"]}]')
                print(result['answer_text'])
                if result['citations']:
                    print(f'\n--- 引用 ({len(result["citations"])}条) ---')
                    for i, c in enumerate(result['citations'][:5], 1):
                        print(f'{i}. {c.get("source", "")} | {c.get("commentator", "")} | 第{c.get("chapter", "?")}章')
                        if c.get('text'):
                            print(f'   {c["text"][:80]}')
                    if len(result['citations']) > 5:
                        print(f'   ...还有 {len(result["citations"]) - 5} 条')
            except KeyboardInterrupt:
                print('\n再见！')
                break
            except Exception as e:
                print(f'错误：{e}')


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Laozi KG QA Agent')
    parser.add_argument('--db', default=None, help='Path to Kuzu database')
    parser.add_argument('-i', '--interactive', action='store_true', help='Interactive mode')
    parser.add_argument('-q', '--question', type=str, help='Single question')
    args = parser.parse_args()

    agent = LaoziQAAgent(args.db)
    if args.interactive:
        agent.interactive()
    elif args.question:
        result = agent.answer(args.question)
        print(f'[意图: {result["intent"]}]')
        print(result['answer_text'])
        if result['citations']:
            print(f'\n引用 ({len(result["citations"])}条):')
            for i, c in enumerate(result['citations'][:10], 1):
                print(f'{i}. {c.get("source", "")} | {c.get("commentator", "")} | 第{c.get("chapter", "?")}章')
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
