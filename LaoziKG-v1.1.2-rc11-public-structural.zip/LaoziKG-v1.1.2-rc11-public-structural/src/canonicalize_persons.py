"""LaoziKG — Stage 4: person entity canonicalization and era disentangling.

Two defects are fixed here, both found in the second-round audit.

1. `Person.era` was inherited from the linked witness's era, not the figure's own
   dates. It matched a linked version's era on 58.9% of authorship edges, and
   produced 老子 = 宋, 玄奘 = 宋, 唐玄宗 = 宋, 庄子 = 清. The field is renamed
   `person_historical_era` and repopulated from scholarship (see
   `person_eras.csv`); the witness's era stays on Version as `witness_era`.

2. Person names carried role tokens and attribution prefixes (王弼註, 傅奕校定,
   題河上公), a doubled name (徐學謨徐學謨), a version description mistaken for a
   person, and several duplicate identities for one figure (李隆基/唐玄宗,
   焦竑/焦竤, 老子/老聃/李耳). Roles belong on the authorship edge, not in the
   name. Surface forms are preserved in `person_aliases.csv`.

Usage: python src/canonicalize_persons.py --data data
"""
import argparse
import os
import re

import pandas as pd

# Role tokens that were parsed into the name. Longest-first so 校訂 is stripped
# before 校.
ROLE_SUFFIXES = ["校定", "校訂", "等人", "章句", "評選著", "評著",
                 "註", "注", "疏", "勘", "編", "輯", "撰", "校", "解"]
# Attribution prefixes: the source attributes the work to this figure, who may
# not be the actual author. The marker moves to the edge's is_attributed flag.
ATTRIB_PREFIXES = ["題", "託名", "传", "傳"]

# Identity merges. Each group maps surface forms -> canonical person_id.
# Only well-established identifications are listed; nothing is merged on
# orthographic similarity alone.
IDENTITY_GROUPS = {
    "P_LAOZI":     ["老子", "老聃", "李耳"],          # one figure, three names
    "P_XUANZONG":  ["李隆基", "唐玄宗"],               # given name / temple name
    "P_JIAOHONG":  ["焦竑", "焦竤"],                   # 竑/竤 variant graph
    "P_XUXUEMO":   ["徐學謨", "徐學謨徐學謨"],          # doubled-name parse error
    "P_HESHANGGONG": ["河上公", "題河上公"],           # attributed form
}

# Surface forms that are parser artefacts, not names anyone ever used. Kept as
# aliases only so the raw string remains traceable; alias_type = parse_error.
PARSE_ERRORS = {"徐學謨徐學謨"}

# Rows that are not persons at all.
NON_PERSON = re.compile(r"通释稿|通釋稿|校订|校訂本|据.*校|據.*校")


def strip_role(name):
    """Remove a trailing role token when a plausible name remains."""
    for suf in ROLE_SUFFIXES:
        if name.endswith(suf) and len(name) - len(suf) >= 2:
            return name[: -len(suf)], suf
    return name, None


def strip_attrib(name):
    for pre in ATTRIB_PREFIXES:
        if name.startswith(pre) and len(name) - len(pre) >= 2:
            return name[len(pre):], True
    return name, False


def canonicalize(data_dir):
    persons = pd.read_csv(os.path.join(data_dir, "persons.csv"), encoding="utf-8-sig")
    auth = pd.read_csv(os.path.join(data_dir, "authorship_edges.csv"), encoding="utf-8-sig")

    surface_to_canon = {}
    for pid, forms in IDENTITY_GROUPS.items():
        for f in forms:
            surface_to_canon[f] = pid

    alias_rows, canon_rows, report = [], {}, {
        "input_persons": len(persons), "non_person_dropped": 0,
        "role_token_stripped": 0, "attribution_prefix_stripped": 0,
        "identity_merges": 0,
    }

    for _, row in persons.iterrows():
        raw = str(row["name"]).strip()
        pid_in = str(row["person_id"])

        # placeholders pass through untouched
        if pid_in in ("ANONYMOUS", "UNKNOWN"):
            canon_rows[pid_in] = {"person_id": pid_in, "canonical_name": raw,
                                  "person_historical_era": "", "era_source": "placeholder",
                                  "era_reviewed": False, "entity_status": "placeholder"}
            alias_rows.append({"person_id": pid_in, "alias": raw,
                               "alias_type": "canonical", "note": ""})
            continue

        if NON_PERSON.search(raw):
            report["non_person_dropped"] += 1
            continue

        name, attributed = strip_attrib(raw)
        if attributed:
            report["attribution_prefix_stripped"] += 1
        name, role = strip_role(name)
        if role:
            report["role_token_stripped"] += 1

        canon_id = surface_to_canon.get(raw) or surface_to_canon.get(name)
        if canon_id:
            report["identity_merges"] += 1
        else:
            canon_id = "P_" + re.sub(r"[^\w\u4e00-\u9fff]", "", name)

        if canon_id not in canon_rows:
            # For a declared identity group the canonical name is the group's
            # FIRST entry, not whichever surface form the input happened to list
            # first — v1.1.1 shipped canonical_name = 徐學謨徐學謨 for that reason.
            canonical = (IDENTITY_GROUPS[canon_id][0] if canon_id in IDENTITY_GROUPS
                         else name)
            canon_rows[canon_id] = {
                "person_id": canon_id, "canonical_name": canonical,
                "person_historical_era": "", "era_source": "", "era_reviewed": False,
                "entity_status": "canonical",
            }
        alias_rows.append({
            "person_id": canon_id, "alias": raw,
            "alias_type": "parse_error" if raw in PARSE_ERRORS
                          else "canonical" if raw == canon_rows[canon_id]["canonical_name"]
                          else ("role_form" if role else
                                ("attributed_form" if attributed else "variant")),
            "note": f"role token '{role}' moved to edge" if role else
                    ("attribution prefix removed" if attributed else ""),
        })
        # remap authorship edges from the old id to the canonical id
        auth.loc[auth["person_id"] == pid_in, "_canon"] = canon_id
        auth.loc[auth["person_id"] == pid_in, "_role_from_name"] = role or ""
        auth.loc[auth["person_id"] == pid_in, "_attrib_from_name"] = bool(attributed)

    persons_out = pd.DataFrame(canon_rows.values())
    # every canonical person must have an alias row equal to its canonical_name,
    # otherwise the alias table does not satisfy its own definition ("every
    # surface form"). v1.1.2-rc2 lacked this for 5 persons whose only raw form
    # embedded a role token (吳汝綸勘, 王元貞校訂, 顧歡等人, 劉惟永編, 傅奕校定).
    have = {(r["person_id"], r["alias"]) for r in alias_rows}
    for pid, row in canon_rows.items():
        if (pid, row["canonical_name"]) not in have:
            alias_rows.append({"person_id": pid, "alias": row["canonical_name"],
                               "alias_type": "canonical", "note": "canonical self-alias (v1.1.2)"})
    aliases_out = pd.DataFrame(alias_rows).drop_duplicates(subset=["person_id", "alias"])

    # apply the remap; edges whose person was dropped as a non-person are removed
    auth["person_id"] = auth["_canon"].fillna(auth["person_id"])
    # Edges left unmapped are the ANONYMOUS/UNKNOWN placeholders, which pass
    # through by design; only edges whose person is absent from the canonical
    # table are actually dropped.
    placeholder_edges = int(auth["_canon"].isna().sum())
    before = len(auth)
    auth = auth[auth["person_id"].isin(set(persons_out["person_id"]))].copy()
    dropped_edges = before - len(auth)
    # a role recovered from the name fills role_raw only where it was empty
    if "_role_from_name" in auth:
        need = auth["role_raw"].isna() | (auth["role_raw"].astype(str).str.strip() == "")
        auth.loc[need, "role_raw"] = auth.loc[need, "_role_from_name"]
        auth["is_attributed"] = (auth["is_attributed"].astype(bool)
                                 | auth["_attrib_from_name"].fillna(False).astype(bool))
    auth = auth.drop(columns=[c for c in ("_canon", "_role_from_name",
                                          "_attrib_from_name") if c in auth.columns])
    auth = auth.drop_duplicates(subset=["version_id", "person_id", "edge_type"])

    report.update({
        "canonical_persons": len(persons_out),
        "alias_rows": len(aliases_out),
        "authorship_edges_in": len(pd.read_csv(os.path.join(data_dir, "authorship_edges.csv"),
                                               encoding="utf-8-sig")),
        "authorship_edges_out": len(auth),
        "edges_dropped_person_absent": dropped_edges,
        "edges_on_placeholders_passed_through": placeholder_edges,
    })
    return persons_out, aliases_out, auth, report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    args = ap.parse_args()
    persons, aliases, auth, report = canonicalize(args.data)
    persons.to_csv(os.path.join(args.data, "persons.csv"), index=False, encoding="utf-8-sig")
    aliases.to_csv(os.path.join(args.data, "person_aliases.csv"), index=False, encoding="utf-8-sig")
    auth.to_csv(os.path.join(args.data, "authorship_edges.csv"), index=False, encoding="utf-8-sig")
    for k, v in report.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()
