"""
LaoziKG — compute every load-bearing figure from the shipped tables into
metadata/release_facts.json. This file is the SINGLE SOURCE OF TRUTH for
numbers in README, dataset card, Zenodo metadata, CITATION.cff, licence and
schema documents (rendered by src/render_docs.py) and for the data dictionary's
table purposes (src/make_metadata.py). Three consecutive release candidates
shipped stale hand-copied figures; nothing publication-facing may hardcode a
count any more.

Usage: python src/make_release_facts.py --root . [--version 1.1.2-rc3]
"""
import argparse
import datetime
import json
import os
import sys
import re
import re

import pandas as pd
from opencc import OpenCC

CC = OpenCC("t2s")
PUNCT = re.compile(r"[，。；：？！、\s,\.;:\?!\"“”‘’「」『』（）()\[\]【】]")


# ---------------------------------------------------------------------------
# The dual-profile vocabulary, defined ONCE. A `*_full_corpus` key always means
# the full internal dataset; in this package it is the package's own value
# (it IS the full corpus), and make_public_facts overrides it with the full
# package's value when building a profile. That module imports this tuple
# rather than keeping its own list: they were two halves of one vocabulary, and
# a key added to one and not the other renders either as an unknown key or,
# worse, silently as the profile's own number.
DUAL = ("sentences", "variants", "commentary", "evidence", "chapter_instances",
            "default_include_instances", "mention_edges_default",
            "mention_occurrences_default", "sentence_mention_rows_default",
            "concepts", "validation_frames_items", "pvs_items",
            # rc11: both are quoted in documents that must name the internal
            # figure even when rendered inside a profile. This tuple and
            # make_public_facts.COMPANION are two halves of one vocabulary — a
            # key added to one and not the other renders as an unknown key
            # (which is how this was caught) or, worse, silently as the
            # profile's own number.
            "commentary_reference_only", "frame_rows_recovered_alignment")


def rd(d, f):
    p = os.path.join(d, f)
    return pd.read_parquet(p) if f.endswith(".parquet") else pd.read_csv(p, encoding="utf-8-sig", keep_default_na=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--version", default=None)
    # Write somewhere other than <root>/metadata/release_facts.json. Used to
    # compute a DISTRIBUTION PROFILE's facts with this same code over that
    # profile's own tables, instead of a second implementation that would drift.
    ap.add_argument("--out", default=None)
    # A DUAL-PROFILE document (the availability comparison table, the citation
    # note on differing counts) has to name both distributions' numbers in one
    # sentence. rc9 rendered the full-profile cell from the SAME key as the
    # public cell, so in the public rendering both cells read the public value —
    # CITATION.md claimed 51,648 default edges "in the full profile", and the
    # availability table gave 18,334 variants for both. The fix is vocabulary:
    # *_full_corpus always means the full internal dataset and public_profile_*
    # always means the distribution, in BOTH facts files, so one template is
    # correct either way. That requires the profile's facts here.
    ap.add_argument("--profile-facts", default=None,
                    help="a distribution profile's facts, to populate public_profile_*")
    a = ap.parse_args()
    root = a.root
    d = os.path.join(root, "data")

    v = rd(d, "versions.csv"); ci = rd(d, "chapter_instances.parquet"); se = rd(d, "sentences.parquet")
    va = rd(d, "variants.parquet")
    sm = rd(os.path.join(root, "derived_diagnostics"), "structural_mismatches.parquet")
    cm = rd(d, "commentary.csv"); ev = rd(d, "evidence.parquet")
    p = rd(d, "persons.csv"); al = rd(d, "person_aliases.csv"); au = rd(d, "authorship_edges.csv")
    c = rd(d, "concepts.csv"); rel = rd(d, "concept_relations.csv"); pa = rd(d, "provenance_assertions.csv")
    me = rd(d, "concept_chapter_mentions.csv"); mr = rd(d, "concept_recovered_mentions.csv"); mu = rd(d, "concept_unaligned_mentions.csv")
    sme = rd(d, "concept_sentence_mentions.parquet"); smr = rd(d, "concept_sentence_recovered_mentions.parquet"); smu = rd(d, "concept_sentence_unaligned_mentions.parquet")
    st = rd(d, "concept_mention_statistics.csv"); rights = rd(d, "source_rights.csv")
    rec = rd(d, "alignment_recovery_report.csv")
    claims_p = os.path.join(root, "derived_unverified", "candidate_scholarly_claims.csv")
    n_claims = len(pd.read_csv(claims_p, encoding="utf-8-sig")) if os.path.exists(claims_p) else 0

    # Version string: the VERSION file is the single declared source. It is not
    # rendered from anything, which matters — CITATION.cff is GENERATED from this
    # fact, so reading the version back out of it made a bump self-cancelling.
    version = a.version
    if version is None:
        vp = os.path.join(root, "VERSION")
        if os.path.exists(vp):
            version = open(vp, encoding="utf-8").read().strip()
        else:
            m = re.search(r"^version:\s*(\S+)",
                          open(os.path.join(root, "CITATION.cff"), encoding="utf-8").read(), re.M)
            version = m.group(1) if m else "unknown"

    # base-text share (like-for-like normalization on both sides)
    ref = rd(d, "wangbi_exegesis_source.parquet")
    cl = {int(r.chapter_num): len(CC.convert(PUNCT.sub("", str(r.jingwen)))) for r in ref.itertuples()}
    ic = se.assign(n=se["normalized_text"].fillna("").astype(str).str.len()).groupby("instance_id")["n"].sum()
    al_ci = ci[ci["chapter_num"] != -1]
    inst_chars = int(al_ci["instance_id"].map(ic).fillna(0).sum()); canon_chars = int(al_ci["chapter_num"].map(cl).sum())

    st_status = ci["alignment_review_status"].value_counts().to_dict()
    tiers = {t: int(st[f"mentions_specificity_{t}"].sum()) for t in ("high", "medium", "low")}
    both = cm[(cm["commentator_historical_era"] != "") & (cm["commentary_witness_era"] != "")]
    differ = int((both["commentator_historical_era"].map(CC.convert) != both["commentary_witness_era"].map(CC.convert)).sum())
    nl = pd.to_numeric(cm.loc[cm["text_provenance"] == "not_located", "source_char_overlap"], errors="coerce")

    graph_report = os.path.join(d, "graph", "build_report.json")
    g = json.load(open(graph_report)) if os.path.exists(graph_report) else {}

    # provider summary for the licence document
    prov = rights["digital_source_provider"].value_counts()
    def bucket(name):
        n = name.lower()
        if "shidian" in n or "识典" in n: return "Shidian Guji (识典古籍) — Daozang/Xu Daozang/Zangwai/Siku/Sibu/HY transcriptions"
        if "cadal" in n: return "CADAL digital library"
        if "pelliot" in n: return "Pelliot chinois, BnF (Dunhuang)"
        if "stein" in n: return "Stein collection, British Library (Dunhuang)"
        if "modern compilation" in n: return "Dataset authors (derived resource)"
        return "Other / undetermined series (see source_rights.csv)"
    prov_b = rights["digital_source_provider"].map(bucket).value_counts().to_dict()

    F = {
        "release_version": version,
        "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "resources": len(v), "source_witnesses": int(v["is_source_witness"].astype(str).str.lower().eq("true").sum()),
        "derived_resources": int((v["resource_class"] == "modern_derived_resource").sum()),
        "chapter_instances": len(ci), "aligned_instances": int((ci["chapter_num"] != -1).sum()),
        "unaligned_instances": int((ci["chapter_num"] == -1).sum()),
        "default_include_instances": int(ci["analysis_default_include"].astype(str).str.lower().eq("true").sum()),
        "recovered_unreviewed_instances": int(st_status.get("auto_recovered_unreviewed", 0)),
        "expert_confirmed_instances": int(st_status.get("expert_confirmed", 0) + st_status.get("expert_corrected", 0)),
        "sentences": len(se), "sentences_split_at_colophon": int(se["sentence_id"].astype(str).str.contains(r"-[ab]$").sum()),
        "variants": len(va), "structural_mismatches": len(sm),
        "variant_explanations_distinct": int(va["semantic_explanation"].replace("", pd.NA).dropna().nunique()),
        "variant_explanation_rows": int((va["semantic_explanation"].fillna("") != "").sum()),
        "commentary": len(cm), "citable_quotes": int(cm["citable_as_quote"].astype(str).str.lower().eq("true").sum()),
        "text_provenance": cm["text_provenance"].value_counts().to_dict(), "evidence": len(ev),
        "commentary_concepts_covered": int(cm["concept_id"].nunique()),
        "era_rows_both_known": len(both), "era_rows_differ": differ, "era_differ_pct": round(differ / len(both) * 100, 1) if len(both) else None,
        "not_located_n": int(len(nl)), "not_located_overlap_min": round(float(nl.min()), 4), "not_located_overlap_max": round(float(nl.max()), 4), "not_located_overlap_mean": round(float(nl.mean()), 4),
        "persons": len(p), "canonical_persons": int((p["entity_status"] == "canonical").sum()),
        "placeholder_persons": int((p["entity_status"] != "canonical").sum()), "aliases": len(al), "authorship_edges": len(au),
        "persons_era_disputed": int(p["era_disputed"].astype(str).str.lower().eq("true").sum()) if "era_disputed" in p.columns else None,
        "concepts": len(c), "seed_concepts": int(c["is_seed"].astype(str).str.lower().eq("true").sum()),
        "llm_expanded_concepts": int((~c["is_seed"].astype(str).str.lower().eq("true")).sum()),
        "concepts_with_mentions": int(me["concept_id"].nunique()), "concept_relations": len(rel), "provenance_assertions": len(pa),
        "candidate_claims": n_claims,
        "mention_edges_default": len(me), "mention_occurrences_default": int(me["mention_count"].sum()),
        "mention_edges_recovered": len(mr), "mention_occurrences_recovered": int(mr["mention_count"].sum()),
        "mention_edges_unaligned": len(mu), "mention_occurrences_unaligned": int(mu["mention_count"].sum()),
        "mention_edges_all_aligned": len(me) + len(mr),
        "sentence_mention_rows_default": len(sme), "sentence_mention_rows_recovered": len(smr), "sentence_mention_rows_unaligned": len(smu),
        "tier_occurrences": tiers, "tier_edges": me.groupby("match_specificity").size().to_dict(),
        "tier_concepts": me.groupby("match_specificity")["concept_id"].nunique().to_dict(),
        "single_char_share_pct": round(tiers["low"] / sum(tiers.values()) * 100, 2),
        "base_text_chars_instances": inst_chars, "base_text_chars_canonical": canon_chars,
        "base_text_share_upper_pct": round(canon_chars / inst_chars * 100, 1),
        "base_text_share_median": round(float((al_ci["chapter_num"].map(cl) / al_ci["instance_id"].map(ic)).clip(upper=1).median()), 3),
        "text_composition": ci["text_composition"].value_counts().to_dict(),
        "work_type": v["work_type"].value_counts().to_dict(), "alignment_status": v["alignment_status"].value_counts().to_dict(),
        "unresolved_reason": v["unresolved_reason"].value_counts().to_dict(),
        "recovery": {r["version_id"]: {"method": r["method"], "chapters": int(r["chapters_kept"])} for _, r in rec.iterrows()},
        "recovered_instances_total": int(rec["chapters_kept"].sum()),
        "rights_rows": len(rights), "rights_cleared": int((rights["redistribution_status"] == "cleared").sum()),
        "rights_not_reviewed": int((rights["redistribution_status"] == "not_reviewed").sum()),
        "rights_provider_low_confidence": int((rights["provider_inference_confidence"] == "low").sum()),
        "rights_redistribution_unknown": int((rights["redistribution_allowed"] == "unknown").sum()),
        "rights_original_text_public_domain": int((rights["original_text_public_domain"] == "yes_by_age").sum()),
        "rights_digitization_undetermined": int((rights["digitization_rights"] == "not_determined").sum()),
        "rights_ocr_undetermined": int((rights["ocr_rights"] == "not_determined").sum()),
        "rights_license_basis_unestablished": int((rights["license_basis"] == "not_established").sum()),
        "rights_provider_buckets": prov_b, "rights_providers": prov.to_dict(),
        "graph_node_tables": len(g.get("node_counts", {})), "graph_rel_tables": len(g.get("relationship_counts", {})),
        "graph_node_counts": g.get("node_counts", {}), "graph_rel_counts": g.get("relationship_counts", {}),
        "graph_inputs_hashed": len(g.get("input_sha256", {})),
        "validation_frames_items": None, "validation_adjudicated": None,
        # design constants quoted in documents (auditable here, not magic numbers)
        "constants": {"mentions_frame_per_tier": 250, "zenodo_interface_file_limit": 100,
                      "canonical_chapters": 81, "variants_frame_per_score_bin": 100,
                      "mention_rate_denominator_chars": 10000},
    }
    _cff_p = os.path.join(root, "docs", "templates", "CITATION.cff.tmpl")
    # BUILD date, not a publication date. A release candidate has no publication
    # date — CITATION.cff deliberately omits date-released and the dataset card
    # says "not published" — so this is read from the BUILD_DATE file, which the
    # release flow refreshes. Reading it back out of CITATION.cff (as rc9 did)
    # was also a source-of-truth cycle: the file is generated from this fact.
    _bd = os.path.join(root, "BUILD_DATE")
    if os.path.exists(_bd):
        F["build_date"] = open(_bd, encoding="utf-8").read().strip()
    else:
        F["build_date"] = datetime.date.today().isoformat()
    F["release_date"] = F["build_date"]
    F["release_date_statement"] = (
        f"not published — this is release candidate {F.get('release_version', '')}; "
        f"built {F['build_date']}. The publication date is set when the Zenodo "
        f"deposit is made.")
    F["release_year"] = F["release_date"][:4] if F.get("release_date") else ""
    # Mention edges the public structural release retains. Derived from the
    # tables, NOT from the profile report: facts are computed before the profile
    # is generated, so depending on that report would make the render stage fail
    # on a clean tree (and did).
    _ref = set(rights.loc[rights["release_disposition"] == "reference_only",
                          "version_id"].astype(str))
    _me = rd(d, "concept_chapter_mentions.csv")
    if _me is not None and "version_id" in _me.columns:
        F["public_profile_mention_edges"] = int((~_me["version_id"].astype(str).isin(_ref)).sum())

    # Rows the public profile drops with the reference_only resources. Registered
    # as facts so documents citing them are citing a current measurement, not a
    # number typed once into prose.
    try:
        _cm = pd.read_csv(os.path.join(root, "data", "commentary.csv"),
                          encoding="utf-8-sig", keep_default_na=False)
        _rt = pd.read_csv(os.path.join(root, "data", "source_rights.csv"),
                          encoding="utf-8-sig", keep_default_na=False)
        _ref = set(_rt.loc[_rt["release_disposition"] == "reference_only",
                           "version_id"].astype(str))
        F["commentary_reference_only"] = int(_cm["version_id"].astype(str).isin(_ref).sum())
    except Exception:
        pass

    # Variant rows the public profile retains. Derived here (the profile may not
    # exist yet at facts time) and cross-checked against the profile's own report
    # by the public QA suite.
    try:
        _va = pd.read_parquet(os.path.join(root, "data", "variants.parquet"))
        _ci = pd.read_parquet(os.path.join(root, "data", "chapter_instances.parquet"))
        _own = dict(zip(_ci["instance_id"].astype(str), _ci["version_id"].astype(str)))
        F["public_profile_variants"] = int(
            (~_va["instance_id"].astype(str).map(_own).isin(_ref)).sum())
    except Exception:
        pass

    # One title, rendered everywhere. rc7 had the full title in the citation
    # file and a bare "LaoziKG v<version>" heading in the readme, dataset card
    # and Zenodo metadata, so a reader could not tell they were one work.
    F["dataset_title"] = "LaoziKG: A Provenance-Aware Multi-Version Textual Knowledge Graph of the Laozi (Dao De Jing)"

    dd_p = os.path.join(root, "metadata", "data_dictionary.csv")
    if os.path.exists(dd_p):
        _dd = pd.read_csv(dd_p, encoding="utf-8-sig", keep_default_na=False)
        F["dictionary_columns"] = len(_dd)
        F["dictionary_tables"] = int(_dd["table"].nunique())
        F["dictionary_undocumented"] = int((_dd["description"] == "").sum())

    ck = os.path.join(root, "metadata", "checksums.sha256")
    if os.path.exists(ck):
        # Deliberately NOT recorded as a fact. Documents are rendered BEFORE
        # metadata/checksums.sha256 is regenerated for this build, so any count
        # captured here is the PREVIOUS run's — rc9 shipped 197 in a
        # distribution whose manifest hashes 149. The verified count for the
        # build that produced this tree is written last, to
        # metadata/final_release_verification.json.
        pass
    # expert-validation frame sizes
    # the three separate gates, from the QA report if it has been run
    # Whether THIS tree can run the clean-room regeneration. A distribution
    # profile ships no raw inputs, so the claim "executed clean-room regeneration"
    # is false there and must not be rendered into its documents.
    _has_raw = os.path.isdir(os.path.join(root, "legacy", "v1.0.0_inputs"))
    F["regeneration_available"] = "yes" if _has_raw else "no"
    F["regeneration_claim"] = (
        "an EXECUTED clean-room regeneration (`src/regenerate_tables.py` from "
        "`legacy/v1.0.0_inputs`), compared table by table"
        if _has_raw else
        "a graph rebuild from the shipped tables and a recomputation of every "
        "derived statistic (the raw inputs are not in this distribution, so "
        "`src/regenerate_tables.py` cannot be run here)")
    # Name of the facts file a reader of THIS tree should consult. A profile's
    # facts live in public_release_facts.json; release_facts.json is the full
    # package's, and telling a public reader to check that path sent them to a
    # file which either is not shipped there or (worse, before rc9) was shipped
    # with full-corpus numbers.
    F["facts_file"] = ("metadata/release_facts.json" if _has_raw
                       else "metadata/public_release_facts.json")
    # Claims whose truth depends on WHICH distribution is being described. rc9
    # asserted all three unconditionally, so the public copy promised a graph
    # snapshot it does not ship and a clean-room table regeneration it cannot
    # run — contradicting docs/REPRODUCIBILITY.md inside the same archive.
    F["reproducibility_short"] = ("fully reproducible" if _has_raw
                                  else "structurally reproducible from the "
                                       "released tables")
    F["graph_artifact_claim"] = (
        "a Kuzu graph snapshot" if _has_raw else
        "graph-construction code and a per-build report, from which the Kuzu "
        "graph is deterministically rebuilt from the released tables")
    F["verified_reproduction_sentence"] = (
        "Clean-room table regeneration from the raw inputs is executed and "
        "compared table by table by the QA suite, so the rebuild status is "
        "earned rather than asserted."
        if _has_raw else
        "Graph reconstruction from the released tables, recomputation of every "
        "derived statistic and regeneration of every figure are verified by the "
        "QA suite; canonical-table regeneration from raw source inputs requires "
        "the full internal profile, whose inputs are not in this distribution.")

    # Curator metadata is a DEPOSIT instruction. Inside the full internal package
    # its figures describe a tree that must not be deposited, and rc9 shipped it
    # there beside the line "upload the public structural release" — a curator
    # copying the description from the package they opened would have described a
    # dataset that is not in the file they uploaded.
    F["curator_metadata_scope_note"] = (
        "> **Not for deposit from this copy.** Every figure below is computed from "
        "the FULL INTERNAL package, which carries the third-party transcriptions and "
        "must not be deposited. Use the identical file inside "
        "`dist/public_structural_release/`, whose figures describe the archive you "
        "actually upload. This copy is here so the checklist is reviewable alongside "
        "the pipeline."
        if _has_raw else
        "> **This is the deposit copy.** Every figure below is computed from this "
        "distribution — the archive named in step 1 — so the description you paste "
        "into Zenodo describes the file you upload.")

    F["qa_report_file"] = ("qa/validation_report.json" if _has_raw
                           else "qa/public_profile_qa_report.json")
    F["regeneration_scope_note"] = (
        "This tree contains the raw inputs, so every table can be regenerated "
        "from them and diffed against what is shipped."
        if _has_raw else
        "This distribution does NOT contain the raw inputs. Reproducible here: "
        "rebuilding the graph from the shipped tables, recomputing the derived "
        "statistics and figures, and re-running the QA suite. Not reproducible "
        "here: regenerating the tables from raw sources, and any check that "
        "requires the withheld character streams.")

    # per-frame row counts, so a document cannot state a frame size the frame
    # does not have (the variant frame is 400 in the full package and 375 here)
    _evd = os.path.join(root, "expert_validation")
    if os.path.isdir(_evd):
        for _f in sorted(os.listdir(_evd)):
            if _f.startswith("frame_") and _f.endswith(".csv") and "strata" not in _f:
                _n = len(pd.read_csv(os.path.join(_evd, _f), encoding="utf-8-sig"))
                F[f"frame_rows_{_f[len('frame_'):-len('.csv')]}"] = _n

    _qa = os.path.join(root, "qa", "validation_report.json")
    if os.path.exists(_qa):
        _q = json.load(open(_qa, encoding="utf-8"))
        for _k in ("full_distribution_status", "public_distribution_status",
                   "scientific_validation_status", "overall_release_status"):
            if _k in _q:
                F[_k] = _q[_k]

    vm_p = os.path.join(root, "expert_validation", "validation_metrics.json")
    if os.path.exists(vm_p):
        _vm = json.load(open(vm_p, encoding="utf-8"))
        F["validation_status"] = _vm["status"]
        _mps = _vm.get("priority_validation_set", {})
        if _mps.get("present"):
            F["pvs_items"] = _mps["items"]
            F["pvs_adjudicated"] = _mps["adjudicated"]
            F["pvs_pct_adjudicated"] = _mps["pct_adjudicated"]
            F["pvs_complete"] = bool(_mps["complete"])
        F["validation_pct_adjudicated"] = _vm["pct_adjudicated"]
        F["validation_default_frame_threshold_pct"] = _vm["default_frame_threshold_pct"]
        F["validation_frames_below_threshold"] = len(_vm.get("frames_below_threshold", []))
        F["validation_frames_total"] = len(_vm.get("frame_status", {}))

    ev_dir = os.path.join(root, "expert_validation")
    if os.path.isdir(ev_dir):
        tot = adj = 0
        for f in os.listdir(ev_dir):
            if f.startswith("frame_") and f.endswith(".csv") and "strata" not in f:
                fr = pd.read_csv(os.path.join(ev_dir, f), encoding="utf-8-sig", keep_default_na=False, dtype=str)
                tot += len(fr)
                adj_cols = [x for x in fr.columns if x.startswith("adjudicated_")]
                if adj_cols:
                    adj += int((fr[adj_cols[0]] != "").sum())
        F["validation_frames_items"] = tot; F["validation_adjudicated"] = adj

    if "relation_category" in rel.columns:
        F["relation_categories"] = rel["relation_category"].value_counts().to_dict()
        F["relation_categories_n"] = int(rel["relation_category"].nunique())
        for _cat, _n in F["relation_categories"].items():
            F[f"rel_cat_{_cat}"] = _n

    F["searched_chars_default_set"] = int(st["searched_chars_default_set"].iloc[0]) if "searched_chars_default_set" in st.columns else None
    F["top_concepts_raw"] = "、".join(st.nlargest(6, "raw_lexical_mentions")["concept_name"].tolist())
    F["top_concepts_high_specificity"] = "、".join(st.nlargest(6, "high_specificity_mentions")["concept_name"].tolist())
    F["spearman_raw_vs_high_specificity"] = round(float(
        st["raw_lexical_mentions"].corr(st["high_specificity_mentions"], method="spearman")), 3)
    F["top10_overlap_raw_high_specificity"] = int(len(
        set(st.nlargest(10, "raw_lexical_mentions")["concept_name"])
        & set(st.nlargest(10, "high_specificity_mentions")["concept_name"])))

    # "fully reproducible" was false of the public distribution, which ships
    # neither the raw regeneration inputs nor the withheld character streams:
    # its graph and statistics rebuild from its own tables, the tables themselves
    # do not. Say which, rather than claiming the strongest of the three.
    F["data_availability_statement"] = (
        "A public structural release is openly available, containing the structural annotations, "
        "derived analytical layers, query tools and quality-control suite produced by the authors. "
        "Its knowledge graph and all derived statistics rebuild deterministically from the tables "
        "it ships; regenerating those tables from raw text requires the source transcriptions, "
        "which are withheld. The original third-party textual witnesses are excluded unless "
        "redistribution rights are confirmed; full-text redistribution remains subject to a "
        "per-provider rights review recorded in data/source_rights.csv "
        f"({F['rights_cleared']} of {F['rights_rows']} resources reviewed). "
        "The validation protocol, sampling frames and scorer are public and runnable; "
        "adjudicating items whose judgement depends on reading the withheld text "
        "requires access to the full internal package.")

    # Recommended phrasing for the chapter-instance count. A bare "N aligned
    # chapter instances" overstates the analysis-ready corpus, because it folds in
    # automatic recoveries no expert has confirmed. Documents render this string.
    F["count_phrasing_instances"] = (
        f"{F['default_include_instances']:,} expert-independent, analysis-ready aligned chapter instances, "
        f"plus {F['recovered_unreviewed_instances']} automatically recovered candidate alignments awaiting "
        f"expert confirmation ({F['unaligned_instances']} units unaligned; {F['chapter_instances']:,} rows in total)")

    os.makedirs(os.path.join(root, "metadata"), exist_ok=True)
    # dual-profile vocabulary: module-level DUAL, see top of file
    for _k in DUAL:
        if _k in F:
            F.setdefault(f"{_k}_full_corpus", F[_k])
    if a.profile_facts and os.path.exists(a.profile_facts):
        _p = json.load(open(a.profile_facts, encoding="utf-8"))
        for _k in DUAL:
            if _k in _p:
                F[f"public_profile_{_k}"] = _p[_k]
        F["profile_facts_source"] = os.path.relpath(a.profile_facts, root)
    else:
        # No profile yet (first pass of a release, or a bare facts run): the
        # public_profile_* keys stay absent and any dual-profile template fails
        # loudly rather than printing a full-corpus number as a public one.
        F["profile_facts_source"] = None

    # count-dependent scoped sentences (shared wording; see src/scoped_claims.py)
    # The sampling table's pre-rc11 sum, stated in the document itself so the
    # correction is auditable rather than silent. Derived, not typed: the whole
    # protocol minus the frame that was missing from the table.
    F["sampling_table_previous_sum"] = f"{F.get('validation_frames_items', 0) - F.get('frame_rows_recovered_alignment', 0):,}"

    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import scoped_claims
    scoped_claims.apply(F, _has_raw)

    _out = a.out or os.path.join(root, "metadata", "release_facts.json")
    os.makedirs(os.path.dirname(_out) or ".", exist_ok=True)
    json.dump(F, open(_out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: F[k] for k in ("release_version", "chapter_instances", "default_include_instances", "sentences",
                                         "mention_edges_default", "mention_occurrences_default", "persons", "aliases",
                                         "graph_node_tables", "graph_rel_tables", "validation_frames_items")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
