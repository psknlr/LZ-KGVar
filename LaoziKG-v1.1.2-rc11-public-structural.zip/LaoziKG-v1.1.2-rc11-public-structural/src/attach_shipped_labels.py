"""LaoziKG — Stage 1b: attach shipped labels and derive alignment status.

Joins the machine-assigned labels in src/shipped_labels/ onto versions.csv and
concepts.csv, renames era -> witness_era, adds resource_class / is_source_witness,
copies concept_relations.csv, and computes alignment_status / unresolved_reason
deterministically:

  alignment_status   aligned_full  if aligned_laozi_chapter_count >= 75
                     aligned_partial if >= 1, else unaligned
  unresolved_reason  not_applicable if unresolved_unit_count == 0;
                     expected_no_ddj_chapter_structure if work_type is not a
                     DDJ text/commentary; otherwise the diagnosis from
                     alignment_failure_diagnosis.csv, falling back to
                     possible_alignment_failure_review_needed.

Usage: python src/attach_shipped_labels.py --data <dir>
"""
import argparse
import os
import shutil

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
LAB = os.path.join(HERE, "shipped_labels")
DDJ = {"canonical_ddj", "ddj_commentary"}
DERIVED = {"WANGBI_TONGSHI_2026"}
DIAG_TO_REASON = {
    "genuine_alignment_failure": "confirmed_alignment_failure_recovery_pending",
    "no_base_text_commentary_only": "commentary_only_no_base_text_to_align",
    "probable_catalogue_or_composite_mismatch": "catalogue_mismatch_expert_review_required",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    d = ap.parse_args().data

    # ---- versions ----
    v = pd.read_csv(os.path.join(d, "versions.csv"), encoding="utf-8-sig")
    if "era" in v.columns and "witness_era" not in v.columns:
        v = v.rename(columns={"era": "witness_era"})
    wt = pd.read_csv(os.path.join(LAB, "version_work_types.csv"), encoding="utf-8-sig")
    v = v.drop(columns=[c for c in wt.columns if c != "version_id" and c in v.columns])
    v = v.merge(wt, on="version_id", how="left")
    v["textual_scope_source"] = v.get("work_type_source", "minimax-m3")
    v["textual_scope_reviewed"] = False
    missing = v["work_type"].isna().sum()
    if missing:
        raise SystemExit(f"{missing} versions lack a work_type label")

    # witness_era: keep the bibliographic record's own claim verbatim, and add an
    # orthographically normalized copy. Normalization is ORTHOGRAPHIC ONLY
    # (traditional->simplified, 其他->不详): it does not resolve genuinely
    # ambiguous labels. 南朝宋 mixes Liu Song (420-479) and Southern Song
    # (1127-1279) in the source records and is flagged, not corrected.
    from opencc import OpenCC
    _cc = OpenCC("t2s")
    v["witness_era_raw"] = v["witness_era"]
    v["witness_era_normalized"] = (v["witness_era"].fillna("不详").astype(str).str.strip()
                                   .map(_cc.convert).replace({"其他": "不详", "": "不详"}))
    v["witness_era_normalization_source"] = "orthographic_only_v1.1.2"
    v["witness_era_ambiguous"] = v["witness_era_normalized"].isin({"南朝宋", "春秋战国", "南北朝"})
    v["witness_era_reviewed"] = False
    v = v.drop(columns=["witness_era"])

    v["resource_class"] = v["version_id"].map(
        lambda x: "modern_derived_resource" if x in DERIVED else "historical_source_witness")
    v["is_source_witness"] = ~v["version_id"].isin(DERIVED)

    # expert alignment review (file is header-only until a review is recorded)
    ci_p = os.path.join(d, "chapter_instances.parquet")
    ci0 = pd.read_parquet(ci_p)
    if "alignment_review_status" not in ci0.columns:
        ci0["alignment_review_status"] = "original_deterministic"
        ci0.loc[ci0["chapter_num"] == -1, "alignment_review_status"] = "not_aligned"
    rev_p = os.path.join(LAB, "alignment_review.csv")
    if os.path.exists(rev_p):
        rev = pd.read_csv(rev_p, encoding="utf-8-sig", keep_default_na=False)
        rev = rev[rev["review_status"].isin(["expert_confirmed", "expert_corrected"])]
        m = ci0["instance_id"].isin(rev["instance_id"])
        ci0.loc[m, "alignment_review_status"] = ci0.loc[m, "instance_id"].map(
            dict(zip(rev["instance_id"], rev["review_status"])))
        print(f"  alignment review applied to {int(m.sum())} instance(s)")
    ci0.to_parquet(ci_p, index=False)

    # recompute alignment counts from chapter_instances (recover_alignment may
    # have changed them since normalize_tables computed the first pass)
    ci = pd.read_parquet(os.path.join(d, "chapter_instances.parquet"))
    al_ = ci[ci["chapter_num"] != -1]
    stats = pd.DataFrame({
        "aligned_laozi_chapter_count": al_[al_["chapter_num"].between(1, 81)].groupby("version_id")["chapter_num"].nunique(),
        "alignment_success_count": al_.groupby("version_id").size(),
        "unresolved_unit_count": ci[ci["chapter_num"] == -1].groupby("version_id").size(),
    })
    v = v.drop(columns=[c for c in stats.columns if c in v.columns])
    v = v.merge(stats, how="left", left_on="version_id", right_index=True)
    for c in stats.columns:
        v[c] = v[c].fillna(0).astype("int64")

    n = v["aligned_laozi_chapter_count"].fillna(0).astype(int)
    v["alignment_status"] = ["aligned_full" if k >= 75 else "aligned_partial" if k >= 1
                             else "unaligned" for k in n]
    diag = pd.read_csv(os.path.join(LAB, "alignment_failure_diagnosis.csv"), encoding="utf-8-sig")
    dmap = dict(zip(diag["version_id"], diag["diagnosis"].map(DIAG_TO_REASON)))
    resolved = set(diag.loc[diag.get("resolution_applied", False) == True, "version_id"])

    def reason(r):
        vid = r["version_id"]
        if vid in resolved:
            # recovered in v1.1.2; any remaining -1 unit is text before the first anchor or
            # unidentified segments (scroll head, dated colophon, scroll totals, or commentary)
            return ("recovered_v1.1.2_residual_unanchored_text"
                    if int(r["unresolved_unit_count"] or 0) > 0 else "recovered_v1.1.2")
        if int(r["unresolved_unit_count"] or 0) == 0:
            return "not_applicable"
        if r["work_type"] not in DDJ:
            return "expected_no_ddj_chapter_structure"
        return dmap.get(vid, "possible_alignment_failure_review_needed")
    v["unresolved_reason"] = v.apply(reason, axis=1)
    v.to_csv(os.path.join(d, "versions.csv"), index=False, encoding="utf-8-sig")

    # ---- concepts ----
    c = pd.read_csv(os.path.join(d, "concepts.csv"), encoding="utf-8-sig")
    nt = pd.read_csv(os.path.join(LAB, "concept_node_types.csv"), encoding="utf-8-sig")
    c = c.drop(columns=[k for k in nt.columns if k != "concept_id" and k in c.columns])
    c = c.merge(nt, on="concept_id", how="left")
    if c["node_type"].isna().any():
        raise SystemExit("some concepts lack a node_type label")
    # Per-field provenance for the concept rows themselves. 20 seed concepts
    # (is_seed = TRUE) were hand-authored by the compilers; the other 91 rows —
    # name, category, definition_core — were LLM-expanded (MiniMax-M3 batch
    # generation) and no field of them has been reviewed.
    seed = c["is_seed"].astype(str).str.lower().eq("true")
    c["concept_generated_by"] = seed.map({True: "compiler_hand_authored", False: "minimax-m3"})
    c["concept_reviewed"] = False
    c["definition_generated_by"] = c["concept_generated_by"]
    c["definition_reviewed"] = False
    c.to_csv(os.path.join(d, "concepts.csv"), index=False, encoding="utf-8-sig")

    # Relation taxonomy over the EXISTING edges. No edge is invented here: the
    # layer is thin (67 edges over 111 concepts) and the right way to thicken it
    # is expert authorship, not more unreviewed machine generation, which would
    # lower the layer's credibility rather than raise it.
    #   lexical_semantic  — A's name contains B's core term (deterministic)
    #   semantic          — asserted conceptual containment/expression
    #   realization       — A is realized or enacted through B
    #   symbolic          — A stands for B figuratively (metaphor/image)
    REL_CATEGORY = {"EXPRESSES": "semantic", "REALIZES": "realization",
                    "SYMBOLIZES": "symbolic"}
    rel = pd.read_csv(os.path.join(LAB, "concept_relations.csv"), encoding="utf-8-sig",
                      keep_default_na=False)
    rel["relation_category"] = rel["relation_type"].map(REL_CATEGORY).fillna("uncategorized")
    # a name-containment EXPRESSES edge is a lexical fact, not a philosophical claim
    rel.loc[(rel["relation_type"] == "EXPRESSES")
            & (rel["source"] == "deterministic_name_containment"),
            "relation_category"] = "lexical_semantic"
    rel["relation_category_source"] = "deterministic_mapping_from_relation_type"
    rel.to_csv(os.path.join(d, "concept_relations.csv"), index=False, encoding="utf-8-sig")
    shutil.copy(os.path.join(LAB, "alignment_failure_diagnosis.csv"),
                os.path.join(d, "alignment_failure_diagnosis.csv"))

    print(f"versions: {len(v)}  alignment_status={v['alignment_status'].value_counts().to_dict()}")
    print(f"unresolved_reason={v['unresolved_reason'].value_counts().to_dict()}")
    print(f"concepts: {len(c)} with node_type; concept_relations copied")


if __name__ == "__main__":
    main()
