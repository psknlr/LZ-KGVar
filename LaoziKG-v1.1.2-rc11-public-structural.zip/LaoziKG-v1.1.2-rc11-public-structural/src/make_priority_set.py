"""
LaoziKG — draw the PRIORITY VALIDATION SET.

The full protocol is every row of every frame (see validation_metrics.json;
the generated README states the live figure). That is more review than a
first publication needs, and an all-or-nothing target tends to produce no review
at all. This script draws a prioritized ~400-item subset that supports the
metrics a Data Descriptor must report — per-stratum precision with a confidence
interval, and inter-annotator agreement — and leaves the remaining items in the
full frames for later rounds.

Allocation (per the round-6 audit recommendation):

    concept mentions      150   50 per specificity tier
    commentary            100   proportional over the 19 sampling strata, floor 1
    recovered alignment    50   proportional over the 5 recovered witnesses
    concept relations      50   proportional over the 4 relation categories
    candidate variants     50   equal allocation, 12/13 per detection-score bin
                          ----
                           400

Each draw PRESERVES the parent frame's own stratification, so a per-stratum rate
estimated from the subset is estimated the same way it would be from the full
frame — the subset is smaller, not differently designed. Every drawn row keeps
its parent frame's identifier, so completed work merges straight back:

    python src/merge_priority_set.py --frames expert_validation

Deterministic given --seed.

Usage: python src/make_priority_set.py --frames expert_validation --seed 20260903
"""
import argparse
import os

import pandas as pd

ALLOC = {
    "mentions":            ("match_specificity",          150),
    "commentary":          ("stratum",                    100),
    "recovered_alignment": ("version_id",                  50),
    "concept_relations":   ("relation_category",           50),
    "variants":            ("variant_detection_score_bin", 50),
}
# Composite where the parent frame has no single id column — these are the
# columns that identify a row uniquely in its parent frame, joined by "+".
KEY = {
    "mentions": "sentence_id+concept_id",
    "commentary": "commentary_id",
    "recovered_alignment": "instance_id",
    "concept_relations": "concept_id_a+concept_id_b+relation_type",
    "variants": "variant_id",
}


def allocate(counts, total):
    """Proportional allocation with a floor of 1 and largest-remainder rounding."""
    strata = list(counts.index)
    if len(strata) >= total:
        return {s: 1 for s in strata[:total]}
    base = {s: 1 for s in strata}
    left = total - len(strata)
    pool = counts - 1
    if pool.sum() <= 0:
        return base
    exact = pool / pool.sum() * left
    floor = exact.astype(int)
    rem = left - int(floor.sum())
    order = (exact - floor).sort_values(ascending=False).index
    for s in list(order)[:rem]:
        floor[s] += 1
    for s in strata:
        base[s] = min(int(base[s] + floor[s]), int(counts[s]))
    return base



def _mirror(a, out):
    """Describe an already-filtered packet copy. Draws nothing."""
    sheets = sorted(f for f in os.listdir(out)
                    if f.startswith("pvs_") and f.endswith(".csv"))
    rows = []
    for fn in sheets:
        frame = fn[len("pvs_"):-len(".csv")]
        here = pd.read_csv(os.path.join(out, fn), encoding="utf-8-sig", keep_default_na=False)
        stratum_col = ALLOC.get(frame, (None, None))[0]
        full_n = None
        if a.full_frames:
            fp = os.path.join(a.full_frames, "priority_validation_set", fn)
            if os.path.exists(fp):
                full_n = len(pd.read_csv(fp, encoding="utf-8-sig"))
        strata = (here[stratum_col].value_counts().sort_index().to_dict()
                  if stratum_col and stratum_col in here.columns else {})
        rows.append({"frame": frame, "items_here": len(here),
                     "items_in_full_packet": full_n,
                     "withheld_with_reference_only": (full_n - len(here))
                     if full_n is not None else None,
                     "strata_here": "; ".join(f"{k}={v}" for k, v in strata.items())})
    m = pd.DataFrame(rows)
    m.to_csv(os.path.join(out, "mirror_allocation.csv"), index=False, encoding="utf-8-sig")
    for stale in ("allocation.csv", "index.csv"):
        sp = os.path.join(out, stale)
        if os.path.exists(sp):
            os.remove(sp)          # those describe a DRAW; this is not one

    here_tot = int(m["items_here"].sum())
    full_tot = (int(m["items_in_full_packet"].sum())
                if m["items_in_full_packet"].notna().all() else None)
    tbl = "\n".join(
        f"| `{r.frame}` | {r.items_here} | "
        f"{'' if r.items_in_full_packet is None else int(r.items_in_full_packet)} | "
        f"{r.strata_here} |" for r in m.itertuples())

    readme = f"""# Priority validation set — filtered mirror ({here_tot} items)

**This is not an independent sampling protocol, and it should not be described as
one.** It is the public mirror of the internal priority validation set: the same
drawn items, with every row belonging to a `reference_only` resource removed,
because this distribution keeps only witness-level records for those resources.

**{here_tot} of the internal packet's {full_tot if full_tot else 'N'} items are here.** Nothing was
re-drawn to make up the difference — doing so would produce different items whose
ids no longer correspond to the internal packet's, which is precisely the
cross-reference that makes a public copy worth having.

| Sheet | Items here | In the internal packet | Strata present here |
|---|---:|---:|---|
{tbl}

## What this copy is for

- reading the **sampling design, the schema, the question wording and the scoring
  methodology**, and checking them against the code in `src/`;
- checking which records were selected, by id;
- running `src/score_validation.py` to see that the machinery works and reports
  `0 / {here_tot}`.

## What it is NOT for

- **Deriving a precision estimate.** The original design allocated equally across
  strata; filtering removed rows unevenly, so the strata here are no longer equal
  and a rate computed from them is not the estimator the design supports. The
  strata present are listed above so the imbalance is visible rather than implied.
- **Adjudication of record.** Judgements that depend on reading the source text
  cannot be made here — the text is withheld. The full internal package is the
  validation corpus of record; adjudicate there, and cite the result for both.

Re-derive this description with
`python src/make_priority_set.py --frames expert_validation --mirror --full-frames <full package>`.
It reads the sheets present and draws nothing.
"""
    with open(os.path.join(out, "README.md"), "w", encoding="utf-8") as fh:
        fh.write(readme)
    print(m.to_string(index=False))
    print(f"mirror described: {here_tot} items"
          + (f" of the internal packet's {full_tot}" if full_tot else ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", default="expert_validation")
    # Document an ALREADY-FILTERED copy instead of drawing a new sample. A
    # distribution profile filters the packet after it was drawn, so re-drawing
    # there would produce a different 400 items whose ids do not correspond to the
    # internal packet's — destroying exactly the cross-reference that makes the
    # public copy useful. In mirror mode we describe what is present.
    ap.add_argument("--mirror", action="store_true",
                    help="describe the existing (filtered) sheets; draw nothing")
    ap.add_argument("--full-frames", default=None,
                    help="mirror mode: the unfiltered frames, for the comparison table")
    ap.add_argument("--seed", type=int, default=20260903)
    a = ap.parse_args()
    out = os.path.join(a.frames, "priority_validation_set")
    os.makedirs(out, exist_ok=True)

    if a.mirror:
        _mirror(a, out)
        return

    rows, alloc_rows = [], []
    for frame, (stratum_col, n) in ALLOC.items():
        path = os.path.join(a.frames, f"frame_{frame}.csv")
        if not os.path.exists(path):
            raise SystemExit(f"missing parent frame: {path}")
        df = pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False)
        if stratum_col not in df.columns:
            # commentary's stratum is the composite the sampler used
            if frame == "commentary":
                df["stratum"] = (df["text_provenance"].astype(str) + "|"
                                 + df["reliability"].astype(str) + "|"
                                 + df["extraction_method"].astype(str))
            else:
                raise SystemExit(f"{frame}: no column {stratum_col}")
        counts = df[stratum_col].value_counts()
        take = allocate(counts, n)
        picked = []
        for s, k in take.items():
            sub = df[df[stratum_col] == s]
            picked.append(sub.sample(n=min(k, len(sub)), random_state=a.seed))
            alloc_rows.append({"frame": frame, "stratum_column": stratum_col,
                               "stratum": s, "parent_frame_rows": int(counts[s]),
                               "drawn": int(min(k, len(sub)))})
        sel = pd.concat(picked, ignore_index=True)
        sel.insert(0, "parent_frame", frame)
        sel.insert(1, "parent_key_column", KEY[frame])
        rows.append(sel)
        sel.to_csv(os.path.join(out, f"pvs_{frame}.csv"), index=False, encoding="utf-8-sig")

    alloc = pd.DataFrame(alloc_rows)
    alloc.to_csv(os.path.join(out, "allocation.csv"), index=False, encoding="utf-8-sig")
    total = int(alloc["drawn"].sum())

    # ---- README, generated so it cannot drift from the allocation ----
    # Protocol total = every row of every non-strata frame, counted from the
    # frames themselves. A first draft summed deduplicated stratum row counts and
    # produced 725 instead of 2,031.
    protocol_items = 0
    for _f in sorted(os.listdir(a.frames)):
        if _f.startswith("frame_") and _f.endswith(".csv") and "strata" not in _f:
            protocol_items += len(pd.read_csv(os.path.join(a.frames, _f),
                                              encoding="utf-8-sig", keep_default_na=False))
    small = alloc[alloc["drawn"] < 10]
    rows = "\n".join(f"| `{r.frame}` | {r.stratum} | {r.drawn} |"
                     for r in small.sort_values("drawn").head(8).itertuples())
    per_frame = "\n".join(
        f"| `pvs_{r.frame}.csv` | {r.strata} | **{r.drawn}** |"
        for r in (alloc.groupby("frame")
                  .agg(strata=("stratum", "nunique"), drawn=("drawn", "sum"))
                  .reset_index().itertuples()))
    readme = f"""# Priority validation set — {int(alloc['drawn'].sum())} items

**0 of {int(alloc['drawn'].sum())} adjudicated.** This packet exists so the review can start
somewhere defensible, not because completing it validates the dataset. The full
protocol is {protocol_items:,} items; this is the subset that supports the metrics a
Data Descriptor has to report — per-stratum precision with an interval, and
inter-annotator agreement.

Renamed from `minimum_publishable_set` in v1.1.2-rc7: the old name asserted
sufficiency for publication, which is not something a sample size can establish.

| Sheet | Strata | Items |
|---|---:|---:|
{per_frame}

## How to use it

1. Two reviewers fill `annotator_A_<question>` and `annotator_B_<question>`
   independently — independently is load-bearing, or the agreement statistic
   measures nothing.
2. A third fills `adjudicated_<question>`, and `corrected_*` where the label is
   wrong. A row counts as adjudicated only when EVERY `adjudicated_*` field on it
   is answered; `NA` is an answer, blank is not.
3. `python src/merge_priority_set.py --frames expert_validation` folds the answers
   back onto the parent frames by key, never overwriting an existing answer and
   reporting conflicts rather than resolving them.
4. `python src/score_validation.py --frames expert_validation` reports the rates.

## Small strata: report the marginal, not the cell

Proportional allocation preserves each parent frame's stratification, which is
what makes a per-stratum rate from this packet estimable the same way it would be
from the full frame. The cost is that **{len(small)} of the {len(alloc)} strata receive fewer
than 10 items**, and commentary — 100 items over 19 strata — is the extreme case.

| Frame | Stratum | Items drawn |
|---|---|---:|
{rows}

A proportion computed on 3 or 5 items has a 95% interval roughly half the width
of the unit interval. Those cells are drawn so the packet REPRESENTS the frame,
not so that each cell is separately reportable.

**Reporting rule.** Quote the frame-level marginal (e.g. commentary faithfulness
over all 100 items); show per-stratum rates only as a table with their intervals;
never a single-stratum point estimate as a headline figure; never a pooled figure
across frames, or across the variant score bins, which are equally allocated
rather than proportional. If a specific stratum matters to a claim, draw more of
it rather than reading more into a thinly-sampled cell than it can carry.

Regenerate deterministically:
`python src/make_priority_set.py --frames expert_validation --seed {a.seed}`
"""
    with open(os.path.join(out, "README.md"), "w", encoding="utf-8") as fh:
        fh.write(readme)

    index = (alloc.groupby("frame")
             .agg(strata=("stratum", "nunique"), drawn=("drawn", "sum"))
             .reset_index())
    index.to_csv(os.path.join(out, "index.csv"), index=False, encoding="utf-8-sig")
    print(index.to_string(index=False))
    print(f"total drawn: {total}")


if __name__ == "__main__":
    main()
