"""LaoziKG — Stage 5: explicit authorship placeholders.

54 versions had no authorship edge at all, so a graph query could not tell
"anonymous by attestation" from "attribution not yet researched". This adds
ANONYMOUS and UNKNOWN person nodes and the corresponding edges.

This step existed in v1.1.0 but only as an ad-hoc shell command, so the
documented pipeline could not reproduce the released persons.csv (it produced
75 canonical persons instead of 77, and 137 authorship edges instead of 191).
Scripting it closes that gap.

Usage: python src/add_anonymous_authorship.py --data data
"""
import argparse
import os

import pandas as pd

# Source strings that assert anonymity, versus an absent attribution.
ATTESTED_ANONYMOUS = ("佚名", "未知", "无名", "無名", "阙名", "闕名")

PLACEHOLDERS = [
    {"person_id": "ANONYMOUS", "canonical_name": "佚名", "entity_status": "placeholder",
     "person_historical_era": "", "person_historical_era_alt": "", "person_era_dates": "",
     "era_source": "placeholder", "era_confidence": "placeholder",
     "era_disputed": False, "era_reviewed": False},
    {"person_id": "UNKNOWN", "canonical_name": "待考", "entity_status": "placeholder",
     "person_historical_era": "", "person_historical_era_alt": "", "person_era_dates": "",
     "era_source": "placeholder", "era_confidence": "placeholder",
     "era_disputed": False, "era_reviewed": False},
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    args = ap.parse_args()

    versions = pd.read_csv(os.path.join(args.data, "versions.csv"), encoding="utf-8-sig")
    persons = pd.read_csv(os.path.join(args.data, "persons.csv"), encoding="utf-8-sig")
    auth = pd.read_csv(os.path.join(args.data, "authorship_edges.csv"), encoding="utf-8-sig")

    for ph in PLACEHOLDERS:
        if ph["person_id"] not in set(persons["person_id"]):
            persons = pd.concat([persons, pd.DataFrame([ph])], ignore_index=True)

    covered = set(auth["version_id"].astype(str))
    new_edges = []
    for _, row in versions.iterrows():
        vid = str(row["version_id"])
        if vid in covered:
            continue
        raw = str(row.get("author_raw") or "")
        attested = any(tok in raw for tok in ATTESTED_ANONYMOUS)
        new_edges.append({
            "version_id": vid,
            "person_id": "ANONYMOUS" if attested else "UNKNOWN",
            "edge_type": "authored",
            "role_raw": "撰" if attested else "",
            "is_attributed": False,
            "attribution_status": "attested_anonymous" if attested else "unrecorded",
        })

    if new_edges:
        auth = pd.concat([auth, pd.DataFrame(new_edges)], ignore_index=True)

    # Named persons carry an explicit attribution_status too, so the column is
    # never null: named / attested_anonymous / unrecorded. role_raw defaults to
    # 撰 on AUTHORED edges lacking one (v1.1.0 did both ad hoc, unscripted).
    ph_ids = {p["person_id"] for p in PLACEHOLDERS}
    named = ~auth["person_id"].isin(ph_ids)
    auth.loc[named & auth["attribution_status"].isna(), "attribution_status"] = "named"
    auth.loc[(auth["edge_type"] == "authored") & auth["role_raw"].isna(), "role_raw"] = "撰"
    auth.loc[(auth["edge_type"] == "authored") & (auth["role_raw"] == ""), "role_raw"] = "撰"

    # Placeholder persons get an alias row so every Person has >= 1 alias.
    al_path = os.path.join(args.data, "person_aliases.csv")
    if os.path.exists(al_path):
        al = pd.read_csv(al_path, encoding="utf-8-sig")
        have = set(zip(al["person_id"].astype(str), al["alias"].astype(str)))
        add = [{"person_id": p["person_id"], "alias": p["canonical_name"],
                "alias_type": "canonical", "note": "placeholder entity"}
               for p in PLACEHOLDERS if (p["person_id"], p["canonical_name"]) not in have]
        if add:
            al = pd.concat([al, pd.DataFrame(add)], ignore_index=True)
            al.to_csv(al_path, index=False, encoding="utf-8-sig")

    persons.to_csv(os.path.join(args.data, "persons.csv"), index=False, encoding="utf-8-sig")
    auth.to_csv(os.path.join(args.data, "authorship_edges.csv"), index=False, encoding="utf-8-sig")

    uncovered = len(set(versions["version_id"].astype(str)) - set(auth["version_id"].astype(str)))
    print(f"placeholder_persons_present: {sum(1 for p in PLACEHOLDERS)}")
    print(f"placeholder_edges_added: {len(new_edges)}")
    print(f"  attested_anonymous: {sum(1 for e in new_edges if e['attribution_status']=='attested_anonymous')}")
    print(f"  unrecorded: {sum(1 for e in new_edges if e['attribution_status']=='unrecorded')}")
    print(f"persons_total: {len(persons)}")
    print(f"authorship_edges_total: {len(auth)}")
    print(f"versions_with_no_authorship_edge: {uncovered}")


if __name__ == "__main__":
    main()
