"""LaoziKG — Stage 1a: anchor-based recovery of confirmed alignment failures.

Five Dunhuang commentary fragments (S06453, PC2517, PC3237, PC2577, S02060) were
diagnosed in v1.1.1 as genuine alignment failures: canonical Laozi text is
present but the v1.0.0 segmenter left each as a single unsegmented unit. This
stage re-segments ONLY those witnesses.

Method (deterministic, no LLM)
------------------------------
1. Body = the witness's sentences in order, script-normalized (OpenCC t2s) and
   punctuation-stripped, with a sentence offset index.
2. For each canonical chapter (jingwen layer of wangbi_exegesis_source.parquet),
   split into clauses of >= 4 characters. A clause "hits" if it occurs as an exact
   substring of the body, or with rapidfuzz partial_ratio >= FUZZ (default 90)
   for clauses >= 6 chars. A chapter is PRESENT if >= 2 clauses hit, or >= 1 hit
   when the chapter has <= 3 clauses. Chapter start = position of its earliest
   hit. Confidence = hits / clauses.
3. Chapter start = earliest hit within the densest hit cluster
   (a short formulaic clause can match far from the chapter body; the median
   is robust to that). Anchors are then sorted by position, and an anchor is
   dropped as spurious if its chapter number is inconsistent (|delta| > 3)
   with BOTH positional neighbours. Global monotonicity is deliberately NOT
   enforced: S06453 runs 8-36, 57-69, 37-56, 70-81 — a real non-standard scroll
   order that a longest-increasing-subsequence filter would have destroyed.
   The recovered sequence is written to the report for expert inspection.
4. Each sentence is assigned to the chapter whose start precedes its END (so a
   sentence that straddles a boundary and contains the next chapter's opener
   goes to that next chapter). Sentences before the first anchor stay in a
   residual `-UNSEG` instance.

Colophon mode (S06453)
----------------------
S06453 is a scripture-only copy whose scribe wrote a character-count colophon
(五十字, 廿六字, 卌四字 ...) after every chapter — 78 of them. Where a witness has
>= 20 such colophons the manuscript's own delimiters drive segmentation: the
body is cut after each colophon, each segment is identified against the 81
canonical chapters by fuzz.ratio (best match, >= IDENT_MIN), and the scribe's
stated count is compared with the segment's actual character count (lacunae □
included) as an internal consistency check written to the report. Sentences
that straddle a colophon are split into two rows with ids <orig>-a / <orig>-b so
the original id remains recoverable; no other sentence ids change.

Everything produced is flagged: segmentation_method = anchor_recovery_v1.1.2,
recovery_reviewed = FALSE. Original sentence_ids are preserved for traceability
(they still carry -UNSEG-; only instance_id changes). Variants are NOT
regenerated for recovered instances.

Usage: python src/recover_alignment.py --data <dir> [--report <csv>]
"""
import argparse
import bisect
import os
import re

import pandas as pd
from opencc import OpenCC
from rapidfuzz import fuzz

CC = OpenCC("t2s")
PUNCT = re.compile(r"[，。；：？！、\s,\.;:\?!\"“”‘’「」『』（）()\[\]【】□]")
TARGETS = ["S06453", "PC2517", "PC3237", "PC2577", "S02060"]
FUZZ = 90
COLOPHON = re.compile(r"[一二三四五六七八九十廿卅卌百]{1,4}字")
COLOPHON_MODE_MIN = 20
IDENT_MIN = 45
CN = {"一":1,"二":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9,"十":10,"廿":20,"卅":30,"卌":40,"百":100}


def norm(t):
    return CC.convert(PUNCT.sub("", str(t)))


def clauses(jingwen):
    return [norm(c) for c in re.split(r"[，。；：？！、\n]", str(jingwen)) if len(norm(c)) >= 4]


def cn_to_int(t):
    """Chinese numeral (up to hundreds, incl. 廿卅卌) -> int; None if unparsable."""
    t = t.rstrip("字")
    total, cur = 0, 0
    for ch in t:
        v = CN.get(ch)
        if v is None:
            return None
        if v == 100:
            total += (cur or 1) * 100; cur = 0
        elif v == 10:
            total += (cur or 1) * 10; cur = 0
        elif v in (20, 30, 40):
            total += v; cur = 0
        else:
            cur = v
    return total + cur


def norm_keep_lacunae(t):
    return CC.convert(re.sub(r"[，。；：？！、\s,\.;:\?!\"“”‘’「」『』（）()\[\]【】]", "", str(t)))


def recover_colophon(vid, sents, canon):
    """Segment at the scribe's own chapter-end colophons; identify each segment."""
    sents = sents.sort_values("seq").reset_index(drop=True)
    canon_n = {ch: norm(jw) for ch, jw in canon.items()}
    # 1. split straddling sentences at colophon ends
    rows = []
    for _, r in sents.iterrows():
        t = str(r["normalized_text"] or "")
        tn = norm_keep_lacunae(t)
        cuts = [m.end() for m in COLOPHON.finditer(tn) if m.end() < len(tn)]
        if not cuts:
            rows.append(dict(r)); continue
        prev = 0
        for i, c in enumerate(cuts + [len(tn)]):
            piece = tn[prev:c]; prev = c
            if not piece:
                continue
            rr = dict(r); rr["normalized_text"] = piece; rr["original_text"] = piece
            rr["sentence_id"] = f"{r['sentence_id']}-{chr(97 + i)}"
            rows.append(rr)
    sents = pd.DataFrame(rows).reset_index(drop=True)
    sents["seq"] = range(len(sents))
    # 2. group sentences into segments ending at a colophon
    seg_id, segs, cur = 0, [], []
    for i, t in enumerate(sents["normalized_text"].fillna("")):
        cur.append(i)
        if COLOPHON.search(norm_keep_lacunae(t)) and norm_keep_lacunae(t).endswith("字"):
            segs.append(cur); cur = []
    if cur:
        segs.append(cur)
    # 3. identify each segment
    new_ci, new_sents, seg_reports = [], [], []
    order = 0
    used = set()
    for idxs in segs:
        sub = sents.iloc[idxs]
        raw = "".join(norm_keep_lacunae(t) for t in sub["normalized_text"].fillna(""))
        m = COLOPHON.search(raw[::-1])
        stated = None
        body = raw
        if raw.endswith("字"):
            mm = list(COLOPHON.finditer(raw))[-1]
            stated = cn_to_int(mm.group()); body = raw[: mm.start()]
        body_clean = PUNCT.sub("", body)
        scores = sorted(((fuzz.ratio(canon_n[ch], body_clean), ch) for ch in canon_n), reverse=True)
        best, ch = scores[0]
        second = scores[1][0]
        ident_ok = best >= IDENT_MIN and ch not in used
        actual = len(body)  # lacunae counted, punctuation not
        rep = {"segment_order": order, "stated_count": stated, "actual_count": actual,
               "count_delta": (actual - stated) if stated is not None else None,
               "identified_chapter": ch if ident_ok else -1, "ident_score": round(best, 1),
               "runner_up_score": round(second, 1), "chars": len(body_clean)}
        seg_reports.append(rep)
        s2 = sub.copy()
        # merged segment: the scribe omitted a colophon, so two chapters share one
        # segment (actual count far above stated). If another unused chapter is
        # clearly contained (partial_ratio >= 75), split at its start.
        if ident_ok and stated is not None and actual - stated > 20:
            cand = []
            for other in canon_n:
                if other in used or other == ch:
                    continue
                al = fuzz.partial_ratio_alignment(canon_n[other], body_clean)
                if al is not None and al.score >= 75:
                    cand.append((al.score, other, al.dest_start))
            if cand:
                _, other, cut_other = max(cand)
                al_ch = fuzz.partial_ratio_alignment(canon_n[ch], body_clean)
                cut_ch = al_ch.dest_start if al_ch else 0
                # the chapter that starts earlier comes first; cut where the second begins
                first, second = ((other, ch) if cut_other < cut_ch else (ch, other))
                cut_pos = max(cut_other, cut_ch)
                # map the cut (in clean-body coordinates) to sentence rows
                acc, split_rows = 0, []
                for _, r in sub.iterrows():
                    tn = norm_keep_lacunae(str(r["normalized_text"] or ""))
                    tc = PUNCT.sub("", tn)
                    if acc + len(tc) <= cut_pos or acc >= cut_pos:
                        split_rows.append((dict(r), first if acc < cut_pos else second)); acc += len(tc); continue
                    k = cut_pos - acc  # split inside this sentence
                    ra_, rb_ = dict(r), dict(r)
                    ra_["normalized_text"] = ra_["original_text"] = tn[:k]
                    rb_["normalized_text"] = rb_["original_text"] = tn[k:]
                    ra_["sentence_id"] = f"{r['sentence_id']}-a"; rb_["sentence_id"] = f"{r['sentence_id']}-b"
                    split_rows += [(ra_, first), (rb_, second)]; acc += len(tc)
                for which in (first, second):
                    rows_w = [rr for rr, w in split_rows if w == which]
                    if not rows_w:
                        continue
                    part = pd.DataFrame(rows_w)
                    txt_w = PUNCT.sub("", "".join(norm_keep_lacunae(t) for t in part["normalized_text"].fillna("")))
                    iid = f"{vid}-CH{which:03d}"
                    used.add(which)
                    new_ci.append({"instance_id": iid, "version_id": vid, "chapter_num": which,
                                   "raw_heading": f"colophon-merged-split:{first}+{second}",
                                   "char_count": len(txt_w), "order_in_doc": order,
                                   "segmentation_method": "colophon_recovery_v1.1.2_merged_split",
                                   "segmentation_score": None,
                                   "identification_score": round(fuzz.ratio(canon_n[which], txt_w) / 100, 3)})
                    part["instance_id"] = iid
                    new_sents.append(part)
                    order += 1
                rep["identified_chapter"] = f"{first}+{second}"
                rep["note"] = "merged segment split (missing colophon)"
                continue
        if ident_ok:
            used.add(ch)
            iid = f"{vid}-CH{ch:03d}"
            new_ci.append({"instance_id": iid, "version_id": vid, "chapter_num": ch,
                           "raw_heading": f"colophon:{raw[-6:]}" if stated is not None else "colophon:none",
                           "char_count": len(body_clean), "order_in_doc": order,
                           "segmentation_method": "colophon_recovery_v1.1.2",
                           "segmentation_score": None, "identification_score": round(best / 100, 3)})
            s2["instance_id"] = iid
        else:
            iid = f"{vid}-UNSEG"
            s2["instance_id"] = iid
        new_sents.append(s2)
        order += 1
    resid = [x for x in new_sents if (x["instance_id"] == f"{vid}-UNSEG").all()]
    if resid:
        rc = sum(len(PUNCT.sub("", "".join(x["normalized_text"].fillna("")))) for x in resid)
        new_ci.append({"instance_id": f"{vid}-UNSEG", "version_id": vid, "chapter_num": -1,
                       "raw_heading": "segments not identified to a chapter",
                       "char_count": rc, "order_in_doc": -1,
                       "segmentation_method": "none", "segmentation_score": None})
    seg_df = pd.DataFrame(seg_reports)
    with_count = seg_df.dropna(subset=["count_delta"])
    kept = [c for c in new_ci if c["chapter_num"] != -1]
    order_list = [c["chapter_num"] for c in sorted(kept, key=lambda c: c["order_in_doc"])]
    report = {
        "version_id": vid, "body_chars": int(sum(len(PUNCT.sub("", t)) for t in sents["normalized_text"].fillna(""))),
        "sentences": len(sents), "chapters_detected": len(segs), "chapters_kept": len(kept),
        "false_anchors_dropped": "",
        "chapters_recovered_in_manuscript_order": ";".join(map(str, order_list)),
        "standard_order": all(order_list[i] < order_list[i + 1] for i in range(len(order_list) - 1)),
        "chars_aligned": sum(c["char_count"] for c in kept),
        "chars_residual_unaligned": next((c["char_count"] for c in new_ci if c["chapter_num"] == -1), 0),
        "mean_identification_score": round(sum(c["identification_score"] for c in kept) / len(kept), 3) if kept else 0.0,
        "mean_anchor_coverage_score": None,
        "method": "colophon_recovery_v1.1.2", "recovery_reviewed": False,
        "colophons": int(seg_df["stated_count"].notna().sum()),
        "segments_unidentified": int((seg_df["identified_chapter"].astype(str) == "-1").sum()),
        "count_check_within_2": int((with_count["count_delta"].abs() <= 2).sum()),
        "count_check_median_abs_delta": float(with_count["count_delta"].abs().median()) if len(with_count) else None,
        "sentences_split_at_colophon": int(sents["sentence_id"].str.contains(r"-[a-z]$").sum()),
    }
    return pd.DataFrame(new_ci), pd.concat(new_sents, ignore_index=True), report, seg_df


def consistent_anchors(found):
    """found: list of dicts with chapter_num/start, sorted by start.
    Keep an anchor if its chapter number is within 3 of at least one positional
    neighbour; a lone anchor is kept only if it is the only one."""
    if len(found) <= 1:
        return found, []
    keep, drop = [], []
    for i, d in enumerate(found):
        prev_ok = i > 0 and abs(found[i - 1]["chapter_num"] - d["chapter_num"]) <= 3
        next_ok = i + 1 < len(found) and abs(found[i + 1]["chapter_num"] - d["chapter_num"]) <= 3
        (keep if (prev_ok or next_ok) else drop).append(d)
    return keep, [d["chapter_num"] for d in drop]


def recover_one(vid, sents, canon):
    sents = sents.sort_values("seq").reset_index(drop=True)
    texts = [norm(t) for t in sents["normalized_text"].fillna("")]
    offsets, pos = [], 0
    for t in texts:
        offsets.append(pos)
        pos += len(t)
    body = "".join(texts)

    found = []
    for ch, jw in canon.items():
        cl = clauses(jw)
        if not cl:
            continue
        hits = []
        for c in cl:
            i = body.find(c)
            if i != -1:
                hits.append(i)
            elif len(c) >= 6:
                r = fuzz.partial_ratio_alignment(c, body)
                if r is not None and r.score >= FUZZ:
                    hits.append(r.dest_start)
        need = 1 if len(cl) <= 3 else 2
        if len(hits) >= need:
            hits.sort()
            L = len(norm(jw))
            win = 2 * L + 50
            # densest cluster of hits (ties -> earliest); robust to a stray
            # formulaic clause matching elsewhere in the manuscript
            centre = max(hits, key=lambda h: (sum(1 for x in hits if abs(x - h) <= win), -h))
            near = [h for h in hits if abs(h - centre) <= win]
            found.append({"chapter_num": ch, "start": min(near), "hits": len(near),
                          "clauses": len(cl)})
    found.sort(key=lambda d: d["start"])
    kept, dropped = consistent_anchors(found)

    # sentence -> chapter by start position
    starts = [d["start"] for d in kept]
    assign = []
    for off, t in zip(offsets, texts):
        end = off + len(t)
        # a sentence that CONTAINS a chapter's anchor belongs to that chapter (the
        # opener is the strongest signal); otherwise the chapter whose start
        # precedes the sentence start
        k = bisect.bisect_right(starts, end - 1) - 1
        assign.append(kept[k]["chapter_num"] if k >= 0 else -1)
    sents = sents.assign(_ch=assign)

    new_ci, new_sents = [], []
    order = 0
    for d in kept:
        ch = d["chapter_num"]
        sub = sents[sents["_ch"] == ch]
        if sub.empty:
            continue
        iid = f"{vid}-CH{ch:03d}"
        new_ci.append({
            "instance_id": iid, "version_id": vid, "chapter_num": ch,
            "raw_heading": f"anchor:{clauses(canon[ch])[0][:12]}",
            "char_count": int(sub["normalized_text"].fillna("").str.len().sum()),
            "order_in_doc": order, "segmentation_method": "anchor_recovery_v1.1.2",
            "segmentation_score": None,
            # matched canonical clauses / canonical clauses: a COVERAGE ratio, not a
            # probability that the chapter identification is right
            "anchor_coverage_score": round(d["hits"] / d["clauses"], 3),
        })
        order += 1
        s2 = sub.drop(columns="_ch").copy()
        s2["instance_id"] = iid
        new_sents.append(s2)
    resid = sents[sents["_ch"] == -1]
    if not resid.empty:
        new_ci.append({
            "instance_id": f"{vid}-UNSEG", "version_id": vid, "chapter_num": -1,
            "raw_heading": "residual before first anchor",
            "char_count": int(resid["normalized_text"].fillna("").str.len().sum()),
            "order_in_doc": -1, "segmentation_method": "none", "segmentation_score": None,
        })
        new_sents.append(resid.drop(columns="_ch"))

    report = {
        "version_id": vid, "body_chars": len(body), "sentences": len(sents),
        "chapters_detected": len(found), "chapters_kept": len(kept),
        "false_anchors_dropped": ";".join(map(str, dropped)),
        "chapters_recovered_in_manuscript_order": ";".join(str(d["chapter_num"]) for d in kept),
        "standard_order": all(kept[i]["chapter_num"] < kept[i + 1]["chapter_num"]
                              for i in range(len(kept) - 1)),
        "chars_aligned": sum(c["char_count"] for c in new_ci if c["chapter_num"] != -1),
        "chars_residual_unaligned": int(resid["normalized_text"].fillna("").str.len().sum()) if not resid.empty else 0,
        "mean_anchor_coverage_score": round(sum(d["hits"] / d["clauses"] for d in kept) / len(kept), 3) if kept else 0.0,
        "mean_identification_score": None,
        "method": "anchor_recovery_v1.1.2", "recovery_reviewed": False,
    }
    return pd.DataFrame(new_ci), pd.concat(new_sents, ignore_index=True) if new_sents else sents.iloc[0:0], report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--report", default=None)
    a = ap.parse_args()
    d = a.data

    ci = pd.read_parquet(os.path.join(d, "chapter_instances.parquet"))
    se = pd.read_parquet(os.path.join(d, "sentences.parquet"))
    ref = pd.read_parquet(os.path.join(d, "wangbi_exegesis_source.parquet"))
    canon = {int(r.chapter_num): r.jingwen for r in ref.itertuples()}

    reports, ci_new, se_new = [], [], []
    for vid in TARGETS:
        old_ci = ci[ci["version_id"] == vid]
        if old_ci.empty or not (old_ci["chapter_num"] == -1).all():
            continue  # already aligned or absent: idempotent
        sub = se[se["version_id"] == vid]
        n_col = sum(len(COLOPHON.findall(norm_keep_lacunae(t))) for t in sub["normalized_text"].fillna(""))
        if n_col >= COLOPHON_MODE_MIN:
            c2, s2, rep, seg_df = recover_colophon(vid, sub, canon)
            seg_df.insert(0, "version_id", vid)
            seg_df.to_csv(os.path.join(d, f"alignment_recovery_segments_{vid}.csv"),
                          index=False, encoding="utf-8-sig")
        else:
            c2, s2, rep = recover_one(vid, sub, canon)
        reports.append(rep)
        ci_new.append(c2)
        se_new.append(s2)
        extra = (f"; colophons {rep['colophons']}, count-check within ±2: "
                 f"{rep['count_check_within_2']}/{rep['colophons']}, unidentified segments "
                 f"{rep['segments_unidentified']}") if rep["method"].startswith("colophon") else \
                f"; dropped anchors: {rep['false_anchors_dropped'] or 'none'}"
        print(f"{vid} [{rep['method']}]: {rep['chapters_kept']} chapters recovered "
              f"({rep['chars_aligned']}/{rep['body_chars']} chars aligned{extra})")

    if reports:
        done = {r["version_id"] for r in reports}
        base_cols = ["instance_id", "version_id", "chapter_num", "raw_heading", "char_count",
                     "order_in_doc", "segmentation_method", "segmentation_score"]
        for extra_col in ("anchor_coverage_score", "identification_score"):
            for df_ in ci_new:
                if extra_col not in df_.columns:
                    df_[extra_col] = None
        ci_keep = ci[~ci["version_id"].isin(done)]
        ci_out = pd.concat([ci_keep[base_cols], *ci_new], ignore_index=True)
        # carry any extra columns present on ci (none at this stage normally)
        for c in ci.columns:
            if c not in ci_out.columns:
                ci_out[c] = ci.set_index("instance_id")[c].reindex(ci_out["instance_id"]).values
        se_out = pd.concat([se[~se["version_id"].isin(done)], *se_new], ignore_index=True)
        # Three-state epistemic status. Recovered instances are algorithmic output
        # and stay OUT of the default analysis set until an expert confirms them
        # (attach_shipped_labels applies expert_confirmed / expert_corrected from
        # src/shipped_labels/alignment_review.csv).
        ci_out["alignment_review_status"] = "original_deterministic"
        ci_out.loc[ci_out["chapter_num"] == -1, "alignment_review_status"] = "not_aligned"
        ci_out.loc[ci_out["segmentation_method"].astype(str).str.contains("recovery"),
                   "alignment_review_status"] = "auto_recovered_unreviewed"
        ci_out.to_parquet(os.path.join(d, "chapter_instances.parquet"), index=False)
        se_out.to_parquet(os.path.join(d, "sentences.parquet"), index=False)
        rep_df = pd.DataFrame(reports)
        rep_df.to_csv(a.report or os.path.join(d, "alignment_recovery_report.csv"),
                      index=False, encoding="utf-8-sig")
    else:
        print("nothing to recover (idempotent)")


if __name__ == "__main__":
    main()
