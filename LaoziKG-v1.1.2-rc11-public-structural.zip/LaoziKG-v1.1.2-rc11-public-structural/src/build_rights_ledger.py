"""LaoziKG — Stage 9: per-source rights ledger (data/source_rights.csv).

Provider is INFERRED from the catalogue-id prefix, the title, and the edition
field; every row states the basis and a confidence for that inference. Nothing
here is a rights determination. Three layers are tracked separately —
(A) original_text_public_domain, (B) digitization_rights, (C) ocr_rights — because
a pre-modern work being out of copyright says nothing about the digital surrogate
or the transcription labour. redistribution_allowed is the conclusion that follows
from all three and is "unknown" until B and C are established from each provider's
terms. redistribution_status is not_reviewed on every
row and can only be changed by a human with the provider's terms in hand.

Usage: python src/build_rights_ledger.py --data data
"""
import argparse
import os
import re

import pandas as pd

# (regex on version_id | title | edition, provider, basis, confidence)
RULES = [
    (r"^DZ\d", "id", "正統道藏 (Daozang), via Shidian Guji", "id prefix DZ = 正統道藏 series on 识典古籍", "high"),
    (r"^ZHXDZ", "id", "中華續道藏 (Zhonghua Xu Daozang), via Shidian Guji", "id prefix ZHXDZ", "high"),
    (r"^ZWDS", "id", "藏外道書 (Zangwai Daoshu), via Shidian Guji", "id prefix ZWDS", "high"),
    (r"^SK\d", "id", "四庫全書 (Siku Quanshu), via Shidian Guji", "id prefix SK", "high"),
    (r"^SBCK", "id", "四部叢刊 (Sibu Congkan), via Shidian Guji", "id prefix SBCK", "high"),
    (r"^HY\d", "id", "涵芬樓/HY Daozang index, via Shidian Guji", "id prefix HY (Harvard-Yenching Daozang number)", "medium"),
    (r"^CADAL", "id", "CADAL digital library", "id prefix CADAL", "high"),
    (r"^PC\d|^P\.Ch\.", "id", "Pelliot chinois, Bibliothèque nationale de France (Dunhuang)", "Pelliot chinois shelfmark", "high"),
    (r"^S\d{4,}|Or\.8210/S\.", "id", "Stein collection, British Library (Dunhuang)", "Or.8210/S. shelfmark", "high"),
    (r"Or\.8210/S\.", "title", "Stein collection, British Library (Dunhuang)", "Or.8210/S. shelfmark in title", "high"),
    (r"P\.Ch\.", "title", "Pelliot chinois, Bibliothèque nationale de France (Dunhuang)", "P.Ch. shelfmark in title", "high"),
    (r"LM20-.*Ot\.", "title", "旅順博物館 Turfan fragment joined with 大谷文書 (Ryukoku)", "LM20 + Ot. shelfmarks in title", "high"),
    (r"^LSDZ", "id", "明《道藏》崂山太清宫藏本 (LSDZ series), digitized source undetermined", "id prefix LSDZ; edition 万历二十七年颁赐崂山太清宫", "medium"),
    (r"^NA\d", "id", "Japanese library holding (NA series; editions incl. 明治/天保/万曆 prints) — digitized source undetermined", "id prefix NA with Japanese-print editions; holder not confirmed", "low"),
    (r"^NGJ", "id", "Chinese library union catalogue record (NGJ series) — holder and digitized source undetermined", "id prefix NGJ; holder not confirmed", "low"),
    (r"^SDZJ", "id", "Daoist canon supplement series (SDZJ) — undetermined", "id prefix SDZJ; series not confirmed", "low"),
    (r"^AMNL", "id", "AMNL series — undetermined", "id prefix AMNL; not resolved", "low"),
    (r"^\d{15,}$", "id", "识典古籍 (Shidian Guji) numeric record; underlying holder per edition field", "15+ digit numeric id = Shidian Guji record id", "medium"),
    (r"^XYXJLZJYB$", "id", "郭店楚簡 transcription — digitized source undetermined", "custom id; excavated-text transcription", "low"),
    (r"^WANGBI_TONGSHI_2026$", "id", "Modern compilation by the dataset authors (derived resource)", "derived resource", "high"),
]

BASE_NOTE = ("Underlying pre-modern work is out of copyright by age. The DIGITIZED "
             "TRANSCRIPTION used here was obtained from a third-party platform; whether "
             "that transcription may be redistributed is a separate question and has not "
             "been determined.")


def infer(row):
    vid, title, ed = str(row["version_id"]), str(row["title"]), str(row.get("edition", ""))
    for pat, field, prov, basis, conf in RULES:
        target = {"id": vid, "title": title, "edition": ed}[field]
        if re.search(pat, target):
            return prov, basis, conf
    return "Unidentified — requires manual determination", "no rule matched", "none"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    d = ap.parse_args().data
    v = pd.read_csv(os.path.join(d, "versions.csv"), encoding="utf-8-sig", keep_default_na=False)
    prev_path = os.path.join(d, "source_rights.csv")
    prev = pd.read_csv(prev_path, encoding="utf-8-sig", keep_default_na=False) if os.path.exists(prev_path) else None

    rows = []
    for _, r in v.iterrows():
        prov, basis, conf = infer(r)
        modern = r["version_id"] == "WANGBI_TONGSHI_2026"
        # THREE SEPARABLE RIGHTS LAYERS. Only layer A is determinable from the
        # dataset itself (age of the underlying work). Layers B and C depend on
        # each provider's terms of use, which are not in the package, so they
        # stay undetermined and redistribution_allowed stays "unknown" —
        # a human with those terms fills them via expert_validation/
        # RIGHTS_WORKSHEET.md and the columns reviewer / review_date.
        rows.append({
            "version_id": r["version_id"], "source_title": r["title"],
            # provider of the DIGITAL surrogate (inferred, not confirmed)
            "digital_source_provider": prov,
            "provider_inference_basis": basis, "provider_inference_confidence": conf,
            "witness_era": r.get("witness_era_normalized", r.get("witness_era", "")),
            "edition": r.get("edition", ""), "resource_class": r["resource_class"],
            # layer A: the underlying pre-modern work
            "original_text_public_domain": "not_applicable_modern_compilation" if modern else "yes_by_age",
            # layer B: the digitization / database layer of the surrogate
            "digitization_rights": "authors_own" if modern else "not_determined",
            # layer C: transcription / OCR / collation labour embodied in the text we ingested
            "ocr_rights": "authors_own" if modern else "not_determined",
            # conclusion that follows from A+B+C — not answerable until they are
            "redistribution_allowed": "authors_own_work" if modern else "unknown",
            "license_basis": ("Compiled by the dataset authors; released under the terms in LICENSE_DATA.md."
                              if modern else "not_established"),
            "redistribution_status": "not_reviewed", "license": "undetermined",
            "evidence": "", "reviewer": "", "review_date": "",
            # PROPOSED release disposition under a conservative reading. This is
            # a packaging decision the dataset authors can act on now; it is NOT
            # a rights determination and does not set redistribution_status.
            #   full_text            — transcription is the authors' own work
            #   metadata_and_offsets — a third-party platform supplied the
            #                          transcription: ship structure, identifiers,
            #                          offsets and derived annotations, withhold
            #                          the character stream
            #   reference_only       — provider itself undetermined: cite the
            #                          witness, ship no text and no offsets
            "release_disposition": ("full_text" if modern else
                                    ("reference_only" if conf == "low" else "metadata_and_offsets")),
            "disposition_basis": ("Authors' own compilation." if modern else
                                  ("Digital source provider could not be identified above low "
                                   "confidence, so neither layer B nor layer C can even be "
                                   "attributed, let alone cleared." if conf == "low" else
                                   "Underlying work is public domain by age, but the transcription "
                                   "was obtained from a third-party platform whose terms are not "
                                   "established (layers B and C undetermined).")),
            "disposition_status": "proposed_not_cleared",
            "notes": "Compiled by the dataset authors in 2026." if modern else BASE_NOTE,
        })
    out = pd.DataFrame(rows)

    # ---- human-recorded sign-off, applied on top of inference --------------
    # src/shipped_labels/rights_sign_off.csv holds decisions a HUMAN made with
    # the rights in hand. Inference can never produce `cleared`; only this file
    # can, and it is separate from the inference tables above so the two cannot
    # be confused. Presently one row: the authors' own compilation, which is
    # settled because the authors are the rightsholders — not by any
    # determination about a third-party provider.
    _so = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "shipped_labels", "rights_sign_off.csv")
    if os.path.exists(_so):
        signed = pd.read_csv(_so, encoding="utf-8-sig", keep_default_na=False)
        unknown = set(signed["version_id"]) - set(out["version_id"])
        if unknown:
            raise SystemExit(f"rights_sign_off.csv names unknown version_id(s): "
                             f"{sorted(unknown)}")
        for _, sr in signed.iterrows():
            m = out["version_id"] == sr["version_id"]
            for c in signed.columns:
                if c != "version_id" and str(sr[c]).strip():
                    out.loc[m, c] = sr[c]
        print(f"applied {len(signed)} recorded rights sign-off(s)")

    # never lose a human review that was recorded in a previous ledger
    if prev is not None:
        rev_col = "reviewer" if "reviewer" in prev.columns else "reviewed_by"
        # carry forward only the columns a previous ledger actually had, so a
        # schema change cannot erase a recorded human review
        carry = [c for c in ("redistribution_status", "license", "redistribution_allowed",
                             "release_disposition", "disposition_basis", "disposition_status",
                             "license_basis", "digitization_rights", "ocr_rights",
                             "evidence", "review_date") if c in prev.columns]
        keep = prev.loc[prev[rev_col] != "", ["version_id", rev_col] + carry].rename(
            columns={rev_col: "reviewer"})
        if len(keep):
            out = out.drop(columns=[c for c in keep.columns if c != "version_id"]).merge(
                keep, on="version_id", how="left")
    out.to_csv(prev_path, index=False, encoding="utf-8-sig")
    print(f"rows: {len(out)}")
    print("provider confidence:", out["provider_inference_confidence"].value_counts().to_dict())
    print("unidentified:", int((out["provider_inference_confidence"] == "none").sum()))
    print("redistribution_allowed:", out["redistribution_allowed"].value_counts().to_dict())
    print("release_disposition (proposed):", out["release_disposition"].value_counts().to_dict())
    print("cleared for redistribution:", int((out["redistribution_status"] == "cleared").sum()))


if __name__ == "__main__":
    main()
