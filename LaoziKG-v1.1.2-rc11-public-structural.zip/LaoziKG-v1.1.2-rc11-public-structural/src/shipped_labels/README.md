# src/shipped_labels/ — machine-assigned labels shipped as data

These files hold every label that was produced by an LLM (MiniMax-M3) or by a
one-off diagnostic step and therefore **cannot be regenerated deterministically**.
They are inputs to `attach_shipped_labels.py` / `attach_person_eras.py`, which
join them onto the regenerated tables. Keeping them here — rather than baked
into the release tables only — makes the regeneration pipeline complete and makes
each label auditable and correctable in one place.

| File | Joins onto | Source | Reviewed |
|---|---|---|---|
| `version_work_types.csv` | versions.version_id | MiniMax-M3 batch (`work_type_source`) | no (`work_type_reviewed=FALSE`) |
| `concept_node_types.csv` | concepts.concept_id | MiniMax-M3 batch (`node_type_source`) | no |
| `concept_relations.csv` | — (whole table) | 32 deterministic name-containment + 35 MiniMax-M3 | no |
| `person_eras.csv` | persons.canonical_name | MiniMax-M3 + compiler reference cross-check | no (`era_reviewed=FALSE`) |
| `alignment_failure_diagnosis.csv` | versions.version_id | opener-matching diagnostic (v1.1.1) | no |

Changing a label here and re-running `regenerate_tables.py` propagates it.
