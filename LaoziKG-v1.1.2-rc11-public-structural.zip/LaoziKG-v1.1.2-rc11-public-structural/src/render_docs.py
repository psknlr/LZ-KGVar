"""
LaoziKG — render publication-facing documents from docs/templates/*.tmpl using
metadata/release_facts.json. Placeholders: {{key}} (formatted with thousands
separators for ints), {{key.sub}} for nested dicts, {{pct:key}} for one-decimal
percentages, {{raw:key}} for unformatted values. Unknown keys abort the render.

Rendered targets (template -> output):
  README.md.tmpl                   -> README.md
  DATASET_CARD.md.tmpl             -> docs/DATASET_CARD.md
  ZENODO_UPLOAD_METADATA.md.tmpl   -> docs/ZENODO_UPLOAD_METADATA.md
  CITATION.cff.tmpl                -> CITATION.cff
  CITATION.md.tmpl                 -> CITATION.md
  LICENSE_DATA.md.tmpl             -> LICENSE_DATA.md
  schema.md.tmpl                   -> docs/schema.md
  DATA_QUALITY_REPORT.md.tmpl      -> docs/DATA_QUALITY_REPORT.md

Usage: python src/render_docs.py --root .
"""
import argparse
import json
import os
import re

TARGETS = {
    "README.md.tmpl": "README.md",
    "DATASET_CARD.md.tmpl": os.path.join("docs", "DATASET_CARD.md"),
    "ZENODO_UPLOAD_METADATA.md.tmpl": os.path.join("docs", "ZENODO_UPLOAD_METADATA.md"),
    "CITATION.cff.tmpl": "CITATION.cff",
    "CITATION.md.tmpl": "CITATION.md",
    "REPRODUCIBILITY.md.tmpl": os.path.join("docs", "REPRODUCIBILITY.md"),
    "DATA_AVAILABILITY.md.tmpl": os.path.join("docs", "DATA_AVAILABILITY.md"),
    "rights_review_summary.md.tmpl": os.path.join("docs", "rights_review_summary.md"),
    "expert_validation_README.md.tmpl": os.path.join("expert_validation", "README.md"),
    "SAMPLING_DESIGN.md.tmpl": os.path.join("expert_validation", "SAMPLING_DESIGN.md"),
    "LICENSE_DATA.md.tmpl": "LICENSE_DATA.md",
    "schema.md.tmpl": os.path.join("docs", "schema.md"),
    "DATA_QUALITY_REPORT.md.tmpl": os.path.join("docs", "DATA_QUALITY_REPORT.md"),
}
PH = re.compile(r"\{\{\s*(pct:|raw:)?([A-Za-z0-9_.\-]+)\s*\}\}")


def lookup(facts, key):
    cur = facts
    for part in key.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            raise KeyError(key)
    return cur


def fmt(val, mode):
    if mode == "raw:":
        return str(val)
    if mode == "pct:":
        # The sign belongs to the formatter. Without it every author has to
        # remember to type a bare % after the placeholder, and one of them did
        # not: the dataset card read "the two differ for 66.4 of glosses".
        return f"{float(val):.1f}%"
    if isinstance(val, bool):
        return "TRUE" if val else "FALSE"
    if isinstance(val, int):
        return f"{val:,}"
    if isinstance(val, float):
        return f"{val:g}"
    return str(val)


def render(text, facts, name):
    missing = []
    def sub(m):
        try:
            return fmt(lookup(facts, m.group(2)), m.group(1))
        except KeyError:
            missing.append(m.group(2)); return m.group(0)
    out = PH.sub(sub, text)
    if missing:
        raise SystemExit(f"{name}: unknown fact keys {sorted(set(missing))}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    # Render INTO a distribution profile, from that profile's own facts. rc7
    # rendered the public distribution's documents from the FULL package's facts,
    # so every count a public reader saw described a corpus they did not have.
    ap.add_argument("--profile", default=None,
                    help="profile directory to render into (uses its "
                         "metadata/public_release_facts.json and the "
                         "docs/templates/public/ overlay where present)")
    a = ap.parse_args()
    if a.profile:
        facts = json.load(open(os.path.join(a.profile, "metadata",
                                            "public_release_facts.json"), encoding="utf-8"))
        # NO FALLBACK. rc8 merged the full facts underneath the profile's, which
        # meant any key the profile did not define silently resolved to a
        # full-corpus value — 94 of 117 keys did, and the public README ended up
        # printing 3,643 chapter instances beside 3,846 "default" ones. A missing
        # key is a bug in the profile's facts, and it fails here, loudly, naming
        # every key it could not resolve. The facts must be COMPLETE, not topped up.
        pass
    else:
        facts = json.load(open(os.path.join(a.root, "metadata", "release_facts.json"),
                               encoding="utf-8"))
    # derived convenience keys
    facts["graph_node_table_rows"] = "\n".join(f"| `{k}` | {v:,} |" for k, v in facts["graph_node_counts"].items())
    facts["graph_rel_table_rows"] = "\n".join(f"| `{k}` | {v:,} |" for k, v in facts["graph_rel_counts"].items())
    facts["provider_bucket_rows"] = "\n".join(f"| {k} | {v} |" for k, v in sorted(facts["rights_provider_buckets"].items(), key=lambda kv: -kv[1]))
    facts["work_type_rows"] = "\n".join(f"| `{k}` | {v} |" for k, v in facts["work_type"].items())
    facts["text_provenance_rows"] = "\n".join(f"| `{k}` | {v:,} |" for k, v in facts["text_provenance"].items())
    facts["recovery_rows"] = "\n".join(f"| {k} | {v['method'].replace('_v1.1.2','')} | {v['chapters']} |" for k, v in facts["recovery"].items())
    facts["tier_rows"] = "\n".join(f"| `{t}` | {facts['tier_concepts'].get(t,0)} | {facts['tier_edges'].get(t,0):,} | {facts['tier_occurrences'][t]:,} |" for t in ("high","medium","low"))
    facts["missing_recovered_default_note"] = ("excluded from default statistics until expert-confirmed"
                                              if facts["recovered_unreviewed_instances"] else "all expert-reviewed")
    src = ("public_release_facts.json (profile)" if a.profile
           else "release_facts.json")
    tdir = os.path.join(a.root, "docs", "templates")
    odir = os.path.join(tdir, "public")          # profile overlay
    outroot = a.profile or a.root
    n = 0
    for tmpl, target in TARGETS.items():
        tp = os.path.join(tdir, tmpl)
        if a.profile and os.path.exists(os.path.join(odir, tmpl)):
            tp = os.path.join(odir, tmpl)        # overlay wins for this profile
        if not os.path.exists(tp):
            continue
        out = render(open(tp, encoding="utf-8").read(), facts, tmpl)
        dst = os.path.join(outroot, target)
        os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
        open(dst, "w", encoding="utf-8").write(out)
        n += 1
    print(f"rendered {n} documents from {src} (version {facts['release_version']})")


if __name__ == "__main__":
    main()
