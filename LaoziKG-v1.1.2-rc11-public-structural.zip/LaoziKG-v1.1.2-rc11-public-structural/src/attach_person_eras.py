"""LaoziKG — Stage 7: attach historical-era assignments to persons.csv.

Era values live in src/person_eras.csv (auditable, LLM-assigned + reference
cross-check). This step joins them onto the canonical persons table. It was an
ad-hoc cell in v1.1.1, which meant the regeneration pipeline could not reproduce
persons.csv. Usage: python src/attach_person_eras.py --data data
"""
import argparse
import os

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ERA_COLS = ["person_historical_era", "person_historical_era_alt", "person_era_dates",
            "era_source", "era_confidence", "era_disputed"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    a = ap.parse_args()
    p = pd.read_csv(os.path.join(a.data, "persons.csv"), encoding="utf-8-sig")
    e = pd.read_csv(os.path.join(HERE, "shipped_labels", "person_eras.csv"), encoding="utf-8-sig")
    keep = ["canonical_name"] + [c for c in ERA_COLS if c in e.columns]
    p = p.drop(columns=[c for c in ERA_COLS + ["era_reviewed"] if c in p.columns])
    p = p.merge(e[keep], on="canonical_name", how="left")
    for c in ("person_historical_era", "person_historical_era_alt", "person_era_dates", "era_source"):
        p[c] = p[c].fillna("")
    p["era_confidence"] = p["era_confidence"].fillna("placeholder")
    p["era_disputed"] = p["era_disputed"].fillna(False).astype(bool)
    p["era_reviewed"] = False
    # Provenance of the cross-check reference set. It is compiler-curated
    # standard biographical dating (37 figures), NOT linked to an external
    # authority record such as CBDB; that link is future work and is said so.
    ref = p["era_source"] == "reference_crosschecked"
    p["era_reference_dates"] = p["person_era_dates"].where(ref, "")
    p["era_reference_source"] = ref.map({
        True: "compiler-curated standard biographical dates (v1.1.1); no external authority record linked",
        False: ""})
    ph = p["entity_status"] == "placeholder"
    p.loc[ph, ["era_source", "era_confidence"]] = "placeholder"
    p.to_csv(os.path.join(a.data, "persons.csv"), index=False, encoding="utf-8-sig")
    print(f"persons: {len(p)}; eras attached: {int((p['person_historical_era'] != '').sum())}")


if __name__ == "__main__":
    main()
