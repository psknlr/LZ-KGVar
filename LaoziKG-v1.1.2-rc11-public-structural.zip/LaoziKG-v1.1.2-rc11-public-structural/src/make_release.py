"""LaoziKG — release orchestrator with a correct freeze order.

The v1.1.0 flow was:

    make_metadata.py    # hashes qa/validation_report.json into checksums.sha256
    validate_dataset.py # REWRITES qa/validation_report.json

so the manifest was stale by construction on every run, and exactly one file
(qa/validation_report.json) failed verification every time. That was a release
bug, not data corruption.

Correct order, enforced here:

    1. build graph
    2. run QA
    3. freeze the validation report (nothing may rewrite it after this)
    4. generate metadata (data dictionary, statistics)
    5. generate manifest + checksums over everything
    6. VERIFY every checksum, and fail on any mismatch
    7. (packaging happens after, and touches no hashed file)

Usage: python src/make_release.py --root .
"""
import argparse
import hashlib
import datetime
import json
import os
import subprocess
import sys


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd, cwd, label):
    print(f"\n=== {label} ===")
    res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    tail = (res.stdout or "").strip().splitlines()[-6:]
    for line in tail:
        print("   " + line)
    if res.returncode != 0:
        print((res.stderr or "").strip()[-800:], file=sys.stderr)
        raise SystemExit(f"RELEASE FAILED at: {label} (exit {res.returncode})")
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--skip-build", action="store_true",
                    help="reuse the existing graph instead of rebuilding")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    py = sys.executable

    # ---- 1. build ----
    if not args.skip_build:
        run([py, "src/build_graph.py", "--data-dir", "data",
             "--db-path", os.path.join("data", "graph", "laozi_kg.kuzu")],
            root, "1/24 build graph")
    else:
        print("=== 1/24 build graph: SKIPPED (--skip-build) ===")

    # ---- 1b. facts, pass 1 ----
    # Two passes, because DUAL-PROFILE documents (the availability comparison
    # table, the citation note on differing counts) name both distributions'
    # numbers in one sentence, and the public numbers do not exist until the
    # profile has been generated. Pass 1 gives make_public_profile /
    # make_public_facts the release identity they read; pass 2 (stage 5d2) adds
    # the public_profile_* keys, and only then are the full package's documents
    # rendered. rc9 rendered them here, from facts that had no public vocabulary,
    # so each dual-profile cell fell back to the single key it shared with the
    # public cell — which is why CITATION.md claimed 51,648 edges "in the full
    # profile" when the full package has 58,619.
    run([py, "src/make_release_facts.py", "--root", "."], root,
        "2/24 compute release facts from the tables (pass 1: no profile yet)")

    # ---- 2. QA (data) + tool tests (software), on the FULL package ----
    qa_report = os.path.join(root, "qa", "validation_report.json")
    # figures are generated, not copied in — before QA, so the manifest hashes
    # what was actually rendered from this release's facts
    run([py, "src/make_figures.py", "--root", ".", "--out", "figures"],
        root, "3/24 render the full package's figures from its facts and tables")

    # QA for the full package now runs at stage 8a, after BOTH distributions'
    # documents have been rendered — its guards read those documents, so running
    # it here would validate the previous run's prose.

    # ---- 4. metadata for the FULL package ----
    run([py, "src/make_metadata.py", "--root", "."], root, "4/24 generate full-package metadata")

    # ---- 5. the public structural release, generated AFTER the full package is
    # final. In v1.1.2-rc6 the profile was produced at stage 1d, before the QA run
    # and before make_metadata, so the qa/ report and metadata/ manifest it carried
    # were the PREVIOUS run's — the profile's own checksum file could not verify
    # the profile. Each distribution now gets its own QA pass and its own manifest.
    PROFILE = os.path.join("dist", "public_structural_release")
    run([py, "src/make_public_profile.py", "--root", ".", "--out", PROFILE],
        root, "5/24 generate the sanitized public structural release")

    prof_root = os.path.join(root, PROFILE)
    # metadata BEFORE QA here: the profile's manifest is one of the things the
    # profile's QA verifies, so it has to exist first.
    # The profile's documents must be rendered from the PROFILE's own facts, not
    # the full package's — rc7 shipped a public README quoting full-corpus counts.
    # The profile FILTERS the validation frames after they were drawn, so its
    # scores and its packet description must be recomputed there — rc8 shipped the
    # unfiltered protocol's metrics (2,031 items, a 400-item packet) inside a copy
    # holding 1,816 and 356. Mirror mode describes the sheets present and draws
    # nothing: re-drawing would break id correspondence with the internal packet.
    run([py, "src/score_validation.py", "--frames",
         os.path.join(PROFILE, "expert_validation")],
        root, "6/24 re-score the profile's validation frames after filtering")
    run([py, "src/make_priority_set.py", "--frames",
         os.path.join(PROFILE, "expert_validation"), "--mirror",
         "--full-frames", "expert_validation"],
        root, "7/24 describe the profile's packet as a filtered mirror")

    run([py, "src/make_public_facts.py", "--profile", PROFILE, "--full-root", "."],
        root, "8/24 compute public-profile facts from the profile's own tables")
    # pass 2: the full facts now learn this distribution's counts, so a
    # dual-profile document renders the full column from *_full_corpus and the
    # public column from public_profile_* — correct in either rendering.
    run([py, "src/make_release_facts.py", "--root", ".", "--profile-facts",
         os.path.join(PROFILE, "metadata", "public_release_facts.json")],
        root, "9/24 recompute release facts with the profile's counts (pass 2)")
    run([py, "src/render_docs.py", "--root", "."],
        root, "10/24 render the full package's documents from the complete facts")
    run([py, "src/render_docs.py", "--root", ".", "--profile", PROFILE],
        root, "11/24 render the profile's documents from its own facts")
    # Figures LAST among the profile's content, so they are drawn from the facts
    # that were just computed. rc8 copied the full package's figures verbatim, so
    # the public set displayed full-corpus counts.
    run([py, "src/make_figures.py", "--root", PROFILE, "--facts",
         os.path.join(PROFILE, "metadata", "public_release_facts.json"),
         "--out", os.path.join(PROFILE, "figures")],
        root, "12/24 render the profile's figures from its own facts and tables")

    # ---- 8a. QA, on documents that are now final ----
    run([py, "qa/validate_dataset.py", "--data", "data",
         "--out", os.path.join("qa", "validation_report.json")],
        root, "13/24 run data QA on the full package (includes executed clean-room regeneration)")
    run([py, "qa/test_tools.py", "--db", os.path.join("data", "graph", "laozi_kg.kuzu"),
         "--data", "data"], root, "14/24 run tool-module result tests")
    frozen = sha256_file(qa_report)
    print(f"\n=== 15/24 freeze validation report ===\n   sha256 {frozen[:16]}…")

    # Figures now exist, so the profile report's final-state fields can be filled
    # in. Must happen before stage 6 hashes the report.
    run([py, "src/make_public_profile.py", "--out", PROFILE, "--finalize"],
        root, "16/24 finalize the profile report now that its figures exist")

    run([py, "src/make_metadata.py", "--root", PROFILE],
        root, "17/24 generate public-profile metadata and checksums")
    run([py, os.path.join("qa", "validate_public_profile.py"), "--profile", PROFILE,
         "--full-root", ".", "--out", os.path.join(PROFILE, "qa", "public_profile_qa_report.json")],
        root, "18/24 run QA on the public structural release")

    # The profile's QA report is a released payload, and it is written by the
    # step above — after its manifest. rc7 therefore shipped it unhashed. Re-run
    # the profile's metadata so the manifest covers it; only the manifest and the
    # checksum index itself remain unlisted, which is unavoidable.
    run([py, "src/make_metadata.py", "--root", PROFILE],
        root, "19/24 re-hash the profile so the manifest covers its QA report")

    # ---- 8. root manifest + checksums, written last so they cover the profile ----
    run([py, "src/make_metadata.py", "--root", "."],
        root, "20/24 regenerate root manifest over the finished tree")

    # The QA report must not have been rewritten after the freeze.
    if sha256_file(qa_report) != frozen:
        raise SystemExit("validation_report.json changed after freeze — "
                         "release order is wrong")
    print("   full-package validation report unchanged since freeze: OK")

    def verify(base, label):
        """Recompute every digest in base/metadata/checksums.sha256 against base."""
        cp = os.path.join(base, "metadata", "checksums.sha256")
        if not os.path.exists(cp):
            raise SystemExit(f"{label}: checksums.sha256 was not produced")
        bad, checked = [], 0
        with open(cp, encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if not line.strip():
                    continue
                digest, rel = line.split("  ", 1)
                full = os.path.join(base, rel)
                if not os.path.exists(full):
                    bad.append((rel, "MISSING"))
                    continue
                checked += 1
                if sha256_file(full) != digest:
                    bad.append((rel, "MISMATCH"))
        print(f"   {label}: verified {checked} files")
        if bad:
            for rel, why in bad[:20]:
                print(f"   {why}: {rel}")
            raise SystemExit(f"RELEASE FAILED: {label}: {len(bad)} checksum problem(s)")
        return checked

    # ---- 9-10. verify each distribution against ITS OWN manifest ----
    print("\n=== 21/24 verify public-profile checksums ===")
    prof_checked = verify(prof_root, "public structural release")
    print("\n=== 22/24 verify root checksums ===")
    checked = verify(root, "full package")
    print("   all checksums verified")

    # ---- 11. the profile's QA must have passed on its own terms ----
    ppr = os.path.join(prof_root, "qa", "public_profile_qa_report.json")
    pp = json.load(open(ppr, encoding="utf-8")) if os.path.exists(ppr) else {}
    if pp.get("errors", 1) != 0:
        raise SystemExit(f"RELEASE FAILED: public-profile QA reported "
                         f"{pp.get('errors')} error(s) — see {ppr}")
    print(f"\n=== 23/24 public-profile QA: {pp.get('checks_passed')}/"
          f"{pp.get('checks_total')} passed ===")

    # ---- 12. final-state record, written after the last file ----
    # Every other count in the tree is captured at some point DURING the build:
    # facts before the manifest, the profile's QA report before its own re-hash.
    # This one is written last and describes the tree as shipped, so a reader has
    # one file whose numbers are not "as of an earlier stage". It is itself
    # unhashable for the same reason checksums.sha256 is — it reports on the
    # manifest — and both distributions' documents name it rather than a count.
    final = {
        "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "release_version": open(os.path.join(root, "VERSION"),
                                encoding="utf-8").read().strip(),
        "full_internal": {
            "payload_files_verified": checked,
            "manifest": "metadata/checksums.sha256",
            "unhashable_self_references": ["metadata/checksums.sha256",
                                           "metadata/file_manifest.csv",
                                           "metadata/final_release_verification.json"],
        },
        "public_structural_release": {
            "payload_files_verified": prof_checked,
            "manifest": "metadata/checksums.sha256",
            "qa_checks": f"{pp.get('checks_passed')}/{pp.get('checks_total')}",
        },
        "validation_report_sha256": frozen,
        "note": ("Written in the final release stage, after every other file. "
                 "Counts recorded earlier in the build (release facts, the "
                 "profile report, the profile's QA report) describe the tree at "
                 "the stage that produced them; these describe it as shipped."),
    }
    for tree in (root, prof_root):
        with open(os.path.join(tree, "metadata", "final_release_verification.json"),
                  "w", encoding="utf-8") as fh:
            json.dump(final, fh, ensure_ascii=False, indent=1)
    print(f"\n=== 24/24 final verification record written to both distributions ===")

    summary = {"root": os.path.basename(root), "files_verified": checked,
               "public_profile_files_verified": prof_checked,
               "public_profile_checks": f"{pp.get('checks_passed')}/{pp.get('checks_total')}",
               "validation_report_sha256": frozen}
    print("\n" + json.dumps(summary, indent=2))
    print("\nRelease is consistent. Package now; do not modify any hashed file.")


if __name__ == "__main__":
    main()
