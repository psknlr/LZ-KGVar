"""LaoziKG — run the full table-regeneration pipeline in order.

    normalize_tables → recover_alignment → attach_shipped_labels → extract_mentions
    → separate_commentary_provenance
    → canonicalize_persons → add_anonymous_authorship → derive_instance_fields
    → attach_person_eras → derive_commentary_fields → build_rights_ledger

Stage order matters (canonicalize before anonymous authorship, or the edge
count differs by one). This is the single entry point used by both the release
flow and the QA clean-room smoke test, so the two cannot drift apart.

Usage: python src/regenerate_tables.py --src legacy/v1.0.0_inputs --out <dir>
"""
import argparse
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CARRY = ("wangbi_exegesis_source.parquet",
         "candidate_concepts_oov.csv")


def run(args, label):
    res = subprocess.run([sys.executable, *args], capture_output=True, text=True)
    if res.returncode != 0:
        sys.stderr.write(f"[{label}] FAILED\n{res.stderr[-1500:]}\n")
        raise SystemExit(res.returncode)
    print(f"[{label}] ok")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    s = lambda name: os.path.join(HERE, name)

    run([s("normalize_tables.py"), "--src", a.src, "--out", a.out], "normalize_tables")
    for f in CARRY:
        p = os.path.join(a.src, f)
        if os.path.exists(p):
            shutil.copy(p, os.path.join(a.out, f))
    run([s("recover_alignment.py"), "--data", a.out], "recover_alignment")
    run([s("attach_shipped_labels.py"), "--data", a.out], "attach_shipped_labels")
    run([s("extract_mentions.py"), "--data", a.out], "extract_mentions")
    run([s("separate_commentary_provenance.py"), "--data", a.out], "separate_commentary_provenance")
    run([s("canonicalize_persons.py"), "--data", a.out], "canonicalize_persons")
    run([s("add_anonymous_authorship.py"), "--data", a.out], "add_anonymous_authorship")
    run([s("derive_instance_fields.py"), "--data", a.out], "derive_instance_fields")
    run([s("attach_person_eras.py"), "--data", a.out], "attach_person_eras")
    run([s("derive_commentary_fields.py"), "--data", a.out], "derive_commentary_fields")
    run([s("build_rights_ledger.py"), "--data", a.out], "build_rights_ledger")
    # candidate claims are not primary data: route them out of the data dir
    dv = os.path.join(os.path.dirname(os.path.abspath(a.out)), "derived_unverified")
    if os.path.isdir(dv):
        for f in ("candidate_scholarly_claims.csv", "candidate_scholarly_claim_evidence.csv"):
            src_f = os.path.join(a.out, f)
            if os.path.exists(src_f):
                shutil.move(src_f, os.path.join(dv, f))
    print("regeneration complete ->", a.out)


if __name__ == "__main__":
    main()
