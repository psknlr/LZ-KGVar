"""LaoziKG — Stage 3: separate attested source text from LLM output in the
commentary layer.

The problem
-----------
v1.0.0 held a single column, `interpretation_text`, for all 2,635 commentary
records, with `is_verified_contiguous_quote = 'unchecked'` on every row. Because
that text reads as classical prose, a reader cannot tell whether a given value
is (a) a verbatim span of the historical commentator's words or (b) an
LLM-produced condensation of them. 2,627 of the 2,635 records were produced by
an LLM (llm_assisted_batch_v1: 2,138; minimax-m3: 489), so the distinction is
load-bearing: quoting (b) as if it were (a) would misattribute modern
machine-generated prose to Wang Bi, Heshanggong, and others.

What this script does
---------------------
For each record it locates the text in its own source document (the sentence
layer for that chapter instance, script-normalized) and classifies it:

  verbatim_contiguous  the whole string occurs as one uninterrupted span
                       -> source_quote is populated; safe to cite as the
                          commentator's words
  spliced_from_source  every character is drawn from the source but the string
                       is not contiguous (the LLM joined separated fragments,
                       usually without an ellipsis)
                       -> llm_interpretation is populated; source_char_overlap
                          records how much of it is source-derived
  not_located          the string could not be aligned to the source document
                       -> llm_interpretation only; must not be cited as a quote

Output columns replacing `interpretation_text`:
  source_quote            verbatim span, or empty
  normalized_quote        punctuation-stripped, script-normalized form
  llm_interpretation      machine-generated text, or empty
  text_provenance         one of the three classes above
  source_char_overlap     fraction of characters present in the source document
  citable_as_quote        boolean; TRUE only for verbatim_contiguous

Usage: python src/separate_commentary_provenance.py --data <v1.1.0 data dir>
"""
import argparse
import os
import re
from collections import Counter

import pandas as pd
from opencc import OpenCC

CC = OpenCC("t2s")
PUNCT = re.compile(
    r"[，。；：？！、\s,\.;:\?!\u201c\u201d\u2018\u2019「」『』（）()\[\]【】·—…]"
)


def norm(text):
    return PUNCT.sub("", CC.convert(str(text)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    args = ap.parse_args()

    commentary = pd.read_csv(os.path.join(args.data, "commentary.csv"), encoding="utf-8-sig")
    sentences = pd.read_parquet(os.path.join(args.data, "sentences.parquet"))

    # Source document text per chapter instance, and per version as a fallback
    # (a few commentary records point at an instance_id absent from the
    # sentence layer; the version-level blob still lets us classify them).
    sentences = sentences.copy()
    sentences["_n"] = [norm(t) for t in sentences["normalized_text"].fillna("")]
    inst_text = sentences.groupby("instance_id")["_n"].apply("".join).to_dict()
    ver_text = sentences.groupby("version_id")["_n"].apply("".join).to_dict()

    # The WANGBI_TONGSHI_2026 records were extracted from the Wang Bi 通释
    # exegesis document, whose text is NOT in the sentence layer. v1.0.0 shipped
    # no copy of that source at all, which made 423 commentary records
    # impossible for a third party to verify. The source table is restored as
    # wangbi_exegesis_source.parquet and used here as the haystack for that
    # version, keyed by chapter.
    wb_path = os.path.join(args.data, "wangbi_exegesis_source.parquet")
    wb_chapter_text = {}
    if os.path.exists(wb_path):
        wb = pd.read_parquet(wb_path)
        for _, wrow in wb.iterrows():
            blob = "".join(str(wrow.get(col) or "") for col in
                           ("jingwen", "wangbi_commentary", "quanjie_interpretation"))
            wb_chapter_text[int(wrow["chapter_num"])] = norm(blob)

    rows = []
    stats = Counter()
    for _, rec in commentary.iterrows():
        raw = str(rec.get("interpretation_text") or "")
        needle = norm(raw)
        if rec.get("version_id") == "WANGBI_TONGSHI_2026":
            try:
                haystack = wb_chapter_text.get(int(rec.get("chapter_num")), "")
            except (TypeError, ValueError):
                haystack = ""
            scope = "wangbi_exegesis_source"
        else:
            haystack = inst_text.get(rec.get("instance_id")) or ""
            scope = "instance"
            if not haystack:
                haystack = ver_text.get(rec.get("version_id")) or ""
                scope = "version"

        if needle and haystack and needle in haystack:
            provenance = "verbatim_contiguous"
            overlap = 1.0
        elif needle and haystack:
            # character-multiset overlap: how much of the string exists in source
            hay_counts = Counter(haystack)
            need_counts = Counter(needle)
            present = sum(min(n, hay_counts.get(ch, 0)) for ch, n in need_counts.items())
            overlap = present / max(1, len(needle))
            provenance = "spliced_from_source" if overlap >= 0.90 else "not_located"
        else:
            provenance = "not_located"
            overlap = 0.0

        stats[provenance] += 1
        stats[f"scope_{scope}"] += 1

        verbatim = provenance == "verbatim_contiguous"
        rows.append({
            "source_quote": raw if verbatim else "",
            "normalized_quote": needle if verbatim else "",
            "llm_interpretation": "" if verbatim else raw,
            "text_provenance": provenance,
            "source_char_overlap": round(float(overlap), 4),
            "citable_as_quote": verbatim,
            "source_match_scope": scope,
        })

    out = pd.concat([commentary.drop(columns=["interpretation_text",
                                              "is_verified_contiguous_quote"],
                                     errors="ignore"),
                     pd.DataFrame(rows)], axis=1)
    out.to_csv(os.path.join(args.data, "commentary.csv"), index=False, encoding="utf-8-sig")

    print(f"records processed: {len(out)}")
    for key in ["verbatim_contiguous", "spliced_from_source", "not_located"]:
        n = stats[key]
        print(f"  {key}: {n} ({n / len(out) * 100:.1f}%)")
    print(f"citable_as_quote TRUE: {int(out['citable_as_quote'].sum())}")
    print("by extraction_method:")
    print(out.groupby(["extraction_method", "text_provenance"]).size().to_string())


if __name__ == "__main__":
    main()
