"""
LaoziKG — build the PUBLIC STRUCTURAL RELEASE profile.

The full distribution carries transcribed character streams obtained from
third-party platforms whose terms are not established (see
data/source_rights.csv, layers B and C). This script emits a second
distribution — the one that can actually be published now — which withholds
exactly those character streams while keeping
everything the dataset authors own: structure, identifiers, offsets, character
counts, all derived annotations, the concept/commentary/variant layers'
metadata, statistics and the graph inputs.

Rule applied per row, driven by source_rights.release_disposition:
  full_text            -> text kept
  metadata_and_offsets -> text columns emptied, offsets and lengths kept
  reference_only       -> text emptied AND per-sentence rows dropped; the
                          witness survives as a citable record only

The result is publishable without clearing a single third-party transcription.
It is NOT a rights determination and does not change redistribution_status.

Usage: python src/make_public_profile.py --root . --out dist/public_structural_release
"""
import argparse
import json
import os
import sys
import shutil

import pandas as pd

# table -> columns holding transcribed source characters.
#
# llm_interpretation is here despite being machine output, because the project's
# own provenance definition disqualifies the "it is our text" argument for most
# of it: `spliced_from_source` means every character is drawn from the source and
# only the ordering is the model's. In v1.1.2-rc10 the public profile shipped 963
# such records carrying 33,709 characters — 900 of them at source_char_overlap =
# 1.0, the longest a single 83-character run — while every declared source column
# beside them was correctly blank. Whether a re-ordered copy of someone else's
# transcription is a new work is a question this release does not need to answer:
# the profile's promise is zero third-party character stream, so the safe reading
# is the one that keeps the promise true.
#
# Emptying is per-resource (full_text keeps its text) and each emptied column
# leaves a *_char_count behind, so the authors' own cleared compilation is
# unaffected and length/structure survive for everything else.
TEXT_COLUMNS = {
    "sentences.parquet": ["original_text", "normalized_text"],
    "chapter_instances.parquet": ["raw_heading"],
    "commentary.csv": ["source_quote", "normalized_quote", "llm_interpretation"],
    "evidence.parquet": ["quote"],
    "variants.parquet": ["old_text", "new_text"],
    "wangbi_exegesis_source.parquet": ["jingwen", "wangbi_commentary", "quanjie_interpretation"],
}

# RELATIONAL CASCADE. Withholding a resource has to propagate through every table
# that references it, not only the tables that happen to carry a version column —
# v1.1.2-rc6 dropped 249 commentary rows while leaving all 2,635 rows of
# commentary_concept_links, so 249 links pointed at commentary that no longer
# existed. Each stage names the key it filters on and the key it then produces.
CASCADE = [
    # (table, key column, which retained-key set to filter against)
    ("chapter_instances.parquet", "version_id", "version"),
    ("sentences.parquet", "version_id", "version"),
    ("authorship_edges.csv", "version_id", "version"),
    ("alignment_failure_diagnosis.csv", "version_id", "version"),
    ("alignment_recovery_report.csv", "version_id", "version"),
    ("alignment_recovery_segments_S06453.csv", "version_id", "version"),
    ("source_rights.csv", None, None),                 # keep every row: it is the ledger
    ("commentary.csv", "instance_id", "instance"),
    ("concept_chapter_mentions.csv", "instance_id", "instance"),
    ("concept_recovered_mentions.csv", "instance_id", "instance"),
    ("concept_unaligned_mentions.csv", "instance_id", "instance"),
    ("concept_sentence_mentions.parquet", "sentence_id", "sentence"),
    ("concept_sentence_recovered_mentions.parquet", "sentence_id", "sentence"),
    ("concept_sentence_unaligned_mentions.parquet", "sentence_id", "sentence"),
    ("variants.parquet", "instance_id", "instance"),
    ("commentary_concept_links.csv", "commentary_id", "commentary"),
    # evidence's FK is `source_ref`, NOT `commentary_id` — the table has no such
    # column. rc7 declared the wrong name here AND in the profile validator, so
    # the filter matched nothing and the validator's `if key not in df.columns:
    # continue` skipped the check: 249 evidence rows for withheld resources
    # shipped in the public profile under a 7/7 pass.
    ("evidence.parquet", "source_ref", "commentary"),
]

# Columns anywhere in the copied directories that hold TRANSCRIBED SOURCE
# CHARACTERS. rc6 copied expert_validation/, derived_diagnostics/ and
# derived_unverified/ verbatim, reintroducing ~63,000 characters of the very text
# the data tables had withheld.
#
# Driven by COLUMN NAME, not by file path, deliberately: a per-file list has to be
# updated whenever a frame is added or renamed, and silently leaks when it is not
# (a path-keyed first draft of this list missed the whole priority-set directory
# because the sheets had been renamed). Any file carrying one of these columns is
# sanitized wherever it sits.
#
# Columns NOT listed are deliberately retained, because they are not third-party
# transcriptions: bibliographic metadata (title, author_raw, commentator_raw,
# edition), the project's own machine output that is NOT drawn from the source
# (definition_core, evidence, claim_text — llm_interpretation moved to
# TEXT_COLUMNS above, see the note there), the question prompts, and every
# identifier, offset,
# character count and adjudication field — so the validation protocol stays
# runnable from the public profile.
SANITIZE_COLUMNS = [
    "original_text", "normalized_text", "raw_heading",
    "source_quote", "normalized_quote", "quote",
    "old_text", "new_text",
    "jingwen", "wangbi_commentary", "quanjie_interpretation",
    "recovered_text", "canonical_chapter_text",
    "segment_text_as_transmitted", "canonical_wangbi_text",
]
# Columns withheld PER RESOURCE (kept for full_text, emptied otherwise) wherever
# they appear outside data/ — the frames and packets carry copies of the same
# commentary rows, so the rule has to be the same in both places.
CONDITIONAL_TEXT_COLUMNS = ["llm_interpretation"]

SANITIZE_DIRS = ["expert_validation", "derived_diagnostics", "derived_unverified"]


def _finalize(out):
    """Refresh fields that are only knowable after the release flow finishes.

    The profile report is written during generation, but figures are rendered
    afterwards (they need the profile's facts, which need the profile). Rather
    than assert a value that cannot be known yet, generation writes None and
    this pass fills it in from what is actually on disk.
    """
    import glob as _glob
    rp = os.path.join(out, "public_profile_report.json")
    rep = json.load(open(rp, encoding="utf-8"))
    figs = sorted(os.path.basename(f) for f in _glob.glob(os.path.join(out, "figures", "*.png")))
    rep.setdefault("reproduction_paths", {})["figures_included"] = bool(figs)
    rep["reproduction_paths"]["figures"] = figs
    rep["finalized"] = True
    json.dump(rep, open(rp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"finalized profile report: figures_included={bool(figs)} ({len(figs)} figures)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", default=os.path.join("dist", "public_structural_release"))
    ap.add_argument("--finalize", action="store_true",
                    help="only refresh final-state fields of an existing profile report")
    a = ap.parse_args()
    if a.finalize:
        _finalize(a.out)
        return
    root, out = a.root, os.path.join(a.root, a.out)
    src_data = os.path.join(root, "data")
    out_data = os.path.join(out, "data")
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out_data, exist_ok=True)

    rights = pd.read_csv(os.path.join(src_data, "source_rights.csv"),
                         encoding="utf-8-sig", keep_default_na=False)
    keep_text = set(rights.loc[rights["release_disposition"] == "full_text", "version_id"].astype(str))
    ref_only = set(rights.loc[rights["release_disposition"] == "reference_only", "version_id"].astype(str))

    report = {"profile": "public_structural_release", "full_text_versions": len(keep_text),
              "metadata_and_offsets_versions": int((rights["release_disposition"] == "metadata_and_offsets").sum()),
              "reference_only_versions": len(ref_only), "tables": {}}

    # ---- stage 1: retained key sets, computed in dependency order ----
    def load(fn):
        path = os.path.join(src_data, fn)
        return (pd.read_parquet(path) if fn.endswith(".parquet")
                else pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False))

    keep_versions = set(rights.loc[rights["release_disposition"] != "reference_only",
                                   "version_id"].astype(str))
    ci_full = load("chapter_instances.parquet")
    keep_instances = set(ci_full.loc[ci_full["version_id"].astype(str).isin(keep_versions),
                                     "instance_id"].astype(str))
    se_full = load("sentences.parquet")
    keep_sentences = set(se_full.loc[se_full["version_id"].astype(str).isin(keep_versions),
                                     "sentence_id"].astype(str))
    cm_full = load("commentary.csv")
    keep_commentary = set(cm_full.loc[cm_full["instance_id"].astype(str).isin(keep_instances),
                                      "commentary_id"].astype(str))
    KEEP = {"version": keep_versions, "instance": keep_instances,
            "sentence": keep_sentences, "commentary": keep_commentary}
    cascade_map = {t: (k, w) for t, k, w in CASCADE}
    report["retained_keys"] = {k: len(v) for k, v in KEEP.items()}

    # ---- stage 2: write every table, cascade-filtered then text-withheld ----
    for fn in sorted(os.listdir(src_data)):
        if not fn.endswith((".csv", ".parquet")) or fn.startswith("_"):
            continue
        df = load(fn)
        before = len(df)
        dropped = 0
        key, which = cascade_map.get(fn, (None, None))
        if key and which and key in df.columns:
            mask = ~df[key].astype(str).isin(KEEP[which])
            dropped = int(mask.sum())
            df = df[~mask].reset_index(drop=True)
        elif fn not in cascade_map and "version_id" in df.columns and fn != "versions.csv":
            # a table nobody declared but which is version-keyed: filter it rather
            # than ship rows for a withheld resource
            mask = ~df["version_id"].astype(str).isin(keep_versions)
            dropped = int(mask.sum())
            df = df[~mask].reset_index(drop=True)
        emptied = []
        for col in TEXT_COLUMNS.get(fn, []):
            if col not in df.columns:
                continue
            if "version_id" in df.columns:
                m = ~df["version_id"].astype(str).isin(keep_text)
            else:
                m = pd.Series(True, index=df.index)      # no version key: withhold wholesale
            lc = f"{col}_char_count"
            if lc not in df.columns:
                df[lc] = df[col].fillna("").astype(str).str.len()
            df.loc[m, col] = ""
            emptied.append(col)
        report["tables"][fn] = {"rows_before": before, "rows_after": len(df),
                                "rows_dropped_reference_only": dropped,
                                "text_columns_withheld": emptied,
                                "cascade_key": key or ("version_id" if dropped and fn not in cascade_map else None)}
        (df.to_parquet(os.path.join(out_data, fn), index=False) if fn.endswith(".parquet")
         else df.to_csv(os.path.join(out_data, fn), index=False, encoding="utf-8-sig"))

    # ---- stage 3: copy documentation, code and validation material ----
    # figures/ ships here too: the six release figures are rendered from the
    # structured tables (counts, eras, co-occurrence), not reproduced from any
    # source scan or transcription, so they carry no third-party text. rc7's
    # public dataset card listed them while the distribution omitted them.
    for sub in ("docs", "metadata", "src", "qa", "expert_validation", "derived_diagnostics",
                "derived_unverified", "figures"):
        if os.path.isdir(os.path.join(root, sub)):
            shutil.copytree(
                os.path.join(root, sub), os.path.join(out, sub),
                # release_facts.json is the FULL package's facts — every count in
                # it is full-corpus. Copying it in put a file reading
                # chapter_instances 4,009 inside a distribution holding 3,643, and
                # sent any reader who opened it to the wrong numbers. The profile
                # gets public_release_facts.json, generated afterwards.
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc",
                                              # both describe the FULL package in
                                              # full-corpus terms; the profile gets
                                              # public_release_facts.json and its own
                                              # public_profile_qa_report.json instead
                                              "release_facts.json",
                                              "validation_report.json"))

    # ---- stage 3b: sanitize the copies ----
    san = {}
    for sub in SANITIZE_DIRS:
        base = os.path.join(out, sub)
        if not os.path.isdir(base):
            continue
        for dirpath, _dirs, files in os.walk(base):
            for f in sorted(files):
                if not f.endswith((".csv", ".parquet")):
                    continue
                path = os.path.join(dirpath, f)
                rel = os.path.relpath(path, out)
                try:
                    d = (pd.read_parquet(path) if f.endswith(".parquet")
                         else pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False))
                except Exception:
                    continue
                done = {}
                # Unconditional columns: transcribed source text, withheld from
                # every resource in these directories.
                for col in SANITIZE_COLUMNS:
                    if col not in d.columns:
                        continue
                    vals = d[col].fillna("").astype(str)
                    n = int(vals.str.len().sum())
                    if n == 0:
                        continue
                    done[col] = n
                    lc = f"{col}_char_count"
                    if lc not in d.columns:
                        d[lc] = vals.str.len()
                    d[col] = ""
                # PER-RESOURCE columns: withheld unless the row's resource is
                # full_text. Without this the frames re-exported a column the
                # data tables had just blanked — rc10 shipped clean
                # commentary.csv rows beside frame_commentary.csv rows carrying
                # the same llm_interpretation text for 39 third-party resources.
                # A sanitizer that filters the table but not its copies is not a
                # sanitizer, so this loop mirrors the data-table rule rather than
                # relying on a flat column list.
                for col in CONDITIONAL_TEXT_COLUMNS:
                    if col not in d.columns or "version_id" not in d.columns:
                        continue
                    m = ~d["version_id"].astype(str).isin(keep_text)
                    vals = d.loc[m, col].fillna("").astype(str)
                    n = int(vals.str.len().sum())
                    if n == 0:
                        continue
                    done[col] = done.get(col, 0) + n
                    lc = f"{col}_char_count"
                    if lc not in d.columns:
                        d[lc] = d[col].fillna("").astype(str).str.len()
                    d.loc[m, col] = ""
                if done:
                    (d.to_parquet(path, index=False) if f.endswith(".parquet")
                     else d.to_csv(path, index=False, encoding="utf-8-sig"))
                    san[rel] = done
    report["sanitized_files"] = san
    report["sanitized_characters_withheld"] = sum(sum(v.values()) for v in san.values())
    for f in ("README.md", "CITATION.cff", "CITATION.md", "CHANGELOG.md", "LICENSE_CODE",
              "LICENSE_DATA.md", "requirements.txt", "VERSION"):
        if os.path.exists(os.path.join(root, f)):
            shutil.copy(os.path.join(root, f), os.path.join(out, f))

    # ---- reference_only means WITNESS RECORD ONLY, outside data/ too ----
    # rc7 sanitized text from the copied validation frames, diagnostics and
    # shipped labels but left the ROWS in place, so 18 resources whose stated
    # disposition is "retain the witness record, nothing else" still contributed
    # row-level derived records: 150 of 750 mention frame rows, 22 of 329
    # commentary rows, 18 of 176 work-type labels, and the packet copies of each.
    # A sanitized row is still an assertion about a resource we are withholding.
    ref_only = set(str(x) for x in rights.loc[
        rights["release_disposition"] == "reference_only", "version_id"])
    _ci_full = pd.read_parquet(os.path.join(src_data, "chapter_instances.parquet"))
    inst_owner = dict(zip(_ci_full["instance_id"].astype(str),
                          _ci_full["version_id"].astype(str)))
    _se_full = pd.read_parquet(os.path.join(src_data, "sentences.parquet"))
    sent_owner = dict(zip(_se_full["sentence_id"].astype(str),
                          _se_full["version_id"].astype(str)))
    ROW_FILTER_DIRS = ("expert_validation", "derived_diagnostics",
                       os.path.join("src", "shipped_labels"))
    row_drops = {}
    for sub in ROW_FILTER_DIRS:
        d_ = os.path.join(out, sub)
        if not os.path.isdir(d_):
            continue
        for dirpath, _dirs, files in os.walk(d_):
            for fn in sorted(files):
                if not fn.endswith((".csv", ".parquet")):
                    continue
                fp = os.path.join(dirpath, fn)
                try:
                    df_ = (pd.read_parquet(fp) if fn.endswith(".parquet")
                           else pd.read_csv(fp, encoding="utf-8-sig", keep_default_na=False))
                except Exception:
                    continue
                # Some frames carry no version_id and are keyed on the instance or
                # sentence instead (the variant frame, the structural diagnostics).
                # Resolve those through the FULL tables, or 25 variant-frame rows
                # and 310 diagnostic rows for withheld resources stay behind.
                if "version_id" in df_.columns:
                    owner = df_["version_id"].astype(str)
                elif "instance_id" in df_.columns:
                    owner = df_["instance_id"].astype(str).map(inst_owner)
                elif "sentence_id" in df_.columns:
                    owner = df_["sentence_id"].astype(str).map(sent_owner)
                else:
                    continue
                mask = owner.isin(ref_only)
                n = int(mask.sum())
                if not n:
                    continue
                df_ = df_[~mask]
                (df_.to_parquet(fp, index=False) if fn.endswith(".parquet")
                 else df_.to_csv(fp, index=False, encoding="utf-8-sig"))
                row_drops[os.path.relpath(fp, out)] = {
                    "rows_dropped_reference_only": n, "rows_after": len(df_)}
    report["reference_only_row_drops"] = row_drops
    report["reference_only_rows_dropped_total"] = sum(
        v["rows_dropped_reference_only"] for v in row_drops.values())

    # ---- recompute derived statistics from the PUBLIC tables ----
    # rc7 copied the full-corpus statistics table into the profile, so its raw
    # occurrence total (365,509) could not be reproduced from the mention table
    # shipped beside it (283,788) — contradicting this notice's own claim to
    # recompute every derived statistic. Recompute from the public tables, and
    # keep the full-corpus figure as an explicitly labelled column.
    me_p = os.path.join(out_data, "concept_chapter_mentions.csv")
    st_p = os.path.join(out_data, "concept_mention_statistics.csv")
    if os.path.exists(me_p) and os.path.exists(st_p):
        me = pd.read_csv(me_p, encoding="utf-8-sig")
        st = pd.read_csv(st_p, encoding="utf-8-sig", keep_default_na=False)
        full_raw = int(st["raw_lexical_mentions"].sum())

        ci_pub = pd.read_parquet(os.path.join(out_data, "chapter_instances.parquet"))
        dflt = ci_pub[ci_pub["analysis_default_include"].astype(str).str.upper().isin(("TRUE", "1"))]
        chars = int(dflt["char_count"].fillna(0).sum())

        g = me.groupby("concept_id", as_index=False).agg(raw_lexical_mentions=("mention_count", "sum"))
        hs = (me[me["match_specificity"] == "high"].groupby("concept_id", as_index=False)
              .agg(high_specificity_mentions=("mention_count", "sum")))
        tiers = me.pivot_table(index="concept_id", columns="match_specificity",
                               values="mention_count", aggfunc="sum", fill_value=0).reset_index()
        for t in ("high", "medium", "low"):
            if t not in tiers.columns:
                tiers[t] = 0

        st = st.rename(columns={"raw_lexical_mentions": "raw_lexical_mentions_full_corpus",
                                "high_specificity_mentions": "high_specificity_mentions_full_corpus"})
        st = st.drop(columns=["mentions_per_10k_chars", "high_specificity_per_10k_chars",
                              "searched_chars_default_set", "single_char_share",
                              "mentions_specificity_high", "mentions_specificity_medium",
                              "mentions_specificity_low"], errors="ignore")
        st = (st.merge(g, on="concept_id", how="left")
                .merge(hs, on="concept_id", how="left")
                .merge(tiers[["concept_id", "high", "medium", "low"]].rename(columns={
                    "high": "mentions_specificity_high", "medium": "mentions_specificity_medium",
                    "low": "mentions_specificity_low"}), on="concept_id", how="left"))
        for c in ("raw_lexical_mentions", "high_specificity_mentions", "mentions_specificity_high",
                  "mentions_specificity_medium", "mentions_specificity_low"):
            st[c] = st[c].fillna(0).astype("int64")
        st["searched_chars_default_set"] = chars
        st["mentions_per_10k_chars"] = (st["raw_lexical_mentions"] / chars * 10000).round(3)
        st["high_specificity_per_10k_chars"] = (st["high_specificity_mentions"] / chars * 10000).round(3)
        st["single_char_share"] = (st["mentions_specificity_low"] /
                                   st["raw_lexical_mentions"].replace(0, pd.NA)).round(4)
        st["statistics_scope"] = "public_structural_release"
        st.to_csv(st_p, index=False, encoding="utf-8-sig")
        report["statistics_recomputed"] = {
            "table": "concept_mention_statistics.csv",
            "raw_occurrences_public": int(st["raw_lexical_mentions"].sum()),
            "raw_occurrences_full_corpus": full_raw,
            "searched_chars_public_default_set": chars,
            "concepts_with_no_public_mention": int((st["raw_lexical_mentions"] == 0).sum()),
        }

    report["mention_edges_full"] = int(report["tables"]["concept_chapter_mentions.csv"]["rows_before"])
    report["mention_edges_retained"] = int(report["tables"]["concept_chapter_mentions.csv"]["rows_after"])
    report["mention_edges_dropped_reference_only"] = (report["mention_edges_full"]
                                                      - report["mention_edges_retained"])

    # What this distribution can and cannot reproduce. The full package ships
    # legacy/ (regeneration inputs), data/graph/ and output/; this one does not,
    # so the README's "regenerate the tables" instruction cannot run here and
    # saying "fully reproducible" without qualification would be false.
    have = {d: os.path.isdir(os.path.join(out, d))
            for d in ("legacy", os.path.join("data", "graph"), "output")}
    report["reproduction_paths"] = {
        "graph_rebuild_from_shipped_tables": True,
        "table_regeneration_from_raw_inputs": have["legacy"],
        "prebuilt_graph_included": have[os.path.join("data", "graph")],
        # Set to None here and finalized by --finalize after the release flow
        # has generated this profile's figures (stage 5f). rc9 reported False
        # in a distribution shipping six figures, because generation runs after
        # this report is written — and it read the wrong key besides.
        "figures_included": None,
        "analysis_of_withheld_character_streams": False,
    }

    # ---- build the graph ONCE, to capture this profile's own graph counts ----
    # The profile ships no prebuilt database (the reader builds it — the quick
    # start does exactly this). But the schema document needs node/edge counts,
    # and rc8 had no source for them, so they fell back to the full package's.
    # Build here, keep the build_report, discard the database.
    import subprocess as _sp, shutil as _sh
    _gdir = os.path.join(out_data, "graph")
    os.makedirs(_gdir, exist_ok=True)
    _db = os.path.join(_gdir, "_facts_only.kuzu")
    _r = _sp.run([sys.executable, os.path.join(root, "src", "build_graph.py"),
                  "--data-dir", out_data, "--db-path", _db],
                 capture_output=True, text=True)
    if _r.returncode != 0:
        raise SystemExit("PROFILE FAILED: the shipped tables do not build a graph:\n"
                         + _r.stdout[-2000:] + _r.stderr[-2000:])
    for _p in (_db, _db + ".wal"):
        if os.path.isdir(_p):
            _sh.rmtree(_p, ignore_errors=True)
        elif os.path.exists(_p):
            os.remove(_p)
    _br = os.path.join(_gdir, "build_report.json")
    report["graph_counts_source"] = ("built from the shipped tables during profile "
                                     "generation; database discarded, report kept")
    report["graph_builds_from_shipped_tables"] = os.path.exists(_br)

    ref_drop_table = "\n".join(
        f"| `{k}` | {v['rows_dropped_reference_only']} | {v['rows_after']} |"
        for k, v in sorted(report["reference_only_row_drops"].items())) or "| (none) | 0 | — |"
    ref_drop_table = ("| File | Rows dropped | Rows kept |\n|---|---:|---:|\n"
                      + ref_drop_table)
    ref_dropped_total = report["reference_only_rows_dropped_total"]

    def _frame_items(base):
        d_ = os.path.join(base, "expert_validation")
        if not os.path.isdir(d_):
            return 0
        return sum(len(pd.read_csv(os.path.join(d_, f), encoding="utf-8-sig"))
                   for f in sorted(os.listdir(d_))
                   if f.startswith("frame_") and f.endswith(".csv") and "strata" not in f)
    pub_frames = _frame_items(out)
    full_frames = _frame_items(root)
    report["validation_frames_items_public"] = pub_frames
    report["validation_frames_items_full_corpus"] = full_frames
    notice = f"""# PUBLIC STRUCTURAL RELEASE profile

This copy withholds the transcribed character streams of every resource whose
`release_disposition` in `data/source_rights.csv` is not `full_text`
({report['metadata_and_offsets_versions']} resources as `metadata_and_offsets`,
{report['reference_only_versions']} as `reference_only`), because those transcriptions came from
third-party platforms whose terms are not established. Only
{report['full_text_versions']} resource carries its text here: the dataset authors' own compilation.

**What is present:** every structural and derived layer — identifiers, chapter and
sentence structure, offsets, character counts (`*_char_count` columns preserve the
withheld lengths so statistics remain reproducible), concept mentions, commentary
metadata and provenance flags, variant positions and edit operations, the graph
inputs, all documentation, the QA suite and the validation frames.

Rows belonging to `reference_only` resources are dropped from the version-keyed
tables, so the restricted profile carries **{report['mention_edges_retained']:,} of the
{report['mention_edges_full']:,} default concept-mention edges**
({report['mention_edges_dropped_reference_only']:,} dropped with those witnesses) — every edge belonging to a
resource that is still represented here, but not every edge in the full profile.

**What is withheld:** `original_text` / `normalized_text` (sentences),
`raw_heading` (chapter instances), `source_quote` / `normalized_quote`
(commentary), `quote` (evidence), `old_text` / `new_text` (variants), and the
Wang Bi exegesis source text. Rows belonging to `reference_only` resources are
dropped from the version-keyed tables entirely; those witnesses survive in
`versions.csv` and `source_rights.csv` as citable records.

**Why it exists and why it is named this way:** this profile is *publishable*,
not access-restricted. "Restricted" (its name up to v1.1.2-rc5) suggested a gated
or embargoed copy; in fact it is the openly distributable one, and the FULL
profile is the copy that must wait for the rights review. It is publishable
without clearing a single third-party transcription, so the rights review is not
a blocker for releasing the dataset authors' own contribution. It is not a rights determination:
`redistribution_status` is `not_reviewed` on every row in both profiles.

## What this distribution can reproduce, and what it cannot

Stated precisely, because "fully reproducible" would be false for this profile:

| Path | Here |
|---|---|
| Rebuild the graph from the shipped tables (`src/build_graph.py`) | **yes** |
| Re-run the QA suites and the validation scorer | **yes** |
| Recompute every derived statistic from the shipped tables | **yes** |
| Audit the expert-validation framework and scorer (frames keep every identifier, stratum and question) | **yes** |
| Perform text-dependent adjudication of record | **no** — the source text, the commentary quotes, the variant strings and the recovered chapter text are withheld, so faithfulness, philosophical-use, variant-genuineness and alignment judgements cannot be made from this copy. Requires the full internal package. |
| Regenerate tables from raw inputs (`src/regenerate_tables.py --src legacy/…`) | **no** — `legacy/` is not included |
| Load a prebuilt graph without building it | **no** — the database `data/graph/laozi_kg.kuzu` is not included; `data/graph/build_report.json` is, so you can diff your build against ours |
| Any analysis over the withheld character streams | **no**, by design |

The full internal package contains `legacy/`, the built `data/graph/laozi_kg.kuzu` and `output/`. If you
need table regeneration from raw inputs, that is the distribution to ask the
authors for; it cannot be published until the rights review in
`data/source_rights.csv` is complete.

## The validation frames are smaller here, and that is the policy working

`reference_only` means *keep the bibliographic record, keep nothing else*. rc7
withheld the text from the copied validation frames but left the rows, so 18
resources we are withholding still contributed row-level derived records. A
sanitized row is still an assertion about a withheld resource, so those rows are
now removed too:

{ref_drop_table}

**{ref_dropped_total} rows** in total. The consequence a reviewer should know: the
validation frames in this distribution are smaller than those in the full internal
package ({pub_frames:,} items here against {full_frames:,} there), and the scorer's
denominators follow the frames it is given. **This distribution is not the
validation corpus of record.** Judgements that require reading the source text
cannot be made here at all, because that text is withheld; and the strata that
survive rights filtering are unequal, so a rate computed from them is not the
estimator the sampling design supports. Adjudicate in the full internal package
and cite the result for both. Use this copy to audit the design, check which
records were selected by id, read the question schema and run the scorer. Both
frame totals are recorded in `expert_validation/validation_metrics.json`
(`items_total` for this copy) and in `metadata/public_release_facts.json`
(`validation_frames_items` here, `validation_frames_items_full_corpus` for the
internal protocol).

Regenerate with `python src/make_public_profile.py --root . --out dist/public_structural_release`.
Per-table effect: `public_profile_report.json`.
"""
    # The copied README documents a regeneration command that cannot run here
    # (legacy/ is not shipped). Replace that block in the COPY rather than
    # shipping an instruction that fails, and point at the scope table.
    rp = os.path.join(out, "README.md")
    if os.path.exists(rp):
        rtxt = open(rp, encoding="utf-8").read()
        rtxt = rtxt.replace(
            "python src/regenerate_tables.py --src legacy/v1.0.0_inputs --out /tmp/regen",
            "# not available in this distribution: legacy/ is not shipped.\n"
            "# See PROFILE_NOTICE.md for what this distribution can reproduce.")
        if "PUBLIC STRUCTURAL RELEASE" not in rtxt:
            rtxt = rtxt.replace("# LaoziKG", "# LaoziKG — PUBLIC STRUCTURAL RELEASE\n\n"
                                "> This is the openly distributable profile. Third-party\n"
                                "> transcriptions are withheld; see `PROFILE_NOTICE.md` for what\n"
                                "> it contains and which reproduction paths it supports.\n\n"
                                "## LaoziKG", 1)
        open(rp, "w", encoding="utf-8").write(rtxt)

    open(os.path.join(out, "PROFILE_NOTICE.md"), "w", encoding="utf-8").write(notice)
    json.dump(report, open(os.path.join(out, "public_profile_report.json"), "w",
                           encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in report.items() if k != "tables"}, indent=1))
    print("tables written:", len(report["tables"]))


if __name__ == "__main__":
    main()
