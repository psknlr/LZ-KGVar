"""LaoziKG — build stratified expert-validation sampling frames.

Eight frames. Three SAMPLED frames over the large machine-generated layers and
five FULL-POPULATION frames over the small LLM-label populations (436 items).
Each is a CSV with the record, the context an annotator needs, and
empty annotator columns (two annotators + adjudication). Seeded, so the frames
are reproducible; the sampling design is recorded in the header row comment file.

  commentary : ~300 records, proportional-stratified by
               text_provenance × reliability × extraction_method (min 5 per
               non-empty cell); annotators judge concept correctness and
               gloss faithfulness against the shown source text.
  mentions   : 250 per match_specificity tier (750), simple random within tier,
               with the sentence shown; annotators judge whether the hit is a
               philosophical use of the concept (precision per tier).
  variants   : equal allocation of 100 candidate events per detection-score bin
               (0.15-0.25, 0.25-0.45, 0.45-0.65, >=0.65); supports P(genuine | bin),
               never a pooled prevalence (population distribution
               recorded so P(genuine | score) can be reported) with the reference
               and witness strings; annotators judge whether it is a genuine
               textual variant vs commentary bleed / orthographic / OCR noise.

Usage: python src/make_validation_frames.py --data data --out expert_validation --seed 20260903
"""
import argparse
import os

import numpy as np
import pandas as pd

def add_annot(df, questions):
    """One annotator_A / annotator_B / adjudicated column PER QUESTION, so that a
    frame asking two things (concept correct? gloss faithful?) can score them
    separately. v1.1.2-rc2 had a single column for both — a design bug that would
    have made the first round of expert annotation unscorable."""
    for q in questions:
        for who in ("annotator_A", "annotator_B", "adjudicated"):
            df[f"{who}_{q}"] = ""
    df["annotator_A_note"] = ""
    df["annotator_B_note"] = ""
    df["adjudication_note"] = ""
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="expert_validation")
    ap.add_argument("--seed", type=int, default=20260903)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    os.makedirs(a.out, exist_ok=True)
    d = a.data

    # ---------------- commentary ----------------
    cm = pd.read_csv(os.path.join(d, "commentary.csv"), encoding="utf-8-sig", keep_default_na=False)
    strata = ["text_provenance", "reliability", "extraction_method"]
    g = cm.groupby(strata).size().rename("n").reset_index()
    target = 300
    g["alloc"] = np.maximum(5, np.round(g["n"] / g["n"].sum() * target)).astype(int)
    g["alloc"] = np.minimum(g["alloc"], g["n"])
    parts = []
    for _, s in g.iterrows():
        pool = cm[(cm[strata[0]] == s[strata[0]]) & (cm[strata[1]] == s[strata[1]]) & (cm[strata[2]] == s[strata[2]])]
        parts.append(pool.sample(n=int(s["alloc"]), random_state=int(rng.integers(1 << 31))))
    fc = pd.concat(parts).sample(frac=1, random_state=a.seed).reset_index(drop=True)
    fc = fc[["commentary_id", "version_id", "chapter_num", "commentator_raw",
             "commentator_historical_era", "concept_name", "source_quote", "llm_interpretation",
             "text_provenance", "source_char_overlap", "reliability", "extraction_method",
             "citable_as_quote"]]
    fc.insert(0, "frame", "commentary")
    fc["q_concept_correct"] = "Y/N/unsure — does the source text actually gloss this concept?"
    fc["q_gloss_faithful"] = "Y/N/unsure/NA — is llm_interpretation faithful to source_quote (no addition)? NA if no interpretation"
    fc = add_annot(fc, ["concept_correct", "gloss_faithful"])
    fc.to_csv(os.path.join(a.out, "frame_commentary.csv"), index=False, encoding="utf-8-sig")
    g.to_csv(os.path.join(a.out, "frame_commentary_strata.csv"), index=False, encoding="utf-8-sig")

    # ---------------- mentions ----------------
    sm = pd.read_parquet(os.path.join(d, "concept_sentence_mentions.parquet"))
    se = pd.read_parquet(os.path.join(d, "sentences.parquet"))[["sentence_id", "original_text", "version_id"]]
    parts = []
    for tier in ("high", "medium", "low"):
        pool = sm[sm["match_specificity"] == tier]
        parts.append(pool.sample(n=min(250, len(pool)), random_state=int(rng.integers(1 << 31))))
    fm = pd.concat(parts).merge(se, on="sentence_id", how="left", suffixes=("", "_s"))
    fm = fm.sample(frac=1, random_state=a.seed).reset_index(drop=True)
    keep = [c for c in ["sentence_id", "instance_id", "version_id", "chapter_num", "concept_id",
                        "concept_name", "match_specificity", "mention_count", "original_text"] if c in fm.columns]
    fm = fm[keep]
    fm.insert(0, "frame", "mentions")
    fm["q_philosophical_use"] = "Y/N/unsure — is this occurrence a use of the CONCEPT (not numeral/adjective/verb)?"
    fm = add_annot(fm, ["philosophical_use"])
    fm.to_csv(os.path.join(a.out, "frame_mentions.csv"), index=False, encoding="utf-8-sig")

    # ---------------- variants ----------------
    # EQUAL ALLOCATION per detection-score bin, not simple random. The score
    # distribution is heavily skewed (bin 0.25-0.45 holds 9,330 of 20,124 events),
    # so a simple-random 400 leaves the high-score bins with a few dozen records
    # and P(genuine | score) cannot be estimated at the top of the range. Equal
    # allocation is the right design when the quantity of interest is a per-bin
    # rate rather than a corpus-wide mean; it is NOT a prevalence sample, and the
    # scorer never pools across bins.
    va = pd.read_parquet(os.path.join(d, "variants.parquet"))
    SCORE_BINS = [(0.15, 0.25, "0.15-0.25"), (0.25, 0.45, "0.25-0.45"),
                  (0.45, 0.65, "0.45-0.65"), (0.65, 1.01, ">=0.65")]
    PER_BIN = 100
    va["variant_detection_score_bin"] = ""
    for lo, hi, lab in SCORE_BINS:
        va.loc[(va["variant_detection_score"] >= lo) & (va["variant_detection_score"] < hi),
               "variant_detection_score_bin"] = lab
    parts, alloc = [], []
    for lo, hi, lab in SCORE_BINS:
        pool = va[va["variant_detection_score_bin"] == lab]
        take = min(PER_BIN, len(pool))
        parts.append(pool.sample(n=take, random_state=a.seed))
        alloc.append({"score_bin": lab, "population": len(pool), "sampled": take,
                      "scheme": "simple random within bin"})
    fv = pd.concat(parts, ignore_index=True).sort_values(
        ["variant_detection_score_bin", "variant_id"]).reset_index(drop=True)
    pd.DataFrame(alloc).to_csv(os.path.join(a.out, "frame_variants_strata.csv"),
                               index=False, encoding="utf-8-sig")
    fv = fv[["variant_id", "reference_text_id", "version_b", "chapter_num", "instance_id", "position",
             "change_type", "edit_op", "old_text", "new_text", "variant_detection_score",
             "variant_detection_score_bin", "variant_status"]]
    fv.insert(0, "frame", "variants")
    fv["q_variant_class"] = ("genuine_variant / orthographic_only / commentary_bleed / "
                             "ocr_or_transcription_noise / lacuna / unsure")
    fv["q_layer_correct"] = "Y/N/NA — is change_type (字形层/词汇层/句法层) right? NA unless genuine_variant"
    fv = add_annot(fv, ["variant_class", "layer_correct"])
    fv.to_csv(os.path.join(a.out, "frame_variants.csv"), index=False, encoding="utf-8-sig")


    # ---------------- full-population ontology / metadata label frames ----------------
    # These populations are small (436 items in total), so they are reviewed in
    # full rather than sampled: every LLM-assigned label gets two annotators.
    def dual(df, q, prompt):
        df[f"q_{q}"] = prompt
        return add_annot(df, [q])

    v = pd.read_csv(os.path.join(d, "versions.csv"), encoding="utf-8-sig", keep_default_na=False)
    fw = v[["version_id", "title", "author_raw", "edition", "witness_era_normalized", "work_type",
            "textual_scope", "aligned_laozi_chapter_count", "work_type_source"]].copy()
    fw.insert(0, "frame", "work_type")
    fw["corrected_work_type"] = ""; fw["corrected_textual_scope"] = ""
    fw = dual(fw, "work_type_correct", "Y/N — are work_type AND textual_scope right? If N, fill corrected_* (enum: canonical_ddj, ddj_commentary, related_laozi_text, ritual_text, apocryphal_text, biography_text, manuscript_composite, fragment / full_81, partial, single_unit, not_ddj)")
    fw.to_csv(os.path.join(a.out, "frame_work_type.csv"), index=False, encoding="utf-8-sig")

    c = pd.read_csv(os.path.join(d, "concepts.csv"), encoding="utf-8-sig", keep_default_na=False)
    fn = c[[x for x in ["concept_id", "name", "category", "definition_core", "node_type", "node_type_source", "is_seed", "canonical_chapters"] if x in c.columns]].copy()
    fn.insert(0, "frame", "node_type"); fn["corrected_node_type"] = ""
    fn = dual(fn, "node_type_correct", "Y/N — is node_type right for this concept? If N, fill corrected_node_type")
    fn.to_csv(os.path.join(a.out, "frame_node_type.csv"), index=False, encoding="utf-8-sig")

    r = pd.read_csv(os.path.join(d, "concept_relations.csv"), encoding="utf-8-sig", keep_default_na=False)
    fr = r.copy(); fr.insert(0, "frame", "concept_relations")
    fr = dual(fr, "relation_correct", "Y/N/unsure — is this relation (type and direction) defensible from the Laozi text or its commentary tradition?")
    fr.to_csv(os.path.join(a.out, "frame_concept_relations.csv"), index=False, encoding="utf-8-sig")

    pp = pd.read_csv(os.path.join(d, "persons.csv"), encoding="utf-8-sig", keep_default_na=False)
    fp = pp[pp["entity_status"] == "canonical"][[x for x in ["person_id", "canonical_name", "person_historical_era", "person_historical_era_alt", "person_era_dates", "era_source", "era_disputed", "role_hint"] if x in pp.columns]].copy()
    fp.insert(0, "frame", "person_eras"); fp["corrected_era"] = ""; fp["corrected_dates"] = ""
    fp = dual(fp, "era_correct", "Y/N — is person_historical_era the figure's own lifetime era? If N, fill corrected_era (and dates)")
    fp.to_csv(os.path.join(a.out, "frame_person_eras.csv"), index=False, encoding="utf-8-sig")

    dg_p = os.path.join(d, "alignment_failure_diagnosis.csv")
    if os.path.exists(dg_p):
        dg = pd.read_csv(dg_p, encoding="utf-8-sig", keep_default_na=False)
        fd = dg.copy(); fd.insert(0, "frame", "alignment_diagnosis")
        fd = dual(fd, "diagnosis_correct", "Y/N — is the diagnosis right, and (where resolution_applied) is the recovery acceptable? See alignment_recovery_report.csv and, for S06453, expert_validation/S06453_review_dossier.csv")
        fd.to_csv(os.path.join(a.out, "frame_alignment_diagnosis.csv"), index=False, encoding="utf-8-sig")

    # ---------------- recovered chapter instances (full population) ----------------
    # The diagnosis frame covers the 7 witnesses; this covers the 116 chapter
    # instances the recovery actually produced, which is what has to be confirmed
    # before they can enter the default analysis set. Each row carries the
    # recovered text and the canonical chapter text side by side so the judgement
    # can be made from the frame alone.
    ci = pd.read_parquet(os.path.join(d, "chapter_instances.parquet"))
    rec = ci[ci["alignment_review_status"] == "auto_recovered_unreviewed"].copy()
    if len(rec):
        se = pd.read_parquet(os.path.join(d, "sentences.parquet"))
        txt = (se.sort_values("seq").groupby("instance_id")["normalized_text"]
                 .apply(lambda x: "".join(str(v) for v in x.fillna(""))))
        ref = pd.read_parquet(os.path.join(d, "wangbi_exegesis_source.parquet"))
        canon = {int(r.chapter_num): str(r.jingwen) for r in ref.itertuples()}
        fri = rec[["instance_id", "version_id", "chapter_num", "char_count",
                   "segmentation_method", "identification_score", "anchor_coverage_score",
                   "order_in_doc"]].copy()
        fri["recovered_text"] = fri["instance_id"].map(txt).fillna("")
        fri["canonical_chapter_text"] = fri["chapter_num"].map(canon).fillna("")
        fri.insert(0, "frame", "recovered_alignment")
        fri["corrected_chapter_num"] = ""
        fri = add_annot(fri, ["chapter_id_correct", "boundaries_correct"])
        fri["q_chapter_id_correct"] = ("Y/N — is this segment the Laozi chapter it is labelled as? "
                                       "If N, fill corrected_chapter_num (or -1 if it is not Laozi text)")
        fri["q_boundaries_correct"] = ("Y/N/NA — do the segment boundaries hold (no text of the "
                                       "neighbouring chapter included or omitted)? NA if chapter_id_correct = N")
        fri = fri.sort_values(["version_id", "order_in_doc"])
        fri.to_csv(os.path.join(a.out, "frame_recovered_alignment.csv"),
                   index=False, encoding="utf-8-sig")
        print(f"recovered-alignment frame: {len(fri)} instances over "
              f"{fri['version_id'].nunique()} witnesses (full population)")

    print(f"ontology frames  : work_type {len(fw)}, node_type {len(fn)}, relations {len(fr)}, "
          f"person eras {len(fp)}, alignment diagnoses {len(fd) if os.path.exists(dg_p) else 0} "
          f"(full population, {len(fw)+len(fn)+len(fr)+len(fp)+(len(fd) if os.path.exists(dg_p) else 0)} items)")

    print(f"commentary frame: {len(fc)} records over {len(g)} strata")
    print(f"mentions frame  : {len(fm)} records ({fm['match_specificity'].value_counts().to_dict()})")
    print(f"variants frame  : {len(fv)} records, equal allocation per score bin "
          f"{fv['variant_detection_score_bin'].value_counts().sort_index().to_dict()}")


if __name__ == "__main__":
    main()
