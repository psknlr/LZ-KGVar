"""LaoziKG — Stage 6: derive per-instance text-composition fields.

Adds to chapter_instances.parquet:

  is_chapter_aligned           chapter_num != -1
  analysis_default_include     is_chapter_aligned AND alignment_review_status !=
                               auto_recovered_unreviewed (47 unaligned units and the
                               116 v1.1.2 recoveries excluded until expert-confirmed)

  base_text_share_upper_bound  canonical chapter length / instance length, capped
                               at 1.0. An UPPER BOUND on the fraction of the
                               instance that is Laozi base scripture: it assumes
                               the whole canonical chapter is present, which a
                               fragment may not satisfy, and it cannot see
                               commentary that quotes scripture. v1.1.1 shipped
                               this as `base_text_share_est`; renamed because
                               "est" read as a measured composition.
  text_composition             band over the bound: scripture_dominant (>=0.5),
                               mixed (>=0.15), commentary_dominant (<0.15),
                               unknown (unaligned or empty).

The canonical reference is the jingwen layer of wangbi_exegesis_source.parquet
(the 81-chapter Wang Bi base text), script-normalized with OpenCC t2s and
stripped of punctuation before measuring length.

Usage: python src/derive_instance_fields.py --data data
"""
import argparse
import os
import re

import pandas as pd
from opencc import OpenCC

CC = OpenCC("t2s")
PUNCT = re.compile(r"[，。；：？！、\s,\.;:\?!\"“”‘’「」『』（）()\[\]【】]")


def norm(t):
    return CC.convert(PUNCT.sub("", str(t)))


def band(x):
    if pd.isna(x):
        return "unknown"
    if x >= 0.5:
        return "scripture_dominant"
    if x >= 0.15:
        return "mixed"
    return "commentary_dominant"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    args = ap.parse_args()
    d = args.data

    ci = pd.read_parquet(os.path.join(d, "chapter_instances.parquet"))
    se = pd.read_parquet(os.path.join(d, "sentences.parquet"))
    ref = pd.read_parquet(os.path.join(d, "wangbi_exegesis_source.parquet"))
    canon_len = {int(r.chapter_num): len(norm(r.jingwen)) for r in ref.itertuples()}

    inst_chars = (se.assign(n=se["normalized_text"].fillna("").astype(str).str.len())
                    .groupby("instance_id")["n"].sum())
    ci = ci.drop(columns=[c for c in ("base_text_share_est", "base_text_share_upper_bound",
                                      "text_composition") if c in ci.columns])
    # alignment flags (v1.1.0 added these in an unscripted step)
    ci["is_chapter_aligned"] = ci["chapter_num"] != -1
    # Variant layer is v1.0.0 generation-stage output: detection ran on every
    # ORIGINAL aligned instance (even where it found nothing) and on none of the
    # v1.1.2 recoveries. Variant density must not be computed where run = FALSE.
    ci["variant_detection_eligible"] = ci["is_chapter_aligned"]
    ci["variant_detection_run"] = ci["is_chapter_aligned"] & (
        ci.get("alignment_review_status", "original_deterministic") == "original_deterministic")
    if "alignment_review_status" not in ci.columns:
        ci["alignment_review_status"] = "original_deterministic"
    # default analysis set = aligned AND not an unreviewed automatic recovery
    ci["analysis_default_include"] = ci["is_chapter_aligned"] & (
        ci["alignment_review_status"] != "auto_recovered_unreviewed")
    ci["_inst"] = ci["instance_id"].map(inst_chars)
    ci["_canon"] = ci["chapter_num"].map(canon_len)
    ub = (ci["_canon"] / ci["_inst"]).where(ci["chapter_num"] != -1)
    ci["base_text_share_upper_bound"] = ub.clip(upper=1.0).round(4)
    ci["text_composition"] = ci["base_text_share_upper_bound"].map(band)
    ci = ci.drop(columns=["_inst", "_canon"])
    ci.to_parquet(os.path.join(d, "chapter_instances.parquet"), index=False)

    print(f"instances: {len(ci)}")
    print("text_composition:", ci["text_composition"].value_counts().to_dict())
    aligned = ci[ci["chapter_num"] != -1]
    print(f"median upper bound (aligned): {aligned['base_text_share_upper_bound'].median():.3f}")


if __name__ == "__main__":
    main()
