"""LaoziKG — Stage 2: witness-text concept mention extraction over the full ontology.

v1.0.0 shipped 111 concepts but concept_chapter_mentions covered only 14 of
them (the original seed set), so a "111-concept knowledge graph" claim was not
computationally supported. This script runs mention extraction for ALL
concepts and emits both chapter-instance aggregates and sentence-level evidence.

Method
------
Deterministic substring matching. No LLM is involved, so the output is exactly
reproducible.

  1. The corpus is overwhelmingly traditional-script (38,486 sentences contain
     無 vs 1,960 containing 无), while concept names are simplified. Both sides
     are therefore converted to simplified with OpenCC (t2s) before matching.
  2. Matching runs on `normalized_text` (punctuation already stripped), so a
     concept spanning a comma in the original still matches.
  3. Counts are summed per (chapter instance, concept) and per sentence.

Precision caveat (recorded in the output, not hidden)
-----------------------------------------------------
Chinese philosophical vocabulary overlaps heavily with ordinary function words.
33 of the 111 concept names are a single character (一, 大, 用, 有, 无, 明 ...),
where a raw substring hit is frequently NOT a philosophical use: 一 as the
numeral "one", 大 as the adjective "big", 用 as the verb "to use". Each mention
row therefore carries:

  name_length        characters in the matched concept name
  match_specificity  'high'   (>=3 chars: phrase/proposition, low ambiguity)
                     'medium' (2 chars: compound term, some ambiguity)
                     'low'    (1 char: high recall, unquantified precision)

The field was named match_reliability in v1.1.0; it is derived from name
LENGTH, not from any measured precision, so "reliability" invited the wrong
reading. Downstream analyses should filter on match_specificity rather than
treating all 111 concepts as equally well identified.

Outputs (v1.1.1+ layout — aligned and unaligned units are SEPARATE files at
both granularities, so exclusion is structural rather than advisory)
--------------------------------------------------------------------
  concept_sentence_mentions.parquet            sentence-level, aligned chapters
  concept_sentence_unaligned_mentions.parquet  sentence-level, chapter_num == -1
  concept_recovered_mentions.csv               chapter-level, instances with
                                               alignment_review_status = auto_recovered_unreviewed
  concept_sentence_recovered_mentions.parquet  sentence-level, same instances
  concept_chapter_mentions.csv                 chapter-instance aggregate, aligned
  concept_unaligned_mentions.csv               chapter-instance aggregate, unaligned
  concept_mention_statistics.csv               per-concept two-tier summary

The text searched is the whole witness text, in which base scripture and
commentary are interleaved, so these are witness-text lexical mentions, not
canonical Laozi term frequencies. Single-character rows are retained
(dropping them would silently discard 道/德/无/有, the core terms) but must not
be reported as precise occurrence counts without disambiguation.

Usage: python src/extract_mentions.py --data data
"""
import argparse
import os

import pandas as pd
from opencc import OpenCC

CC = OpenCC("t2s")


def specificity_for(name_length):
    if name_length >= 3:
        return "high"
    if name_length == 2:
        return "medium"
    return "low"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    args = ap.parse_args()

    concepts = pd.read_csv(os.path.join(args.data, "concepts.csv"), encoding="utf-8-sig")
    sentences = pd.read_parquet(os.path.join(args.data, "sentences.parquet"))
    chapter_instances = pd.read_parquet(os.path.join(args.data, "chapter_instances.parquet"))

    # --- apply auditable concept corrections ---------------------------------
    # Three v1.0.0 concepts matched zero sentences. Diagnosis (see
    # src/concept_corrections.csv): one is an orthographic error, two are
    # analytic labels never present in the text. Corrections are applied from a
    # declarative file so the change is reviewable rather than hard-coded.
    corr_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "concept_corrections.csv")
    concepts["is_textually_attested"] = True
    concepts["attestation_note"] = ""
    if os.path.exists(corr_path):
        corrections = pd.read_csv(corr_path, encoding="utf-8-sig")
        for _, fix in corrections.iterrows():
            mask = concepts["concept_id"] == fix["concept_id"]
            if not mask.any():
                continue
            if fix["field"] == "name" and fix["old_value"] != fix["new_value"]:
                concepts.loc[mask, "name"] = fix["new_value"]
            concepts.loc[mask, "is_textually_attested"] = bool(fix["is_textually_attested"])
            concepts.loc[mask, "attestation_note"] = fix["attestation_note"]
        concepts.to_csv(os.path.join(args.data, "concepts.csv"),
                        index=False, encoding="utf-8-sig")
        print(f"applied {len(corrections)} concept corrections")

    # --- prepare match target -------------------------------------------------
    sent = sentences[["sentence_id", "instance_id", "version_id", "normalized_text"]].copy()
    sent["normalized_text"] = sent["normalized_text"].fillna("").astype(str)
    sent["match_text"] = [CC.convert(t) for t in sent["normalized_text"]]
    match_texts = sent["match_text"].tolist()

    inst_chapter = chapter_instances.set_index("instance_id")["chapter_num"].to_dict()

    sentence_rows = []
    for _, crow in concepts.iterrows():
        name = str(crow["name"]).strip()
        if not name:
            continue
        needle = CC.convert(name)
        # Plain str.count: literal substring semantics, no regex escaping needed.
        counts = pd.Series([t.count(needle) for t in match_texts], index=sent.index)
        hit = counts > 0
        if not hit.any():
            continue
        sub = sent.loc[hit, ["sentence_id", "instance_id", "version_id"]].copy()
        sub["concept_id"] = crow["concept_id"]
        sub["concept_name"] = name
        sub["mention_count"] = counts[hit].to_numpy()
        sub["name_length"] = len(name)
        sub["match_specificity"] = specificity_for(len(name))
        sentence_rows.append(sub)

    sentence_mentions = pd.concat(sentence_rows, ignore_index=True)
    sentence_mentions["chapter_num"] = (
        sentence_mentions["instance_id"].map(inst_chapter).fillna(-1).astype("int64")
    )

    # --- chapter-instance aggregate ------------------------------------------
    chapter_mentions = (
        sentence_mentions
        .groupby(["instance_id", "version_id", "chapter_num", "concept_id",
                  "concept_name", "name_length", "match_specificity"], as_index=False)
        .agg(mention_count=("mention_count", "sum"),
             sentence_count=("sentence_id", "nunique"))
    )

    # --- split aligned / unaligned at BOTH granularities --------------------
    # instances that are aligned but come from an unreviewed automatic recovery
    # are held in their own files: default statistics never include them.
    if "alignment_review_status" in chapter_instances.columns:
        recovered_ids = set(chapter_instances.loc[
            chapter_instances["alignment_review_status"] == "auto_recovered_unreviewed", "instance_id"])
    else:
        recovered_ids = set()
    default_instances = set(instances_default) if (instances_default := (
        chapter_instances.loc[(chapter_instances["chapter_num"] != -1)
                              & ~chapter_instances["instance_id"].isin(recovered_ids),
                              "instance_id"])) is not None else set()
    s_rec_mask = sentence_mentions["instance_id"].isin(recovered_ids)
    c_rec_mask = chapter_mentions["instance_id"].isin(recovered_ids)
    s_aligned = sentence_mentions[(sentence_mentions["chapter_num"] != -1) & ~s_rec_mask]
    s_recovered = sentence_mentions[s_rec_mask]
    s_unaligned = sentence_mentions[sentence_mentions["chapter_num"] == -1]
    c_aligned = chapter_mentions[(chapter_mentions["chapter_num"] != -1) & ~c_rec_mask]
    c_recovered = chapter_mentions[c_rec_mask]
    c_unaligned = chapter_mentions[chapter_mentions["chapter_num"] == -1]
    s_recovered.to_parquet(
        os.path.join(args.data, "concept_sentence_recovered_mentions.parquet"), index=False)
    c_recovered.to_csv(os.path.join(args.data, "concept_recovered_mentions.csv"),
                       index=False, encoding="utf-8-sig")

    s_aligned.to_parquet(
        os.path.join(args.data, "concept_sentence_mentions.parquet"), index=False)
    s_unaligned.to_parquet(
        os.path.join(args.data, "concept_sentence_unaligned_mentions.parquet"), index=False)
    c_aligned.to_csv(os.path.join(args.data, "concept_chapter_mentions.csv"),
                     index=False, encoding="utf-8-sig")
    c_unaligned.to_csv(os.path.join(args.data, "concept_unaligned_mentions.csv"),
                       index=False, encoding="utf-8-sig")

    # --- per-concept two-tier statistics (aligned only) -----------------------
    # Raw counts are dominated by single-character names; both tiers ship so
    # neither can be quoted without the other being visible.
    wide = (c_aligned.pivot_table(index=["concept_id", "concept_name"],
                                  columns="match_specificity",
                                  values="mention_count", aggfunc="sum", fill_value=0)
            .reset_index())
    for col in ("high", "medium", "low"):
        if col not in wide.columns:
            wide[col] = 0
    wide["raw_lexical_mentions"] = wide[["high", "medium", "low"]].sum(axis=1)
    wide["high_specificity_mentions"] = wide["high"] + wide["medium"]
    # Length-normalized rate. Raw counts are dominated by 1-character names, and
    # the searched text differs in size between analyses, so a rate per 10,000
    # searched characters lets a concept's prevalence be compared without the
    # name-length artefact. Denominator = normalized characters of the DEFAULT
    # analysis set only (the same text the aligned mention files were built from).
    searched_chars = int(sentences.loc[
        sentences["instance_id"].isin(set(default_instances)), "normalized_text"]
        .fillna("").astype(str).str.len().sum())
    wide["searched_chars_default_set"] = searched_chars
    wide["mentions_per_10k_chars"] = (
        wide[["high", "medium", "low"]].sum(axis=1) / searched_chars * 10000).round(3)
    wide["high_specificity_per_10k_chars"] = (
        (wide["high"] + wide["medium"]) / searched_chars * 10000).round(3)
    wide["single_char_share"] = (wide["low"] / wide["raw_lexical_mentions"]
                                 .replace(0, pd.NA)).fillna(0).astype(float).round(4)
    wide = wide.merge(concepts[["concept_id", "node_type", "is_textually_attested"]],
                      on="concept_id", how="left")
    wide = wide[["concept_id", "concept_name", "node_type", "is_textually_attested",
                 "raw_lexical_mentions", "high_specificity_mentions",
                 "mentions_per_10k_chars", "high_specificity_per_10k_chars",
                 "searched_chars_default_set", "single_char_share",
                 "high", "medium", "low"]].rename(columns={
                     "high": "mentions_specificity_high",
                     "medium": "mentions_specificity_medium",
                     "low": "mentions_specificity_low"})
    wide["raw_lexical_mentions"] = wide["raw_lexical_mentions"].astype(float)
    wide["high_specificity_mentions"] = wide["high_specificity_mentions"].astype(float)
    for c in ("mentions_specificity_high", "mentions_specificity_medium",
              "mentions_specificity_low"):
        wide[c] = wide[c].astype(float)
    wide.to_csv(os.path.join(args.data, "concept_mention_statistics.csv"),
                index=False, encoding="utf-8-sig")

    print(f"concepts in ontology:                 {len(concepts)}")
    print(f"concepts with >=1 mention:            {chapter_mentions['concept_id'].nunique()}")
    print(f"chapter-instance rows  default/recovered/unal.: {len(c_aligned)} / {len(c_recovered)} / {len(c_unaligned)}")
    print(f"sentence-level rows    default/recovered/unal.: {len(s_aligned)} / {len(s_recovered)} / {len(s_unaligned)}")
    print(f"raw occurrences        aligned/unal.: {int(c_aligned['mention_count'].sum())} / "
          f"{int(c_unaligned['mention_count'].sum())}")
    print("aligned chapter rows by match_specificity:")
    for k, v in c_aligned["match_specificity"].value_counts().items():
        print(f"  {k}: {v}")

if __name__ == "__main__":
    main()
