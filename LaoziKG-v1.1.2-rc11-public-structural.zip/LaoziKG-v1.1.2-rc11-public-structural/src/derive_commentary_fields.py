"""LaoziKG — Stage 8: derive commentary era fields and evidence quote fields.

commentary.csv
  era -> commentary_witness_era           (era of the EDITION the gloss came from)
  commentator_person_id                   commentator_raw resolved via person_aliases
  commentator_historical_era              that person's era (use THIS for cross-era work)
  gloss_generated_by / gloss_reviewed / gloss_review_status / gloss_reviewer
                                          review-status fields; all rows unreviewed

evidence.parquet (1:1 with commentary via source_ref)
  source_char_overlap                     copied from commentary
  quote_kind                              verbatim_contiguous -> attested_source_quote
                                          spliced_from_source -> llm_spliced_excerpt
                                          not_located         -> llm_paraphrase_unlocated
  quote_is_verbatim                       text_provenance == verbatim_contiguous

Both were produced by unscripted cells in v1.1.0/v1.1.1, which is why the
regeneration pipeline could not reproduce these tables until this stage existed.

Usage: python src/derive_commentary_fields.py --data <dir>
"""
import argparse
import os
import re

import pandas as pd

ROLE_STRIP = re.compile(r"(註|注|疏|校定|校訂|勘|編|輯|撰|章句|等人|評選著|評著|著|譯|译|解|校)+$")
QUOTE_KIND = {"verbatim_contiguous": "attested_source_quote",
              "spliced_from_source": "llm_spliced_excerpt",
              "not_located": "llm_paraphrase_unlocated"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    d = ap.parse_args().data

    cm = pd.read_csv(os.path.join(d, "commentary.csv"), encoding="utf-8-sig")
    al = pd.read_csv(os.path.join(d, "person_aliases.csv"), encoding="utf-8-sig")
    pe = pd.read_csv(os.path.join(d, "persons.csv"), encoding="utf-8-sig")

    if "era" in cm.columns and "commentary_witness_era" not in cm.columns:
        cm = cm.rename(columns={"era": "commentary_witness_era"})
    alias_to_pid = dict(zip(al["alias"].astype(str), al["person_id"]))
    pid_to_era = dict(zip(pe["person_id"], pe["person_historical_era"].fillna("")))

    def resolve(raw):
        if pd.isna(raw):
            return None
        s = str(raw).strip()
        first = re.split(r"[、，,]", s)[0].strip()
        for cand in (s, ROLE_STRIP.sub("", s), first, ROLE_STRIP.sub("", first)):
            if cand in alias_to_pid:
                return alias_to_pid[cand]
        return None

    cm["commentator_person_id"] = cm["commentator_raw"].map(resolve)
    cm["commentator_historical_era"] = cm["commentator_person_id"].map(pid_to_era).fillna("")
    # Review-status fields. Every gloss was LLM-generated and none has been
    # expert-reviewed; the README's promise that "LLM-derived fields carry
    # explicit unreviewed flags" was not true for this table until v1.1.2.
    GEN = {"minimax-m3": "minimax-m3",
           "llm_assisted_batch_v1": "platform-utility-llm-haiku-class",
           "direct_text_match": "deterministic_text_match"}
    cm["gloss_generated_by"] = cm["extraction_method"].map(GEN).fillna("llm_unspecified")
    cm["gloss_reviewed"] = False
    cm["gloss_review_status"] = "unreviewed"
    cm["gloss_reviewer"] = ""
    cm.to_csv(os.path.join(d, "commentary.csv"), index=False, encoding="utf-8-sig")

    ev = pd.read_parquet(os.path.join(d, "evidence.parquet"))
    ev = ev.drop(columns=[c for c in ("source_char_overlap", "quote_is_verbatim", "quote_kind")
                          if c in ev.columns])
    look = cm.set_index("commentary_id")[["text_provenance", "source_char_overlap"]]
    ev = ev.join(look, on="source_ref")
    ev["quote_kind"] = ev["text_provenance"].map(QUOTE_KIND)
    ev["quote_is_verbatim"] = ev["text_provenance"] == "verbatim_contiguous"
    ev = ev.drop(columns=["text_provenance"])
    ev = ev[["evidence_id", "source_type", "source_ref", "quote", "reliability",
             "source_char_overlap", "quote_is_verbatim", "quote_kind"]]
    ev.to_parquet(os.path.join(d, "evidence.parquet"), index=False)

    n_res = int(cm["commentator_person_id"].notna().sum())
    print(f"commentary: {len(cm)}; commentator resolved {n_res} "
          f"({n_res / len(cm) * 100:.1f}%); era populated "
          f"{int((cm['commentator_historical_era'] != '').sum())}")
    print(f"evidence: {len(ev)}; quote_kind={ev['quote_kind'].value_counts().to_dict()}")


if __name__ == "__main__":
    main()
