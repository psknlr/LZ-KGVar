"""
ConceptBrowser — Concept evolution visualization for the Laozi KG.

Provides cross-era timelines, density heatmaps, and single-concept HTML reports
showing how key Laozi concepts (道, 无为, 自然, etc.) were interpreted
across 175+ versions spanning the Spring & Autumn through Qing periods.

Usage:
    from concept_browser import ConceptBrowser
    cb = ConceptBrowser("path/to/laozi_kg.kuzu")
    cb.plot_concept_density_heatmap("heatmap.png")
    cb.generate_concept_report("道", "dao_report.html")
    cb.close()
"""
import kuzu
import pandas as pd
import os
import html
from typing import Optional, List, Dict
from collections import defaultdict


class ConceptBrowser:
    """Browse concept evolution across eras in the Laozi knowledge graph."""

    DEFAULT_DB = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "graph", "laozi_kg.kuzu"
    )

    ERA_ORDER = ["春秋", "春秋战国", "西汉", "东汉", "三国", "东晋",
                 "南北朝", "南朝宋", "南朝陈", "唐", "北宋", "南宋",
                 "宋", "元", "明", "清"]

    def __init__(self, db_path: str = None):
        self.db_path = db_path or self.DEFAULT_DB
        self.db = kuzu.Database(self.db_path)
        self.conn = kuzu.Connection(self.db)

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _query(self, cypher: str) -> pd.DataFrame:
        result = self.conn.execute(cypher)
        cols = result.get_column_names()
        rows = []
        while result.has_next():
            row = result.get_next()
            flat = {}
            for i, col in enumerate(cols):
                val = row[i] if i < len(row) else None
                if isinstance(val, dict):
                    for k, v in val.items():
                        if k.startswith("_"):
                            continue
                        flat[k] = v
                elif isinstance(val, list):
                    flat[col] = str(val)
                else:
                    flat[col] = val
            rows.append(flat)
        return pd.DataFrame(rows)

    def _era_sort_key(self, era):
        try:
            return self.ERA_ORDER.index(era)
        except (ValueError, TypeError):
            return 99

    def get_concept_timeline(self, concept_name: str) -> pd.DataFrame:
        """Return a timeline of commentary on a concept, ordered by era."""
        df = self._query(f"""
            MATCH (com:Commentary)-[:GLOSSES]->(c:Concept)
            WHERE c.name = '{concept_name}' OR c.concept_id = '{concept_name}'
            RETURN com.commentary_id AS commentary_id,
                   com.version_id AS version_id,
                   com.chapter_num AS chapter_num,
                   com.commentator_raw AS commentator,
                   com.commentator_historical_era AS commentator_historical_era,
                   com.commentary_witness_era AS witness_era,
                   com.source_quote AS source_quote,
                   com.llm_interpretation AS llm_interpretation,
                   com.reliability AS reliability,
                   com.citable_as_quote AS citable_as_quote,
                   com.text_provenance AS text_provenance
        """)
        if df.empty:
            return df
        df["_era_sort"] = df["commentator_historical_era"].apply(self._era_sort_key)
        return df.sort_values("_era_sort").drop(columns=["_era_sort"])

    def get_concept_density_matrix(self) -> pd.DataFrame:
        """Build a concept × era density matrix (gloss counts)."""
        df = self._query("""
            MATCH (com:Commentary)-[:GLOSSES]->(c:Concept)
            RETURN c.name AS concept, com.commentator_historical_era AS commentator_historical_era,
                   com.commentary_witness_era AS witness_era, count(com) AS gloss_count
        """)
        if df.empty:
            return pd.DataFrame()
        pivot = df.pivot_table(index="concept", columns="era",
                              values="gloss_count", fill_value=0)
        # Sort columns by era order
        era_cols = [e for e in self.ERA_ORDER if e in pivot.columns]
        other_cols = [c for c in pivot.columns if c not in era_cols]
        pivot = pivot[era_cols + other_cols]
        # Sort rows by total count descending
        pivot = pivot.loc[pivot.sum(axis=1).sort_values(ascending=False).index]
        return pivot

    def plot_concept_density_heatmap(self, save_path: str = None,
                                      top_n: int = 30) -> object:
        """Plot a concept × era density heatmap. Returns the figure object."""
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            import seaborn as sns
            plt.rcParams['font.sans-serif'] = [
                'Microsoft YaHei', 'SimHei', 'STSong', 'SimSun',
                'Noto Sans CJK SC', 'Source Han Sans SC', 'Arial Unicode MS',
                'DejaVu Sans'
            ]
            plt.rcParams['axes.unicode_minus'] = False
        except ImportError:
            print("matplotlib/seaborn not available. Returning data instead.")
            return self.get_concept_density_matrix()

        matrix = self.get_concept_density_matrix()
        if matrix.empty:
            print("No data for heatmap.")
            return None

        top = matrix.head(top_n)
        fig, ax = plt.subplots(figsize=(max(12, len(top.columns) * 1.2),
                                        max(8, len(top) * 0.4)))
        sns.heatmap(top, annot=True, fmt=".0f", cmap="YlOrRd",
                    ax=ax, cbar_kws={"label": "训解条目数"})
        ax.set_title(f"概念×时代训解密度热力图 (Top {min(top_n, len(matrix))} 概念)")
        ax.set_xlabel("时代")
        ax.set_ylabel("概念")
        plt.xticks(rotation=45, ha="right")
        plt.yticks(rotation=0)
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            print(f"Heatmap saved to {save_path}")
        return fig

    def generate_concept_report(self, concept_name: str,
                                 save_path: str = None) -> str:
        """Generate a self-contained HTML report for a single concept."""
        timeline = self.get_concept_timeline(concept_name)
        concept_df = self._query(f"""
            MATCH (c:Concept)
            WHERE c.name = '{concept_name}' OR c.concept_id = '{concept_name}'
            RETURN c
        """)

        if concept_df.empty and timeline.empty:
            return f"<p>Concept '{concept_name}' not found.</p>"

        info = concept_df.iloc[0].to_dict() if not concept_df.empty else {}
        definition = info.get("definition_core", "")
        category = info.get("category", "")
        is_seed = info.get("is_seed", False)
        seed_badge = '<span class="badge seed">种子概念</span>' if is_seed else '<span class="badge">扩展概念</span>'

        # Build era-grouped timeline sections
        era_sections = []
        if not timeline.empty:
            for era, group in timeline.groupby("era"):
                entries_html = []
                for _, row in group.iterrows():
                    ver = f"{row.get('commentator', '')} ({row.get('version_id', '')})"
                    interp = html.escape(str(row.get("interpretation", "")))
                    rel = row.get("reliability", "")
                    verified = row.get("verified", "")
                    ver_mark = ""
                    if verified == True:
                        ver_mark = '<span class="verified">✓逐字核验</span>'
                    elif verified == False:
                        ver_mark = '<span class="unverified">⚠非连续引文</span>'
                    entries_html.append(
                        f'<div class="entry"><span class="commentator">{html.escape(ver)}</span> '
                        f'<span class="reliability">[{rel}]</span> {ver_mark}'
                        f'<p class="interp">{interp}</p></div>'
                    )
                era_sections.append(
                    f'<h3 class="era">{html.escape(str(era))}</h3>'
                    f'{"".join(entries_html)}'
                )

        era_html = "\n".join(era_sections) if era_sections else "<p>暂无训解记录</p>"

        report = f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="UTF-8">
<title>「{html.escape(concept_name)}」概念演变报告</title>
<style>
body {{ font-family: 'Noto Serif SC', 'Source Han Serif SC', 'SimSun', 'STSong', 'Microsoft YaHei', serif; margin: 2em; background: #faf8f5; line-height: 1.8; }}
h1 {{ color: #2c3e50; border-bottom: 2px solid #2c3e50; padding-bottom: 0.3em; }}
.meta {{ color: #666; margin: 0.5em 0 1.5em; }}
.badge {{ font-size: 0.8em; padding: 2px 8px; border-radius: 3px; background: #ecf0f1; color: #7f8c8d; }}
.badge.seed {{ background: #e74c3c; color: white; }}
.definition {{ font-size: 1.1em; margin: 1em 0; padding: 1em; background: #fffde0; border-left: 4px solid #f39c12; }}
h3.era {{ color: #8e44ad; margin-top: 2em; border-bottom: 1px dashed #8e44ad; padding-bottom: 0.2em; }}
.entry {{ margin: 1em 0; padding: 0.8em; background: white; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
.commentator {{ font-weight: bold; color: #2c3e50; }}
.reliability {{ font-size: 0.85em; color: #e74c3c; }}
.verified {{ font-size: 0.8em; color: #27ae60; }}
.unverified {{ font-size: 0.8em; color: #e67e22; }}
.interp {{ margin: 0.5em 0 0; }}
.stat {{ display: inline-block; margin: 0 1em 1em 0; padding: 0.5em 1em; background: #ecf0f1; border-radius: 4px; }}
</style></head><body>
<h1>「{html.escape(concept_name)}」概念演变报告</h1>
<div class="meta">{seed_badge}
  {f'<span class="badge">分类: {html.escape(category)}</span>' if category else ''}
</div>
{f'<div class="definition"><strong>核心定义：</strong>{html.escape(str(definition))}</div>' if definition else ''}
<div>
  <span class="stat">训解条目: {len(timeline)}</span>
  <span class="stat">涉及时代: {timeline["commentator_historical_era"].nunique() if not timeline.empty else 0}</span>
  <span class="stat">涉及注家: {timeline["commentator"].nunique() if not timeline.empty else 0}</span>
</div>
<h2>历代训解时间线</h2>
{era_html}
</body></html>"""

        if save_path:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(report)
            print(f"Report saved to {save_path}")
        return report

    def list_concepts_by_category(self) -> pd.DataFrame:
        """List all concepts grouped by category."""
        return self._query("""
            MATCH (c:Concept)
            RETURN c.concept_id AS concept_id, c.name AS name,
                   c.category AS category, c.subcategory AS subcategory,
                   c.is_seed AS is_seed, c.definition_core AS definition
            ORDER BY c.category, c.name
        """)
