"""
LaoziKG — Query API for the Computable Laozi Knowledge Graph.

Provides programmatic access to 175+ versions of the Laozi/Dao De Jing
stored in a Kuzu embedded graph database. Every method returns pandas
DataFrames with traceable provenance (version_id, chapter_num, evidence refs).

Usage:
    from query_api import LaoziKG
    kg = LaoziKG("path/to/laozi_kg.kuzu")
    df = kg.get_concept_history("无为")
    kg.close()
"""
import kuzu
import pandas as pd
import os
import json
from typing import Optional, List, Dict, Any


class LaoziKG:
    """Core query API wrapping the Kuzu graph database of Laozi texts."""

    DEFAULT_DB = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "graph", "laozi_kg.kuzu"
    )

    def __init__(self, db_path: str = None):
        self.db_path = db_path or self.DEFAULT_DB
        self.db = kuzu.Database(self.db_path)
        self.conn = kuzu.Connection(self.db)

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── internal ──────────────────────────────────────────────

    def _query(self, cypher: str) -> pd.DataFrame:
        result = self.conn.execute(cypher)
        cols = result.get_column_names()
        rows = []
        while result.has_next():
            row = result.get_next()
            flat = {}
            for i, col in enumerate(cols):
                val = row[i] if i < len(row) else None
                if isinstance(val, dict):
                    for k, v in val.items():
                        if k.startswith("_"):
                            continue
                        flat[k] = v
                elif isinstance(val, list):
                    flat[col] = json.dumps(val, ensure_ascii=False)
                else:
                    flat[col] = val
            rows.append(flat)
        return pd.DataFrame(rows)

    def _query_single(self, cypher: str) -> Optional[Any]:
        result = self.conn.execute(cypher)
        if result.has_next():
            return result.get_next()[0]
        return None

    # ── Text Layer ────────────────────────────────────────────

    def get_versions(self) -> pd.DataFrame:
        """Return all 176 version records (175 original + 1 Wang Bi exegesis)."""
        return self._query("MATCH (v:Version) RETURN v ORDER BY v.witness_era, v.title")

    def get_version(self, version_id: str) -> Optional[pd.Series]:
        """Return a single version by ID."""
        cypher = f"MATCH (v:Version) WHERE v.version_id = '{version_id}' RETURN v"
        df = self._query(cypher)
        return df.iloc[0] if len(df) > 0 else None

    def get_chapter_text(self, version_id: str, chapter_num: int) -> pd.DataFrame:
        """Return all sentences of a specific chapter in a specific version."""
        instance_id = f"{version_id}-CH{chapter_num:03d}"
        cypher = f"""
            MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence)
            WHERE ci.instance_id = '{instance_id}'
            RETURN s.sentence_id AS sentence_id, s.seq AS seq,
                   s.original_text AS original_text,
                   s.normalized_text AS normalized_text
            ORDER BY s.seq
        """
        df = self._query(cypher)
        if len(df) == 0:
            # try without zero-padding
            instance_id = f"{version_id}-CH{chapter_num}"
            cypher = f"""
                MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence)
                WHERE ci.instance_id = '{instance_id}'
                RETURN s.sentence_id AS sentence_id, s.seq AS seq,
                       s.original_text AS original_text,
                       s.normalized_text AS normalized_text
                ORDER BY s.seq
            """
            df = self._query(cypher)
        return df

    def get_chapter_instances(self, version_id: str = None) -> pd.DataFrame:
        """Return chapter instances, optionally filtered by version."""
        if version_id:
            cypher = f"MATCH (ci:ChapterInstance) WHERE ci.version_id = '{version_id}' RETURN ci ORDER BY ci.chapter_num"
        else:
            cypher = "MATCH (ci:ChapterInstance) RETURN ci ORDER BY ci.version_id, ci.chapter_num"
        return self._query(cypher)

    def get_persons(self) -> pd.DataFrame:
        """Return all 84 person records."""
        return self._query("MATCH (p:Person) RETURN p ORDER BY p.person_historical_era, p.canonical_name")

    def get_authors(self, version_id: str) -> pd.DataFrame:
        """Return authors/annotators of a version."""
        cypher = f"""
            MATCH (v:Version)-[r:AUTHORED_BY]->(p:Person)
            WHERE v.version_id = '{version_id}'
            RETURN v.version_id AS version_id, p.person_id AS person_id,
                   p.canonical_name AS name, p.person_historical_era AS person_historical_era,
                   r.role_raw AS role, 'authored' AS relation
        """
        df1 = self._query(cypher)
        cypher2 = f"""
            MATCH (v:Version)-[r:ANNOTATED_BY]->(p:Person)
            WHERE v.version_id = '{version_id}'
            RETURN v.version_id AS version_id, p.person_id AS person_id,
                   p.canonical_name AS name, p.person_historical_era AS person_historical_era,
                   r.role_raw AS role, 'annotated' AS relation
        """
        df2 = self._query(cypher2)
        return pd.concat([df1, df2], ignore_index=True)

    # ── Variant Layer ─────────────────────────────────────────

    def get_variants(self, chapter_num: int = None, version_id: str = None,
                     change_type: str = None) -> pd.DataFrame:
        """Return variant records, optionally filtered by chapter/version/type."""
        filters = []
        if chapter_num is not None:
            filters.append(f"v.chapter_num = {chapter_num}")
        if version_id:
            filters.append(f"v.version_b = '{version_id}'")
        if change_type:
            filters.append(f"v.change_type = '{change_type}'")
        where = f" WHERE {' AND '.join(filters)}" if filters else ""
        cypher = f"MATCH (v:Variant){where} RETURN v ORDER BY v.chapter_num, v.position"
        return self._query(cypher)

    def get_variant_summary(self, chapter_num: int = None) -> pd.DataFrame:
        """Aggregate variant counts by version and chapter."""
        if chapter_num:
            cypher = f"""
                MATCH (v:Variant) WHERE v.chapter_num = {chapter_num}
                RETURN v.version_b AS version_id, v.change_type AS change_type,
                       count(v) AS variant_count
                ORDER BY variant_count DESC
            """
        else:
            cypher = """
                MATCH (v:Variant)
                RETURN v.version_b AS version_id, v.change_type AS change_type,
                       count(v) AS variant_count
                ORDER BY variant_count DESC
            """
        return self._query(cypher)

    # ── Concept Layer ─────────────────────────────────────────

    def get_concepts(self, seed_only: bool = False) -> pd.DataFrame:
        """Return all 104 concept records, optionally only the 15 seed concepts."""
        if seed_only:
            return self._query("MATCH (c:Concept) WHERE c.is_seed = true RETURN c ORDER BY c.name")
        return self._query("MATCH (c:Concept) RETURN c ORDER BY c.is_seed DESC, c.name")

    def get_concept_history(self, concept_name: str) -> Dict[str, pd.DataFrame]:
        """Return the evolution of a concept across eras.

        Returns a dict with:
            'concept': the concept node
            'glosses': commentary glosses tagged with this concept
            'mentions': chapter instances mentioning this concept
        """
        concept_id = concept_name
        # Try to find by name first
        cypher = f"MATCH (c:Concept) WHERE c.name = '{concept_name}' OR c.concept_id = '{concept_name}' RETURN c"
        df_c = self._query(cypher)
        if len(df_c) > 0:
            concept_id = df_c.iloc[0]["concept_id"]

        glosses = self._query(f"""
            MATCH (com:Commentary)-[:GLOSSES]->(c:Concept)
            WHERE c.concept_id = '{concept_id}' OR c.name = '{concept_name}'
            RETURN com.commentary_id AS commentary_id, com.version_id AS version_id,
                   com.chapter_num AS chapter_num, com.commentator_raw AS commentator,
                   com.commentator_historical_era AS commentator_historical_era,
                   com.commentary_witness_era AS witness_era, com.source_quote AS source_quote,
                   com.llm_interpretation AS llm_interpretation,
                   com.reliability AS reliability,
                   com.citable_as_quote AS citable_as_quote,
                   com.text_provenance AS text_provenance
            ORDER BY com.commentator_historical_era
        """)

        mentions = self._query(f"""
            MATCH (ci:ChapterInstance)-[r:MENTIONS_CONCEPT]->(c:Concept)
            WHERE c.concept_id = '{concept_id}' OR c.name = '{concept_name}'
            RETURN ci.instance_id AS instance_id, ci.version_id AS version_id,
                   ci.chapter_num AS chapter_num,
                   r.mention_count AS mention_count
            ORDER BY ci.version_id, ci.chapter_num
        """)

        return {
            "concept": df_c,
            "glosses": glosses,
            "mentions": mentions,
        }

    def get_concept_mentions(self, concept_name: str = None) -> pd.DataFrame:
        """Return chapter-concept mention relationships."""
        if concept_name:
            cypher = f"""
                MATCH (ci:ChapterInstance)-[r:MENTIONS_CONCEPT]->(c:Concept)
                WHERE c.name = '{concept_name}' OR c.concept_id = '{concept_name}'
                RETURN ci.version_id AS version_id, ci.chapter_num AS chapter_num,
                       c.name AS concept_name, r.mention_count AS mention_count
                ORDER BY ci.version_id, ci.chapter_num
            """
        else:
            cypher = """
                MATCH (ci:ChapterInstance)-[r:MENTIONS_CONCEPT]->(c:Concept)
                RETURN ci.version_id AS version_id, ci.chapter_num AS chapter_num,
                       c.concept_id AS concept_id, c.name AS concept_name,
                       r.mention_count AS mention_count
                ORDER BY c.name, ci.version_id
            """
        return self._query(cypher)

    # ── Commentary Layer ──────────────────────────────────────

    def search_commentary(self, query: str = None, concept_name: str = None,
                          version_id: str = None, chapter_num: int = None) -> pd.DataFrame:
        """Search commentary records by text, concept, version, or chapter."""
        filters = []
        if query:
            filters.append(f"com.llm_interpretation CONTAINS '{query}'")
        if concept_name:
            filters.append(f"(com.concept_name = '{concept_name}' OR com.concept_id = '{concept_name}')")
        if version_id:
            filters.append(f"com.version_id = '{version_id}'")
        if chapter_num is not None:
            filters.append(f"com.chapter_num = {chapter_num}")
        where = f" WHERE {' AND '.join(filters)}" if filters else ""
        cypher = f"""
            MATCH (com:Commentary)
            OPTIONAL MATCH (com)-[:GLOSSES]->(c:Concept)
            OPTIONAL MATCH (com)-[:HAS_EVIDENCE]->(e:Evidence)
            {where}
            RETURN com.commentary_id AS commentary_id, com.version_id AS version_id,
                   com.instance_id AS instance_id, com.chapter_num AS chapter_num,
                   com.commentator_raw AS commentator, com.commentator_historical_era AS commentator_historical_era,
                   com.commentary_witness_era AS witness_era,
                   com.concept_id AS concept_id, com.concept_name AS concept_name,
                   com.source_quote AS source_quote,
                   com.llm_interpretation AS llm_interpretation,
                   com.reliability AS reliability,
                   com.citable_as_quote AS citable_as_quote,
                   com.text_provenance AS text_provenance,
                   e.evidence_id AS evidence_id,
                   e.quote AS evidence_quote,
                   e.source_type AS evidence_source_type,
                   e.reliability AS evidence_reliability
            ORDER BY com.commentator_historical_era, com.chapter_num
        """
        return self._query(cypher)

    def get_commentary(self, commentary_id: str) -> Optional[pd.Series]:
        """Return a single commentary record."""
        cypher = f"MATCH (com:Commentary) WHERE com.commentary_id = '{commentary_id}' RETURN com"
        df = self._query(cypher)
        return df.iloc[0] if len(df) > 0 else None

    def get_evidence_for_commentary(self, commentary_id: str) -> pd.DataFrame:
        """Return evidence supporting a specific commentary entry."""
        cypher = f"""
            MATCH (com:Commentary)-[:HAS_EVIDENCE]->(e:Evidence)
            WHERE com.commentary_id = '{commentary_id}'
            RETURN e.evidence_id AS evidence_id, e.source_type AS source_type,
                   e.source_ref AS source_ref, e.quote AS quote,
                   e.reliability AS reliability
        """
        return self._query(cypher)

    # ── Provenance Layer (v2) ─────────────────────────────────

    def get_provenance_assertions(self, version_id: str = None) -> pd.DataFrame:
        """Return provenance assertions (version-to-version lineage claims)."""
        if version_id:
            cypher = f"""
                MATCH (v:Version)<-[:PA_ASSERTS_A]-(pa:ProvenanceAssertion)
                WHERE v.version_id = '{version_id}'
                RETURN pa.*
            """
            df1 = self._query(cypher)
            cypher2 = f"""
                MATCH (pa:ProvenanceAssertion)-[:PA_ASSERTS_B]->(v:Version)
                WHERE v.version_id = '{version_id}'
                RETURN pa.*
            """
            df2 = self._query(cypher2)
            return pd.concat([df1, df2], ignore_index=True).drop_duplicates()
        return self._query("MATCH (pa:ProvenanceAssertion) RETURN pa ORDER BY pa.version_a")

    def get_provenance_chain(self, version_id: str) -> pd.DataFrame:
        """Trace the provenance chain for a version via ProvenanceAssertion.

        v1.1.0 also queried a direct SAME_WORK_EDITION relationship, which the
        build never created (the input file was hashed but its edges were never
        written). ProvenanceAssertion is the single supported mechanism.
        """
        assertions = self._query(f"""
            MATCH (v:Version)<-[:PA_ASSERTS_A]-(pa:ProvenanceAssertion)-[:PA_ASSERTS_B]->(w:Version)
            WHERE v.version_id = '{version_id}' OR w.version_id = '{version_id}'
            RETURN v.version_id AS source_version, w.version_id AS target_version,
                   pa.relation_type AS relation_type,
                   pa.confidence AS confidence,
                   pa.assertion_basis AS basis,
                   pa.asserter AS asserter,
                   pa.reliability AS reliability,
                   pa.notes AS notes
        """)
        return assertions

    def get_version_lineage(self, version_id: str) -> pd.DataFrame:
        """Alias for get_provenance_chain."""
        return self.get_provenance_chain(version_id)

    # ── Scholarly Claims Layer (v2) ──────────────────────────

    def get_scholarly_claims(self) -> pd.DataFrame:
        """Return all 10 scholarly dispute claims."""
        return self._query("MATCH (sc:CandidateScholarlyClaim) RETURN sc ORDER BY sc.domain")

    def get_claim_evidence(self, sc_id: str) -> pd.DataFrame:
        """Return pro/con evidence for a scholarly claim."""
        cypher = f"""
            MATCH (sc:CandidateScholarlyClaim)-[:CLAIM_EVIDENCE]->(sce:CandidateScholarlyClaimEvidence)
            WHERE sc.sc_id = '{sc_id}'
            RETURN sce.evidence_id AS evidence_id, sce.sc_id AS sc_id,
                   sce.side AS side, sce.evidence_text AS evidence_text,
                   sce.reliability AS reliability
            ORDER BY sce.side
        """
        return self._query(cypher)

    def search_scholarly_claims(self, keyword: str) -> pd.DataFrame:
        """Search scholarly claims by keyword in claim text, proponents, or opponents."""
        cypher = f"""
            MATCH (sc:CandidateScholarlyClaim)
            WHERE sc.claim_text CONTAINS '{keyword}'
               OR sc.proponents CONTAINS '{keyword}'
               OR sc.opponents CONTAINS '{keyword}'
               OR sc.domain CONTAINS '{keyword}'
            RETURN sc.*
        """
        return self._query(cypher)

    # ── Statistics ────────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        """Return database-wide statistics."""
        # Enumerate from the database: a hardcoded list silently omits tables
        # added later (PersonAlias, CONCEPT_LOCUS and RELATED_CONCEPT were all
        # missing from these counts before this was introspected).
        node_tables, rel_tables = [], []
        res = self.conn.execute("CALL show_tables() RETURN *")
        while res.has_next():
            row = res.get_next()
            (node_tables if str(row[2]).upper().startswith("NODE")
             else rel_tables).append(row[1])
        node_tables.sort(); rel_tables.sort()

        node_counts = {}
        for t in node_tables:
            cnt = self._query_single(f"MATCH (n:{t}) RETURN count(n)")
            node_counts[t] = cnt

        rel_counts = {}
        for t in rel_tables:
            cnt = self._query_single(f"MATCH (a)-[r:{t}]->(b) RETURN count(r)")
            rel_counts[t] = cnt

        # Era distribution
        era_dist = self._query("""
            MATCH (v:Version)
            RETURN v.witness_era AS witness_era, count(v) AS count
            ORDER BY count DESC
        """)

        # Variant distribution by type
        variant_dist = self._query("""
            MATCH (v:Variant)
            RETURN v.change_type AS change_type, count(v) AS count
        """)

        return {
            "node_counts": node_counts,
            "relationship_counts": rel_counts,
            "total_versions": node_counts.get("Version", 0),
            "total_chapters": node_counts.get("ChapterInstance", 0),
            "total_sentences": node_counts.get("Sentence", 0),
            "total_variants": node_counts.get("Variant", 0),
            "total_concepts": node_counts.get("Concept", 0),
            "total_commentary": node_counts.get("Commentary", 0),
            "era_distribution": era_dist,
            "variant_distribution": variant_dist,
        }
    # ---- Feature 1: Sentence Variant Collation ----

    def get_sentence_variants(self, chapter_num, seq=None):
        if seq is not None:
            cy = (
                "MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence) "
                "MATCH (v:Version)-[:HAS_INSTANCE]->(ci) "
                "WHERE ci.chapter_num = %d AND s.seq = %d "
                "RETURN s.seq AS seq, s.original_text AS text, "
                "s.normalized_text AS norm, v.version_id AS version_id, "
                "v.title AS version_title, v.witness_era AS witness_era "
                "ORDER BY v.witness_era, v.version_id"
            ) % (chapter_num, seq)
        else:
            cy = (
                "MATCH (ci:ChapterInstance)-[:HAS_SENTENCE]->(s:Sentence) "
                "MATCH (v:Version)-[:HAS_INSTANCE]->(ci) "
                "WHERE ci.chapter_num = %d "
                "RETURN s.seq AS seq, s.original_text AS text, "
                "s.normalized_text AS norm, v.version_id AS version_id, "
                "v.title AS version_title, v.witness_era AS witness_era "
                "ORDER BY s.seq, v.witness_era, v.version_id"
            ) % chapter_num
        return self._query(cy)

    def get_chapter_variant_diffs(self, chapter_num):
        cy = (
            "MATCH (v:Variant) "
            "WHERE v.chapter_num = %d "
            "RETURN v.reference_text_id AS version_a, v.version_b AS version_b, "
            "v.position AS position, v.change_type AS change_type, "
            "v.edit_op AS edit_op, v.old_text AS old_text, v.new_text AS new_text, "
            "v.variant_detection_score AS variant_detection_score, v.semantic_explanation AS explanation "
            "ORDER BY v.position, v.change_type"
        ) % chapter_num
        return self._query(cy)

    # ---- Feature 2: Commentary Synopsis ----

    def get_chapter_commentaries(self, chapter_num):
        cy = (
            "MATCH (cm:Commentary) "
            "WHERE cm.chapter_num = %d "
            "RETURN cm.commentator_raw AS commentator, "
            "cm.commentator_historical_era AS commentator_historical_era, "
            "cm.commentary_witness_era AS witness_era, "
            "cm.concept_name AS concept, cm.source_quote AS source_quote, "
            "cm.llm_interpretation AS llm_interpretation, "
            "cm.citable_as_quote AS citable_as_quote, "
            "cm.reliability AS reliability, cm.version_id AS version_id "
            "ORDER BY cm.concept_name, cm.reliability, cm.commentator_raw"
        ) % chapter_num
        return self._query(cy)

    def get_commentary_conflicts(self, chapter_num=None):
        where = f"WHERE cm.chapter_num = {chapter_num}" if chapter_num else ""
        cy = (
            "MATCH (cm:Commentary) " + where + " "
            "WITH cm.concept_name AS concept, "
            "count(DISTINCT cm.commentator_raw) AS n_commentators, "
            "count(DISTINCT coalesce(cm.source_quote, cm.llm_interpretation)) AS n_distinct_readings "
            "WHERE n_commentators >= 2 "
            "RETURN concept, n_commentators, n_distinct_readings "
            "ORDER BY n_commentators DESC, n_distinct_readings DESC "
            "LIMIT 30"
        )
        return self._query(cy)

    # ---- Feature 3: Concept Relations ----

    def get_concept_cooccurrence(self, seed_only=True):
        if seed_only:
            cy = (
                "MATCH (c1:Concept)<-[:GLOSSES]-(cm:Commentary)-[:GLOSSES]->(c2:Concept) "
                "WHERE c1.is_seed = true AND c2.is_seed = true "
                "AND c1.concept_id < c2.concept_id "
                "WITH c1 AS a, c2 AS b, count(*) AS weight "
                "RETURN a.name AS source, b.name AS target, weight, "
                "a.category AS source_cat, b.category AS target_cat "
                "ORDER BY weight DESC "
                "LIMIT 200"
            )
        else:
            cy = (
                "MATCH (c1:Concept)<-[:GLOSSES]-(cm:Commentary)-[:GLOSSES]->(c2:Concept) "
                "WHERE c1.concept_id < c2.concept_id "
                "WITH c1 AS a, c2 AS b, count(*) AS weight "
                "RETURN a.name AS source, b.name AS target, weight, "
                "a.category AS source_cat, b.category AS target_cat "
                "ORDER BY weight DESC "
                "LIMIT 200"
            )
        return self._query(cy)

    def get_concept_neighborhood(self, concept_name, hop=1):
        cy = (
            "MATCH (target:Concept {name: '" + concept_name + "'}) "
            "MATCH (neighbor:Concept)<-[:GLOSSES]-(cm:Commentary)-[:GLOSSES]->(target) "
            "WHERE neighbor.concept_id <> target.concept_id "
            "WITH neighbor AS n, count(*) AS w "
            "RETURN n.name AS name, n.category AS category, "
            "n.is_seed AS is_seed, w AS weight "
            "ORDER BY w DESC "
            "LIMIT 40"
        )
        neighbors = self._query(cy)
        nodes = [dict(name=concept_name, category="target", is_seed=True, weight=None)]
        edges = []
        seen = {concept_name}
        for _, row in neighbors.iterrows():
            nname = row["name"]
            if nname in seen:
                continue
            seen.add(nname)
            nodes.append(dict(
                name=nname,
                category=row.get("category", ""),
                is_seed=bool(row.get("is_seed", False)),
                weight=int(row["weight"])))
            edges.append(dict(
                source=concept_name, target=nname, weight=int(row["weight"])))
        return dict(nodes=nodes, edges=edges)

