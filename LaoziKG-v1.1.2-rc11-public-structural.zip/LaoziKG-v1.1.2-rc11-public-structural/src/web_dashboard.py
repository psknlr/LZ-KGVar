#!/usr/bin/env python3
"""
Laozi KG Web Dashboard — single-file HTTP server (stdlib only, no Flask).

Provides:
  GET  /                 → Dashboard HTML
  GET  /api/stats        → database statistics
  GET  /api/versions     → all 176 versions
  GET  /api/concepts     → all 111 concepts
  GET  /api/concept/<n>  → concept detail + glosses + mentions
  GET  /api/variants/<c> → chapter variants
  GET  /api/commentary   → commentary search (?q=&concept=&chapter=)
  GET  /api/chapter/<v>/<c> → chapter text
  GET  /api/persons      → 84 persons
  GET  /api/scholarly_claims → 10 scholarly claims
  POST /api/qa           → QA agent {"question": "..."}
"""
import json
import os
import sys
import traceback
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from src.query_api import LaoziKG
from src.qa_agent import LaoziQAAgent

kg = LaoziKG()
qa = LaoziQAAgent(kg=kg)



def _banner():
    """Header counts, read from release_facts.json rather than typed into the
    template. The literal version drifted: it said 224,753 sentences after the
    recovery raised the table to 224,794."""
    import json as _j, os as _o
    here = _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))
    try:
        F = _j.load(open(_o.path.join(here, "metadata", "release_facts.json"),
                         encoding="utf-8"))
        return (f"{F['resources']} \u7248\u672c \u00b7 {F['concepts']} \u6982\u5ff5 \u00b7 "
                f"{F['commentary']:,} \u8bad\u89e3 \u00b7 {F['variants']:,} \u5f02\u6587 \u00b7 "
                f"{F['sentences']:,} \u53e5\u5b50")
    except Exception:
        return ""


def df_to_json(df):
    return json.loads(df.to_json(orient="records", force_ascii=False))


def json_response(handler, data, status=200):
    body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def error_response(handler, msg, status=400):
    json_response(handler, {"error": msg}, status)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        qs = parse_qs(parsed.query)

        try:
            if path == "" or path == "/":
                self.serve_dashboard()
            elif path == "/api/stats":
                s = kg.stats()
                s["era_distribution"] = df_to_json(s["era_distribution"])
                s["variant_distribution"] = df_to_json(s["variant_distribution"])
                json_response(self, s)
            elif path == "/api/versions":
                json_response(self, df_to_json(kg.get_versions()))
            elif path == "/api/concepts":
                json_response(self, df_to_json(kg.get_concepts()))
            elif path.startswith("/api/concept/"):
                name = unquote(path.split("/api/concept/", 1)[1])
                result = kg.get_concept_history(name)
                json_response(self, {
                    "concept": df_to_json(result["concept"]),
                    "glosses": df_to_json(result["glosses"]),
                    "mentions": df_to_json(result["mentions"]),
                })
            elif path.startswith("/api/variants/"):
                ch = int(path.split("/api/variants/", 1)[1])
                json_response(self, df_to_json(kg.get_variants(chapter_num=ch)))
            elif path == "/api/commentary":
                q = qs.get("q", [None])[0]
                concept = qs.get("concept", [None])[0]
                chapter = qs.get("chapter", [None])[0]
                chapter = int(chapter) if chapter else None
                json_response(self, df_to_json(
                    kg.search_commentary(query=q, concept_name=concept, chapter_num=chapter)
                ))
            elif path.startswith("/api/chapter/"):
                parts = path.split("/api/chapter/", 1)[1].split("/")
                if len(parts) == 2:
                    vid, ch = parts[0], int(parts[1])
                    json_response(self, df_to_json(kg.get_chapter_text(vid, ch)))
                else:
                    error_response(self, "Usage: /api/chapter/<version_id>/<chapter_num>")
            elif path == "/api/persons":
                json_response(self, df_to_json(kg.get_persons()))
            elif path == "/api/scholarly_claims":
                json_response(self, df_to_json(kg.get_scholarly_claims()))
            # ── NEW Feature APIs ──
            elif path == "/api/collation":
                ch = int(qs.get("ch", [1])[0])
                json_response(self, {
                    "sentences": df_to_json(kg.get_sentence_variants(ch)),
                    "diffs": df_to_json(kg.get_chapter_variant_diffs(ch)),
                })
            elif path == "/api/chapter_views":
                ch = int(qs.get("ch", [1])[0])
                json_response(self, {
                    "commentaries": df_to_json(kg.get_chapter_commentaries(ch)),
                    "conflicts": df_to_json(kg.get_commentary_conflicts(ch)),
                })
            elif path == "/api/concept_graph":
                name = qs.get("name", [None])[0]
                seed = qs.get("seed", ["true"])[0].lower() == "true"
                if name:
                    json_response(self, kg.get_concept_neighborhood(name))
                else:
                    json_response(self, df_to_json(kg.get_concept_cooccurrence(seed_only=seed)))
            else:
                error_response(self, "Not found", 404)
        except Exception as e:
            import traceback
            traceback.print_exc()
            error_response(self, str(e), 500)

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        if path == "/api/qa":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
                question = data.get("question", "")
                result = qa.answer(question)
                json_response(self, result)
            except Exception as e:
                error_response(self, str(e), 500)
        else:
            error_response(self, "Not found", 404)

    def serve_dashboard(self):
        html = DASHBOARD_HTML.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>《老子》知识图谱 — Dashboard</title>
<script src="https://cdn.bootcdn.net/ajax/libs/echarts/5.5.0/echarts.min.js"></script>
<script>
if(typeof echarts==='undefined'){document.write('<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"><\/script>');}
</script>
<style>
:root{--bg:#0a0c10;--card:#14171f;--border:#252836;--accent:#d4a574;--accent2:#6cb6e4;--green:#4ade80;--text:#e2e8f0;--dim:#94a3b8;--mute:#64748b}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:-apple-system,"PingFang SC","Microsoft YaHei","Noto Sans SC",sans-serif;line-height:1.7}
.header{background:linear-gradient(135deg,#14171f,#1e2230,#14171f);border-bottom:1px solid var(--border);padding:32px 24px;text-align:center}
.header h1{font-size:28px;color:var(--accent);letter-spacing:2px;margin-bottom:8px}
.header .sub{color:var(--dim);font-size:14px}
.stats-row{display:flex;justify-content:center;gap:28px;flex-wrap:wrap;margin-top:20px}
.stat{text-align:center}
.stat .v{font-size:26px;font-weight:700;color:var(--accent2)}
.stat .l{font-size:11px;color:var(--mute);margin-top:2px}
.nav{display:flex;justify-content:center;gap:8px;padding:16px;background:var(--card);border-bottom:1px solid var(--border);flex-wrap:wrap}
.nav button{padding:8px 18px;border:1px solid var(--border);border-radius:6px;background:transparent;color:var(--dim);cursor:pointer;font-size:13px;transition:all .2s}
.nav button:hover,.nav button.active{background:var(--accent);color:#1a1a1a;border-color:var(--accent);font-weight:600}
.wrap{max-width:1100px;margin:0 auto;padding:24px 16px}
.panel{display:none}
.panel.active{display:block}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:16px}
.card h2{font-size:17px;color:var(--accent);margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--border)}
.chart-box{width:100%;height:400px}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;padding:8px 10px;color:var(--mute);font-size:11px;text-transform:uppercase;border-bottom:1px solid var(--border)}
td{padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.04);color:var(--dim);max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
td.mono{font-family:Consolas,monospace;color:var(--accent2)}
.qa-box{display:flex;gap:10px;margin-bottom:16px}
.qa-box input{flex:1;padding:12px 16px;border:1px solid var(--border);border-radius:8px;background:rgba(255,255,255,.03);color:var(--text);font-size:14px;outline:none}
.qa-box input:focus{border-color:var(--accent2)}
.qa-box button{padding:12px 24px;background:var(--accent);color:#1a1a1a;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px}
.qa-result{background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:8px;padding:18px;font-size:13px;line-height:1.9;max-height:600px;overflow-y:auto}
.qa-result h2{font-size:16px;color:var(--accent);margin:16px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--border)}
.qa-result h3{font-size:14px;color:var(--accent2);margin:14px 0 8px}
.qa-result strong{color:var(--accent);font-weight:600}
.qa-result ul{list-style:none;padding:0;margin:6px 0}
.qa-result ul li{padding:5px 0 5px 16px;position:relative;color:var(--dim);font-size:12.5px;line-height:1.7}
.qa-result ul li::before{content:'·';position:absolute;left:4px;color:var(--accent);font-weight:700}
.qa-result p{margin:6px 0}
.qa-meta{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}
.qa-meta .meta-chip{display:inline-flex;align-items:center;padding:3px 10px;border-radius:4px;font-size:11px;font-weight:600;background:rgba(108,182,228,.12);color:var(--accent2);border:1px solid rgba(108,182,228,.2)}
.qa-meta .meta-chip.intent{background:rgba(212,165,116,.12);color:var(--accent);border-color:rgba(212,165,116,.2)}
.qa-meta .meta-chip cite{opacity:.7;margin-left:2px}
.qa-cite{margin-top:14px;padding-top:12px;border-top:1px solid var(--border)}
.qa-cite h4{color:var(--mute);font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px}
.qa-cite ol{padding-left:20px;color:var(--dim);font-size:12px}
.qa-cite ol li{margin:4px 0}
.tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;margin-right:6px}
.tag-seed{background:rgba(212,165,116,.15);color:var(--accent)}
.tag-era{background:rgba(108,182,228,.15);color:var(--accent2)}
.search-bar{display:flex;gap:10px;margin-bottom:16px}
.search-bar input,.search-bar select{padding:10px 14px;border:1px solid var(--border);border-radius:6px;background:rgba(255,255,255,.03);color:var(--text);font-size:13px;outline:none}
.search-bar input{flex:1}
.search-bar button{padding:10px 20px;background:var(--accent2);color:#1a1a1a;border:none;border-radius:6px;font-weight:600;cursor:pointer}
@media(max-width:640px){.stats-row{gap:16px}.header h1{font-size:22px}}
</style>
</head>
<body>
<div class="header">
  <h1>《老子》知识图谱</h1>
  <div class="sub">{_banner()}</div>
  <div class="stats-row" id="hero-stats"></div>
</div>
<div class="nav">
  <button class="active" onclick="showPanel('overview')">统计概览</button>
  <button onclick="showPanel('versions')">版本列表</button>
  <button onclick="showPanel('concepts')">概念网络</button>
  <button onclick="showPanel('variants')">异文对比</button>
  <button onclick="showPanel('commentary')">训解检索</button>
  <button onclick="showPanel('collation')">章句异文</button>
  <button onclick="showPanel('views')">章句各家</button>
  <button onclick="showPanel('concept-graph')">概念图谱</button>
  <button onclick="showPanel('qa')">智能问答</button>
</div>
<div class="wrap">

<div id="panel-overview" class="panel active">
  <div class="card"><h2>按朝代版本分布</h2><div id="chart-era" class="chart-box"></div></div>
  <div class="card"><h2>异文类型分布</h2><div id="chart-variant" class="chart-box"></div></div>
  <div class="card"><h2>数据规模</h2><table id="table-stats"></table></div>
</div>

<div id="panel-versions" class="panel">
  <div class="card"><h2>176 个版本</h2>
    <div class="search-bar"><input id="ver-search" placeholder="搜索版本标题/ID..." oninput="filterVersions()"><button onclick="filterVersions()">搜索</button></div>
    <div style="max-height:600px;overflow-y:auto"><table id="table-versions"></table></div>
  </div>
</div>

<div id="panel-concepts" class="panel">
  <div class="card"><h2>111 个哲学概念</h2>
    <div class="search-bar"><input id="concept-search" placeholder="搜索概念..." oninput="filterConcepts()"></div>
    <div style="max-height:600px;overflow-y:auto"><table id="table-concepts"></table></div>
  </div>
  <div class="card" id="concept-detail" style="display:none"><h2 id="cd-name"></h2><div id="cd-body"></div></div>
</div>

<div id="panel-variants" class="panel">
  <div class="card"><h2>异文对比</h2>
    <div class="search-bar"><label style="color:var(--mute);font-size:13px;line-height:40px">章节：</label><input id="var-ch" type="number" value="1" min="1" max="81" style="width:80px"><button onclick="loadVariants()">查询</button></div>
    <div id="var-summary" style="margin-bottom:12px;color:var(--dim);font-size:13px"></div>
    <div style="max-height:600px;overflow-y:auto"><table id="table-variants"></table></div>
  </div>
</div>

<div id="panel-commentary" class="panel">
  <div class="card"><h2>训解检索</h2>
    <div class="search-bar"><input id="com-q" placeholder="关键词..."><input id="com-concept" placeholder="概念名（可选）" style="max-width:160px"><button onclick="searchCommentary()">检索</button></div>
    <div id="com-count" style="margin-bottom:12px;color:var(--dim);font-size:13px"></div>
    <div style="max-height:600px;overflow-y:auto"><table id="table-commentary"></table></div>
  </div>
</div>


<div id="panel-collation" class="panel">
  <div class="card"><h2>章句异文比刊校对</h2>
    <div class="search-bar">
      <label style="color:var(--mute);font-size:13px;line-height:40px">章节：</label>
      <input id="col-ch" type="number" value="1" min="1" max="81" style="width:80px">
      <button onclick="loadCollation()">比对</button>
      <div id="col-summary" style="margin-left:auto;color:var(--dim);font-size:13px;align-self:center"></div>
    </div>
    <div style="margin-bottom:16px">
      <h3 style="font-size:14px;color:var(--accent2);margin-bottom:10px">跨版本原文（滚动浏览）</h3>
      <div style="max-height:340px;overflow-y:auto;overflow-x:auto">
        <table id="table-sentences"></table>
      </div>
    </div>
    <div>
      <h3 style="font-size:14px;color:var(--accent2);margin-bottom:10px">异文差异清单（old → new）</h3>
      <div style="max-height:340px;overflow-y:auto">
        <table id="table-diffs"></table>
      </div>
    </div>
  </div>
</div>

<div id="panel-views" class="panel">
  <div class="card"><h2>章句各家观点与冲突</h2>
    <div class="search-bar">
      <label style="color:var(--mute);font-size:13px;line-height:40px">章节：</label>
      <input id="vi-ch" type="number" value="1" min="1" max="81" style="width:80px">
      <button onclick="loadViews()">查看</button>
      <div id="vi-summary" style="margin-left:auto;color:var(--dim);font-size:13px;align-self:center"></div>
    </div>
    <div style="margin-bottom:16px;background:rgba(248,113,113,.05);border:1px solid rgba(248,113,113,.2);border-radius:8px;padding:14px">
      <h3 style="font-size:13px;color:#f87171;margin-bottom:8px">争议概念（2+ 注家异读）</h3>
      <div id="table-conflicts"></div>
    </div>
    <div>
      <h3 style="font-size:14px;color:var(--accent2);margin-bottom:10px">按概念分组的各家注疏</h3>
      <div id="views-grouped" style="max-height:600px;overflow-y:auto"></div>
    </div>
  </div>
</div>

<div id="panel-concept-graph" class="panel">
  <div class="card"><h2>概念关系图谱（GLOSSES 注疏关联）</h2>
    <div class="search-bar">
      <label style="color:var(--mute);font-size:13px;line-height:40px">中心概念：</label>
      <input id="cg-name" placeholder="如：道、无为、自然" style="max-width:200px">
      <button onclick="loadConceptGraph()">渲染子图</button>
      <button onclick="loadGlobalGraph()" style="background:var(--green)">全局共现</button>
    </div>
    <div id="cg-summary" style="margin-bottom:12px;color:var(--dim);font-size:13px"></div>
    <div id="chart-concept-graph" class="chart-box" style="height:540px"></div>
  </div>
</div>

<div id="panel-qa" class="panel">
  <div class="card"><h2>智能问答</h2>
    <div class="qa-box"><input id="qa-input" placeholder="输入问题，如：什么是道" onkeydown="if(event.key==='Enter')askQA()"><button onclick="askQA()">提问</button></div>
    <div id="qa-result" class="qa-result" style="display:none"></div>
  </div>
</div>

</div>
<script>
const API = '';
let allVersions=[], allConcepts=[];

function showPanel(name){
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('panel-'+name).classList.add('active');
  document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('active'));
  event.target.classList.add('active');
}

async function fetchJSON(url){const r=await fetch(API+url);return r.json();}

async function init(){
  const stats=await fetchJSON('/api/stats');
  const s=stats.node_counts||{};
  const hero=document.getElementById('hero-stats');
  [['版本',s.Version||0],['概念',s.Concept||0],['训解',s.Commentary||0],['异文',s.Variant||0],['句子',s.Sentence||0]].forEach(([l,v])=>{
    hero.innerHTML+=`<div class="stat"><div class="v">${v.toLocaleString()}</div><div class="l">${l}</div></div>`;
  });
  const tbl=document.getElementById('table-stats');
  let h='<thead><tr><th>类别</th><th>数量</th></tr></thead><tbody>';
  for(const[k,v]of Object.entries(s))h+=`<tr><td>${k}</td><td class="mono">${(v||0).toLocaleString()}</td></tr>`;
  tbl.innerHTML=h+'</tbody>';

  const eraData=stats.era_distribution||[];
  if(eraData.length&&typeof echarts!=='undefined'){
    const c1=echarts.init(document.getElementById('chart-era'));
    c1.setOption({tooltip:{trigger:'axis'},xAxis:{type:'category',data:eraData.map(d=>d.witness_era??d.commentator_historical_era??d.era),axisLabel:{rotate:45,color:'#94a3b8',fontSize:11}},yAxis:{type:'value',axisLabel:{color:'#94a3b8'}},series:[{type:'bar',data:eraData.map(d=>d.count),itemStyle:{color:'#d4a574'}}],grid:{left:40,right:20,bottom:80,top:20}});
    window.addEventListener('resize',()=>c1.resize());
  }
  const varData=stats.variant_distribution||[];
  if(varData.length&&typeof echarts!=='undefined'){
    const c2=echarts.init(document.getElementById('chart-variant'));
    c2.setOption({tooltip:{trigger:'item'},series:[{type:'pie',radius:['40%','70%'],data:varData.map(d=>({name:d.change_type,value:d.count})),label:{color:'#94a3b8',fontSize:12},itemStyle:{borderColor:'#0a0c10',borderWidth:2}}]});
    window.addEventListener('resize',()=>c2.resize());
  }

  allVersions=await fetchJSON('/api/versions');
  renderVersions(allVersions);
  allConcepts=await fetchJSON('/api/concepts');
  renderConcepts(allConcepts);
}

function renderVersions(data){
  const t=document.getElementById('table-versions');
  let h='<thead><tr><th>版本ID</th><th>标题</th><th>时代</th><th>类别</th></tr></thead><tbody>';
  data.forEach(v=>{h+=`<tr><td class="mono">${v.version_id||''}</td><td>${v.title||''}</td><td><span class="tag tag-era">${v.witness_era||''}</span></td><td>${v.category_tags||''}</td></tr>`;});
  t.innerHTML=h+'</tbody>';
}
function filterVersions(){const q=document.getElementById('ver-search').value.toLowerCase();renderVersions(allVersions.filter(v=>(v.title||'').toLowerCase().includes(q)||(v.version_id||'').toLowerCase().includes(q)));}

function renderConcepts(data){
  const t=document.getElementById('table-concepts');
  let h='<thead><tr><th>概念</th><th>类别</th><th>种子</th><th>定义</th></tr></thead><tbody>';
  data.forEach(c=>{h+=`<tr style="cursor:pointer" onclick="showConcept('${c.name}')"><td style="font-weight:600;color:var(--accent)">${c.name||''}</td><td>${c.category||''}</td><td>${c.is_seed?'<span class="tag tag-seed">种子</span>':''}</td><td>${(c.definition_core||c.description||'').substring(0,60)}</td></tr>`;});
  t.innerHTML=h+'</tbody>';
}
function filterConcepts(){const q=document.getElementById('concept-search').value.toLowerCase();renderConcepts(allConcepts.filter(c=>(c.name||'').includes(q)||(c.category||'').includes(q)));}

async function showConcept(name){
  const d=await fetchJSON('/api/concept/'+encodeURIComponent(name));
  const el=document.getElementById('concept-detail');
  el.style.display='block';
  const c=(d.concept||[])[0]||{};
  document.getElementById('cd-name').textContent='「'+(c.name||name)+'」';
  let body=`<p style="color:var(--dim);margin-bottom:12px"><strong>类别：</strong>${c.category||''} ${c.is_seed?'<span class="tag tag-seed">种子概念</span>':''}</p>`;
  if(c.definition_core)body+=`<p style="margin-bottom:16px;padding:12px;background:rgba(212,165,116,.05);border-left:3px solid var(--accent);border-radius:4px">${c.definition_core}</p>`;
  const glosses=d.glosses||[];
  body+=`<p style="color:var(--mute);font-size:12px;margin-bottom:8px">历代训解（${glosses.length} 条）</p>`;
  body+='<div style="max-height:400px;overflow-y:auto">';
  glosses.slice(0,50).forEach(g=>{body+=`<div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span class="tag tag-era">${g.commentator_historical_era||''}</span><strong style="color:var(--accent2)">${g.commentator||''}</strong><p style="color:var(--dim);font-size:13px;margin-top:4px">${(g.llm_interpretation||g.source_quote||'').substring(0,200)}</p></div>`;});
  body+='</div>';
  document.getElementById('cd-body').innerHTML=body;
  el.scrollIntoView({behavior:'smooth'});
}

async function loadVariants(){
  const ch=parseInt(document.getElementById('var-ch').value)||1;
  const data=await fetchJSON('/api/variants/'+ch);
  document.getElementById('var-summary').textContent=`第 ${ch} 章：${data.length} 条异文`;
  const t=document.getElementById('table-variants');
  let h='<thead><tr><th>位置</th><th>版本</th><th>类型</th><th>原文</th><th>异文</th></tr></thead><tbody>';
  data.slice(0,200).forEach(v=>{h+=`<tr><td>${v.position||''}</td><td class="mono">${v.version_b||''}</td><td>${v.change_type||''}</td><td>${v.old_text||''}</td><td style="color:var(--green)">${v.new_text||''}</td></tr>`;});
  t.innerHTML=h+'</tbody>';
}

async function searchCommentary(){
  const q=document.getElementById('com-q').value;
  const concept=document.getElementById('com-concept').value;
  let url='/api/commentary?';
  if(q)url+='q='+encodeURIComponent(q)+'&';
  if(concept)url+='concept='+encodeURIComponent(concept)+'&';
  const data=await fetchJSON(url);
  document.getElementById('com-count').textContent=`找到 ${data.length} 条训解`;
  const t=document.getElementById('table-commentary');
  let h='<thead><tr><th>时代</th><th>注家</th><th>概念</th><th>章节</th><th>训解内容</th></tr></thead><tbody>';
  data.slice(0,200).forEach(c=>{h+=`<tr><td><span class="tag tag-era">${c.commentator_historical_era||''}</span></td><td>${c.commentator_raw||''}</td><td style="color:var(--accent)">${c.concept_name||''}</td><td>${c.chapter_num||''}</td><td title="${(c.llm_interpretation||c.source_quote||'').replace(/"/g,'&quot;')}">${(c.llm_interpretation||c.source_quote||'').substring(0,100)}</td></tr>`;});
  t.innerHTML=h+'</tbody>';
}

function renderMD(text){
  if(!text)return '';
  let html=text.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
  const lines=html.split('\n');
  let out='',inList=false;
  for(const line of lines){
    if(line.startsWith('### ')){
      if(inList){out+='</ul>';inList=false;}
      out+='<h3>'+line.slice(4)+'</h3>';
    }else if(line.startsWith('## ')){
      if(inList){out+='</ul>';inList=false;}
      out+='<h2>'+line.slice(3)+'</h2>';
    }else if(line.startsWith('- ')){
      if(!inList){out+='<ul>';inList=true;}
      out+='<li>'+line.slice(2)+'</li>';
    }else if(line.trim()===''){
      if(inList){out+='</ul>';inList=false;}
      out+='';
    }else{
      if(inList){out+='</ul>';inList=false;}
      out+='<p>'+line+'</p>';
    }
  }
  if(inList)out+='</ul>';
  return out;
}

async function askQA(){
  const q=document.getElementById('qa-input').value.trim();
  if(!q)return;
  const el=document.getElementById('qa-result');
  el.style.display='block';
  el.innerHTML='<div style="color:var(--mute)">思考中...</div>';
  try{
    const r=await fetch(API+'/api/qa',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});
    const d=await r.json();
    // Meta chips
    let meta='<div class="qa-meta">';
    meta+=`<span class="meta-chip intent">意图：${d.intent||'unknown'}</span>`;
    if(d.entities&&Object.keys(d.entities).length){
      for(const[k,v]of Object.entries(d.entities)){
        meta+=`<span class="meta-chip">${k}: ${v}</span>`;
      }
    }
    meta+='</div>';
    // Markdown body
    let body='';
    if(d.answer_text){
      body=renderMD(d.answer_text);
    }else{
      body='<p style="color:var(--mute)">(无回答)</p>';
    }
    // Citations
    let cite='';
    if(d.citations&&d.citations.length){
      cite='<div class="qa-cite"><h4>引用 ('+d.citations.length+' 条)</h4><ol>';
      d.citations.slice(0,5).forEach(c=>{
        cite+=`<li>${c.source||''} | ${c.commentator||''} | 第${c.chapter||'?'}章</li>`;
      });
      cite+='</ol></div>';
    }
    el.innerHTML=meta+'<div>'+body+'</div>'+cite;
  }catch(e){el.innerHTML='<div style="color:#f87171">错误: '+e.message+'</div>';}
}


// ── FEATURE A: Collation ──
async function loadCollation(){
  const ch=parseInt(document.getElementById('col-ch').value)||1;
  document.getElementById('col-summary').textContent='加载中...';
  try{
    const d=await fetchJSON('/api/collation?ch='+ch);
    const sentences=d.sentences||[];
    const diffs=d.diffs||[];
    document.getElementById('col-summary').textContent=
      `第 ${ch} 章：跨版本 ${sentences.length} 句文本 · ${diffs.length} 条异文`;
    // Build a pivot: rows=seq, cols=version_id
    const seqs=[...new Set(sentences.map(s=>s.seq))].sort((a,b)=>a-b);
    const verMap={};
    sentences.forEach(s=>{
      const key=s.version_title?(s.version_title+' ('+s.version_id+')'):s.version_id;
      if(!verMap[key])verMap[key]={era:s.witness_era??s.era,cells:{}};
      verMap[key].cells[s.seq]=s.text;
    });
    const versions=Object.keys(verMap);
    // only show top 20 versions for readability
    const topV=versions.slice(0,30);
    let h='<thead><tr><th style="position:sticky;left:0;background:var(--card);z-index:2">序号</th>';
    topV.forEach(v=>h+=`<th style="min-width:120px;font-size:11px">${verMap[v].era?'<span class="tag tag-era">'+verMap[v].era+'</span> ':''}${v.substring(0,24)}</th>`);
    h+='</tr></thead><tbody>';
    seqs.forEach(seq=>{
      h+=`<tr><td style="position:sticky;left:0;background:var(--card);color:var(--accent2);font-weight:600">${seq}</td>`;
      topV.forEach(v=>{h+=`<td style="font-size:13px;white-space:nowrap">${verMap[v].cells[seq]||''}</td>`;});
      h+='</tr>';
    });
    h+='</tbody>';
    document.getElementById('table-sentences').innerHTML=h;
    // Diff table
    let dh='<thead><tr><th>位置</th><th>类型</th><th>操作</th><th>版本A</th><th>版本B</th><th>旧文</th><th>异文</th><th>置信度</th></tr></thead><tbody>';
    diffs.slice(0,300).forEach(d=>{
      const col=d.change_type==='词汇层'?'#d4a574':d.change_type==='句法层'?'#6cb6e4':'#94a3b8';
      dh+=`<tr><td>${d.position}</td><td style="color:${col}">${d.change_type||''}</td><td>${d.edit_op||''}</td><td class="mono" style="font-size:11px">${d.reference_text_id||d.version_a||''}</td><td class="mono" style="font-size:11px">${d.version_b||''}</td><td>${d.old_text||''}</td><td style="color:var(--green);font-weight:600">${d.new_text||''}</td><td>${(d.variant_detection_score??d.confidence??"")!==""?Number(d.variant_detection_score??d.confidence).toFixed(2):""}</td></tr>`;
    });
    dh+='</tbody>';
    document.getElementById('table-diffs').innerHTML=dh;
  }catch(e){document.getElementById('col-summary').textContent='错误: '+e.message;}
}

// ── FEATURE B: Chapter Views ──
async function loadViews(){
  const ch=parseInt(document.getElementById('vi-ch').value)||1;
  document.getElementById('vi-summary').textContent='加载中...';
  try{
    const d=await fetchJSON('/api/chapter_views?ch='+ch);
    const cms=d.commentaries||[];
    const conf=d.conflicts||[];
    document.getElementById('vi-summary').textContent=
      `第 ${ch} 章：${cms.length} 条注疏 · ${conf.length} 个争议概念`;
    // Conflicts
    let chT='<thead><tr><th>概念</th><th>注家数</th><th>异读数</th></tr></thead><tbody>';
    conf.forEach(c=>{
      chT+=`<tr><td style="color:var(--accent);font-weight:600">${c.concept}</td><td>${c.n_commentators}</td><td style="color:#f87171">${c.n_distinct_readings}</td></tr>`;
    });
    chT+='</tbody>';
    document.getElementById('table-conflicts').innerHTML=chT;
    // Group by concept
    const groups={};
    cms.forEach(c=>{
      const k=c.concept||'(未标注)';
      if(!groups[k])groups[k]=[];
      groups[k].push(c);
    });
    let gh='';
    Object.entries(groups).sort((a,b)=>b[1].length-a[1].length).forEach(([concept,items])=>{
      // detect conflict
      const readings=[...new Set(items.map(i=>i.interpretation).filter(Boolean))];
      const hasConflict=readings.length>=2;
      gh+=`<div style="margin-bottom:16px;padding:14px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:8px">`;
      gh+=`<h4 style="margin:0 0 10px;color:var(--accent);font-size:15px">「${concept}」 <span style="font-size:11px;color:var(--mute);font-weight:400">${items.length} 家注 · ${readings.length} 种解读</span>`;
      if(hasConflict)gh+=` <span class="tag" style="background:rgba(248,113,113,.15);color:#f87171;border:1px solid rgba(248,113,113,.3)">注家异读</span>`;
      gh+=`</h4>`;
      items.forEach(c=>{
        const rel=c.reliability==='A'?'#4ade80':c.reliability==='B'?'#d4a574':'#94a3b8';
        gh+=`<div style="padding:8px 0;border-bottom:1px dashed rgba(255,255,255,.06);font-size:13px;color:var(--dim)">
          <span class="tag tag-era">${c.commentator_historical_era||''}</span>
          <strong style="color:var(--accent2)">${c.commentator||''}</strong>
          <span style="margin-left:6px;color:${rel};font-size:11px">[${c.reliability||''}]</span>
          <p style="margin:4px 0 0;color:var(--text);line-height:1.7">${c.interpretation||''}</p>
        </div>`;
      });
      gh+='</div>';
    });
    document.getElementById('views-grouped').innerHTML=gh;
  }catch(e){document.getElementById('vi-summary').textContent='错误: '+e.message;}
}

// ── FEATURE C: Concept Graph ──
let cgChart=null;
function getCg(){
  if(!cgChart||cgChart.isDisposed()){
    if(typeof echarts==='undefined')return null;
    cgChart=echarts.init(document.getElementById('chart-concept-graph'));
    window.addEventListener('resize',()=>cgChart.resize());
  }
  return cgChart;
}
function seedCatColor(c,isSeed){
  if(c==='target')return '#f87171';
  if(isSeed)return '#d4a574';
  return '#94a3b8';
}
async function loadConceptGraph(){
  const name=document.getElementById('cg-name').value.trim()||'道';
  document.getElementById('cg-summary').textContent='加载中...';
  try{
    const d=await fetchJSON('/api/concept_graph?name='+encodeURIComponent(name));
    const nodes=(d.nodes||[]).map(n=>({
      name:n.name,
      symbolSize:n.category==='target'?55:Math.max(18,Math.min(42,Math.log2((n.weight||1)+1)*12)),
      itemStyle:{color:seedCatColor(n.category,n.is_seed)},
      label:{show:true,color:'#e2e8f0',fontSize:12,fontWeight:n.category==='target'?'bold':'normal'},
      category:n.category==='target'?'核心概念':(n.is_seed?'种子概念':'非种子'),
      value:n.weight||0,
    }));
    const edges=(d.edges||[]).map(e=>({
      source:e.source,target:e.target,
      lineStyle:{width:Math.max(1,Math.min(8,Math.log2(e.weight+1)*2)),opacity:.6,color:'#64748b'},
      label:{show:e.weight>=30,color:'#64748b',fontSize:10,formatter:e.weight.toString()},
    }));
    const chart=getCg();
    if(!chart){document.getElementById('cg-summary').textContent='ECharts 未加载';return;}
    chart.setOption({
      tooltip:{formatter:p=>{
        if(p.dataType==='node')return '<b>'+p.data.name+'</b><br>共现次数: '+(p.data.value||'—');
        return p.data.source+' ↔ '+p.data.target+'<br>共现 '+p.data.value+' 次';
      }},
      legend:[{data:['核心概念','种子概念','非种子'],textStyle:{color:'#94a3b8'}}],
      series:[{
        type:'graph',layout:'force',roam:true,
        force:{repulsion:180,gravity:.08,edgeLength:[40,110]},
        draggable:true,
        data:nodes,links:edges,
        categories:[{name:'核心概念'},{name:'种子概念'},{name:'非种子'}],
        emphasis:{focus:'adjacency',lineStyle:{width:4}},
      }],
    },true);
    document.getElementById('cg-summary').textContent=
      `「${name}」概念邻域：${nodes.length} 个节点 · ${edges.length} 条关联（基于 GLOSSES 注疏共现）`;
  }catch(e){document.getElementById('cg-summary').textContent='错误: '+e.message;}
}
async function loadGlobalGraph(){
  document.getElementById('cg-summary').textContent='加载中（seed 概念全局共现）...';
  try{
    const d=await fetchJSON('/api/concept_graph?seed=true');
    // Build node set from both endpoints
    const nodeMap={};
    d.forEach(e=>{
      if(!nodeMap[e.source])nodeMap[e.source]={name:e.source,edges:0};
      if(!nodeMap[e.target])nodeMap[e.target]={name:e.target,edges:0};
      nodeMap[e.source].edges++;nodeMap[e.target].edges++;
    });
    const topNodes=Object.values(nodeMap).sort((a,b)=>b.edges-a.edges).slice(0,60);
    const nameSet=new Set(topNodes.map(n=>n.name));
    const nodes=topNodes.map(n=>({
      name:n.name,
      symbolSize:Math.max(16,Math.min(50,Math.log2(n.edges+1)*11)),
      itemStyle:{color:'#d4a574'},
      label:{show:true,color:'#e2e8f0',fontSize:11},
      category:'种子概念',
      value:n.edges,
    }));
    const edges=d.filter(e=>nameSet.has(e.source)&&nameSet.has(e.target)).map(e=>({
      source:e.source,target:e.target,
      lineStyle:{width:Math.max(1,Math.min(8,Math.log2(e.weight+1)*2)),opacity:.5,color:'#64748b'},
      label:{show:e.weight>=50,color:'#64748b',fontSize:10,formatter:e.weight.toString()},
    }));
    const chart=getCg();
    if(!chart){document.getElementById('cg-summary').textContent='ECharts 未加载';return;}
    chart.setOption({
      tooltip:{formatter:p=>{
        if(p.dataType==='node')return '<b>'+p.data.name+'</b><br>关联数: '+p.data.value;
        return p.data.source+' ↔ '+p.data.target+'<br>共现 '+p.data.value+' 次';
      }},
      series:[{
        type:'graph',layout:'force',roam:true,
        force:{repulsion:150,gravity:.06,edgeLength:[30,90]},
        draggable:true,
        data:nodes,links:edges,
        emphasis:{focus:'adjacency',lineStyle:{width:4}},
      }],
    },true);
    document.getElementById('cg-summary').textContent=
      `全局 seed 概念网络：${nodes.length} 节点 · ${edges.length} 边（取前 60 高关联节点的子图）`;
  }catch(e){document.getElementById('cg-summary').textContent='错误: '+e.message;}
}

init();
</script>
</body>
</html>"""


def main():
    port = int(os.environ.get("PORT", 5000))
    server = HTTPServer(("127.0.0.1", port), Handler)
    print(f"  Dashboard running at http://127.0.0.1:{port}")
    print(f"  Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")
    finally:
        server.server_close()
        kg.close()


if __name__ == "__main__":
    main()
