"""LaoziKG — generate release metadata: data dictionary, file manifest,
dataset statistics and a SHA256 checksum file.

The dictionary is generated from the actual shipped tables (dtype, null count,
distinct count, sample values) and merged with curated per-column descriptions,
so it cannot drift out of sync with the data the way a hand-written one does.

Usage: python src/make_metadata.py --root . 
"""
import argparse
import csv
import datetime
import hashlib
import json
import os

import pandas as pd

# Curated descriptions. Columns not listed still appear in the dictionary with
# an empty description rather than being dropped.
DESCRIPTIONS = {
    ("versions.csv", "version_id"): "Primary key. Shidian Guji catalogue id, or a numeric string for items lacking one (see id_is_numeric_string).",
    ("versions.csv", "title"): "Title as printed in the source document header.",
    ("versions.csv", "author_raw"): "Unparsed author/annotator string, may list several people with roles.",
    ("versions.csv", "era"): "Dynastic period of the witness.",
    ("versions.csv", "edition"): "Edition/print-run description from the source header.",
    ("versions.csv", "category_tags"): "Bibliographic subject tags; sparsely populated (see docs/provenance.md).",
    ("versions.csv", "source_structural_unit_count"): "The source's OWN structural unit count (卷/節/章 headings) as recorded bibliographically. NOT the number of aligned Laozi chapters.",
    ("versions.csv", "aligned_laozi_chapter_count"): "Distinct canonical Laozi chapters (1-81) this witness was aligned to. Computed from chapter_instances.",
    ("versions.csv", "alignment_success_count"): "Chapter instances that resolved to a chapter number. Computed from chapter_instances.",
    ("versions.csv", "unresolved_unit_count"): "Chapter instances that did not resolve (chapter_num = -1). Computed from chapter_instances.",
    ("versions.csv", "lineage_branch"): "Heuristic textual-tradition grouping. Coarse; not a stemma.",
    ("versions.csv", "is_fragment"): "Whether the witness is a fragmentary manuscript.",
    ("versions.csv", "work_type"): "Document genre. LLM-assigned (MiniMax-M3), unreviewed. Enum: canonical_ddj, ddj_commentary, fragment, related_laozi_text, ritual_text, apocryphal_text, biography_text, manuscript_composite.",
    ("versions.csv", "textual_scope"): "Coverage of the Laozi. LLM-assigned, unreviewed. Enum: full_81, partial, single_unit, not_ddj.",
    ("versions.csv", "alignment_status"): "Computed (not LLM). Enum: aligned_full (>=75 chapters), aligned_partial, unaligned.",
    ("versions.csv", "unresolved_reason"): "Why unresolved units exist. Enum: not_applicable, expected_no_ddj_chapter_structure, possible_alignment_failure_review_needed.",
    ("versions.csv", "work_type_reviewed"): "FALSE for all rows: no human has reviewed the LLM genre assignment.",
    ("versions.csv", "id_is_numeric_string"): "TRUE where version_id is a 15+ digit numeric string that loses precision if imported as a number in Excel/Sheets. Read as text.",

    ("concepts.csv", "concept_id"): "Primary key.",
    ("concepts.csv", "name"): "Chinese term, phrase or proposition.",
    ("concepts.csv", "category"): "Original v1.0.0 free-text category. Retained for traceability; 29 unnormalized values. Prefer node_type.",
    ("concepts.csv", "subcategory"): "Original v1.0.0 free-text subcategory. Unnormalized.",
    ("concepts.csv", "definition_core"): "Short gloss of the term.",
    ("concepts.csv", "is_seed"): "TRUE for the 15 hand-authored seed concepts; FALSE for LLM-expanded entries.",
    ("concepts.csv", "node_type"): "Ontological stratum. LLM-assigned (MiniMax-M3), unreviewed. Concept subclasses (Ontological/Cosmological/Ethical/Political/Cultivation/Epistemic) are atomic terms; Proposition/Phrase/Metaphor/Practice are composite entries linked to atomic ones via concept_relations.csv.",
    ("concepts.csv", "node_type_source"): "Model or method that assigned node_type.",
    ("concepts.csv", "node_type_reviewed"): "FALSE for all rows: no human has reviewed the stratification.",
    ("concepts.csv", "is_textually_attested"): "FALSE where the name does not occur anywhere in the corpus (an analytic label rather than a quotation). See attestation_note.",
    ("concepts.csv", "attestation_note"): "For unattested entries, the closest attested wording and its chapter.",

    ("concept_chapter_mentions.csv", "mention_count"): "Total substring occurrences of the concept name in this chapter instance.",
    ("concept_chapter_mentions.csv", "sentence_count"): "Distinct sentences in this instance containing the name.",
    ("concept_chapter_mentions.csv", "name_length"): "Characters in the concept name; drives match_reliability.",
    ("concept_chapter_mentions.csv", "match_reliability"): "high (name >=3 chars, low ambiguity) / medium (2 chars) / low (1 char: also an ordinary function word or numeral, so raw counts overstate philosophical use). Filter on this rather than treating all concepts as equally identified.",

    ("commentary.csv", "commentary_id"): "Primary key.",
    ("commentary.csv", "concept_id"): "The single concept this record glosses.",
    ("commentary.csv", "reliability"): "A/B/C confidence carried over from extraction; refers to the gloss judgment, not to quote fidelity.",
    ("commentary.csv", "extraction_method"): "extraction_method \u2208 {llm_assisted_batch_v1, minimax-m3, direct_text_match}. Only direct_text_match records are not LLM-produced. Current distribution counts are reported in this tree's release-facts file (see metadata/) and in the column's own distinct_count below.",
    ("commentary.csv", "source_quote"): "Verbatim span of the historical commentator's text. Populated ONLY when text_provenance = verbatim_contiguous. Safe to cite.",
    ("commentary.csv", "normalized_quote"): "Punctuation-stripped, script-normalized form of source_quote.",
    ("commentary.csv", "llm_interpretation"): "Machine-generated text. Populated when the string is NOT a verbatim contiguous span. Must NOT be attributed to the historical commentator as a quotation.",
    ("commentary.csv", "text_provenance"): "text_provenance \u2208 {verbatim_contiguous, spliced_from_source, not_located}. spliced_from_source: all characters present in the source but non-contiguous, i.e. fragments joined by the model, usually without ellipsis. not_located: the quoted span was not found in the source. Only verbatim_contiguous records carry citable_as_quote = TRUE. Current distribution counts are reported in this tree's release-facts file (see metadata/) and in the column's own distinct_count below.",
    ("commentary.csv", "source_char_overlap"): "Fraction of characters present in the source document. 1.0 for verbatim; mean 0.995 for spliced; 0.2745–0.8958 (mean 0.7242) for not_located.",
    ("commentary.csv", "citable_as_quote"): "TRUE only for verbatim_contiguous. Use this as the gate before quoting.",
    ("commentary.csv", "source_match_scope"): "Which source text was searched: instance, version, or wangbi_exegesis_source.",

    ("evidence.parquet", "quote_kind"): "attested_source_quote / llm_spliced_excerpt / llm_paraphrase_unlocated. Mirrors commentary.text_provenance.",
    ("evidence.parquet", "quote_is_verbatim"): "TRUE only where the quote is a verbatim contiguous source span.",

    ("candidate_scholarly_claims.csv", "claim_status"): "AI_GENERATED_UNVERIFIED for every row. These are machine-generated summaries of scholarly debates, NOT peer-reviewed positions.",
    ("candidate_scholarly_claims.csv", "citable_as_scholarship"): "FALSE for every row.",
    ("candidate_scholarly_claims.csv", "review_required"): "TRUE for every row: expert review is outstanding.",
    ("candidate_scholarly_claims.csv", "usage_restriction"): "Explicit statement of what the record may and may not be used for.",
    ("candidate_scholarly_claims.csv", "proponents"): "Scholars named by the model as holding the position. NOT verified against the literature.",
    ("candidate_scholarly_claims.csv", "opponents"): "Scholars named by the model as opposing. NOT verified against the literature.",

    ("authorship_edges.csv", "edge_type"): "authored or annotated (lowercase vocabulary).",
    ("authorship_edges.csv", "attribution_status"): "named (138) / attested_anonymous (34: source records 佚名/未知) / unrecorded (20: attribution not yet researched). Lets queries distinguish real anonymity from a data gap.",
    ("authorship_edges.csv", "is_attributed"): "TRUE where the source itself attributes the work to a person who may not be the actual author (託名/傳).",

    ("concept_relations.csv", "relation_type"): "EXPRESSES / REALIZES / SYMBOLIZES, linking a composite entry to an atomic concept.",
    ("concept_relations.csv", "source"): "deterministic_name_containment (32, exactly reproducible) or minimax-m3 (35, LLM semantic judgment).",
    ("concept_relations.csv", "reviewed"): "FALSE for all rows.",

    ("concept_canonical_chapters.csv", "relation"): "CANONICAL_LOCUS: a chapter the concept is editorially associated with.",
    ("concept_canonical_chapters.csv", "evidence"): "Origin of the association.",

    ("variants.parquet", "change_type"): "Layer of variation: 字形层 (graphic) / 词汇层 (lexical) / 句法层 (syntactic).",
    ("variants.parquet", "_retired_confidence"): "Calibrated by candidate/reference length ratio; low where the witness is a commentary edition and scripture is interleaved with prose.",
    ("variants.parquet", "semantic_explanation"): "Scholarly gloss, LLM-generated for 8 well-known character pairs only; empty for most rows.",
    ("variants.parquet", "scholar_validation"): "Empty: awaiting expert input.",
    ("variants.parquet", "manual_status"): "unreviewed for all rows.",

    ("chapter_instances.parquet", "chapter_num"): "Canonical Laozi chapter 1-81, or -1 where the unit could not be aligned.",
    ("chapter_instances.parquet", "segmentation_score"): "Uncalibrated heuristic score from the v1.0.0 segmenter (heading match / content-anchor coverage). NOT a probability of correct alignment. Empty for units produced by v1.1.2 recovery (they carry anchor_coverage_score or identification_score instead) and for unaligned units. Was named `confidence` up to v1.1.2-rc3.",
    ("chapter_instances.parquet", "segmentation_method"): "How the chapter boundary was found: heading, fuzzy_content, or none.",
    ("chapter_instances.parquet", "is_chapter_aligned"): "chapter_num != -1.",
    ("chapter_instances.parquet", "analysis_default_include"): "FALSE for every unaligned unit and every auto-recovered instance awaiting review; exclude them from chapter-level analysis by default. Current distribution counts are reported in this tree's release-facts file (see metadata/) and in the column's own distinct_count below.",
}

TABLE_PURPOSE = {
    "versions.csv": "One row per textual witness.",
    "persons.csv": "Canonical persons plus ANONYMOUS/UNKNOWN placeholders.",
    "authorship_edges.csv": "Version-to-person authorship/annotation edges.",
    "concepts.csv": "Stratified concept ontology.",
    "concept_canonical_chapters.csv": "Concept-to-chapter editorial loci, normalized from the former canonical_chapters string column.",
    "concept_relations.csv": "Typed edges from composite entries to atomic concepts.",
    "concept_chapter_mentions.csv": "Concept occurrences aggregated per chapter instance, covering all textually attested concepts (the 2 with is_textually_attested=FALSE have no matches).",
    "concept_sentence_mentions.parquet": "Sentence-level mention evidence backing the aggregates.",
    "chapter_instances.parquet": "One row per chapter-like unit found in a witness.",
    "sentences.parquet": "Sentence-segmented text of every witness.",
    "variants.parquet": "Character-level variants against the Wang Bi reference.",
    "commentary.csv": "Concept glosses drawn from commentaries, with quote provenance separated.",
    "commentary_concept_links.csv": "Commentary-to-concept edges, self-consistent.",
    "evidence.parquet": "Evidence records backing each commentary gloss.",
    "provenance_assertions.csv": "Mediated version-relationship assertions.",
    "version_provenance_edges.csv": "Legacy direct version-relationship edges, superseded by provenance_assertions.",
    "candidate_scholarly_claims.csv": "AI-generated scholarly debate summaries. UNVERIFIED.",
    "candidate_scholarly_claim_evidence.csv": "Pro/con evidence for the candidate claims. UNVERIFIED.",
    "wangbi_exegesis_source.parquet": "Source text of the Wang Bi 通释 exegesis that the WANGBI_TONGSHI_2026 commentary records were extracted from. Absent from v1.0.0, which made those records unverifiable.",
}



# ---- v1.1.1 additions: fields the second-round audit found underspecified ----
DESCRIPTIONS.update({
    ("versions.csv", "witness_era"): "Era of THIS witness/edition as the bibliographic record claims it. NOT the era of the author — see persons.csv.person_historical_era. Unreliable per row: the vocabulary contains both 南朝宋 and 南宋, and the 南朝宋 group mixes Liu Song (顧歡, correct) with Southern Song (范應元, wrong). Retained unmodified as the source's own claim.",
    ("versions.csv", "resource_class"): "historical_source_witness or modern_derived_resource (1, WANGBI_TONGSHI_2026, a 2026 compilation). Enum.",
    ("versions.csv", "is_source_witness"): "TRUE for the 175 historical witnesses; FALSE for the modern derived resource. Filter on this for any statement about the historical corpus.",
    ("versions.csv", "work_type_source"): "Model or method that assigned work_type. 'minimax-m3' for all 176 rows: LLM-assigned, never expert-validated (see work_type_reviewed).",
    ("versions.csv", "source_structural_unit_count"): "The source's OWN count of structural units (卷/節/章 headings) as recorded bibliographically. NOT the number of aligned Laozi chapters — 老子義疏 has 213 structural units but 14 aligned chapters. This conflation was the v1.0.0 defect.",
    ("versions.csv", "unresolved_reason"): "Why unresolved chapter units exist. Enum: not_applicable; expected_no_ddj_chapter_structure (genre has no chapter structure); confirmed_alignment_failure_recovery_pending (canonical text verified present, recovery not applied); commentary_only_no_base_text_to_align; catalogue_mismatch_expert_review_required. See data/alignment_failure_diagnosis.csv.",

    ("persons.csv", "canonical_name"): "Canonical form of the person's name, with role tokens (註/校定/勘/編) and attribution prefixes (題) removed. All surface forms are in person_aliases.csv.",
    ("persons.csv", "entity_status"): "canonical (a real historical figure) or placeholder (ANONYMOUS = source attests anonymity; UNKNOWN = attribution not researched).",
    ("persons.csv", "person_historical_era"): "The era the FIGURE lived in. In v1.1.0 this field was named `era` and was wrongly inherited from the linked witness's era (matching it on 58.9% of edges), producing 老子=宋 and 庄子=清. Assigned by MiniMax-M3, cross-checked against a 37-figure reference set (81% agreement). Never expert-reviewed.",
    ("persons.csv", "person_historical_era_alt"): "The competing era value where sources disagree; populated only when era_disputed=TRUE.",
    ("persons.csv", "era_confidence"): "high (reference-confirmed) / disputed / the model's own high|medium|low / placeholder.",
    ("persons.csv", "era_disputed"): "TRUE for the 7 figures where the reference set and the model disagree; 5 are dynastic-transition figures whose lifespans straddle two dynasties.",

    ("person_aliases.csv", "alias_type"): "canonical | variant (orthographic, e.g. 焦竑/焦竤) | role_form (name with a role token, e.g. 王弼註) | attributed_form (e.g. 題河上公).",

    ("commentary.csv", "commentary_witness_era"): "Era of the EDITION the gloss was drawn from. Named `era` in v1.1.0, where it was ambiguous.",
    ("commentary.csv", "commentator_historical_era"): "Era of the COMMENTATOR, resolved via person_aliases. Empty where the commentator string resolves to no person.",
    ("commentary.csv", "commentator_person_id"): "Canonical person_id of the commentator; null where commentator_raw could not be resolved.",
    ("commentary.csv", "source_match_scope"): "Which source text the quote was verified against: 'instance' (this chapter instance's text), 'version' (the whole witness), or 'wangbi_exegesis_source' (the separate exegesis document). Determines how strong the verification is.",
    ("commentary.csv", "reliability"): "A/B/C grade on the GLOSS JUDGMENT (how confidently the commentator's text bears on the concept). It says nothing about quote fidelity — that is text_provenance/citable_as_quote.",

    ("concept_chapter_mentions.csv", "match_specificity"): "Renamed from match_reliability in v1.1.1: the grading derives from concept-name LENGTH and match specificity, NOT from measured precision, and 'reliability' invited the wrong reading. high = name >=3 chars; medium = 2 chars; low = 1 char (also an ordinary word/numeral). 82.24% of raw mentions are 'low'. No precision has been empirically measured.",

    ("concept_mention_statistics.csv", "raw_lexical_mentions"): "Total substring occurrences across witness text. Dominated by single-character names; do NOT report as concept prevalence.",
    ("concept_mention_statistics.csv", "high_specificity_mentions"): "Occurrences restricted to concept names of >=2 characters. Gives an almost disjoint top-8 ranking from the raw counts — report both.",
    ("concept_mention_statistics.csv", "single_char_share"): "Fraction of this concept's raw mentions arising from single-character matching.",

    ("chapter_instances.parquet", "base_text_share_upper_bound"): "Estimated fraction of this instance's text that is Laozi base scripture (canonical chapter length / instance length, capped at 1.0). Median 0.237 across aligned instances: most witnesses are mostly commentary.",
    ("chapter_instances.parquet", "text_composition"): "Band over base_text_share_upper_bound: scripture_dominant (>=0.5), mixed (>=0.15), commentary_dominant (<0.15), unknown (unaligned). Band counts in release_facts.json.",
    ("chapter_instances.parquet", "analysis_default_include"): "FALSE for every unaligned unit. Those units' mentions are additionally moved out to concept_unaligned_mentions.csv, so exclusion is structural, not advisory.",

    ("source_rights.csv", "original_text_public_domain"): "yes_by_age for pre-modern works; 'no' for the modern derived resource. A statement about the WORK, not about the digitization.",
    ("source_rights.csv", "digitization_rights"): "Rights in the digitized transcription, which are separate from the age of the underlying work. 'not_determined' for every row.",
    ("source_rights.csv", "redistribution_status"): "redistribution_status \u2208 {not_reviewed, cleared}. Only a human with the provider's terms in hand can set cleared; inference never does. Current counts are in this tree's release-facts file. Cannot be determined from inside the dataset — requires each provider's terms plus institutional sign-off.",
    ("source_rights.csv", "digital_source_provider"): "Repository the transcription came from, INFERRED from the catalogue-id prefix. 34 rows are 'Unidentified — requires manual determination'.",

    ("alignment_failure_diagnosis.csv", "diagnosis"): "genuine_alignment_failure (canonical chapter text verified present but unaligned) | no_base_text_commentary_only | probable_catalogue_or_composite_mismatch.",
    ("alignment_failure_diagnosis.csv", "resolution_applied"): "TRUE for the witnesses re-segmented in v1.1.2 (recovery applied but expert-unreviewed; instances gated by alignment_review_status); FALSE for those left to expert review.",
})

TABLE_PURPOSE.update({
    "expert_validation/frame_commentary.csv": "TV4 sampling frame: proportional-stratified commentary records for concept-correctness and gloss-faithfulness adjudication.",
    "expert_validation/frame_commentary_strata.csv": "Per-stratum allocation of the commentary frame.",
    "expert_validation/frame_mentions.csv": "TV3 sampling frame: 250 concept mentions per specificity tier, with the containing sentence.",
    "expert_validation/frame_variants.csv": "TV5 sampling frame: 100 candidate variant events per detection-score bin.",
    "expert_validation/frame_variants_strata.csv": "Per-bin allocation of the variant frame, with the population needed for any reweighting.",
    "expert_validation/frame_work_type.csv": "TV6 full-population frame for work_type and textual_scope labels.",
    "expert_validation/frame_node_type.csv": "TV6 full-population frame for concept node_type labels.",
    "expert_validation/frame_concept_relations.csv": "TV6 full-population frame for typed concept relations.",
    "expert_validation/frame_person_eras.csv": "TV6 full-population frame for person historical eras.",
    "expert_validation/frame_alignment_diagnosis.csv": "TV2 full-population frame for the diagnosed alignment failures and their recoveries.",
    "expert_validation/S06453_review_dossier.csv": "Per-segment review sheet for the S06453 colophon recovery.",
    "expert_validation/S06453_residual_sentences.csv": "Sentences left unassigned by the S06453 recovery (scroll apparatus).",
    "derived_diagnostics/structural_mismatches.parquet": "Generation-stage diagnostic events sharing the variant schema: diff spans too long to be character-level variants (commentary bleed / misalignment candidates). NOT a canonical data layer.",
    "derived_unverified/candidate_scholarly_claims.csv": "AI-generated scholarly debate summaries. UNVERIFIED; not citable as scholarship.",
    "derived_unverified/candidate_scholarly_claim_evidence.csv": "Pro/con evidence for the candidate claims. UNVERIFIED.",
    "person_aliases.csv": "Every surface form of each person (canonical, orthographic variant, role form, attributed form).",
    "concept_unaligned_mentions.csv": "Mentions from unaligned chapter units, split out of the default statistics.",
    "concept_mention_statistics.csv": "Per-concept two-tier mention aggregates: raw lexical vs high-specificity.",
    "source_rights.csv": "Per-resource redistribution-rights ledger; publication of the full package is gated on it. Current cleared/not_reviewed counts are in this tree's release-facts file.",
    "alignment_failure_diagnosis.csv": "Per-witness diagnosis of the 7 flagged alignment failures, with evidence.",
})

# ---- v1.1.2 additions ----
DESCRIPTIONS.update({
    ("versions.csv", "witness_era_raw"): "The bibliographic record's own era string, verbatim. Not analysis-safe.",
    ("versions.csv", "witness_era_normalized"): "Orthographic normalization only (traditional->simplified; 其他->不详). Genuinely ambiguous labels are NOT resolved — see witness_era_ambiguous.",
    ("versions.csv", "witness_era_normalization_source"): "Method tag for the normalization (orthographic_only_v1.1.2).",
    ("versions.csv", "witness_era_ambiguous"): "TRUE where the label spans two dynasties in the source records (南朝宋 = Liu Song or Southern Song; 南北朝; 春秋战国).",
    ("versions.csv", "witness_era_reviewed"): "Always FALSE: no expert has reviewed witness eras.",
    ("persons.csv", "era_reference_dates"): "Dates used in the compiler cross-check, where the figure was in the 37-person reference set; empty otherwise.",
    ("persons.csv", "era_reference_source"): "Provenance of the cross-check: compiler-curated standard biographical dates; NO external authority (e.g. CBDB) link yet.",
    ("commentary.csv", "gloss_generated_by"): "Generator of the gloss: platform-utility-llm-haiku-class / minimax-m3 / deterministic_text_match.",
    ("commentary.csv", "gloss_reviewed"): "Always FALSE: no gloss has been expert-reviewed.",
    ("commentary.csv", "gloss_review_status"): "unreviewed on every row until a review is recorded.",
    ("commentary.csv", "gloss_reviewer"): "Empty until a review is recorded.",
    ("variants.parquet", "reference_text_id"): "Reference text the event was detected against. WANGBI_CANONICAL = the jingwen layer of WANGBI_TONGSHI_2026 (wangbi_exegesis_source.parquet), not a Version row. Was version_a.",
    ("variants.parquet", "reference_version_id"): "Version whose base-text layer is the reference (WANGBI_TONGSHI_2026).",
    ("variants.parquet", "variant_detection_score"): "6-level heuristic score from the v1.0.0 detector (0.15–0.85). Not a probability; not validated. Was confidence.",
    ("variants.parquet", "variant_status"): "candidate_auto_detected on every row: these are candidate variant events, not confirmed 异文.",
    ("variants.parquet", "detection_method"): "difflib_char_diff_v1.0.0 — generation-stage output carried forward.",
    ("variants.parquet", "explanation_source"): "minimax-m3_per_character_pair where semantic_explanation is populated (7 explanations over 544 rows); empty otherwise.",
    ("chapter_instances.parquet", "base_text_share_upper_bound"): "canonical chapter length / instance length, capped at 1. UPPER BOUND on the base-scripture share (assumes the whole canonical chapter is present; cannot see quoted scripture in commentary). Both sides script-normalized and punctuation-stripped. Was base_text_share_est.",
    ("chapter_instances.parquet", "text_composition"): "Band over the upper bound: scripture_dominant >=0.5, mixed >=0.15, commentary_dominant <0.15, unknown (unaligned or no sentences).",
    ("chapter_instances.parquet", "segmentation_method"): "How the unit was delimited. anchor_recovery_v1.1.2 / colophon_recovery_v1.1.2(_merged_split) mark instances recovered in v1.1.2 (recovery_reviewed = FALSE in alignment_recovery_report.csv).",
    ("sentences.parquet", "sentence_id"): "Stable id. Suffix -a/-b marks the two halves of a sentence split at a scribal colophon during v1.1.2 recovery; the original id is the prefix.",
    ("concept_sentence_unaligned_mentions.parquet", "chapter_num"): "Always -1: sentence-level mentions from unaligned units, held separately from concept_sentence_mentions.parquet.",
    ("source_rights.csv", "provider_inference_basis"): "What the provider inference rests on (id prefix / shelfmark in title / edition field). An inference, not a rights determination.",
    ("source_rights.csv", "provider_inference_confidence"): "high / medium / low. low = only the id series could be characterized; the holder is not confirmed.",
    ("alignment_recovery_report.csv", "chapters_recovered_in_manuscript_order"): "Chapter sequence as it occurs in the witness. S06453 is non-standard (8-36, 57-69, 37-56, 70-81).",
    ("alignment_recovery_report.csv", "count_check_within_2"): "Colophon mode only: segments whose scribal character count matches the actual count within ±2.",
    ("alignment_recovery_report.csv", "recovery_reviewed"): "Always FALSE: recovery is machine output awaiting a Dunhuang specialist.",
    ("alignment_failure_diagnosis.csv", "resolution_applied"): "TRUE for the 5 witnesses re-segmented in v1.1.2; FALSE for the 2 left to expert review.",
    ("alignment_failure_diagnosis.csv", "resolution_method"): "anchor_recovery_v1.1.2 / colophon_recovery_v1.1.2 / empty.",
})

# ---- columns shared across tables: one definition, applied wherever the
# (table, column) pair has no more specific entry ----
COMMON_COLUMNS = {
    "version_id": "Catalogue id of the textual resource (FK -> versions.csv). Numeric-string ids are 识典古籍 record ids; DZ/ZHXDZ/ZWDS/SK/SBCK/HY/CADAL/PC/S prefixes name the series.",
    "instance_id": "Chapter-instance id, <version_id>-CH<nnn> or <version_id>-UNSEG (FK -> chapter_instances.parquet).",
    "chapter_num": "Laozi chapter 1-81 in Wang Bi numbering; -1 = unit not aligned to a chapter.",
    "concept_id": "Concept slug (FK -> concepts.csv).",
    "concept_name": "Concept surface name at the time of extraction (denormalized from concepts.csv for readability).",
    "person_id": "Canonical person id (FK -> persons.csv); ANONYMOUS / UNKNOWN are placeholders.",
    "sentence_id": "Sentence id, <instance_id>-S<nnnn>; suffix -a/-b marks halves of a sentence split at a scribal colophon in v1.1.2 recovery.",
    "commentary_id": "Commentary gloss id (FK -> commentary.csv).",
    "variant_id": "Candidate variant event id.",
    "name_length": "Character length of the matched concept name; drives match_specificity (>=3 high, 2 medium, 1 low).",
    "match_specificity": "Length-derived specificity grade of the lexical match (high / medium / low). NOT measured precision.",
    "mention_count": "Number of raw substring occurrences of the concept name in the unit (chapter instance or sentence).",
    "sentence_count": "Number of distinct sentences of the chapter instance containing the concept name.",
    "version_b": "Witness id the candidate variant was observed in (FK -> versions.csv).",
    "position": "Character offset of the event in the script-normalized, punctuation-stripped reference chapter text.",
    "edit_op": "difflib opcode: replace / insert / delete.",
    "old_text": "Reference (Wang Bi base-text) characters at the event; empty for insertions.",
    "new_text": "Witness characters at the event; empty for deletions.",
    "length_ratio": "len(witness chapter text) / len(reference chapter text); >1 indicates interleaved commentary.",
    "change_type": "Heuristic layer label: 字形层 (graphic/phonetic-loan) / 词汇层 (lexical) / 句法层 (syntactic). Unreviewed.",
    "semantic_explanation": "LLM (MiniMax-M3) explanation attached per character pair; empty for most rows. Unreviewed.",
    "scholar_validation": "Empty on every row: no philological validation recorded.",
    "manual_status": "Empty on every row: no manual review recorded.",
    "variant_status": "candidate_auto_detected (variants) or structural_mismatch_diagnostic (structural_mismatches). Never 'confirmed'.",
    "detection_method": "difflib_char_diff_v1.0.0: generation-stage detector carried forward.",
    "reference_text_id": "WANGBI_CANONICAL = the jingwen layer of WANGBI_TONGSHI_2026 (wangbi_exegesis_source.parquet), not a Version row. Was version_a.",
    "reference_version_id": "Version whose base-text layer served as reference (WANGBI_TONGSHI_2026).",
    "variant_detection_score": "6-level heuristic score from the v1.0.0 detector; not a probability. Was confidence.",
    "explanation_source": "minimax-m3_per_character_pair where semantic_explanation is populated; empty otherwise.",
    "evidence": "Free-text evidence or basis supporting the row's claim, as recorded by the producing step.",
    "note": "Free-text note from the producing step.",
    "notes": "Free-text notes from the producing step.",
    "method": "Method tag of the producing step (e.g. anchor_recovery_v1.1.2, colophon_recovery_v1.1.2).",
    "title": "Title of the textual resource as catalogued.",
    "body_chars": "Characters of witness body text after script normalization and punctuation stripping.",
    "expert_reviewed": "Always FALSE until a domain expert records a review.",
    "resolution_version": "Release in which the automatic resolution was applied (1.1.2), empty if none.",
    "source_filename": "Filename of the source DOCX used at construction (not redistributed).",
    "is_seed": "TRUE for the compiler-authored seed concepts; FALSE for LLM-expanded rows.",
    "category": "Free-text category as originally assigned; 29 unnormalized raw values (legacy). Prefer node_type.",
    "name": "Concept surface name.",
    "reliability": "A/B/C grade assigned at extraction to the gloss judgment; not a measure of quote fidelity (see text_provenance).",
    "role_raw": "Role token as written in the source author string (撰/注/疏/校/輯 ...).",
    "seq": "Sentence order within its chapter instance (0-based).",
    "original_text": "Sentence text as transmitted (traditional/variant characters, lacuna marks □ kept).",
    "normalized_text": "Sentence text after light normalization used for matching; script may still be traditional.",
    "raw_heading": "Heading or opening text under which the unit was segmented (colophon:... for colophon-recovered units).",
    "char_count": "Characters in the unit after normalization.",
    "order_in_doc": "Position of the unit in the witness (0-based); -1 for residual UNSEG units.",
    "alignment_review_status": "original_deterministic / auto_recovered_unreviewed / expert_confirmed / expert_corrected / not_aligned. Drives analysis_default_include.",
    "anchor_coverage_score": "Anchor-recovery instances only: matched canonical clauses / canonical clauses. A coverage ratio, not a probability.",
    "identification_score": "Colophon-recovery instances only: fuzz.ratio(canonical chapter, segment)/100. String similarity, not a probability.",
    "variant_detection_eligible": "TRUE for aligned instances (a variant detector could run).",
    "variant_detection_run": "TRUE only where the v1.0.0 detector actually ran (original instances). FALSE for recovered and unaligned units: do not compute variant density there.",
    "concept_generated_by": "compiler_hand_authored (seed rows) or minimax-m3 (expanded rows) — provenance of name/category.",
    "concept_reviewed": "Always FALSE: no concept row has been expert-reviewed.",
    "definition_generated_by": "Provenance of definition_core (same as concept_generated_by).",
    "definition_reviewed": "Always FALSE.",
    "textual_scope_source": "minimax-m3: assigned in the same LLM batch as work_type.",
    "textual_scope_reviewed": "Always FALSE.",
    "era_source": "reference_crosschecked (figure in the compiler reference set) or minimax-m3.",
    "era_reviewed": "Always FALSE.",
    "person_era_dates": "Lifetime dates where the LLM or the reference set supplied them; empty otherwise.",
    "alias": "Surface form (canonical name, variant, role form, attributed form, or parse artefact).",
    "source_title": "Title of the resource (mirror of versions.title).",
    "witness_era": "Era of this witness/edition (normalized form).",
    "edition": "Edition statement from the catalogue record.",
    "resource_class": "historical_source_witness or modern_derived_resource.",
    "license": "Licence determined for redistribution; 'undetermined' until reviewed.",
    "reviewer": "Person who performed the rights review for this row; empty until reviewed.",
    "review_date": "Date of the rights review; empty until reviewed.",
}

DESCRIPTIONS.update({
    ("concept_relations.csv", "relation_category"): "Taxonomy over the existing relation types: lexical_semantic (A's name deterministically contains B's core term — a lexical fact), semantic (asserted conceptual expression), realization (A enacted through B), symbolic (figurative standing-for). Derived from relation_type; no edge was created for it.",
    ("concept_relations.csv", "relation_category_source"): "deterministic_mapping_from_relation_type on every row.",
    ("derived_unverified/candidate_scholarly_claims.csv", "sc_id"): "Candidate-claim id.",
    ("derived_unverified/candidate_scholarly_claims.csv", "claim_text"): "LLM-generated summary of a purported scholarly position. UNVERIFIED: not checked against any publication.",
    ("derived_unverified/candidate_scholarly_claims.csv", "domain"): "Debate area the claim belongs to (作者 / 成书年代 / 版本关系 / 篇序 / 字句).",
    ("derived_unverified/candidate_scholarly_claims.csv", "scholarly_consensus"): "LLM's assertion about the state of consensus. UNVERIFIED and not a measurement.",
    ("derived_unverified/candidate_scholarly_claims.csv", "confidence"): "LLM's own confidence tag. Not a calibrated probability and not evidence.",
    ("derived_unverified/candidate_scholarly_claims.csv", "related_versions"): "Semicolon-joined version_ids the claim mentions.",
    ("derived_unverified/candidate_scholarly_claims.csv", "generated_by"): "Model that produced the row (minimax-m3).",
    ("derived_unverified/candidate_scholarly_claims.csv", "verified_by"): "Empty on every row: nobody has verified these.",
    ("derived_unverified/candidate_scholarly_claims.csv", "verified_date"): "Empty on every row.",
    ("derived_unverified/candidate_scholarly_claim_evidence.csv", "sc_id"): "Claim this evidence row belongs to.",
    ("derived_unverified/candidate_scholarly_claim_evidence.csv", "evidence_id"): "Evidence row id.",
    ("derived_unverified/candidate_scholarly_claim_evidence.csv", "side"): "pro / con relative to the claim.",
    ("derived_unverified/candidate_scholarly_claim_evidence.csv", "evidence_text"): "LLM-generated argument text. UNVERIFIED: named proponents and citations are unchecked.",
    ("derived_unverified/candidate_scholarly_claim_evidence.csv", "claim_status"): "AI_GENERATED_UNVERIFIED on every row.",
    ("source_rights.csv", "ocr_rights"): "LAYER C — rights in the transcription/OCR/collation labour embodied in the text actually ingested. not_determined for every source witness: it depends on the provider's terms, which are not in this package.",
    ("source_rights.csv", "redistribution_allowed"): "Conclusion following from layers A+B+C. 'unknown' on every source witness; 'authors_own_work' only for the modern derived resource. NOT a permission grant.",
    ("source_rights.csv", "license_basis"): "The reasoning that would justify a licence for this row. 'not_established' until layers B and C are determined.",
    ("alignment_failure_diagnosis.csv", "declared_work_type"): "work_type label at diagnosis time.",
    ("alignment_failure_diagnosis.csv", "declared_textual_scope"): "textual_scope label at diagnosis time.",
    ("alignment_failure_diagnosis.csv", "canonical_openers_exact"): "Number of the 81 canonical chapter openers found as exact substrings in the witness body.",
    ("alignment_failure_diagnosis.csv", "diagnosis_confidence"): "high / medium / low, compiler judgment from the opener test.",
    ("alignment_recovery_report.csv", "sentences"): "Sentence rows of the witness after recovery (splits included).",
    ("alignment_recovery_report.csv", "chapters_detected"): "Anchor mode: candidate chapters with enough clause hits; colophon mode: segments cut.",
    ("alignment_recovery_report.csv", "chapters_kept"): "Chapter instances written after filtering / identification.",
    ("alignment_recovery_report.csv", "false_anchors_dropped"): "Anchor mode: chapters dropped by the neighbour-consistency rule (semicolon list).",
    ("alignment_recovery_report.csv", "standard_order"): "TRUE if recovered chapters run in ascending canonical order.",
    ("alignment_recovery_report.csv", "chars_aligned"): "Characters placed in chapter instances.",
    ("alignment_recovery_report.csv", "chars_residual_unaligned"): "Characters left in the -UNSEG residual.",
    ("alignment_recovery_report.csv", "mean_identification_score"): "Colophon mode only: mean identification_score.",
    ("alignment_recovery_report.csv", "mean_anchor_coverage_score"): "Anchor mode only: mean anchor_coverage_score.",
    ("alignment_recovery_report.csv", "colophons"): "Colophon mode: scribal character-count colophons found.",
    ("alignment_recovery_report.csv", "segments_unidentified"): "Colophon mode: segments below IDENT_MIN or already-used chapter (left in residual).",
    ("alignment_recovery_report.csv", "count_check_median_abs_delta"): "Colophon mode: median |stated - actual| character count.",
    ("alignment_recovery_report.csv", "sentences_split_at_colophon"): "Sentence rows created by splitting at a colophon (-a/-b ids).",
    ("alignment_recovery_segments_S06453.csv", "segment_order"): "Segment position in the scroll (0-based).",
    ("alignment_recovery_segments_S06453.csv", "stated_count"): "Character count written by the scribe in the colophon (Chinese numerals parsed); empty if none.",
    ("alignment_recovery_segments_S06453.csv", "actual_count"): "Characters actually present in the segment (lacunae □ counted, punctuation not).",
    ("alignment_recovery_segments_S06453.csv", "count_delta"): "actual_count - stated_count.",
    ("alignment_recovery_segments_S06453.csv", "identified_chapter"): "Chapter assigned by best fuzz.ratio (>= 45 and unused); -1 if none; 'a+b' for a merged segment split.",
    ("alignment_recovery_segments_S06453.csv", "ident_score"): "fuzz.ratio of best canonical chapter vs segment (0-100).",
    ("alignment_recovery_segments_S06453.csv", "runner_up_score"): "Second-best chapter score; a large gap supports the identification.",
    ("alignment_recovery_segments_S06453.csv", "chars"): "Segment characters after punctuation stripping.",
    ("candidate_concepts_oov.csv", "concept_id"): "Slug of a concept proposed by extraction but not adopted into concepts.csv.",
    ("commentary.csv", "commentator_raw"): "Commentator string as recorded in the source (before alias resolution).",
    ("concept_canonical_chapters.csv", "chapter_num"): "Chapter the compilers regard as a canonical locus of the concept (editorial, unreviewed).",
    ("concept_mention_statistics.csv", "mentions_per_10k_chars"): "Raw occurrences per 10,000 searched characters of the default analysis set. A monotone rescaling of raw_lexical_mentions (one shared denominator), so it reproduces the raw ranking; use it to compare against corpora of different size, NOT to correct the name-length artefact — the specificity split does that.",
    ("concept_mention_statistics.csv", "high_specificity_per_10k_chars"): "High-specificity occurrences (names >=2 chars) per 10,000 searched characters of the default analysis set.",
    ("concept_mention_statistics.csv", "searched_chars_default_set"): "Denominator of the per-10k rates: normalized characters of the default analysis set (identical on every row).",
    ("concept_mention_statistics.csv", "mentions_specificity_high"): "Occurrences in the default set from names >= 3 chars.",
    ("concept_mention_statistics.csv", "mentions_specificity_medium"): "Occurrences in the default set from 2-char names.",
    ("concept_mention_statistics.csv", "mentions_specificity_low"): "Occurrences in the default set from 1-char names (also ordinary words).",
    ("concept_mention_statistics.csv", "is_textually_attested"): "FALSE for analytic labels that occur nowhere in the corpus.",
    ("concept_mention_statistics.csv", "node_type"): "Ontological node type (from concepts.csv).",
    ("concept_relations.csv", "concept_id_a"): "Source concept of the typed relation.",
    ("concept_relations.csv", "concept_id_b"): "Target concept of the typed relation.",
    ("evidence.parquet", "evidence_id"): "Evidence record id (1:1 with commentary_id).",
    ("evidence.parquet", "source_type"): "Kind of source the quote was taken from (chapter instance / exegesis source).",
    # NOT an instance_id: every one of the 2,635 values is a commentary_id and
    # none is an instance_id (verified against the tables). The v1.1.2-rc7
    # dictionary said instance_id, which is how the public profile's cascade came
    # to declare the wrong key and drop nothing.
    ("evidence.parquet", "source_ref"): "Commentary record this evidence supports "
        "(FK -> commentary.commentary_id). Named source_ref for historical reasons; "
        "it is a commentary_id, not an instance_id. Renaming is deferred to v1.2.0 "
        "so rc-series consumers are not broken mid-series.",
    ("evidence.parquet", "quote"): "Quoted span as extracted; verbatim only where quote_kind says so.",
    ("evidence.parquet", "source_char_overlap"): "Share of quote characters found in the source text (1.0 = all present; contiguity is a separate flag).",
    ("provenance_assertions.csv", "pa_id"): "Provenance assertion id.",
    ("provenance_assertions.csv", "version_a"): "First version of the asserted relationship (FK -> versions.csv). Kept as version_a/version_b: both sides are Version rows here.",
    ("provenance_assertions.csv", "version_b"): "Second version of the asserted relationship (FK -> versions.csv).",
    ("provenance_assertions.csv", "relation_type"): "SAME_WORK_EDITION: the two catalogue records are editions of one work.",
    ("provenance_assertions.csv", "confidence"): "高/中/低 compiler grade of the assertion; not a probability.",
    ("provenance_assertions.csv", "assertion_basis"): "What the assertion rests on (title match, collation-report cross-reference).",
    ("provenance_assertions.csv", "asserter"): "Who/what made the assertion (compiler rule or report).",
    ("sentences.parquet", "seq"): "Sentence order within its chapter instance.",
    ("derived_diagnostics/structural_mismatches.parquet", "variant_id"): "Diagnostic event id (same detector as variants; spans too long to be character-level variants).",
    ("wangbi_exegesis_source.parquet", "chapter_num"): "Chapter 1-81 of the 2026 Wang Bi exegesis compilation (WANGBI_TONGSHI_2026).",
    ("wangbi_exegesis_source.parquet", "jingwen"): "Base text (經文) of the chapter as given in the compilation; the WANGBI_CANONICAL reference for variant detection.",
    ("wangbi_exegesis_source.parquet", "wangbi_commentary"): "Wang Bi's commentary (王弼注) as transcribed in the compilation.",
    ("wangbi_exegesis_source.parquet", "quanjie_interpretation"): "Modern interpretation section (诠解) of the compilation; source of the WANGBI_TONGSHI_2026 concept glosses.",
})

# ---- expert_validation frames and derived diagnostics ----
COMMON_COLUMNS.update({
    "frame": "Which validation frame this row belongs to (commentary / mentions / variants / work_type / node_type / concept_relations / person_eras / alignment_diagnosis).",
    "variant_detection_score_bin": "Detection-score bin used for equal-allocation sampling (0.15-0.25 / 0.25-0.45 / 0.45-0.65 / >=0.65). See expert_validation/SAMPLING_DESIGN.md.",
    "score_bin": "Detection-score bin (allocation table).",
    "population": "Number of records in the stratum/bin in the full data, before sampling.",
    "sampled": "Number of records drawn from that stratum/bin.",
    "scheme": "Sampling scheme applied within the stratum/bin.",
    "corrected_work_type": "Reviewer's corrected work_type; empty unless the verdict is N.",
    "corrected_textual_scope": "Reviewer's corrected textual_scope; empty unless the verdict is N.",
    "corrected_node_type": "Reviewer's corrected node_type; empty unless the verdict is N.",
    "corrected_era": "Reviewer's corrected person_historical_era; empty unless the verdict is N.",
    "corrected_dates": "Reviewer's corrected lifetime dates; empty unless supplied.",
    "reviewer_chapter": "Reviewer's chapter assignment for an S06453 segment; empty until reviewed.",
    "reviewer_verdict": "confirm / correct / reject for an S06453 segment; empty until reviewed.",
    "reviewer_note": "Reviewer's free-text note; empty until reviewed.",
    "sentence": "The sentence containing the concept match, shown to the annotator as context.",
    "segment_text_as_transmitted": "Segment text as transmitted (traditional/variant characters and lacuna marks kept), for visual comparison against the canonical text.",
    "canonical_wangbi_text": "Canonical Wang Bi text of the identified chapter, shown beside the segment.",
    "scribal_colophon_count": "Character count the scribe wrote in the colophon after this segment; empty if none.",
    "n": "Records in the stratum in the full population.",
    "alloc": "Records allocated to the sample from that stratum.",
    "reviewed": "Whether the row has been expert-reviewed (FALSE throughout this release).",
    "source": "Provenance tag of the label (e.g. minimax-m3).",
    "near_threshold": "YES where the identification score is below 60 — flagged for closer reviewer attention.",
})

def _annot_desc(col):
    """Per-question annotator / adjudication / prompt columns of a validation frame."""
    for pre, what in (("annotator_A_", "Annotator A's independent judgment on"),
                      ("annotator_B_", "Annotator B's independent judgment on"),
                      ("adjudicated_", "Adjudicated (third-party) verdict on"),
                      ("q_", "Controlled vocabulary and question text for")):
        if col.startswith(pre):
            q = col[len(pre):]
            return (f"{what} `{q}`. Empty until the review is performed; NA where the question "
                    f"does not apply (dropped from denominators by src/score_validation.py).")
    if col.endswith("_note"):
        return "Annotator's free-text note; empty until reviewed."
    return ""

# A validation frame is a projection of a source table plus annotator columns, so
# its columns inherit that table's definitions rather than duplicating them.
FRAME_SOURCE = {
    "expert_validation/frame_commentary.csv": "commentary.csv",
    "expert_validation/frame_commentary_strata.csv": "commentary.csv",
    "expert_validation/frame_mentions.csv": "concept_chapter_mentions.csv",
    "expert_validation/frame_variants.csv": "variants.parquet",
    "expert_validation/frame_variants_strata.csv": "variants.parquet",
    "expert_validation/frame_work_type.csv": "versions.csv",
    "expert_validation/frame_node_type.csv": "concepts.csv",
    "expert_validation/frame_concept_relations.csv": "concept_relations.csv",
    "expert_validation/frame_person_eras.csv": "persons.csv",
    "expert_validation/frame_alignment_diagnosis.csv": "alignment_failure_diagnosis.csv",
    "expert_validation/S06453_review_dossier.csv": "alignment_recovery_segments_S06453.csv",
    "expert_validation/S06453_residual_sentences.csv": "sentences.parquet",
    "derived_diagnostics/structural_mismatches.parquet": "variants.parquet",
    "derived_unverified/candidate_scholarly_claims.csv": "candidate_scholarly_claims.csv",
    "derived_unverified/candidate_scholarly_claim_evidence.csv": "candidate_scholarly_claim_evidence.csv",
}
# dossier columns renamed relative to their source table
DOSSIER_ALIAS = {"actual_char_count": "actual_count", "identified_chapter": "identified_chapter",
                 "runner_up_score": "runner_up_score", "segment_order": "segment_order",
                 "count_delta": "count_delta"}


def describe(filename, col):
    """Resolve a column description: exact entry, then source-table entry, then
    shared-column entry, then the annotator-column pattern."""
    d = DESCRIPTIONS.get((filename, col))
    if d:
        return d
    src = FRAME_SOURCE.get(filename)
    if src:
        d = DESCRIPTIONS.get((src, DOSSIER_ALIAS.get(col, col))) or DESCRIPTIONS.get((src, col))
        if d:
            return d
    return COMMON_COLUMNS.get(col) or _annot_desc(col)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    data_dir = os.path.join(root, "data")
    meta_dir = os.path.join(root, "metadata")
    os.makedirs(meta_dir, exist_ok=True)

    # The dictionary covers every released table a consumer opens, not only
    # data/: the expert_validation frames and the derived diagnostics are exactly
    # the files a Technical Validation reviewer reads first.
    EXTRA_DIRS = [("expert_validation", "expert_validation/"), ("derived_diagnostics", "derived_diagnostics/"),
                  ("derived_unverified", "derived_unverified/")]
    tables = sorted(f for f in os.listdir(data_dir)
                    if f.endswith((".csv", ".parquet")) and not f.startswith("_"))

    dict_rows, stat_rows = [], []
    extra = []
    for sub, prefix in EXTRA_DIRS:
        sd = os.path.join(root, sub)
        if os.path.isdir(sd):
            extra += [(prefix + f, os.path.join(sd, f)) for f in sorted(os.listdir(sd))
                      if f.endswith((".csv", ".parquet")) and not f.startswith("_")]
    for filename, path in [(t, os.path.join(data_dir, t)) for t in tables] + extra:
        df = pd.read_parquet(path) if filename.endswith(".parquet") else \
            pd.read_csv(path, encoding="utf-8-sig")
        stat_rows.append({"table": filename, "rows": len(df),
                          "columns": len(df.columns),
                          "purpose": TABLE_PURPOSE.get(filename, "")})  # counts live in the rows column and release_facts.json, never in prose
        for col in df.columns:
            series = df[col]
            non_null = series.dropna()
            samples = [str(x)[:40] for x in non_null.unique()[:3]]
            dict_rows.append({
                "table": filename,
                "column": col,
                "dtype": str(series.dtype),
                "null_count": int(series.isna().sum()),
                "null_pct": round(float(series.isna().mean() * 100), 2),
                "distinct_count": int(non_null.nunique()),
                "sample_values": " | ".join(samples),
                "description": describe(filename, col),
            })

    pd.DataFrame(dict_rows).to_csv(os.path.join(meta_dir, "data_dictionary.csv"),
                                   index=False, encoding="utf-8-sig",
                                   quoting=csv.QUOTE_ALL)
    pd.DataFrame(stat_rows).to_csv(os.path.join(meta_dir, "dataset_statistics.csv"),
                                   index=False, encoding="utf-8-sig",
                                   quoting=csv.QUOTE_ALL)

    # ---- manifest + checksums over the whole release tree ----
    manifest, lines = [], []
    for dirpath, dirnames, filenames in os.walk(root):
        # never manifest bytecode or VCS/OS artefacts: they are not part of the
        # release, and the tool-test stage compiles bytecode before this runs
        dirnames[:] = [d for d in dirnames if d not in ("__pycache__", ".git", ".ipynb_checkpoints")]
        if os.sep + ".git" in dirpath:
            continue
        for fn in sorted(filenames):
            if fn.endswith((".pyc", ".pyo")) or fn == ".DS_Store" or fn.startswith("handoff_"):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root)
            # Files that cannot appear in the manifest they describe. The first
            # two are self-referential; final_release_verification.json is
            # written in the LAST release stage, after this manifest, and reports
            # the verified payload count — so any hash recorded here would be the
            # previous build's. It declares itself among these in its own
            # `unhashable_self_references` list.
            #
            # Two different exclusion scopes, because the two reasons differ.
            #
            # Self-reference is relative to THIS manifest, so it applies only to
            # the top-level metadata dir. The profile nested under dist/ has its
            # own manifest pair, and those files already exist when this runs —
            # hashing them is deterministic and is what gives the full package
            # tamper coverage over the profile's manifest. Excluding them by
            # directory NAME would silently drop that coverage.
            if rel.startswith("metadata" + os.sep) and fn in (
                    "file_manifest.csv", "checksums.sha256"):
                continue
            # Staleness, by contrast, applies in EVERY tree: this file is written
            # in the last release stage, after each manifest, so a copy present
            # now is necessarily the previous build's. Anchoring this one to the
            # top level too meant the full package walked into dist/ and hashed
            # the profile's leftover, making the manifest depend on prior-build
            # residue rather than only on the tree it describes. Measured on this
            # tree: with the top-level anchor, a clean build gave 351 entries and
            # an uncleaned re-run 352; with the match below, both give 351.
            if fn == "final_release_verification.json" and \
                    os.path.basename(dirpath) == "metadata":
                continue
            if os.path.isdir(full):
                continue
            digest = sha256_file(full)
            manifest.append({"path": rel, "size_bytes": os.path.getsize(full),
                             "sha256": digest})
            lines.append(f"{digest}  {rel}")

    pd.DataFrame(manifest).to_csv(os.path.join(meta_dir, "file_manifest.csv"),
                                  index=False, encoding="utf-8-sig")
    with open(os.path.join(meta_dir, "checksums.sha256"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    summary = {
        "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "tables": len(tables),
        "dictionary_columns_documented": sum(1 for r in dict_rows if r["description"]),
        "dictionary_columns_total": len(dict_rows),
        "files_in_manifest": len(manifest),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
