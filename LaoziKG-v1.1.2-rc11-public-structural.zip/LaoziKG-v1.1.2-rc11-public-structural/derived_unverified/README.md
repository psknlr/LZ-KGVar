# derived_unverified/ — machine-generated, NOT peer-reviewed

Content here is **not** part of the primary dataset. It is retained because it
is legitimately useful as a starting point for a literature search, and removed
from `data/` so that the primary dataset contains only bibliographic facts,
structural data, textual evidence, and clearly-flagged machine annotations.

## `candidate_scholarly_claims.csv` (10 rows) + `candidate_scholarly_claim_evidence.csv` (20 rows)

Machine-generated summaries of Laozi textual-history debates. Every row carries
`claim_status = AI_GENERATED_UNVERIFIED`, `citable_as_scholarship = FALSE`,
`review_required = TRUE`.

**Do not cite these as scholarship.** The named `proponents` and `opponents`
have **not** been checked against the literature; some attributions may be
wrong or fabricated. No domain expert has reviewed any row.
