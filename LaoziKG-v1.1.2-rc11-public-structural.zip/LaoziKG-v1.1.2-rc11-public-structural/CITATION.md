# How to cite LaoziKG

Machine-readable metadata is in [`CITATION.cff`](CITATION.cff); GitHub, Zenodo
and most reference managers read it directly. This file is the human-readable
companion.

## Cite the dataset

> Shen Li, Yanlan Kang, Xuening Wu, Yang Hu, Wenqi Li, William Cheng-Chung Chu (2026). *LaoziKG: A Provenance-Aware Multi-Version Textual
> Knowledge Graph of the Laozi (Dao De Jing)*, version 1.1.2-rc11. Zenodo.

Add the Zenodo DOI once minted. Cite the **version you used** — the concept DOI
resolves to the latest release, which may differ from the one your results came
from.

## Cite the right profile

Two distributions exist and they are not interchangeable in a methods section:

- **Public structural release** (`dist/public_structural_release/`) — openly
  available; withholds third-party transcriptions. State this if your analysis
  used it, because concept-mention counts differ (58,619 default
  edges in the full internal package, 51,648 in the public
  structural release).
- **Full profile** — not redistributable pending the rights review.

## What must accompany a citation

Three facts are load-bearing and should appear wherever results from this
dataset are reported:

1. **No annotation layer has been reviewed by a domain expert**
   (0 of 1,816 items adjudicated). LLM-derived fields carry
   `*_reviewed = FALSE`.
2. **Variants are candidate detections**, not philologically confirmed readings
   (18,334 events).
3. **Redistribution rights for source transcriptions are undetermined**
   (1 of 176 reviewed) — see `docs/DATA_AVAILABILITY.md`.

## Citing the sources behind the data

The witnesses are transcriptions held by third-party platforms and libraries
(识典古籍, CADAL, Bibliothèque nationale de France, British Library). Work using
the texts themselves should credit the holding institution as well as this
dataset; `data/source_rights.csv` records the provider per resource.
