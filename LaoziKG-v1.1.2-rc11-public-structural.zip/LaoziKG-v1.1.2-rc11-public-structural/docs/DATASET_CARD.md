# Dataset Card — LaoziKG: A Provenance-Aware Multi-Version Textual Knowledge Graph of the Laozi (Dao De Jing)

**Version 1.1.2-rc11**

## Dataset summary

**Name:** LaoziKG  
**Full title:** LaoziKG: A Provenance-Aware Multi-Version Textual Knowledge Graph of the Laozi (Dao De Jing)  
**Version:** 1.1.2-rc11  
**Build date:** 2026-09-14 (release candidate; see publication status below)  
**Publication date:** not published — `overall_release_status = NOT_READY_FOR_PUBLICATION`  
**Domain:** Digital humanities; Chinese philosophy; textual criticism; knowledge graphs; data provenance  
**Primary contribution:** provenance-aware multi-version textual modelling — witness-level attribution, separated witness/author eras, and machine-derived layers gated out of default analyses — rather than corpus scale  
**Languages:** Classical Chinese and Modern Chinese (data); English/Chinese metadata  

## Figures

Generated from the shipped tables into `figures/`, default analysis set only:

| Figure | Shows |
|---|---|
| `fig1_source_distribution.png` | corpus composition by edition era and genre; proposed release disposition |
| `fig2_concept_network.png` | concept co-occurrence across chapter instances (high/medium-specificity matches) |
| `fig3_commentary_lineage.png` | commentator era against edition era — the two differ for 68.9% of glosses |
| `fig4_temporal_evolution.png` | concept share of each era's glosses, by the commentator's own era |
| `fig5_architecture.png` | the four layers, how each was produced, and what is gated out of default analyses |
| `fig6_version_lineage.png` | chapter instances by lineage branch and alignment status; same-work assertions between branches |

Every panel uses the default analysis set and labels the era semantics it carries
(`witness_era` vs `commentator_historical_era`); the recovered-unreviewed
instances are excluded, as everywhere else.

## Intended uses

LaoziKG is designed for research on multi-version textual comparison, textual-variant detection, knowledge-graph construction and querying, concept evolution, computational commentary analysis, digital humanities, and evaluation of AI-assisted scholarly workflows.

## Out-of-scope / discouraged uses

The LLM-assisted commentary and scholarly-claim layers should not be used as authoritative critical editions, verified historical quotations, or validated measurements of scholarly consensus without independent human review and source verification.

## Composition

All figures below are rendered from `metadata/public_release_facts.json` (computed from the
tables at release). Count vocabulary: *edges* = chapter-instance × concept rows;
*occurrences* = summed `mention_count`; *sentence rows* = sentence × concept.

- **Recommended phrasing for the corpus size:** 3,481 expert-independent, analysis-ready aligned chapter instances, plus 116 automatically recovered candidate alignments awaiting expert confirmation (46 units unaligned; 3,643 rows in total)
- Resources: 176 (175 historical source witnesses + 1 modern derived resource)
- Chapter instances: 3,643 — 3,481 in the default analysis set
  (`original_deterministic`), 116 `auto_recovered_unreviewed` (v1.1.2
  algorithmic recovery, excluded from defaults until expert-confirmed), 46 unaligned
- Sentences: 167,506
- Candidate variant events: 18,334 (none philologically confirmed). A further 3,493 structural-mismatch diagnostics ship in `derived_diagnostics/`, outside the canonical data layer; the two must not be summed
- Concepts: 111 (20 hand-authored seeds, 91 LLM-expanded; 109 with mentions)
- Concept mentions, default set: 51,648 edges / 283,788 occurrences / 233,892 sentence rows
- Concept mentions, recovered-unreviewed (separate files): 1,029 edges / 2,753 occurrences
- Concept mentions, unaligned (separate files): 1,268 edges / 15,193 occurrences
- Commentary records: 2,386 (1,282 citable as verbatim quotes)
- Persons: 77 (75 named + 2 placeholders), 90 aliases
- Provenance assertions: 19; candidate scholarly claims (outside `data/`): 10
- Graph: 12 node tables, 17 relationship tables

## Data generation and annotation

The package records multiple automated and LLM-assisted processing methods through fields such as `segmentation_method`, `extraction_method`, `generated_by`, `asserter`, `confidence`, `reliability`, and `manual_status`. These fields are retained to make epistemic status machine-readable.

## Validation state

- TV1 structural integrity: automated (`qa/validate_dataset.py`) — primary keys, foreign keys,
  enums, cross-table counts, and a graph rebuild from the shipped tables and a recomputation of every derived statistic (the raw inputs are not in this distribution, so `src/regenerate_tables.py` cannot be run here).
- Commentary quote provenance computed for all 2,386 records:
  1,282 `verbatim_contiguous` (citable), 1,038
  `spliced_from_source`, 66 `not_located`. Gate on `citable_as_quote = TRUE`.
- Candidate scholarly claims: all 10 are `AI_GENERATED_UNVERIFIED`, `citable_as_scholarship = FALSE`.
- Person eras re-assigned in v1.1.1 (v1.1.0 had inherited the edition's era); 7
  dynastic-transition figures carry `era_disputed = TRUE`; every row `era_reviewed = FALSE`.
- Alignment recovery (v1.1.2): 116 instances across 5 witnesses,
  `recovery_reviewed = FALSE`, excluded from default statistics.
- **Expert validation (TV2–TV6): not performed.** `expert_validation/` holds 1,816
  items in sampled and full-population frames; 0 adjudicated.
- **Rights review: not performed.** `data/source_rights.csv`: 1 of 176 cleared.

## Provenance

`versions.csv.source_filename` retains the name of the source DOCX used by the construction pipeline. The corresponding DOCX files are not included in this Zenodo release. Consequently, the package supports internal provenance tracing to source filenames but not full source-document audit from the public archive alone.

## Licensing

Recommended record-level license: CC BY 4.0 for original dataset contributions, subject to source-rights verification. Code: MIT. Third-party rights are not overridden.

## Maintenance and versions

Use semantic versioning for public releases. Changes to data values, annotations, or schema should be issued as a new Zenodo version rather than silently replacing v1.0.0.
