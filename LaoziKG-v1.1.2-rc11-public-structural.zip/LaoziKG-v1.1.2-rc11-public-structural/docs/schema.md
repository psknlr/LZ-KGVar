# LaoziKG v1.1.2-rc11 — Graph Schema

Schema version `1.1.2-rc11`. Backend: [Kuzu](https://kuzudb.com) (embedded,
Cypher-compatible). Rebuild with:

```bash
python src/build_graph.py --data-dir data --db-path data/graph/laozi_kg.kuzu
```

The build writes `data/graph/build_report.json` with per-table counts, SHA256
of every input, and library versions, so a rebuild can be proven equivalent to
the published graph.

## 1. Node tables (12)

| Node | Rows | Key | Notes |
|---|---:|---|---|
| `Version` | 176 | `version_id` | One textual resource. Carries `work_type`, `textual_scope`, `alignment_status`, `witness_era` (= normalized form; raw in the table), `resource_class`. |
| `Person` | 77 | `person_id` | Canonical persons (75 named + `ANONYMOUS`/`UNKNOWN`). `person_historical_era` is the figure's own era. |
| `PersonAlias` | 90 | `alias_key` | Surface forms → Person (`alias_type`: canonical / variant / role_form / attributed_form / parse_error). |
| `ChapterInstance` | 3,643 | `instance_id` | A chapter-like unit in a resource. `chapter_num = -1` for the 46 unaligned units. 116 instances added by v1.1.2 alignment recovery (gated: `alignment_review_status`) (`segmentation_method` ∈ anchor_recovery / colophon_recovery). |
| `Sentence` | 167,506 | `sentence_id` | Sentence-segmented witness text. 82 rows carry `-a`/`-b` suffixes from colophon splits. |
| `Variant` | 18,334 | `variant_id` | Automatically detected CANDIDATE variant event against the Wang Bi base text (`reference_text_id = WANGBI_CANONICAL`). `variant_detection_score` is heuristic; `variant_status = candidate_auto_detected`. |
| `Concept` | 111 | `concept_id` | Stratified by `node_type` (§3). |
| `Commentary` | 2,386 | `commentary_id` | A concept gloss. Quote provenance separated (§4); `commentator_historical_era` ≠ `commentary_witness_era`; `gloss_reviewed = FALSE`. |
| `Evidence` | 2,386 | `evidence_id` | Backing record for a gloss, with `quote_kind`. |
| `ProvenanceAssertion` | 19 | `pa_id` | Mediated version-relationship claim. |
| `CandidateScholarlyClaim` | 10 | `sc_id` | **AI-generated, unverified.** Lives in derived_unverified/. |
| `CandidateScholarlyClaimEvidence` | 20 | `evidence_id` | **AI-generated, unverified.** |


### Evidence is keyed on commentary, despite the column name

`evidence.parquet` links to `commentary.csv` through **`source_ref`**, whose values
are `commentary_id`s. The name is historical and misleading: all 2,386 values
resolve against `commentary.commentary_id` and none against `commentary.instance_id`.

```cypher
// evidence for a commentary record
MATCH (c:Commentary)-[:HAS_EVIDENCE]->(e:Evidence) RETURN c, e
```

Anything that filters or cascades on this table must use `source_ref`. In
v1.1.2-rc7 both the public-profile generator and its validator declared
`commentary_id` instead; the column does not exist, so the filter matched nothing
and the validator skipped its own check, so evidence rows for withheld
resources shipped under a passing report. The validator now fails when a declared
key is absent, and cross-checks its key names against the generator's.
(In the full internal package this concerned 249 evidence rows, one per commentary record belonging to a withheld resource. This distribution carries 0 of them, those records having been removed with their resource.)
Renaming the column to `commentary_id` is deferred to v1.2.0.


## 2. Relationship tables (17)

| Relationship | From → To | Rows |
|---|---|---:|
| `HAS_INSTANCE` | Version → ChapterInstance | 3,643 |
| `HAS_SENTENCE` | ChapterInstance → Sentence | 167,506 |
| `HAS_VARIANT` | ChapterInstance → Variant | 18,334 |
| `VARIANT_AGAINST` | Variant → Version | 18,334 |
| `AUTHORED_BY` | Version → Person | 145 |
| `ANNOTATED_BY` | Version → Person | 27 |
| `HAS_ALIAS` | Person → PersonAlias | 90 |
| `MENTIONS_CONCEPT` | ChapterInstance → Concept | 52,677 |
| `GLOSSES` | Commentary → Concept | 2,386 |
| `INTERPRETS` | Commentary → ChapterInstance | 2,386 |
| `COMMENTARY_OF` | Commentary → Version | 2,386 |
| `HAS_EVIDENCE` | Commentary → Evidence | 2,386 |
| `CONCEPT_LOCUS` | Concept → ChapterInstance | 8,515 |
| `RELATED_CONCEPT` | Concept → Concept | 67 |
| `PA_ASSERTS_A` | ProvenanceAssertion → Version | 19 |
| `PA_ASSERTS_B` | ProvenanceAssertion → Version | 19 |
| `CLAIM_EVIDENCE` | CandidateScholarlyClaim → …Evidence | 20 |

`AUTHORED_BY` / `ANNOTATED_BY` carry `role_raw`, `is_attributed`,
`attribution_status`. `MENTIONS_CONCEPT` carries `mention_count`,
`sentence_count`, `match_specificity`. `RELATED_CONCEPT` carries
`relation_type`, `source`, `reviewed`.

### Changes from v1.0.0

- `GLOSSES` is **2,386, not 10,715** (the 10,715 is a v1.0.0 figure, quoted as history). v1.0.0 cross-joined each commentary
  record against many concepts; 8,080 of its edges asserted a gloss on a
  concept the record does not gloss (e.g. a gloss on 圣人 wired to 道, 德, 无,
  有, 一, 柔, 智). Only self-consistent edges are kept.
- `MENTIONS_CONCEPT` is **51,648** default edges here, plus
  1,029 on `auto_recovered_unreviewed` instances, giving
  52,677 in the graph; the two are distinguishable by the edge
  property `alignment_review_status`. For history: v1.0.0 had 11,334, v1.1.0
  raised it to 60,096, and v1.1.1 moved the unaligned units out — those three are
  past-version figures, not counts of this release. Coverage is
  109 of the 111 concepts rather than v1.0.0's 14. The
  remainder are analytic labels that occur nowhere in the corpus, carry
  `is_textually_attested = FALSE`, and so have no substring matches to record —
  full coverage is not attainable by design. See
  `expert_validation/SAMPLING_DESIGN.md` for the per-frame design and thresholds.
- `CONCEPT_LOCUS` and `RELATED_CONCEPT` are new.
- `ScholaryClaimEvidence` (v1.0.0 typo, and inconsistent with its own build
  script) is now `CandidateScholarlyClaimEvidence`.

## 3. Concept stratification

v1.0.0 held 道, 德, 无 co-equal with 上善若水 and 反者道之动. `node_type`
separates the strata:

**Atomic concepts (57)** — `OntologicalConcept` (11), `EpistemicConcept` (13),
`CultivationConcept` (11), `CosmologicalConcept` (10), `EthicalConcept` (6),
`PoliticalConcept` (6).

**Composite entries (54)** — `Practice` (19), `Phrase` (17), `Proposition`
(14), `Metaphor` (4).

Every composite entry links to at least one atomic concept via
`RELATED_CONCEPT` (`EXPRESSES` / `REALIZES` / `SYMBOLIZES`), so the ontology is
hierarchical:

```
反者道之动  (Proposition) --EXPRESSES--> 道  (OntologicalConcept)
上善若水    (Phrase)      --EXPRESSES--> 善
涤除玄览    (Practice)    --REALIZES-->  玄
婴儿        (Metaphor)    --SYMBOLIZES--> 朴
```

`node_type` is LLM-assigned (MiniMax-M3) and `node_type_reviewed = FALSE` on
every row.

## 4. Citing commentary text — read this first

`Commentary` does **not** have a single text column. v1.0.0 had one
(the v1.0.0 `interpretation_text` column, then carrying
`is_verified_contiguous_quote = 'unchecked'`) on all
all commentary rows, so a reader could not tell an attested quotation from model output.
all but the 8 direct-text-match records (2,386 total) were LLM-produced.

Each record is now classified against its own source document:

| `text_provenance` | Rows | Populated column | Citable as the commentator's words |
|---|---:|---|---|
| `verbatim_contiguous` | 1,282 | `source_quote` | **Yes** |
| `spliced_from_source` | 1,038 | `llm_interpretation` | No — fragments joined by the model |
| `not_located` | 66 | `llm_interpretation` | No |

Gate on `citable_as_quote = TRUE`:

```cypher
MATCH (c:Commentary)-[:GLOSSES]->(k:Concept {name: '无为'})
WHERE c.citable_as_quote = true
RETURN c.commentator_raw, c.commentator_historical_era, c.source_quote
```

`spliced_from_source` records average 0.995 character overlap with the source
(median 1.000), so they are genuine excerpts — but non-contiguous and usually
unmarked by ellipsis, so quoting them verbatim misrepresents the source.

## 5. Concept mention reliability

`MENTIONS_CONCEPT.match_specificity` must be respected. 33 of the 111 concept
names are a single character that is also an ordinary word — 一 (also the
numeral), 大 (also the adjective), 用 (also the verb). Raw counts for those
overstate philosophical usage.

| `match_specificity` | Concepts | Edges | Meaning |
|---|---:|---:|---|
| `high` | 37 | 2,400 | Name ≥3 chars; low ambiguity |
| `medium` | 39 | 13,679 | 2-char compound; some ambiguity |
| `low` | 33 | 35,569 | 1 char; high recall, precision not quantified |

```cypher
MATCH (ci:ChapterInstance)-[m:MENTIONS_CONCEPT]->(k:Concept)
WHERE m.match_specificity IN ['high', 'medium']
  AND ci.analysis_default_include = true
RETURN k.name, sum(m.mention_count) AS n ORDER BY n DESC
```

## 6. Chapter alignment

Filter on `ChapterInstance.analysis_default_include` (FALSE for the 47
unaligned units) for chapter-level work. On `Version`, four separate fields
replace v1.0.0's two conflated ones:

- `source_structural_unit_count` — the source's own 卷/節/章 headings
  (bibliographic). 老子義疏 has 213.
- `aligned_laozi_chapter_count` — distinct Laozi chapters aligned. 老子義疏 has 14.
- `alignment_success_count`, `unresolved_unit_count` — computed from
  `chapter_instances`.

In v1.0.0 the single `chapter_count_total` field carried the first meaning while
being read as the second, which is why 132 of 176 rows disagreed with the
chapter data.

---

### Concept relation taxonomy

`concept_relations.csv` carries 67 edges over 111 concepts,
categorized by `relation_category`:

| Category | Meaning | Edges |
|---|---|---:|
| `lexical_semantic` | A's name deterministically contains B's core term — a lexical fact, not a philosophical claim | 32 |
| `semantic` | asserted conceptual expression between concepts | 25 |
| `realization` | A is enacted or realized through B | 5 |
| `symbolic` | A stands for B figuratively (image / metaphor) | 5 |

The category is derived deterministically from `relation_type`; **no edge was
created to populate it**. This layer is deliberately thin. Thickening it with
richer relation types (causal, interpretive, historical-evolution,
commentary-inheritance) would require authored philosophical claims, and
generating those with a language model would add unreviewed assertions to the
layer whose credibility is already the dataset's weakest point. The
67 existing edges are themselves unreviewed
(`frame_concept_relations.csv` holds all of them for full-population adjudication);
expansion should follow that review, by a scholar, not precede it.

## 7. v1.1.2-rc2: the graph is a projection, not a lossless mirror

The Kuzu snapshot is a **graph-oriented projection** of the canonical tables,
not a complete representation of every released column. The **tables are
authoritative**; the graph exists for traversal.

Columns present in the released tables but not carried into the graph include
`Version.id_is_numeric_string`, `Version.work_type_source`,
`Concept.node_type_source`, and the candidate-claim review fields
(`manual_status`, `verified_by`, `verified_date`).

Two different integrity scopes apply:

- `data/graph/build_report.json` → `input_sha256` covers the **17 graph
  inputs** only.
- `metadata/checksums.sha256` covers **every release payload file** except the
  two that cannot hash themselves: `metadata/checksums.sha256` and
  `metadata/file_manifest.csv`. The verified payload count for the build that
  produced this tree is in `metadata/final_release_verification.json`, written
  after the last file — a count captured while documents are rendered would be
  the previous build's.
- `Variant.confidence` → `variant_detection_score`; `Variant.version_a` →
  `reference_text_id`; new `variant_status`, `detection_method`,
  `reference_version_id`, `explanation_source`. Read these as *candidate variant
  events*, not confirmed 异文.
- `ChapterInstance.base_text_share_est` → `base_text_share_upper_bound`.
- `Commentary` gains `gloss_generated_by`, `gloss_reviewed`, `gloss_review_status`,
  `gloss_reviewer`.
- `Version.witness_era` in the graph is the **normalized** form
  (`witness_era_normalized` in the table; `witness_era_raw` keeps the record's
  own string; `witness_era_ambiguous` flags the dual-dynasty labels).
- `PA_ASSERTS_A/B` run **from** ProvenanceAssertion **to** Version. The query
  layer traversed them the other way from v1.1.0 to v1.1.1 and returned empty
  chains; fixed and now covered by `qa/test_tools.py`.
- Every tool query names its era column: `person_historical_era`,
  `commentator_historical_era`, `witness_era`. No output column is a bare `era`.

## 9. v1.1.2-rc11 schema changes

- `ChapterInstance.alignment_review_status` (original_deterministic / auto_recovered_unreviewed /
  expert_confirmed / expert_corrected / not_aligned); `analysis_default_include` now excludes
  `auto_recovered_unreviewed`. `MENTIONS_CONCEPT` carries the same property on every edge.
- `ChapterInstance.anchor_coverage_score` and `identification_score` replace `confidence` for
  recovered instances (`confidence` is NULL there); `variant_detection_eligible` /
  `variant_detection_run` say where the v1.0.0 variant detector actually ran.
- `PersonAlias` now includes a canonical self-alias for every person (90 rows).
- `Concept` rows carry `concept_generated_by` / `definition_generated_by` and the matching
  `*_reviewed` flags; `Version` carries `textual_scope_source` / `textual_scope_reviewed`.
