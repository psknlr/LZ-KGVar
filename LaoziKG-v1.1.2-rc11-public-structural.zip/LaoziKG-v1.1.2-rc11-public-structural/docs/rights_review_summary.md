# rights_review_summary — status at v1.1.2-rc11

| Question | Answer today |
|---|---|
| Resources reviewed | **1 of 176** |
| Cleared for redistribution | **1** |
| `redistribution_allowed = unknown` | 175 |
| Underlying works public domain by age | 175 |
| Digitization rights established (layer B) | 0 |
| Transcription/OCR rights established (layer C) | 0 |

## Which sources could be published, under the proposed dispositions

- **In full:** 1 — the dataset authors' own 2026 compilation.
- **As metadata and offsets, text withheld:** 157 — public-domain works whose
  transcription came from an identified third-party platform.
- **As a reference record only:** 18 — provider not identifiable above low
  confidence; text and offsets both withdrawn.

None of this is a determination. See `metadata/source_license_resolution.md` for
the per-bucket reasoning and `expert_validation/RIGHTS_WORKSHEET.md` for the work.

## What is already implemented

The restricted distribution (`dist/public_structural_release/`, regenerable) enacts the above:
224,794 → 167,506 sentence rows, character streams withheld on all but
the authors' own resource, withheld lengths preserved as `*_char_count` so every
published statistic remains reproducible.

## Honest statement for a reviewer or editor

> No resource in this dataset has completed a rights review. The underlying
> pre-modern works are out of copyright by age; the digital transcriptions were
> obtained from third-party platforms whose terms have not been established. We
> therefore ship a restricted profile that withholds all third-party
> transcriptions and contains only the structural and analytical layers produced
> by the authors. The full-text profile must not be redistributed until the
> per-provider review recorded in `source_rights.csv` is complete.
