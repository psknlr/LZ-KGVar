# DATA_AVAILABILITY — what is available, what is withheld, and why

Written to be quotable in a journal Data Availability section.

## Statement (short form, for a manuscript)

> A public structural release of LaoziKG is openly available and
> structurally reproducible from the released tables: it contains the structural annotations, derived analytical layers,
> knowledge graph, regeneration pipeline and quality-control suite produced by the
> authors. The original third-party textual witnesses are excluded from this
> release unless redistribution rights are confirmed; the full-text profile is
> retained by the authors pending a per-provider rights review recorded in
> `data/source_rights.csv`.

Do **not** write "the LaoziKG dataset is openly released" without qualification:
1 of 176 resources have completed a rights review (the authors' own compilation); 175 remain unreviewed.

## Two profiles

| | Full profile | Public structural release (`dist/public_structural_release/`) |
|---|---|---|
| Transcribed character streams | all 224,794 sentences | withheld except the authors' own resource (167,506 rows retained, 471 with text) |
| Structure, identifiers, offsets, character counts | yes | yes |
| Concept mentions (default set) | 58,619 edges | 51,648 edges (dropped with the 18 `reference_only` witnesses) |
| Commentary records | 2,635 | 2,386 (metadata; source quotes withheld) |
| Variant positions and edit operations | 20,124 | 18,334 |
| Graph, statistics, documentation, QA suite, validation frames | yes | yes |
| May be distributed openly | **no** — carries the third-party transcriptions; blocked pending the rights review | **yes** — no third-party character stream; subject to author and institutional sign-off |

## Why the underlying works being old is not sufficient

Three rights layers are tracked separately in `data/source_rights.csv`: the
pre-modern work (175 public domain by age), the digital surrogate
(175 undetermined) and the transcription/OCR labour (175 undetermined).
`redistribution_allowed` is the conclusion from all three and is `unknown` on
175 of 176 resources. See `metadata/source_license_resolution.md`
for the per-provider reasoning and `expert_validation/RIGHTS_WORKSHEET.md` for
the work that would close it.

## Code and reproduction

All code is in `src/` and `qa/` under the licence in `LICENSE_CODE`.
Graph reconstruction from the released tables, recomputation of every derived statistic and regeneration of every figure are verified by the QA suite; canonical-table regeneration from raw source inputs requires the full internal profile, whose inputs are not in this distribution. See `docs/REPRODUCIBILITY.md` for the
reproduction paths this distribution does and does not support.

## Validation status

No annotation layer has been reviewed by a domain expert
(0 of 1,816 frame items adjudicated). A prioritized
356-item priority validation packet is provided in
`expert_validation/priority_validation_set/`. Every LLM-derived field carries an
explicit `*_reviewed = FALSE` flag.
