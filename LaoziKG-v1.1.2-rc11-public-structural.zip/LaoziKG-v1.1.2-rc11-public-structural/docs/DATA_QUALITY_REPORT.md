# Data Quality Report — LaoziKG v1.1.2-rc11

This report states the **current** quality state of the release, organized by the
six Technical Validation layers used in `expert_validation/README.md`. It is
rendered from `metadata/public_release_facts.json` and `qa/public_profile_qa_report.json`; it
does not carry history (see `CHANGELOG.md`) and every figure is recomputed at
release. Status vocabulary: **AUTOMATED PASS** (machine-checked on this build),
**PARTIAL** (some checks automated, judgment pending), **NOT PERFORMED**.

| Layer | Status | What exists |
|---|---|---|
| TV1 Structural integrity | AUTOMATED PASS | `qa/validate_dataset.py` (keys, foreign keys, enums, cross-table counts, review-flag uniformity, documented-figure guards) + executed clean-room regeneration + `qa/test_tools.py` |
| TV2 Text alignment | NOT PERFORMED (human) | 116 recovered instances gated out of defaults; dossier in `expert_validation/S06453_review_dossier.csv`; 7 diagnoses in `frame_alignment_diagnosis.csv` |
| TV3 Concept extraction | NOT PERFORMED (human) | `frame_mentions.csv`, 250 per specificity tier |
| TV4 Commentary | NOT PERFORMED (human) | `frame_commentary.csv`, 19 strata; quote provenance computed per record (below) |
| TV5 Candidate variants | NOT PERFORMED (human) | `frame_variants.csv`, P(genuine \| score) design |
| TV6 Ontology / metadata | NOT PERFORMED (human) | full-population frames: 176 work_type/textual_scope, 111 node_type, 67 relations, 75 person eras |

**Overall:** `qa/public_profile_qa_report.json` → `overall_release_status = NOT_READY_FOR_PUBLICATION`
while any human layer is NOT PERFORMED or rights are unreviewed (1 of 176 cleared).

## TV1 — Structural integrity (automated)

- Primary-key uniqueness on every table with a declared key; referential integrity for
  every foreign key across chapter_instances / sentences / authorship / commentary / links /
  mentions / loci / evidence / relations / aliases; enum conformance for alignment_status,
  unresolved_reason, alignment_review_status, text_provenance, match_specificity, variant_status,
  alias_type, attribution_status.
- Cross-table consistency: sentence-level occurrence sums equal chapter-level sums; default,
  recovered and unaligned mention files are mutually exclusive and jointly exhaustive by
  `alignment_review_status`; commentary_concept_links agree with commentary.concept_id.
- Review-flag uniformity: every `*_reviewed` column (work_type, textual_scope, witness_era,
  node_type, concept, definition, gloss, era) is FALSE on every row — no row can quietly
  claim review before one is recorded.
- Documentation guards: load-bearing figures in the rendered documents are compared against
  the tables; never-existed vocabulary presented as current fails the build; version and date
  strings agree across all publication-facing files.
- **Regeneration check** (no): `src/regenerate_tables.py` is run into a temporary
  directory from `legacy/v1.0.0_inputs/` and every regenerated canonical table is compared on
  rows, keys, columns and content. Files copied through unchanged (`wangbi_exegesis_source.parquet`,
  `candidate_concepts_oov.csv`) and derived reports are not content-compared. Status in
  `qa/public_profile_qa_report.json` → `rebuild_smoke_test`.
- Graph: 12 node tables / 17 relationship tables rebuilt from
  18 hashed inputs; `data/graph/build_report.json`.
- Checksums: `metadata/checksums.sha256` covers every release payload file; `src/make_release.py`
  re-verifies all of them after generation.

## TV2 — Text alignment

Chapter instances: 3,643 = 3,481 `original_deterministic` +
116 `auto_recovered_unreviewed` + 46 `not_aligned`.
Heading-only instances with no sentence rows are dropped at normalization (logged in
`data/_dropped_phantom_instances.csv`, a full-package diagnostic not carried in the public distribution). The five witnesses recovered in v1.1.2 are
excluded from `analysis_default_include` and from the default mention files until
`src/shipped_labels/alignment_review.csv` records an expert decision
(0 so far). Recovery scores are `anchor_coverage_score`
(matched / canonical clauses — a coverage ratio) and `identification_score` (string
similarity), neither a probability.

| Witness | Method | Chapters recovered |
|---|---|---:|
| S06453 | colophon_recovery | 74 |
| PC2517 | anchor_recovery | 21 |
| PC3237 | anchor_recovery | 6 |
| PC2577 | anchor_recovery | 8 |
| S02060 | anchor_recovery | 7 |

## TV3 — Concept extraction

Witness-text lexical mentions. Default set: 51,648 edges /
283,788 occurrences / 233,892 sentence rows over
109 of 111 concepts. Recovered-unreviewed (1,029 edges)
and unaligned (1,268 edges) are held in separate files.

| Specificity tier | Concepts | Edges | Occurrences |
|---|---:|---:|---:|
| `high` | 37 | 2,400 | 3,579 |
| `medium` | 39 | 13,679 | 49,213 |
| `low` | 33 | 35,569 | 230,996 |

### Three measures, and what each is for

| Measure | Column | Top concepts |
|---|---|---|
| Raw lexical occurrences | `raw_lexical_mentions` | 无、有、道、知、大、一 |
| High-specificity occurrences (names ≥2 chars) | `high_specificity_mentions` | 曲则全、反者道之动、不见可欲、众妙之门、上善若水、弱其志 |
| Rate per 10,000 searched characters | `mentions_per_10k_chars` | 无、有、道、知、大、一 (identical order to raw) |

The searched text of the default analysis set is 2,225,628 normalized
characters. Note what the normalized rate does and does not do: because every concept
shares that one denominator, `mentions_per_10k_chars` is a **monotone rescaling of the raw
count and reproduces the raw ranking exactly** (verified). It makes counts comparable
across corpora or subsets of different size; it does **not** correct the name-length
artefact. Only the specificity split does that, and the two orderings disagree sharply —
Spearman ρ = -0.655 between raw and high-specificity counts, with
0 concept(s) shared between the two top-10 lists.

Reporting rule: raw occurrence counts measure **lexical realization frequency** and are
dominated by high-frequency single-character concepts (81.4% of default
occurrences). They are not a measure of philosophical importance. Quote raw and
high-specificity counts together, per tier. At most
0.0% of matched text is Laozi base scripture (upper bound; median
per-instance bound 0.0); filter `text_composition`. Precision per tier
is unknown until TV3 is performed.

## TV4 — Commentary

2,386 records; commentator era resolved via aliases, and it differs from the edition's
era on 68.9% of rows where both are known — use `commentator_historical_era`.
Quote provenance is computed per record:

| text_provenance | Records |
|---|---:|
| `verbatim_contiguous` | 1,282 |
| `spliced_from_source` | 1,038 |
| `not_located` | 66 |

Gate on `citable_as_quote = TRUE` (1,282). `not_located` rows have source
character overlap 0.2745–0.8958 (mean
0.7201). Every gloss carries `gloss_generated_by` and
`gloss_reviewed = FALSE`; concept-link correctness and gloss faithfulness are unknown until
TV4 is performed.

## TV5 — Candidate variants

18,334 candidate variant events (`variant_status = candidate_auto_detected`,
`detection_method = difflib_char_diff_v1.0.0`) against `reference_text_id = WANGBI_CANONICAL`,
A further 3,493 structural-mismatch diagnostics share this schema but live in `derived_diagnostics/` (see its README): same detector, spans too long to be character-level variants. They are a diagnostic on the alignment layer, not additional variants, and have no shared identifier space with `variants.parquet`.
`variant_detection_score` has six heuristic levels and no measured discriminative power yet.
Detection ran only where `chapter_instances.variant_detection_run = TRUE`; recovered
instances have no variants and must not enter density comparisons.
7 LLM explanations cover 475 rows
(`explanation_source`).

## TV6 — Ontology and metadata

All labels are LLM-assigned and unreviewed: `work_type` / `textual_scope` on 176
resources, `node_type` on 111 concepts (20 hand-authored seeds,
91 LLM-expanded rows whose name/category/definition are also unreviewed),
67 concept relations, `person_historical_era` on 75 named
persons (7 dynastic-transition figures flagged `era_disputed`).
`witness_era` is the bibliographic record's own claim (raw and orthographically normalized
copies; ambiguous dual-dynasty labels flagged, not resolved).

## Rights

`data/source_rights.csv`: 176 rows, 1 cleared,
175 not reviewed, 18 with only a low-confidence
provider inference. This is a publication gate independent of every layer above.

## Candidate scholarly claims

10 AI-generated claim summaries in `derived_unverified/`, all
`AI_GENERATED_UNVERIFIED`, `citable_as_scholarship = FALSE`. Not part of the primary data.

### Next milestone: the priority validation set

0 of 356 items adjudicated (0.0%).
`expert_validation/priority_validation_set/` is a **filtered mirror** of the full internal package's 400-item priority validation set: 356 of those items, with every row belonging to a `reference_only` resource removed along with the resource. It is not an independent sample and **must not be used to estimate precision** — rights filtering removed rows unevenly, so the equal allocation the design specifies no longer holds here (see `expert_validation/priority_validation_set/mirror_allocation.csv` for the strata actually present). Statistical estimates come from adjudicating the full internal 400-item sample; this copy is for auditing the design, the record identifiers, the question schema and the scorer.
