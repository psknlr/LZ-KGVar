# LaoziKG v1.1.2-rc11 — Provenance and Limitations

This document states, per table, how the data was produced and what has not
been verified. It is deliberately blunt: several tables contain machine-generated
content that must not be cited as scholarship, and one contains machine text
that could previously be mistaken for historical quotation.

> **Scope of the counts in this document.** They describe the **full internal
> construction corpus** — the material the pipeline actually processed — because
> that is what a provenance record has to account for: a row produced by a
> language model was produced whether or not it is redistributable. A
> distribution profile retains a filtered subset of those rows, so its own
> totals are smaller. For the counts of the distribution you are holding, read
> the release-facts file in `metadata/` (a profile ships
> `public_release_facts.json`, the full package `release_facts.json`); the
> per-table `distinct_count` in `metadata/data_dictionary.csv` is likewise
> measured on the tables present here.

## 1. Provenance by table

| Table | Production method | Human reviewed |
|---|---|---|
| `versions.csv` | Deterministic parse of 175 document headers + a bibliographic list; `work_type`/`textual_scope` LLM-assigned | Metadata: yes (source headers). `work_type`: **no** |
| `persons.csv` | Rule-based parse of author strings + anonymity placeholders | **No** |
| `authorship_edges.csv` | Rule-based role-verb parse | **No** |
| `chapter_instances.parquet` | Deterministic tiered alignment (heading match, then fuzzy content match against the Wang Bi reference) | **No** |
| `sentences.parquet` | Deterministic sentence segmentation | **No** |
| `variants.parquet` | Deterministic `difflib` diff against the Wang Bi reference; `semantic_explanation` LLM-generated for 7 character pairs | **No** |
| `concepts.csv` | 15 hand-authored seed concepts; 96 LLM-expanded; `node_type` LLM-assigned | **No** |
| `concept_chapter_mentions.csv` | Deterministic substring matching (no LLM) | **No** |
| `concept_sentence_mentions.parquet` | Deterministic substring matching (no LLM) | **No** |
| `concept_canonical_chapters.csv` | Parsed from curated concept definitions | **No** |
| `concept_relations.csv` | 32 deterministic name containment; 35 LLM semantic judgment | **No** |
| `commentary.csv` | 2,627 of 2,635 records LLM-extracted; quote/interpretation split computed deterministically | **No** |
| `evidence.parquet` | Derived from `commentary.csv` | **No** |
| `provenance_assertions.csv` | Conservative same-work groupings + a manually verified same-title cross-reference list | Partly (source list was manual) |
| `candidate_scholarly_claims.csv` | **Entirely LLM-generated** | **No** |
| `candidate_scholarly_claim_evidence.csv` | **Entirely LLM-generated** | **No** |
| `wangbi_exegesis_source.parquet` | Structural parse of the Wang Bi 通释 document | **No** |

Models used: MiniMax-M3 (`work_type`, `node_type`, concept expansion, semantic
concept relations, 489 commentary glosses, all scholarly claims); an earlier
LLM-assisted batch pass (`llm_assisted_batch_v1`, 2,138 commentary glosses).

**No part of this dataset has been reviewed by a domain expert.** Every
LLM-derived field ships with an explicit `*_reviewed = FALSE` or
`manual_status = unreviewed` flag.

## 2. What must not be done with this dataset

1. **Do not cite `candidate_scholarly_claims.csv` as scholarship.** All 10
   records are `claim_status = AI_GENERATED_UNVERIFIED`,
   `citable_as_scholarship = FALSE`. The named `proponents` and `opponents` have
   **not** been checked against the literature; some attributions may be wrong
   or invented. Treat these as prompts for a literature search, never as a
   finding.
2. **Do not quote `llm_interpretation` as a commentator's words.** 1,263 of
   2,635 commentary records (`spliced_from_source` + `not_located`) are not
   verbatim source spans. Gate on `citable_as_quote = TRUE`.
3. **Do not report single-character concept counts as philosophical usage.**
   Filter `MENTIONS_CONCEPT.match_specificity`.
4. **Do not treat `lineage_branch` as a stemma.** It is a coarse heuristic
   grouping, not a reconstructed transmission history.
5. **Do not include unaligned units in chapter-level statistics.** Filter
   `analysis_default_include = TRUE`.

## 3. Known limitations

- **Scripture and commentary are interleaved.** In most of the 175 source witnesses + 1 modern derived resource the
  base text and the commentator's prose are not distinguished by any surviving
  formatting. Variant detection therefore has irreducible noise, which is why
  `variants.confidence` is calibrated by length ratio and why diff spans beyond
  a threshold are routed to `structural_mismatches` instead of being reported as
  variants.
- **`category_tags` is 48.9% null** (86 of 176). Not imputed.
- **7 witnesses may be alignment failures rather than non-DDJ texts.** Of the 47
  unaligned witnesses, 40 are non-DDJ genres (expected). The other 7 (`PC2517`,
  `PC2577`, `PC2823`, `PC3237`, `S04681`, `S02060`, `S06453`) are classified as
  DDJ commentaries that *should* have chapters, and carry
  `unresolved_reason = possible_alignment_failure_review_needed`.
- **2 concepts are not textually attested.** `正奇相成` and `强弱之变` are
  analytic labels that occur nowhere in the corpus
  (`is_textually_attested = FALSE`); `attestation_note` gives the closest
  attested wording.
- **`concepts.category`/`subcategory` are unnormalized.** 29 distinct raw
  category values, including some that are bare concept names. Retained only for
  traceability to v1.0.0; use `node_type`.
- **`variants_detected.parquet` was dropped from this release.** It contained
  41,172 rows whose `variant_id` values had **zero** overlap with the 20,124 in
  `variants.parquet` — two disjoint detection runs, only one of which was ever
  loaded into the graph. Shipping both invited double counting. `variants.parquet`
  is authoritative; it is the one carrying the curation fields.
- **`wangbi_commentary.csv` was dropped from this release.** Its 497 rows were
  all already present in `commentary.csv`, which invited double counting. Query
  `commentary.csv` with `version_id = 'WANGBI_TONGSHI_2026'` instead.

## 4. Defects corrected relative to v1.0.0

Each was reproduced against the v1.0.0 files before being fixed.

| # | Defect | v1.0.0 | v1.1.0 |
|---|---|---|---|
| 1 | Concept mentions covered 14 of 111 concepts | 11,334 rows, 14 concepts | 60,096 rows, 109 attested concepts + 2 flagged unattested |
| 2 | `chapter_count_*` disagreed with chapter data for 132/176 textual resources (175 historical witnesses + 1 modern derived) | 2 conflated fields | 4 explicit fields; 0 mismatches |
| 3 | 47 unaligned units mixed into chapter analysis | undifferentiated | `is_chapter_aligned`, `analysis_default_include`, `unresolved_reason` |
| 4 | Scholarly claims presented without status | `manual_status=unreviewed` only | renamed `candidate_*`; `claim_status`, `citable_as_scholarship`, `usage_restriction` |
| 5 | Commentary quote fidelity unknown | `unchecked` on all 2,635 | computed: 1,372 verbatim / 1,191 spliced / 72 unlocated |
| 6 | Flat ontology mixing strata | single `category` string | 10 `node_type` strata + 67 typed relations |
| 7 | `canonical_chapters` in two serializations | mixed list/CSV string | normalized relation table |
| 8 | `ci.` / `c.` column prefixes | inconsistent | stripped; one canonical name per table |
| 9 | **Build script produced an empty graph and exited 0** | invalid Cypher, silent `except: pass`, missing inputs skipped | rewritten; loads all 27 tables; fatal on missing input |
| 10 | No build provenance | none | `build_report.json`: counts, input SHA256, library versions |
| 11 | Dependencies incomplete/undeclared | `.bat` claimed auto-install | pinned `requirements.txt`; no auto-install claim |
| 12 | 54 versions had no authorship edge | absent | explicit `ANONYMOUS`/`UNKNOWN` edges + `attribution_status` |
| 13 | Duplicate subsets invited double counting | `wangbi_commentary.csv`, `variants_detected.parquet` | removed; documented above |
| 14 | Release metadata incomplete | partial | data dictionary, schema, provenance, manifest, checksums, validation report |

### Defects found during this revision, not in the original audit

| # | Defect | Detail |
|---|---|---|
| 15 | **75.4% of `GLOSSES` edges were false** | `commentary_glosses.parquet` fanned 2,635 records into 10,715 rows; only 2,635 had `glossed_concept_id == concept_id`. A gloss on 圣人 was wired to 道, 德, 无, 有, 一, 柔, 智 and others. The 8,080 spurious edges would have inflated every concept-level aggregate ~4x. |
| 16 | **The Wang Bi exegesis source text was missing** | 423 commentary records were extracted from the Wang Bi 通释 document, but v1.0.0's `wangbi_exegesis_chapters.parquet` had been overwritten with a chapter-instance table. No copy of the source text shipped, so those records were unverifiable. Restored as `wangbi_exegesis_source.parquet`. |
| 17 | **A concept name was misspelled** | `抟气致柔` matched 0 sentences; the Laozi ch.10 wording is `專氣致柔` / `专气致柔`, which matches 167. Corrected via `src/concept_corrections.csv`. |
| 18 | **`authorship_edges.edge_type` used two vocabularies** | `authored`/`annotated` (138 rows) alongside `AUTHORED_BY` (54). Loading naively yielded `ANNOTATED_BY = 0`. Normalized to lowercase; the builder now raises on an unmapped value. |
| 19 | **Two disjoint variant tables** | See §3. |

## 5. Reproducing the dataset

```bash
pip install -r requirements.txt

python src/normalize_tables.py --src <v1.0.0 data> --out data
python src/extract_mentions.py --data data
python src/separate_commentary_provenance.py --data data
python src/build_graph.py --data-dir data --db-path data/graph/laozi_kg.kuzu
python src/make_metadata.py --root .
python qa/validate_dataset.py --data data --out qa/validation_report.json
```

Stages 1-3 and the graph build are deterministic and reproduce exactly.
`work_type`, `node_type` and the 35 LLM concept relations are **not**
reproducible from these scripts alone — they were produced by MiniMax-M3 calls
at revision time and are shipped as data. Regenerating them requires API access
and will not reproduce identical labels.

## 6. Outstanding work before publication

1. Expert review of the 10 candidate scholarly claims — or removal from the
   release. This is the largest remaining risk for peer review.
2. Expert spot-check of `work_type` and `node_type` (176 + 111 labels).
3. Adjudication of the 7 possible alignment failures.
4. Normalization or removal of the legacy `concepts.category` values.
5. Disambiguation strategy for single-character concept mentions.

---

# v1.1.1-rc additions

## 7. Person eras were systematically wrong in v1.1.0

`Person.era` was **inherited from the linked witness's era**, not the figure's
own dates — it matched a linked version's era on 58.9% of authorship edges. This
produced 老子 = 宋, 玄奘 = 宋, 唐玄宗 = 宋, 庄子 = 清.

The field family is now split:

| Field | Meaning |
|---|---|
| `Version.witness_era` | The era of *this witness/edition*, as the bibliographic record claims |
| `Person.person_historical_era` | The era the *figure* lived in |
| `Commentary.commentary_witness_era` | Era of the edition the gloss was drawn from |
| `Commentary.commentator_historical_era` | Era of the *commentator* |

**This mattered downstream.** Among commentary rows where both eras are known,
**67.4% (1,297/1,925) have a commentator era different from the witness era**.
Any v1.1.0 "cross-era" commentary view — including the shipped concept-by-era
heatmap — was plotting *edition* era while labelling it 时代.

`person_historical_era` was assigned by MiniMax-M3 and cross-checked against an
independent 37-figure reference set: **81% agreement** after script
normalization. The 7 disagreements are recorded in
`person_historical_era_alt` with `era_disputed = TRUE`; 5 of them are dynastic-
transition figures whose lifespans straddle two dynasties (葛玄 164–244,
顧歡 420–483, 李道純 1219–1296, 謝守灝 1244–1311). `era_reviewed = FALSE`
everywhere. Assignments are auditable in `src/shipped_labels/person_eras.csv`.

**`witness_era` is retained unmodified and is unreliable per row.**
`versions.csv` contains both 南朝宋 (5) and 南宋 (3), and the 南朝宋 group
genuinely mixes Liu Song (顧歡, 420–483 — correct) with Southern Song
(范應元's 古本集注 — wrong). It is the source's own claim, not a verified date.

## 8. Person entities were not normalized

77 person nodes collapsed to **77**. Role tokens were embedded in 7 names
(王弼註, 李榮註, 傅奕校定, 王元貞校訂, 吳汝綸勘, 顧歡等人, 劉惟永編) and now
live on the authorship edge. One attribution prefix was stripped (題河上公).
Seven identity groups were merged — including three the audit did not name:
**老子/老聃/李耳 were three nodes for one figure**, `徐學謨徐學謨` was a
doubled-name parse error duplicating an existing 徐學謨, and a version
*description* had become a Person node. All surface forms are preserved in
`person_aliases.csv`.

## 9. The mention layer measures witness text, not Laozi base text

Matching runs over the whole witness text, in which base scripture, commentary
and editorial matter are interleaved and undifferentiated. Measured:

- aligned chapter-instance text: **3,055,804 chars**
- canonical base-text equivalent (same normalization — script-converted and
  punctuation-stripped on BOTH sides): **257,574 chars**
- so **at most 8.4%** of the searched text is Laozi base scripture

Median per-instance `base_text_share_upper_bound` is **0.196**; **641 of
4,010** instances are scripture-dominant (1,791 mixed, 1,530
commentary-dominant, 48 unknown). *Correction:* v1.1.1 printed 10.0%, median
0.237 and bands 683 / 1,952 / 1,211 — it compared punctuation-bearing canonical
text against punctuation-stripped instance text, inflating the ratio. The
direction of the finding is unchanged and slightly stronger.
`chapter_instances` now carries `base_text_share_upper_bound` and `text_composition` so
this is filterable rather than a caveat to remember.

Call this layer **witness-text lexical concept mentions**, never "canonical
Laozi concept frequencies".

## 10. Raw mention counts must not be read as prevalence

`match_specificity` (renamed from `match_reliability`, which invited reading it
as measured precision — it is derived from name length) splits the layer:

| Tier | Concepts | Mentions |
|---|---:|---:|
| `high` (≥3 chars) | 37 | 4,113 |
| `medium` (2 chars) | 39 | 60,810 |
| `low` (1 char) | 33 | 300,586 |
| **total** | **109** | **365,509** |

These are the **post-exclusion** counts shipped in
`concept_mention_statistics.csv`, i.e. the default analysis set — aligned, original-deterministic instances only (see §13 and §15). Adding
the 16,058 unaligned occurrences back would give 381,567; the 2,753 occurrences from unreviewed recovered instances are held in concept_recovered_mentions.csv (v1.1.2-rc3 gating).

**82.25% of raw mentions come from single-character names.** The two tiers give
almost disjoint rankings:

| Rank by raw count | Rank by high-specificity count |
|---|---|
| 无, 有, 道, 知, 大, 一, 德, 天下 | 天下, 圣人, 万物, 无为, 天地, 自然, 无名, 不争 |

Only 天下 appears in both. A claim like "道 is the most prevalent concept" drawn
from raw counts is a string-matching artifact. `concept_mention_statistics.csv`
ships both tiers.

## 11. Corpus composition

**175 historical source witnesses + 1 modern derived resource**
(`WANGBI_TONGSHI_2026`, a 2026 compilation). Use `resource_class` /
`is_source_witness`.

`work_type` distribution over all 176 resources:

| `work_type` | Count |
|---|---:|
| `ddj_commentary` | 113 |
| `manuscript_composite` | 22 |
| `related_laozi_text` | 15 |
| `canonical_ddj` | 10 |
| `apocryphal_text` | 9 |
| `fragment` | 3 |
| `biography_text` | 2 |
| `ritual_text` | 2 |

Only **10** resources are `canonical_ddj` (a Daodejing text proper) and 113 are
commentary editions; **53 are neither**, carrying one of the six other genre
labels. The corpus is therefore *Laozi-related textual resources*, not
*editions of the Tao Te Ching*.

There is **no `not_ddj` label** in the data — earlier drafts of this document
referred to one, and to a count of 36. Both were wrong: the value does not
exist in `versions.csv`, and the non-DDJ-genre total is 53.

All 176 `work_type` labels are LLM-assigned with `work_type_reviewed = FALSE`
and must not be presented as philological fact.

## 12. Commentary covers 33 of 111 concepts

The commentary layer is **selective, not ontology-wide**: 78 of the 111
concepts have no gloss. "111-concept ontology with commentary evidence" would
misdescribe it.

## 13. Unaligned units are structurally excluded

`concept_chapter_mentions.csv` now holds aligned chapters only
(59,648 rows). The 1,306 rows / 16,058 mentions (4.89% of raw) from
`chapter_num = -1` moved to `concept_unaligned_mentions.csv`.

## 14. Alignment-failure diagnosis

See `data/alignment_failure_diagnosis.csv`. Of the 7 flagged witnesses:

- **5 are confirmed alignment failures** with recoverable base text. S06453
  carries 10 exact canonical chapter openers in 5,086 chars (≈ a complete
  Daodejing); PC2517 carries 4 in 10,676 chars; PC3237, PC2577, S02060 carry 1–2.
- **PC2823** is not a failure: zero openers, body is continuous 疏 exposition
  with no quoted base text — nothing to align.
- **S04681** — a finding beyond the audit — is titled 老子德經下卷上河上公注 but
  its 244-char body is Buddhist doctrinal vocabulary (真如, 因緣, 法定性),
  indicating a mis-catalogued sheet or composite manuscript.

Recovery is **not** applied: it would materially change the chapter-instance and
mention layers and should follow expert confirmation.
`expert_reviewed = resolution_applied = FALSE`.

## 15. The graph is a projection, not a lossless mirror

The Kuzu snapshot is a **graph-oriented projection** of the canonical tables.
Columns present in the released tables but not carried into the graph include
`Version.id_is_numeric_string`, `Version.work_type_source`,
`Concept.node_type_source`, `Commentary.source_match_scope` (loaded in v1.1.1)
and the candidate-claim review fields. The **tables are authoritative**; the
graph is for traversal. The build report's input-hash list covers graph inputs
only (17 files); `metadata/checksums.sha256` covers every released file.

## 16. Ghost input removed

v1.1.0's `build_graph.py` read and hashed `version_provenance_edges.csv` but
never wrote its edges, while `query_api.py` queried a `SAME_WORK_EDITION` table
no build created. The file is now in `legacy/` and is not a graph input; the
queries traverse `ProvenanceAssertion` instead.


---

# v1.1.2-rc2 additions

## 15. Alignment recovery for the five confirmed failures

The five witnesses diagnosed in v1.1.1 as genuine alignment failures were
re-segmented by `src/recover_alignment.py` (pipeline stage 1a; deterministic, no
LLM). Full per-witness figures: `data/alignment_recovery_report.csv`; per-segment
detail for S06453: `data/alignment_recovery_segments_S06453.csv`.

| Witness | Method | Chapters | Chars aligned / body | Residual | Standard order | Mean confidence |
|---|---|---:|---|---:|---|---:|
| S06453 | colophon_recovery | 74 | 4,655 / 5,079 (91.7%) | 165 | no | 0.813 |
| PC2517 | anchor_recovery | 21 | 10,372 / 10,676 (97.2%) | 304 | yes | 0.305 |
| PC3237 | anchor_recovery | 6 | 2,333 / 2,464 (94.7%) | 131 | yes | 0.344 |
| PC2577 | anchor_recovery | 8 | 2,493 / 2,729 (91.4%) | 236 | yes | 0.419 |
| S02060 | anchor_recovery | 7 | 2,209 / 2,594 (85.2%) | 387 | yes | 0.385 |

**Two methods.** The four commentary editions (李榮注 / 義疏 fragments) use
*anchor recovery*: canonical clauses locate chapters, the start is the earliest
hit in the densest hit cluster, spurious anchors are dropped only when
inconsistent with both positional neighbours, and a sentence that straddles a
boundary goes to the chapter whose anchor it contains. Confidence for these is
`hits / clauses` and is LOW BY CONSTRUCTION (0.3–0.4): commentary is interleaved
and Dunhuang orthography (𢙣/恶, 扵/于, 𣸪/复, 𠩄/所) defeats exact clause matching.
It measures anchor density, not segmentation accuracy.

S06453 uses *colophon recovery*: the scribe wrote a character-count colophon
(五十字, 廿六字 …) after every chapter — 78 of them — so the manuscript's own
delimiters drive the segmentation and canonical text only *identifies* each
segment (`fuzz.ratio`, min 48.8, median 82). The scribe's stated count agrees
with the actual count within ±2 characters on 68 of 78 segments; the four
largest mismatches are scroll-level totals (115–199 字), correctly left
unassigned. One segment lacked its colophon and held chapters 36 + 57 merged
(stated 85, actual 137); it was split at the start of 57 (55 / 86 chars against
canonical 56 / 88). Result: 74 chapters — all but 1–7, lost with the scroll head
— in a **non-standard order 8–36, 57–69, 37–56, 70–81**. The 13 residual
sentences are the scroll's own apparatus: a dated colophon transmitted as **大唐天寶千載 — 千 read by us as 十, i.e. Tianbao 10 = 751 CE, because the cyclical year 歳次辛卯 and 正月乙酉朔 fit 751 (a specialist should confirm) —
炖煌郡炖煌县玉関乡**, the line 五千文上下二合八十一章四千九百九十九字, and the title
太极左仙公序系师定河上真人章句老子道德经上下卷. These identify the copy as a
系师定本 / 河上公 tradition text and should be examined by a Dunhuang specialist;
they are observations from the text, not a catalogue determination.

**Consequences.** ChapterInstance 3,894 → 4,010 (aligned 3,847 → 3,963);
Sentence 224,753 → 224,794 (41 sentences straddling a colophon were split into
`<id>-a` / `<id>-b`; no other sentence id changed). Concept mentions for the new
instances were regenerated by the normal stage 2. **Variants were NOT
regenerated** for recovered instances — the variant layer remains the v1.0.0
generation-stage output. `versions.unresolved_reason` for the five is now
`recovered_v1.1.2_residual_unanchored_text`; the two other diagnosed cases
(PC2823 commentary-only, S04681 catalogue mismatch) are unchanged.

Every recovered instance carries `segmentation_method` =
`anchor_recovery_v1.1.2` / `colophon_recovery_v1.1.2` (`_merged_split` for the
36+57 pair) and `recovery_reviewed = FALSE` in the report. Re-running the
pipeline reproduces this exactly (QA `rebuild_smoke_test`).


Default-set mention rows: 58,619.

## 16. v1.1.2-rc3: recovered instances gated out of the default set

The 116 instances recovered in §15 are algorithmic output that no
expert has confirmed. From rc3 they carry
`alignment_review_status = auto_recovered_unreviewed`, are **excluded** from
`analysis_default_include`, and their mentions live in
`concept_recovered_mentions.csv` / `concept_sentence_recovered_mentions.parquet`
(1,029 edges / 2,753 occurrences), so default statistics equal
the pre-recovery figures exactly. `recover_alignment.py` no longer writes the
legacy `confidence` column for these rows; `anchor_coverage_score` (matched /
canonical clauses) and `identification_score` (string similarity) name what was
actually measured — neither is a probability. `variant_detection_run = FALSE` on
every recovered instance. A heading-only phantom instance
(`7489099792547577906-CH006`, the 8-character heading 谷神不死天長地久 of an edition merging
chapters 6–7) is dropped at normalization; ChapterInstance is 4,009.
Expert decisions enter through `src/shipped_labels/alignment_review.csv`
(0 so far) and flip instances into the default set on
regeneration.
