# LaoziKG v1.1.2-rc11 — Reproducibility

> **Scope of this copy.** This distribution does NOT contain the raw inputs. Reproducible here: rebuilding the graph from the shipped tables, recomputing the derived statistics and figures, and re-running the QA suite. Not reproducible here: regenerating the tables from raw sources, and any check that requires the withheld character streams.
> `metadata/public_release_facts.json` carries `regeneration_available = no` so a reader can check this mechanically.


"Reproducible" means three different things for this package. Say which one.

## 1. Graph rebuild — deterministic, verified on every build

```bash
python src/build_graph.py --data-dir data --db-path data/graph/laozi_kg.kuzu
```

Loads the shipped `data/` tables into Kuzu. `data/graph/build_report.json`
records per-table counts, the SHA256 of all 17 graph inputs and library versions,
so a rebuild can be diffed against the published one. Tables are authoritative;
the graph is a projection (`docs/schema.md` §7).

## 2. Table regeneration — deterministic, EXECUTED by the QA suite

```bash
python src/regenerate_tables.py --src legacy/v1.0.0_inputs --out /tmp/regen
```

Stages, in an order that matters (1a adds `alignment_review_status`; 1b applies expert decisions from `src/shipped_labels/alignment_review.csv`):

| # | Stage | Produces |
|---|---|---|
| 1 | `normalize_tables.py` | v1.1 column semantics; claim tables → `derived_unverified/` |
| 1a | `recover_alignment.py` | re-segments the 5 confirmed alignment failures (anchor / colophon) |
| 1b | `attach_shipped_labels.py` | joins LLM labels from `src/shipped_labels/`; recomputes alignment counts and status |
| 2 | `extract_mentions.py` | witness-text mentions, aligned/unaligned split at both granularities, statistics |
| 3 | `separate_commentary_provenance.py` | `source_quote` / `llm_interpretation` / `text_provenance` |
| 4 | `canonicalize_persons.py` | 77 canonical persons, 90 aliases |
| 5 | `add_anonymous_authorship.py` | ANONYMOUS / UNKNOWN placeholders; `attribution_status` |
| 6 | `derive_instance_fields.py` | `is_chapter_aligned`, `base_text_share_upper_bound`, `text_composition` |
| 7 | `attach_person_eras.py` | historical eras + reference provenance |
| 8 | `derive_commentary_fields.py` | commentator resolution, era fields, review flags, evidence quote kinds |
| 9 | `build_rights_ledger.py` | `source_rights.csv` with provider inference basis |

After regeneration the release flow computes `metadata/public_release_facts.json` and renders the publication documents from `docs/templates/` (`src/make_release_facts.py`, `src/render_docs.py`).

`qa/validate_dataset.py` **runs this pipeline into a temporary directory on every
invocation** and compares every regenerated canonical table on row count, key set, column set
and full content (files copied through unchanged and derived reports are not content-compared). `rebuild_smoke_test` is `PASS` only if the subprocess exits 0
and every table agrees; `FAIL` carries the per-table diff; `NOT_TESTED` when
`legacy/v1.0.0_inputs/` is absent (and `NOT_TESTED` never yields a ready
release). In v1.1.1 this status was a literal string in the code; it is now a
measurement. Pass `--no-rebuild` for a quick run (status becomes `NOT_TESTED`).

What this does **not** regenerate: the LLM-assigned labels themselves. They ship
in `src/shipped_labels/` (`work_type`, `node_type`, 35 of 67 concept relations,
person eras, alignment diagnoses) and are *joined*, not recomputed. Re-running
the LLM would not reproduce them.

## 3. Generation from raw text — NOT reproducible from this package

The scripts that first produced the text layer from the DOCX corpus are in
`legacy/generation_v1.0.0/`. They cannot regenerate the current tables (they
write 6 of 12 ChapterInstance fields and 9 of 19 Variant fields against a
different reference id), and the raw corpus is not redistributed because its
rights are undetermined. The variant layer in particular is a v1.0.0
generation-stage output carried forward, extended by `normalize_tables.py`, and
not regenerated for the 116 instances recovered in v1.1.2.

## Software tests

`qa/test_tools.py` asserts non-empty, correctly shaped results from every tool
module against the shipped graph (exit 1 on failure). It exists because v1.1.1
tested the modules for "no exception" only, which hid a provenance query that
had returned empty for every version since v1.1.0.

## Environment

`requirements.txt` is the single source for dependency pins (it is pip-installable;
v1.1.1's copy carried a `python_requires` line that pip rejected). Tested with
Python 3.13; `python >= 3.11` is required. Release flow: `python
src/make_release.py --root .` (build → QA → tool tests → freeze report → metadata →
checksums → verify). Every file in `metadata/checksums.sha256` is re-verified
before the flow reports success.
