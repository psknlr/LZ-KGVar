# Data licensing and redistribution rights — LaoziKG v1.1.2-rc11

**This is the PUBLIC STRUCTURAL RELEASE, and it is the distribution that may be
published.** It contains no third-party transcribed character stream: the
undetermined layer described below has been withheld from it rather than
licensed. The rights review remains open, but it does not gate this
distribution — it gates the full internal package, which carries the
transcriptions and must not be deposited until the review is complete.

Licence for what is here: **CC BY 4.0** for the structured annotations and
derived layers (the authors' own work), and `LICENSE_CODE` for the code.

## 1. Two separable layers

| Layer | What it is | Rights position |
|---|---|---|
| **Original structured annotations** | Our schema, concept ontology, alignment, variant detection, mention layer, commentary provenance classification, graph projection, code | **CC BY 4.0** (annotations) / see `LICENSE_CODE` (code). These are our own work. |
| **Underlying source transcriptions** | The digitized text of the 175 historical witnesses | **UNDETERMINED — and therefore WITHHELD from this distribution.** Only the authors' own compilation carries text here. See `data/source_rights.csv` and `PROFILE_NOTICE.md`. |

## 2. Why the source layer is not cleared

The pre-modern *works* are out of copyright by age. That says nothing about the
**digitized transcriptions** used here, which were obtained from third-party
platforms. A transcription, critical edition, or OCR output can carry its own
rights in many jurisdictions, independently of the age of the underlying text.

`data/source_rights.csv` records one row per resource with
`redistribution_status`. **1 of 176 rows are `cleared`; the remaining 175 are `not_reviewed`.** The cleared row is the authors' own compilation, settled because the authors are the rightsholders — no third-party provider's terms have been determined. Determining this requires each provider's terms of use and
institutional sign-off — neither of which can be established from inside the
dataset, and neither of which has been done.

Sources requiring determination include (provider inferred from catalogue id):

Provider summary, rendered from `data/source_rights.csv` at release (inferred from
catalogue ids, shelfmarks and edition fields; see `provider_inference_basis` /
`provider_inference_confidence` per row — an inference, not a rights determination):

| Provider (bucket) | Resources |
|---|---:|
| Shidian Guji (识典古籍) — Daozang/Xu Daozang/Zangwai/Siku/Sibu/HY transcriptions | 72 |
| Pelliot chinois, BnF (Dunhuang) | 32 |
| CADAL digital library | 26 |
| Other / undetermined series (see source_rights.csv) | 23 |
| Stein collection, British Library (Dunhuang) | 22 |
| Dataset authors (derived resource) | 1 |

18 rows carry only a low-confidence provider inference.
Redistribution status: **1 of 176 cleared**; 175 not reviewed.

### The three rights layers, tracked separately

`source_rights.csv` separates what can be established from what cannot:

| Layer | Column | State in this release |
|---|---|---|
| A — the underlying pre-modern work | `original_text_public_domain` | `yes_by_age` for 175 witnesses (determinable from the work's age) |
| B — the digital surrogate / database layer | `digitization_rights` | `not_determined` for 175 witnesses |
| C — transcription, OCR and collation labour | `ocr_rights` | `not_determined` for 175 witnesses |
| Conclusion | `redistribution_allowed` | **`unknown` for 175 of 176** |
| Licence reasoning | `license_basis` | `not_established` for 175 rows |

A pre-modern work being out of copyright by age settles layer A only. Layers B and C
depend on each provider's terms of use, which are not in this package and cannot be
determined from inside the dataset. **The question "may users legally redistribute
the released files?" therefore has no answer yet for the source transcriptions** —
it is answerable only for the dataset authors' own annotations, code and the modern
derived resource. `expert_validation/RIGHTS_WORKSHEET.md` sets out exactly what must
be established, per provider bucket, to close this.

## 3. Before publication

1. Complete `data/source_rights.csv`: obtain each provider's terms, record
   `digitization_rights`, `redistribution_status`, `license`, `evidence`,
   `reviewer`, `review_date`.
2. For any resource that cannot be cleared, either remove its text from the
   release or ship only derived annotations (offsets, counts, identifiers)
   without the transcription.
3. Only then state a dataset-level license.

Zenodo supports declaring multiple licenses on one record, so the annotation
layer and the source layer can be published under different terms rather than
forcing a single blanket claim.

## 4. What we do NOT claim

We do not claim that CC BY 4.0 covers the source transcriptions. Any
dataset-level "CC BY 4.0" label seen elsewhere in earlier metadata applied to
our own annotation and code contributions only, and that ambiguity is corrected
in this release candidate.
