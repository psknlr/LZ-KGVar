# LaoziKG: A Provenance-Aware Multi-Version Textual Knowledge Graph of the Laozi (Dao De Jing)

**Version 1.1.2-rc11**

A **provenance-aware, multi-version textual knowledge graph** of the *Laozi*: every
assertion is tied to the witness it came from, the era of that witness is kept
distinct from the era of the person who wrote it, and machine-derived layers are
gated out of default analyses until a human confirms them. The contribution is
that design, not the corpus size.

Built over 175 historical source witnesses plus
1 modern derived resource of the *Laozi* (《老子》/《道德經》), covering text,
candidate-variant, concept and commentary layers with an evidence-chain design.
The variant layer holds automatically detected candidate difference events; none is
philologically confirmed.

Backend: [Kuzu](https://kuzudb.com) (embedded, Cypher-compatible, no server).

> **Every number in this file is rendered from `metadata/public_release_facts.json`**, which is
> computed from the shipped tables on each release. Do not edit README.md directly —
> edit `docs/templates/public/README.md.tmpl`.
>
> **This is the PUBLIC STRUCTURAL RELEASE.** Every count below is measured in THIS
> distribution, from `metadata/public_release_facts.json`. Third-party transcribed
> text is withheld (see `PROFILE_NOTICE.md`); the full internal package has more
> rows in the text-bearing tables and is not publishable until the rights review
> is complete.

## Contents

```
data/                 release tables (27) — structure, identifiers, offsets, annotations;
                      transcribed source text withheld except the authors' own compilation
src/                  query tools + the profile generator and pipeline modules
src/shipped_labels/   every LLM-assigned label, in one auditable place
qa/                   validate_dataset.py, validate_public_profile.py (this profile's own
                      profile-specific public-release QA suite) + both reports
docs/                 schema, provenance, dataset card, quality report, availability
metadata/             public_release_facts.json (every figure in these documents),
                      data dictionary, manifest, checksums
expert_validation/    Technical Validation frames + scorer — 0 of
                      1,816 items in this profile adjudicated
figures/              the six release figures (generated from structured data)
derived_unverified/   AI-generated scholarly-claim candidates — not primary data
PROFILE_NOTICE.md     what is withheld, and which reproduction paths hold here
```

Not in this distribution: `legacy/` (raw regeneration inputs), the prebuilt
Kuzu database `data/graph/laozi_kg.kuzu`
(prebuilt database) and the withheld character streams. `PROFILE_NOTICE.md` states
the consequence for each reproduction path.


## Quick start

No prebuilt database ships here, so build it from the shipped tables first — one
command, deterministic, about a minute:

```bash
pip install -r requirements.txt
python src/build_graph.py --data-dir data --db-path data/graph/laozi_kg.kuzu
python -c "
import kuzu
db = kuzu.Database('data/graph/laozi_kg.kuzu'); conn = kuzu.Connection(db)
r = conn.execute('MATCH (v:Version) RETURN count(v)')
print('versions:', r.get_next()[0])
"
```

Verify what you received, and check this profile's own invariants:

```bash
python - <<'SH'
import hashlib, os
man = {l.split('  ',1)[1].strip(): l.split('  ',1)[0]
       for l in open('metadata/checksums.sha256', encoding='utf-8') if l.strip()}
bad = [f for f, d in man.items()
       if not os.path.exists(f) or hashlib.sha256(open(f,'rb').read()).hexdigest() != d]
print(f"{len(man)-len(bad)}/{len(man)} files verify")
SH
python qa/validate_public_profile.py --profile . --full-root .
```

Which reproduction paths hold here (full detail in `PROFILE_NOTICE.md`):

| Path | Here |
|---|---|
| Rebuild the graph from the shipped tables | **yes** |
| Recompute the derived statistics from the shipped tables | **yes** |
| Regenerate the tables from raw inputs | no — `legacy/` is not distributed |
| Any analysis over the withheld character streams | no — request the full package |

## Status: RELEASE CANDIDATE

Three gates, separate because they are separate decisions:

1. **Public distribution.** The public structural release is technically prepared for open distribution: it contains no third-party transcribed character stream, so the per-provider rights review does not gate it. Release remains subject to author and institutional sign-off. Status: `READY_FOR_AUTHOR_SIGN_OFF`.
2. **Full internal package.** It carries the transcriptions and is not redistributable until the rights review is complete (1 of 176 resources cleared). Status: `BLOCKED_PENDING_RIGHTS_REVIEW`.
3. **Scientific validation / manuscript readiness.** No domain expert has adjudicated any label (0 of 1,816 items in this distribution; the corpus of record is the internal protocol of 2,031). Status: `NOT_PERFORMED`. This gates a Data Descriptor submission, not distribution.

Neither distribution status is a legal determination: that rests with the authors and their institution. `overall_release_status` is the conjunction of all three and is therefore `NOT_READY_FOR_PUBLICATION`.

**Epistemic gating of alignment.** `chapter_instances.alignment_review_status` has three
live states: `original_deterministic` (3,481 instances, in the default
analysis set), `auto_recovered_unreviewed` (116 instances recovered
in v1.1.2 by `src/recover_alignment.py`, **excluded from `analysis_default_include` and
from the default mention files until an expert confirms them**), and `not_aligned`
(46). Expert-confirmed rows flow in via `src/shipped_labels/alignment_review.csv`.

**How to quote the corpus size.** Use: *3,481 expert-independent, analysis-ready aligned chapter instances, plus 116 automatically recovered candidate alignments awaiting expert confirmation (46 units unaligned; 3,643 rows in total)*. A bare
"3,597 aligned chapter instances" overstates the analysis-ready corpus,
because it folds in recoveries no expert has confirmed (3,481 default +
116 recovered-unreviewed).

Count vocabulary used throughout: **edges/rows** (one per chapter-instance × concept),
**occurrences** (summed `mention_count`), **sentence rows** (sentence × concept).
Never compare across kinds; never compute variant density where
`variant_detection_run = FALSE`.

## Read this before analysing

1. **Two era fields are not interchangeable.** `Person.person_historical_era` is the figure's
   own era; `Version.witness_era` is the edition's. v1.1.0 conflated them, and
   68.9% of commentary rows with both known have differing values — use
   `Commentary.commentator_historical_era` for cross-era analysis.
2. **Mentions measure witness text, not base scripture.** At most 0.0%
   of the matched text is Laozi base text (upper bound); filter `text_composition`.
3. **Concept counts.** Filter `MENTIONS_CONCEPT.match_specificity`; 81.4% of
   raw occurrences are single-character matches that are also ordinary words.
4. **Commentary quotes.** Gate on `citable_as_quote` (1,282 of 2,386); the rest
   are model-spliced excerpts or unlocated paraphrase.
5. **Variants are candidates.** `variant_status = candidate_auto_detected` on every row;
   `variant_detection_score` is a heuristic, not a probability.

## Figures at a glance

| | |
|---|---:|
| Resources | 176 = 175 historical source witnesses + 1 modern derived resource |
| Chapter instances | 3,643 (3,481 default set; 116 recovered-unreviewed; 46 unaligned) |
| Sentences | 167,506 |
| Candidate variant events | 18,334 — plus 3,493 structural-mismatch diagnostics held **outside `data/`** in `derived_diagnostics/`; never sum the two |
| Concepts | 111 (20 hand-authored seeds, 91 LLM-expanded; 109 with mentions) |
| Concept mentions, default set | 51,648 edges · 283,788 occurrences · 233,892 sentence rows |
| Concept mentions, recovered-unreviewed (separate files) | 1,029 edges · 2,753 occurrences |
| Concept mentions, unaligned (separate files) | 1,268 edges · 15,193 occurrences |
| Commentary glosses | 2,386 (1,282 citable as verbatim quotes; all `gloss_reviewed = FALSE`) |
| Persons | 77 (75 named + 2 placeholders), 90 aliases |
| Graph | 12 node tables, 17 relationship tables |

## Licence

Data: see `LICENSE_DATA.md`. Code: see `LICENSE_CODE`.
