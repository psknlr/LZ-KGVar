# derived_diagnostics/ — generation-stage diagnostics, not a data layer

`structural_mismatches.parquet` holds events found by the same v1.0.0 difflib
detector that produced `data/variants.parquet`, but whose diff spans are too long
to be character-level textual variants. In practice they mark **commentary bleed**
(interlinear 注 text sitting inside what the aligner treated as base text) and
**misalignment candidates** — useful for diagnosing the alignment layer, not for
counting textual difference.

It shares the variant schema (`reference_text_id`, `variant_detection_score`,
`variant_status = structural_mismatch_diagnostic`, …) precisely so the two files
can be told apart by one column rather than by filename.

**Do not** concatenate it with `data/variants.parquet`, and do not add its row
count to a variant total: the two tables have no shared identifier space and an
event can be represented in both. It lives outside `data/` for that reason.

Nothing here is expert-reviewed. Column definitions are in
`metadata/data_dictionary.csv` under the `derived_diagnostics/` prefix.
