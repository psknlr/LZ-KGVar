# Changelog

## v1.1.2-rc11 — text-leak purge, Methods completeness, rights wording

No knowledge content changed: no concept, relation, variant, commentary or
sentence row was added, removed or edited. Every change is in the public
distribution, the validation Methods, the rights wording or the release flow.

### P0 — spliced source text removed from the public distribution
`commentary.llm_interpretation` was being carried into the public profile for
resources whose disposition withholds their character streams. The column is a
machine paraphrase, but it is composed from the source, so for a
`metadata_and_offsets` or `reference_only` resource it re-publishes exactly what
the disposition withholds. It is now blank there and retained only for the
authors' own `full_text` resource; the data dictionary, the graph loader and the
facts all state the conditional rather than describing the column as present.

### The leak class is now gated, not just fixed
Three checks, each negative-controlled:

- **Conditional text-column check.** A text column may be non-empty only for
  resources whose `release_disposition` is `full_text`. The previous check asked
  only whether withheld columns were absent, which a conditionally-populated
  column passes while leaking.
- **Rights-document consistency.** Every document stating the rights position
  must state the same one. Four files had drifted into three different framings.
- **Standalone-run reproducibility.** Running the profile suite against the
  profile as its own reference root now reproduces the shipped check count, so a
  third party's run and the release run agree.

### Validation Methods
The sampling table listed eight frames summing to 1,915 while the protocol is
2,031 — the gap was exactly `frame_recovered_alignment` (116), so a reader
adding the published rows could not reach the published total. The table now
carries nine rows, states its own total, and names the pre-correction sum so the
correction is auditable; that figure is derived from the facts, not typed. The
validation README's TV2 layer names the frame and its two questions. Both
corrections landed in the public overlay templates as well — the overlay exists
to say different things about scope, not to hold a stale Methods table. The
scorer's packet-size note is now read from the packet the run actually scored,
the literal having been correct for the internal package and wrong inside the
filtered mirror.

### Documents
- Both publication documents carried **two** dataset titles — the pre-rc7 string
  in their own heading and the current one in the citation block beside it. Both
  headings now render from `dataset_title`, and a new check asserts the
  publication documents name a single title.
- Two dangling sentences (a profile-notice sentence lacking its object, a schema
  bullet ending in a bare cross-reference) completed; a provenance path that
  named a directory one level above the file corrected; a schema parenthetical
  that read as a self-contradiction inside the distribution now states the
  internal and distribution figures separately.
- The dual-profile fact vocabulary had been two parallel lists, one per facts
  generator, where a key added to one and not the other renders as an unknown key
  or — worse — silently as the distribution's own number. Hoisted to one
  definition that both import.

### Release flow
The stage labels carried three different denominators, because an earlier
mechanical renumber matched only two of them and so half-renumbered. All 24
stages are now labelled in execution order with one denominator, verified by
reading the printed sequence from a full run.

### Unchanged gates
Rights 1/176. Expert validation 0/2,031, of which the prioritized packet is
400. `overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc10 — release engineering only; no knowledge content changed

No concept, relation, variant, commentary or sentence row was added, removed or
altered. Every change is in documentation semantics, dual-profile metadata,
release-state bookkeeping and rights recording.

### Dual-profile documents
- **Comparison documents named one distribution's value twice.** A shared
  template key meant one thing in each tree, so the availability table's
  "full internal" column and the citation document's edge count rendered the
  PUBLIC value in the public copy. Introduced a vocabulary the templates cannot
  confuse: `*_full_corpus` always means the full internal dataset (a self-alias
  in the full package, which IS the full corpus) and `public_profile_*` always
  means the distribution. Forced a real reordering — public counts do not exist
  until the profile is generated, so facts computation is now two passes and
  full-package rendering and QA moved after the profile exists.
- **New public QA check (4th of the doc-consistency family):** for every fact
  pair whose two values genuinely differ, a line naming both profiles must carry
  the full value, not the public one twice. This closes the gap that let the
  defect through — the documents allowed to quote both distributions are exactly
  the ones the full-corpus leak check skips, so nothing was examining them. They
  are now held to the stricter requirement instead of the weaker one. Table rows
  are judged individually, prose as the wrapped paragraph (per-line judgement
  flagged a correct but line-wrapped citation sentence). Negative-controlled.
- **Three overstated claims scoped by distribution:** `reproducibility_short`,
  `graph_artifact_claim` and `verified_reproduction_sentence` now render from
  whether the tree holds raw inputs. The public copy claims neither a clean-room
  table regeneration nor a graph snapshot — it claims graph reconstruction from
  the released tables, statistic recomputation and figure regeneration, which is
  what its QA suite actually verifies.

### Validation semantics
- The public packet is stated as a **filtered mirror** of the internal
  400-item priority set, not an independent
  sample, and must not be used to estimate precision: rights filtering removed
  rows unevenly, so the equal allocation the design specifies no longer holds.
  Estimates come from adjudicating the internal sample. The deposit checklist
  now points there too, resolving a contradiction between two shipped files in
  favour of the internal package being the corpus of record. Both sentences live
  in `src/scoped_claims.py` and are composed by both facts generators, because
  they must quote the internal counts even when rendering inside the profile.
- **Profile notice split** so that auditing the framework and scorer is
  permitted while text-dependent adjudication of record is not — the source
  text, commentary quotes, variant strings and recovered chapter text are
  withheld, so faithfulness, philosophical-use, variant-genuineness and
  alignment judgements cannot be made from that copy at all.
- **Full-population frames now require 100%.** work_type/textual_scope (176),
  node_type (111) and person_eras (75) inherited the 80% default despite being
  defined as full-population, which would have left a fifth of each population
  unreviewed under a claim of complete coverage. Negative-controlled at 90%.
  The per-frame threshold map is exported in `validation_metrics.json`.

### Metadata and final-state bookkeeping
- Data-dictionary descriptions no longer embed corpus-level counts. A shared
  description with an embedded count is necessarily wrong in one distribution;
  each now states the permitted value set plus the semantics a reader needs and
  points at this tree's facts file and the column's own `distinct_count`.
- `docs/provenance.md` gained a scope banner: its counts account for the full
  internal construction corpus, because a row produced by a language model was
  produced whether or not it is redistributable.
- **`checksum_payload_files` removed rather than corrected.** Documents are
  rendered before the manifest is regenerated, so any count captured there is
  the previous build's — rc9 shipped 197 in a distribution whose manifest hashes
  149. The schema paragraph now names
  the files that cannot hash themselves and points at the final record.
- **`figures_included` was read from the wrong key and evaluated before figures
  exist.** Generation writes an unknown value; a new `--finalize` pass fills it
  from the filesystem at stage 5g, after figures and before the report is hashed.
- **`metadata/final_release_verification.json`** is written in the last release
  stage to both distributions, recording each one's verified payload count, its
  manifest path, the profile's QA result and the frozen validation-report hash.
  It declares itself among the unhashable self-references for the same reason the
  manifest is one. The path check exempts it and the profile's own QA report —
  the run that checks cannot have written them yet — and the exemption was
  controlled to be narrow: a genuinely absent path still fails.
- The public README named the profile suite by a hardcoded check count; it now
  names the suite instead. The count it carried was two revisions out of date,
  and quoting the stale number even here trips the check-count guard — which
  is the guard working, so the sentence avoids it rather than being exempted.

### Rights and status
- **Four coexisting publication statuses replaced by three separated gates.**
  None was wrong — they were about different objects. `three_gate_statement`
  renders in both READMEs: public distribution
  `BLOCKED_ENGINEERING`, full internal package
  `BLOCKED_PENDING_RIGHTS_REVIEW`, scientific validation
  `NOT_PERFORMED`, closing with the note that no
  distribution status is a legal determination and that
  `overall_release_status` is their conjunction. All three statuses are now
  shared keys, so they read identically in both trees — they rendered as
  `unknown` in the profile on the first attempt.
- **The authors' own compilation is recorded as cleared** under CC BY 4.0
  (rights 1 of 176). Implemented as
  `src/shipped_labels/rights_sign_off.csv` — a human-decision layer applied on
  top of the inferred ledger, which raises on an unknown `version_id`.
  Inference can never produce `cleared`; only that file can. The reviewer field
  records who conveyed the decision and notes that the corresponding author's
  countersignature is pending. The clean-room regeneration reproduces the row.

### Deposit hygiene
- Upload filenames are the names the files actually carry in the archive.
- Curator metadata carries a per-distribution scope banner: "Not for deposit
  from this copy" in the internal package, "This is the deposit copy" in the
  public one — rc9 shipped full-corpus description figures beside an instruction
  to upload the other archive.
- **`date-released` removed.** It contradicted "Publication date: not published"
  in the same archive. Removing it broke rendering and exposed that the date was
  read out of CITATION.cff, a file generated from that fact — the third instance
  of this cycle after the version string. `BUILD_DATE` is now its own unrendered
  source. A 76th QA check asserts an unpublished release declares no publication
  date; negative-controlled by reinstating the key.
- `numpy` declared (imported directly by `src/make_figures.py`), with the tested
  versions of numpy and networkx recorded.

### Unchanged gates
Rights 1/176 — the
175 third-party rows are untouched. Expert validation
0/2,031.
`overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc9 — 2026-09-13

Publication-layer unification for the public structural release. **No knowledge
content changed**: no table row, concept, relation, variant or commentary record was
added, removed or altered. Every change is in facts generation, rendering,
validation scoring, figures, status reporting and QA.

### The finding, and why it was mine

rc8 rendered the profile's documents from `{**full_facts, **profile_facts}`. The
profile facts carried 42 keys; the full facts carry 117; **94 keys resolved silently
to a full-corpus value.** That fallback was a deliberate decision in rc8, made so
structural tables would still render — and it is the same shape as the absent-key
skip removed from the FK validator in rc8: a guard that substitutes instead of
complaining. The public README ended up printing 3,643 chapter
instances beside "3,846 default", which cannot both be true.

A partial facts file plus a silent default is strictly worse than no profile facts,
because the output looks computed.

### Changed

- **No fallback.** A placeholder a profile's facts cannot resolve now aborts the
  render, naming every missing key.
- **Profile facts are complete by construction.** `make_release_facts.py` gained
  `--out` and is run against the profile's own tables — one computation, two inputs,
  rather than a second implementation that would drift. 149 keys, of which
  119 are computed from the profile's tables,
  15 are shared release identity listed explicitly, and
  12 are `*_full_corpus` companions.
- **Profile graph counts are real.** Generation builds the graph from the shipped
  tables, keeps `build_report.json`, discards the database — and fails the profile
  if those tables do not build.
- **Analytics recomputed.** These are conclusions, not counts, and a public reader
  could not reproduce them: single-character share 81.4% (full
  82.24%), Spearman raw vs high-specificity
  -0.655 (full -0.172),
  top-ten overlap 0 (full
  1).
- **Validation re-scored in the profile**: 1,816 items, not the
  unfiltered protocol's 2,031. Every per-frame size now renders from
  a row-count fact — documents had asserted 750 / 329 / 400 / 176 where the sheets
  hold 600 / 307 / 375 / 158.
- **The public packet is a filtered mirror**, 356 of the internal
  400, described by `--mirror` mode which draws nothing. Re-drawing would
  break id correspondence with the internal packet, which is the whole point of a
  public copy. The equal-allocation design no longer holds here and the strata
  present are recorded in `mirror_allocation.csv`.
- **`src/make_figures.py`** — the six figures are generated, not copied. The public
  set is now drawn from public facts; five of six differ from the full set.
  Figure 1 is legitimately identical (it plots the version table and rights ledger,
  which list all 176 resources in either distribution).
- **Three separate statuses**: `full_distribution_status = BLOCKED_PENDING_RIGHTS_REVIEW`
  (the rights ledger gates the package carrying third-party text),
  `public_distribution_status = READY_FOR_AUTHOR_SIGN_OFF` (no third-party
  character stream, so the ledger does not gate it), and
  `scientific_validation_status = NOT_PERFORMED` (gates the
  manuscript and both profiles). Neither distribution status is a legal determination.
- **Reproducibility scoped by `regeneration_available`**, derived from whether the
  tree holds the raw inputs — so the public copy cannot claim an executed clean-room
  regeneration it cannot run.
- **Four new public QA checks** (now 14 total): the profile's
  load-bearing figures must appear in its documents, and no `*_full_corpus`
  companion value may appear where a public one belongs. Negative-controlled by
  reinstating the rc8 fallback and stripping the keys. Two more close a gap those
  two could not see, because they scan numeric values: **no full-package artifact
  may be present in the profile** (`metadata/release_facts.json` and
  `qa/validation_report.json` were both being copied in, the first reading
  `chapter_instances: 4,009` inside a distribution holding 3,643), and **every
  path a public document points a reader at must exist there**. The second failed
  immediately on five documents naming the full package's facts file — including
  the reproducibility banner telling a reader to verify `regeneration_available`
  in a file whose copy here said the opposite. Documents now name their own tree's
  files via `facts_file` / `qa_report_file`. The only exempted path is this
  suite's own report, which the run that checks cannot have written yet; its
  presence in the shipped archive is covered by the manifest instead. Controlled
  both ways: a genuinely absent path still fails, and restoring the copied
  artifacts produces two failures.

### Unchanged gates
Rights 0/176. Expert validation 0/2,031 full,
0/1,816 in the public mirror. `overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc8 — 2026-09-13

Release-layer only; no knowledge content added or removed. The headline fix is a
defect the rc7 public-profile QA suite could not see, because the suite had
copied the generator's mistake.

### The evidence cascade, and the blind spot (P0)
- `evidence.parquet` cascades on **`source_ref`**, its real foreign key. rc7's
  generator declared `commentary_id`, a column the table does not have, so the
  filter matched nothing: the public profile carried all 2,635 evidence rows
  against 2,386 commentary records — **249 orphans** for
  withheld resources. Now 2,386 with zero orphans.
- The profile validator declared the **same wrong column**, and skipped the check
  when the column was absent. Generator and validator agreed with each other and
  neither agreed with the data, which is how a 7/7 pass covered a real defect.
  Three changes: an absent declared key is now a hard failure naming the columns
  that do exist; the orphan check asserts it actually checked every declared
  relationship rather than reporting clean on a subset; and a new check parses the
  generator's cascade map and fails if the two disagree on any key. Restoring
  rc7's configuration now produces three failures instead of a pass.
- `data_dictionary` described `source_ref` as an `instance_id` — the documentation
  the wrong code was written from. Corrected; `schema.md` states the relationship.

### The public distribution now describes itself
- **`metadata/public_release_facts.json`**: facts computed from the profile's own
  tables. rc7 rendered the public documents from the full package's facts, so a
  public reader saw 224,794 sentences where the distribution
  ships 167,506, 20,124 variants where it ships
  18,334. Every public count now carries a `*_full_corpus` companion so both
  are visible without either being implied.
- `render_docs.py --profile` renders into a distribution from its own facts, with a
  `docs/templates/public/` overlay where the prose must differ — replacing rc7's
  string-patching of copied files, which is what allowed the drift.
- **Derived statistics recomputed inside the profile.** rc7 shipped the full-corpus
  statistics table, so its raw-occurrence total (365,509)
  could not be reproduced from the mention table beside it
  (283,788). They now agree.
- **Quick start runs.** It opened a prebuilt database the distribution does not
  contain; it now builds the graph from the shipped tables first (tested end to end),
  and the contents tree lists what is actually present.
- `figures/` ships here — rendered from structured tables, so no rights reason to withhold.

### reference_only now means witness record only
- rc7 withheld the *text* from the copied frames but left the *rows*, so 18 withheld
  resources still contributed row-level derived records. **587 rows**
  removed across 9 files; the filter resolves instance- and sentence-keyed files
  through the full tables, which a first version keyed only on `version_id` missed.
- New check: no file outside the rights ledger and version table may carry a row for
  a `reference_only` resource. Consequence documented — the validation frames here
  hold 1,816 items against the internal package's
  2,031.

### Consistency
- The QA report hardcoded the pre-recovery protocol total and the relation and
  diagnosis counts, contradicting the metrics file beside it; all are now read live.
- Public variant claim corrected to 18,334 of 20,124;
  dashboard banner and alias count now derived, not typed (they said 224,753 and 85
  against 224,794 and 90).
- "Fully reproducible" replaced with which of the three paths actually hold, and the
  validation claim scoped: protocol and frames are public, adjudication that depends
  on reading withheld text needs the full package. Both phrasings guarded.
- Licence split by distribution — the public one may be published because the
  undetermined layer was withheld rather than licensed; the full package may not.
- One rendered title across citation, readme, dataset card and Zenodo metadata.
- The profile's own QA report is now covered by its manifest (rc7 wrote it after).

### Unchanged gates
Rights 0/176. Expert validation 0/2,031
(0/400 of the priority set). `overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc7 — 2026-09-11

Sixth-round audit response. **No data changed.** Every item is a defect in the
distribution layer — the machinery that decides what leaves this repository —
and all seven were reproduced against the rc6 archive before being fixed.

The headline: the rc6 public profile was **not** publishable, despite being built
to be. It cleaned the data tables and then copied the validation frames and
diagnostics over the top of them.

### Public structural release (P0)
- **109,097 characters of third-party text removed** from the profile.
  `expert_validation/`, `derived_diagnostics/` and `derived_unverified/` were
  copied verbatim, reintroducing text the data tables had withheld: 750 mention
  rows, 159 commentary quotes, all 116 recovered-alignment rows with their
  canonical counterparts, variant text, the S06453 dossier and the priority-set
  copies of all of it. Of the 750 mention rows, 598 belonged to
  `metadata_and_offsets` resources, 150 to `reference_only` ones and 2 to the
  authors' own `full_text` compilation (598 + 150 + 2 = 750). An earlier draft of
  this entry omitted the last term, so the breakdown read as a partition that did
  not sum.
  The sanitizer is driven by **column name** across the copied directories, not
  by a file list: a path-keyed first draft missed the entire priority-set
  directory because those sheets are renamed in this same release.
- **Referential cascade.** rc6 filtered only tables carrying a `version_id`,
  leaving 249 `commentary_concept_links` pointing at removed commentary and 38
  unaligned mentions from withheld witnesses. The profile is now built by an
  explicit cascade — 158 versions → 3,643 instances →
  167,506 sentences → 2,386 commentary records — and each table is filtered on
  the key it actually references. Zero orphans across 10 relationships.
- **Each distribution now has its own QA and its own manifest.** rc6 generated
  the profile at stage 1d, before QA and before `make_metadata`, so the `qa/` and
  `metadata/` it carried were the *previous run's*; its checksum file could not
  verify itself. The release is 11 stages, and `qa/validate_public_profile.py`
  (7 checks) gates it.
- **Reproducibility scoped.** The profile ships no `legacy/`, no built graph database or
  `output/`, yet carried a README telling the reader to regenerate from
  `legacy/`. `PROFILE_NOTICE.md` now tables what it can and cannot reproduce, and
  the unrunnable command is replaced in the copy.

### Validation (P0/P1)
- **Completion is row-wise.** The scorer took the per-question *maximum*, so
  answering one of commentary's two questions on all 329 rows reported 329/329
  adjudicated with the other question untouched. A row counts only when every
  `adjudicated_*` field is answered; per-question counts are reported alongside.
- **Per-frame thresholds replace the global 80%.** Filling every frame except
  commentary and concept relations reaches 80.5% overall — `VALIDATED` under the
  old rule. It now returns `PARTIALLY_VALIDATED` naming both. Relations,
  recovered alignment and alignment diagnosis require 100%.
- **`minimum_publishable_set` → `priority_validation_set`.** The old name
  asserted a sufficiency no sample size establishes. Its README is now generated,
  and states that 23 of the 35 strata hold fewer than 10 items, so the
  frame-level marginal is quotable and a single-stratum point estimate is not.

### Documentation
- Four documents carrying the pre-recovery total of 1,915 (and one titled at
  rc5) are now rendered from facts: 2,031 items, 0 adjudicated.
- **Zenodo upload object is the public profile**, not the full archive — rc6's
  instructions contradicted its own availability statement.
- The `pct:` formatter emits its own `%`. The dataset card had read "the two
  differ for 66.4 of glosses"; fixing the formatter surfaced two templates that
  were typing the sign themselves.

### Unchanged gates
Rights 0/176. Expert validation 0/2,031 (0/400 of the priority set).
`overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc6 — 2026-09-11

Sixth-round audit response. Still a release candidate, deliberately: the audit's
route to v1.2.0 requires ~400 expert adjudications and a completed rights review,
neither of which the pipeline can perform. rc6 makes both as easy to start as
they can be made, and renames the publishable distribution so it stops reading
like an embargo.

### The publishable profile is no longer called "restricted"
`dist/restricted/` → **`dist/public_structural_release/`**
(`src/make_restricted_profile.py` → `src/make_public_profile.py`,
report → `public_profile_report.json`). The old name suggested a gated copy; in
fact this is the openly distributable one and the FULL profile is what must wait
for the rights review. Propagated through the release flow, the QA guards, the
data dictionary and every document; `PROFILE_NOTICE.md` explains the rename so a
reader of the old name is not lost.

### Data availability and citation
- **`docs/DATA_AVAILABILITY.md`** — a quotable statement, a profile-by-profile
  table of what is carried and withheld, the three rights layers, and why the
  works' age settles only the first. The short form is a rendered fact, so it
  cannot drift from the rights counts, and it appears in the dataset card and the
  Zenodo metadata.
- **`CITATION.md`** — human-readable companion to `CITATION.cff`, rendered from
  `docs/templates/CITATION.md.tmpl` (it was hand-written first and immediately
  shipped a stale version and adjudication total; a QA check now fails if any
  publication-facing document is not rendered from a template). It names which
  profile to cite in a methods section (default mention edges differ:
  58,619 full vs 51,648 public) and the three facts that must accompany
  any citation.
- Do not write "the LaoziKG dataset is openly released": 0 of 176 reviewed.

### Framing: design, not scale
README, citation title, Zenodo abstract and the dataset card now lead with
**provenance-aware multi-version textual modelling** — witness-level attribution,
separated witness/author eras, machine-derived layers gated out of defaults —
and say outright that this, not corpus size, is the contribution.

### A 400-item review that can actually be finished
- **`expert_validation/priority_validation_set/`** — exactly 400 items on the
  audit's allocation: mentions 150 (50/tier), commentary 100 (all 19 strata),
  recovered alignment 50, relations 50, variants 50 (12–13 per score bin). Each
  draw preserves its parent frame's stratification, so a per-stratum rate from the
  packet is estimated exactly as it would be from the full frame.
- **`frame_recovered_alignment.csv`** — new, all 116 auto-recovered chapter
  instances (the population that has to be confirmed before they can enter the
  default set), each row carrying the recovered text and the canonical chapter
  text side by side. Protocol total 2,031 (was 1,915).
- **`src/merge_priority_set.py`** — merges completed sheets back onto the parent
  frames by key, never overwriting an existing answer, reporting conflicts.
- The scorer reports packet completion separately from the full protocol; facts
  carry `pvs_*`. Verified end to end on a synthetic fill in a scratch copy: status
  flips to `PARTIALLY_VALIDATED`, packet reads 400/400, real rates with Wilson
  intervals appear. Shipped frames remain **0 of 2,031**.

### Figures
`figures/` now holds six. New: **fig5_architecture** (the four layers, how each
was produced, what is gated) and **fig6_version_lineage** (instances by lineage
branch and alignment status — all 116 gated recoveries sit in the
Dunhuang–Turfan branch — plus the branch pairs the 19 same-work assertions
link, with no textual-descent claim anywhere).

### Unchanged gates
Rights 0/176. Expert validation 0/2,031 (0/400 of the minimum
set). `overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc5 — 2026-09-11

Fifth-round audit response. The two Priority-A gates the audit names — rights
clearance and expert validation — **cannot be closed from inside this package**:
one needs each provider's terms plus institutional sign-off, the other needs
domain scholars. Neither may be simulated, so both remain open. What rc5 adds is
the machinery that makes them executable, and a distribution that is publishable
without either.

### Rights: a disposition, and a distribution that acts on it
- `source_rights.csv` gains `release_disposition` / `disposition_basis` /
  `disposition_status`: **full_text 1** (the authors' own compilation),
  **metadata_and_offsets 157** (public-domain work, third-party transcription),
  **reference_only 18** (provider not identifiable above low confidence).
  Every row is `proposed_not_cleared`; `redistribution_status` is untouched.
- **`dist/public_structural_release/` is generated** (`src/make_public_profile.py`): sentences
  224,794 → 167,506, every third-party character stream withheld,
  withheld lengths kept as `*_char_count` so statistics stay reproducible.
  Rows of the 18 `reference_only` witnesses are dropped with them, so the profile
  carries 51,648 of 58,619 default mention edges and 2,386 of 2,635 commentary
  records — every row belonging to a witness that remains represented, not every
  row in the full profile. A QA check now asserts any retained count claimed in a
  document against the profile's own report. **Publishable today
  without clearing a single third-party transcription.**
- `metadata/source_license_resolution.md` (per-bucket proposed outcome and what
  would change it) and `docs/rights_review_summary.md` (status, and a statement
  for an editor). Still **0 of 176 cleared**.

### Expert validation: results pipeline, not results
- `score_validation.py` now always writes `expert_validation/results.csv` (tidy:
  frame × question × stratum, n, positives, rate, Wilson CI) and
  `validation_metrics.json`, so "0 adjudicated" is data rather than a missing file.
- The QA tier status is **derived** from adjudication counts
  (NOT_PERFORMED → PARTIALLY_VALIDATED → VALIDATED at 80.0%), not a literal, and a
  check fails if any document names a different status. Verified by filling one
  frame in a scratch copy: the status flips and the rates appear. Shipped frames
  remain **0 of 1,915**.

### Concept relations: categorized, deliberately not expanded
`relation_category` over the existing 67 edges — lexical_semantic 32,
semantic 25, realization 5, symbolic 5 — derived from `relation_type`,
**no edge invented**. The audit suggested adding causal / interpretive /
historical-evolution / commentary-inheritance types; doing that with a language
model would add unreviewed philosophical assertions to the layer the same audit
identifies as the weakest. All 67 existing edges are already staged for
full-population review; expansion should follow it, by a scholar.

### Figures
Four in `output/`: source distribution + release disposition, concept
co-occurrence network, commentator-era × edition-era lineage (66.4% divergence),
and concept share by commentator era. Deleted the superseded
`concept_density_heatmap.png`, which was built from pre-correction data and
labelled edition era simply "era".

### Documentation
Release-candidate date distinguished from a publication date (and the date is now
a rendered fact, not hardcoded in three templates); candidate-variant wording in
the README opening; "validated / curated / verified knowledge graph" added to the
vocabulary guard.

### Unchanged gates
Rights 0/176. Expert validation 0/1,915. `overall_release_status = NOT_READY_FOR_PUBLICATION`.

## v1.1.2-rc4 — 2026-09-08

Pre-freeze release candidate answering the fourth-round audit. No new data. Two of
the fifteen items were already satisfied in rc3 and are recorded as such below.

### Rights (P0-1, still the publication gate)
- `source_rights.csv` restructured into the three separable layers the question
  actually has: **A** `original_text_public_domain` (`yes_by_age`,
  175 witnesses — the only layer determinable from the dataset),
  **B** `digitization_rights` (175 `not_determined`), **C** `ocr_rights`
  (new, 175 `not_determined`), plus `redistribution_allowed`
  (**`unknown` on 175 of 176**), `license_basis` (175 `not_established`),
  `digital_source_provider` (was `source_provider`) and `reviewer` (was `reviewed_by`).
- `expert_validation/RIGHTS_WORKSHEET.md`: what must be established per provider
  bucket (terms + retrieval date, layer B, layer C, conclusion, basis, sign-off),
  the bucket table with example ids, the 18 rows needing provider
  identification first, and the partial-release fallback if a bucket cannot be cleared.
- LICENSE_DATA now answers "may users redistribute the released files?" with: not yet,
  for the source transcriptions — and says why age alone does not settle it.
- Still **0 of 176 cleared**. This cannot be closed from inside the dataset.

### Alignment scores and count discipline (P0-2, P0-3)
- The memo's claim that the recoveries "use `confidence`" was already false in rc3
  (those rows carry none). But the legacy column remained on all 3,846 original
  instances and is equally uncalibrated, so `chapter_instances.confidence` →
  **`segmentation_score`** everywhere (pipeline, graph schema, dictionary), documented
  as a heuristic and not a probability, with the old name in the vocabulary guard.
- Recommended corpus-size phrasing added to the facts and rendered in README and the
  dataset card: *3,846 expert-independent, analysis-ready aligned chapter instances, plus 116 automatically recovered candidate alignments awaiting expert confirmation (47 units unaligned; 4,009 rows in total)*. New QA check: the aligned total may not
  appear in any document without the default/recovered split in the same paragraph.

### Sampling design (P1-1, P1-6)
- `frame_variants.csv` was simple-random, leaving the top score levels at 21 and 36
  records. Now **equal allocation of 100 per detection-score bin**
  (0.15-0.25, 0.25-0.45, 0.45-0.65, >=0.65) with `variant_detection_score_bin` and
  `frame_variants_strata.csv` carrying the population needed for reweighting. The
  scorer groups by bin and refuses to pool.
- `expert_validation/SAMPLING_DESIGN.md`: population, scheme, seed and the estimator
  each frame supports — and what each design does *not* support (no pooled precision
  across mention tiers; no corpus-wide genuine-variant rate without reweighting).
- Data dictionary extended beyond `data/` to the validation frames and diagnostics:
  **517 columns across 42 tables, 0 undocumented** (rc3: 309 across 28, with the
  frames a reviewer opens first absent). Frame columns inherit their source table's
  definitions; per-question annotator columns are generated.

### Mention layer, terminology, layout (P1-2 to P1-5)
- Added `mentions_per_10k_chars`, `high_specificity_per_10k_chars` and
  `searched_chars_default_set` (3,033,476 characters). Stated plainly: the rate
  shares one denominator, so it **reproduces the raw ranking exactly** and buys
  comparability across corpora, not de-biasing. Only the specificity split separates
  the measures — Spearman ρ = -0.172 between raw and high-specificity counts,
  1 concept shared between the top-10 lists (raw 无、有、道、知、大、一;
  high-specificity 天下、圣人、万物、无为、天地、自然).
- Variant keywords in CITATION/Zenodo changed to "textual variation" +
  "candidate variant detection"; "validated/confirmed/verified variants" and
  "expert-curated knowledge graph" added to the vocabulary guard.
- `structural_mismatches.parquet` (3,803 rows) moved to
  **`derived_diagnostics/`** with a README stating it must never be concatenated with
  or added to the variant layer.
- requirements.txt was headed "LaoziKG v1.1.1-rc" and a provenance doc "v1.1.0";
  neither matched a version-field pattern, so the rc3 guard missed them. Both fixed,
  module-docstring versions removed, and a new guard fails the build if any shipped
  file header names a version other than the release.

### Still open
- Rights: 0 of 176 cleared. Expert validation: 0 of 1,915 items.
  Both are runnable from the package; neither is closable by the pipeline.

## v1.1.2-rc3 — 2026-09-03

Quality-control release answering the third-round pre-publication audit. No new
data was added; all 30 findings were reproduced against rc2 before being fixed.

### Validation protocol (P0)
- Expert-validation frames had ONE annotator column for TWO questions (commentary:
  concept correct + gloss faithful; variants: class + layer). Rebuilt with
  per-question `annotator_A_<q>` / `annotator_B_<q>` / `adjudicated_<q>` columns;
  same seed, identical record sets.
- `score_validation.py` now reports P_concept and P_faithfulness per
  text_provenance × reliability × extraction_method stratum, mention precision per
  tier, variant P(genuine | detection_score) and layer accuracy among genuine,
  κ/α per question; verified on synthetic labels.
- Five full-population frames for the LLM ontology labels (176 work_type/
  textual_scope, 111 node_type, 67 relations, 75 person eras,
  7 alignment diagnoses = 436 items). Total 1,915 items, **0 adjudicated**.
  README documents the six Technical Validation layers TV1–TV6.

### Epistemic gating of recovered alignment
- `chapter_instances.alignment_review_status` (original_deterministic /
  auto_recovered_unreviewed / expert_confirmed / expert_corrected / not_aligned).
  **The 116 v1.1.2 recoveries are excluded from `analysis_default_include`**
  and from the default mention files until `src/shipped_labels/alignment_review.csv`
  records an expert decision. Default mention statistics therefore equal the
  pre-recovery figures (58,619 edges / 365,509 occurrences);
  recovered instances' 1,029 edges ship in `concept_recovered_mentions.csv`.
- Recovered instances no longer populate `confidence`; `anchor_coverage_score`
  (matched/canonical clauses) and `identification_score` (string similarity) name
  what was measured. `variant_detection_eligible` / `variant_detection_run` added so
  variant density cannot be computed over recovered chapters.
- Heading-only phantom instance `7489099792547577906-CH006` (吳鼐《老子解》 merges
  chapters 6–7; CH006 carries only the 8-character heading 谷神不死天長地久, the body sits in CH007 under 谷神不死至天長地久) removed by normalization rule
  N7; ChapterInstance 4,009. QA now errors on aligned instances without sentences.
- `expert_validation/S06453_review_dossier.csv` + summary: per-segment review sheet
  for the colophon recovery, flagging the two sub-60 identifications.

### Data and provenance
- Every canonical person has a canonical self-alias (85 → 90 aliases; the 5 that
  had only role-form aliases: 吳汝綸, 王元貞, 顧歡, 劉惟永, 傅奕).
- `structural_mismatches.parquet` normalized to the variant schema
  (`reference_text_id`, `variant_detection_score`, `variant_status =
  structural_mismatch_diagnostic`) and regenerated by the pipeline.
- Provenance flags completed: `textual_scope_source/_reviewed` on versions;
  `concept_generated_by`, `concept_reviewed`, `definition_generated_by`,
  `definition_reviewed` on concepts (20 hand-authored seeds, 91
  LLM-expanded — the memo's 15/96 was not the data's split). QA asserts all 8 review
  flags uniformly FALSE.
- QA tier texts (semantic_qa said "not yet recovered") are now computed from the
  tables; the rebuild tier says "all N REGENERATED canonical tables identical" and
  names what is not content-compared.

### Single source of truth for documentation
- `metadata/release_facts.json` (src/make_release_facts.py) computes every
  load-bearing figure from the tables. README, dataset card, Zenodo metadata,
  CITATION.cff, LICENSE_DATA, schema.md and the quality report are **rendered**
  from `docs/templates/*.tmpl` by `src/render_docs.py` in the release flow. Do not
  edit the rendered files.
- `make_metadata.py` carries no hardcoded counts (the stale 3,894 / 224,753 / 86 /
  1,477 / 18,811 / "34 rows Unidentified" / "every row" / "8 pairs" are gone);
  data dictionary 309/309 columns documented (was 111/275, 8 tables empty).
- DATA_QUALITY_REPORT rewritten around TV1–TV6 with current values only.
- New QA guard: every number in a rendered document must equal a current fact
  (negative-controlled with the memo's own 60,096 example). Fixed on the way:
  schema.md header (v1.1.0), Cypher example (`c.era`), checksum scope wording,
  LICENSE_DATA provider counts (65/31/19/34 → 72/32/22 Shidian/Pelliot/Stein, 0 unidentified).

### Still open (gates)
- Expert review: 0 of 1,915 items. Rights: 0 of 176 cleared.

## v1.1.2-rc2 — 2026-09-03

Release candidate answering a third-round audit that cross-checked scripts, QA
logic, Zenodo metadata, graph schema and analysis method. All 17 findings were
reproduced against the v1.1.1-rc package before being fixed; several further
defects were found in the process.

### Reproducibility (P0)
- **`rebuild_smoke_test` was a hardcoded `PASS`.** It is now executed: QA runs the
  regeneration pipeline into a temp dir and compares all 22 shipped tables
  (rows, keys, columns, content). PASS / FAIL-with-diff / NOT_TESTED.
- `requirements.txt` was not pip-installable (`python_requires` line). Fixed.
- `extract_mentions.py` wrote the removed `match_reliability` and a single
  unsplit table; rewritten for the v1.1 layout at both granularities. New
  `concept_sentence_unaligned_mentions.parquet` (12,954 rows): the
  sentence-level file previously still contained `chapter_num = -1` rows.
- `segment_corpus.py`, `detect_variants.py`, `parse_headers.py` and their
  orchestrator cannot regenerate the release (6/12 and 9/19 fields, different
  reference id); moved to `legacy/generation_v1.0.0/` with a per-script table of
  why. `docs/REPRODUCIBILITY.md` now states three kinds of reproducibility.
- Seven steps that had only ever been ad-hoc cells are scripted: shipped LLM
  labels (`src/shipped_labels/` + `attach_shipped_labels.py`), person eras,
  alignment flags, commentary era resolution, evidence quote kinds, claim
  epistemic flags, the rights ledger. `src/regenerate_tables.py` is the single
  entry point (10 stages). `legacy/v1.0.0_inputs/` ships so the test runs from
  the package alone.
- `variant_comparison.py` queried `ver.era` (removed in v1.1.1). Fixed.
- **Latent tool defects found:** `query_api` traversed `PA_ASSERTS_A/B` in the
  wrong direction since v1.1.0 — every provenance chain returned empty and the
  v1.1.1 tests only checked for exceptions; 11 queries aliased three era
  semantics to a bare `era`; `qa_agent` rendered blank fields from stale keys.
  All fixed; `qa/test_tools.py` now asserts results.

### Data (P1)
- `徐學謨徐學謨` was still the canonical name (v1.1.1's CHANGELOG said otherwise).
  Root cause fixed in `canonicalize_persons.py`; alias_type `parse_error`.
- `commentary.csv`: `gloss_generated_by`, `gloss_reviewed`, `gloss_review_status`,
  `gloss_reviewer` — the README's "every LLM field is flagged" claim was untrue
  for this table until now.
- Variant layer repositioned as *automatically detected candidate variant
  events*: `confidence` → `variant_detection_score`, `version_a` →
  `reference_text_id` (WANGBI_CANONICAL = jingwen layer of WANGBI_TONGSHI_2026),
  `variant_status`, `detection_method`, `reference_version_id`,
  `explanation_source` (7 LLM explanations over 544 rows — docs said 8).
- `base_text_share_est` → `base_text_share_upper_bound`. Re-deriving it exposed
  an error: v1.1.1 compared punctuation-bearing canonical text against
  punctuation-stripped instance text. Corrected: at most **8.4%** (was 10.0%),
  median 0.196 (was 0.237), bands 641 / 1,791 / 1,530 (were 683 / 1,952 / 1,211).
- `persons.csv`: `era_reference_dates`, `era_reference_source` (compiler-curated,
  no external authority link — stated as such). `versions.csv`: `witness_era_raw`,
  `witness_era_normalized` (orthographic only), `witness_era_ambiguous` (9 rows),
  `witness_era_reviewed`.

### Alignment recovery
- The 5 confirmed failures re-segmented deterministically (`recover_alignment.py`).
  S06453 via its own 78 character-count colophons (68/78 agree with the actual
  count within ±2): 74 chapters in a non-standard order 8–36, 57–69, 37–56, 70–81, plus a 751 CE dated colophon left in the residual. Four commentary
  editions via clause anchoring: 21 / 8 / 7 / 6 chapters.
  ChapterInstance 4,010 (was 3,894), Sentence 224,794 (41 colophon splits),
  mention rows 59,648 / occurrences 368,262. Variants NOT regenerated for
  recovered instances. All `recovery_reviewed = FALSE`.

### Expert validation and rights
- `expert_validation/`: stratified frames (329 commentary / 750 mentions / 400
  variants) + scorer (Wilson CIs, κ, α). **0 adjudicated.**
- Rights ledger scripted; 34 unidentified providers reduced to 0 unidentified but
  18 low-confidence inferences, each with its basis. **0 cleared.**

### Documentation
- README title said v1.1.0; schema said 11/16 tables (12/17); DATASET_CARD and
  Zenodo metadata said 86 persons and carried resolved checklist items;
  REPRODUCIBILITY said "100 checksums". All synchronized; count vocabulary
  (edges / occurrences / sentence rows) adopted.

## v1.1.1-rc — 2026-09-03

Release candidate answering a second-round pre-publication audit. All 22 audited
findings were reproduced against the v1.1.0 files before being fixed; several
further defects were found during the work. **This is a release candidate: two
gates remain open (see below) and it should not be published yet.**

### Fixed — data semantics (P0)
- **`Person.era` was systematically wrong.** It was inherited from the linked
  witness's era (matching it on 58.9% of authorship edges), giving 老子 = 宋,
  玄奘 = 宋, 唐玄宗 = 宋, 庄子 = 清. Split into `Version.witness_era`,
  `Person.person_historical_era`, `Commentary.commentary_witness_era` and
  `Commentary.commentator_historical_era`. **67.4% of commentary rows have a
  commentator era different from the witness era**, so every v1.1.0 "cross-era"
  view — including the shipped heatmap — was plotting edition era.
- **Person entities normalized: 86 → 77.** Role tokens removed from 7 names and
  moved to the authorship edge; 7 identity groups merged, including three the
  audit did not name (老子/老聃/李耳 as one figure, a doubled-name parse error,
  and a version description that had become a Person node). New
  `person_aliases.csv` (85 rows) + `PersonAlias`/`HAS_ALIAS` in the graph.
- **Corpus restated as 175 historical source witnesses + 1 modern derived
  resource** via `resource_class`/`is_source_witness`, and qualified as
  Laozi-*related* resources: only 10 of 176 are `canonical_ddj` and 113 are
  commentary editions, leaving 53 in other genres (`manuscript_composite` 22,
  `related_laozi_text` 15, `apocryphal_text` 9, `fragment` 3, `biography_text` 2,
  `ritual_text` 2). Earlier drafts cited "36 resources classified `not_ddj`" —
  no such label exists in the data and the non-DDJ total is 53.

### Fixed — statistical integrity (P1)
- `match_reliability` → **`match_specificity`** (it derives from name length,
  not measured precision). Added `concept_mention_statistics.csv` with both raw
  and high-specificity tiers: **82.24% of raw mentions are single-character
  matches**, and the two tiers give almost disjoint top-8 rankings.
- Unaligned units **structurally excluded**: 1,306 rows / 16,058 mentions moved
  to `concept_unaligned_mentions.csv`.
- Mention layer reframed as **witness-text** lexical mentions: at most **10.0%**
  of the searched text is Laozi base scripture. Added `base_text_share_upper_bound` and
  `text_composition`.
- **7 flagged alignment failures diagnosed** (`alignment_failure_diagnosis.csv`):
  5 confirmed with recoverable text (S06453 has 10 canonical openers in 5,086
  chars), PC2823 is commentary-only, and S04681's body is Buddhist doctrinal
  text despite a Laozi title — a mis-catalogue found beyond the audit.
- Corrected the documented `not_located` overlap range from 0.56–0.83 to the
  true **0.2745–0.8958 (mean 0.7242)** — my own earlier error, generalized from
  a 6-row sample.
- Disclosed that commentary covers **33 of 111** concepts, not the full ontology.

### Fixed — software reproducibility (P0)
- **45 stale schema references repaired** across `query_api.py`,
  `qa_agent.py`, `concept_browser.py`, `web_dashboard.py`. All 26 query_api
  methods, 4 concept_browser methods and 4 qa_agent intents now execute; before,
  commentary fields would have rendered empty.
- `run_text_layer_pipeline.py` passed `build` bare to a helper calling
  `func(*args)`, so `build(data_dir, db_path)` got zero arguments and step 4
  raised `TypeError`. Fixed and verified end to end.
- `segment_corpus.py` emitted the removed `chapters.parquet`;
  `detect_variants.py` regenerated the deprecated `variants_detected.parquet`;
  `normalize_tables.py` wrote `scholarly_claims.csv` instead of the released
  `candidate_*` names — so the documented pipeline could not reproduce the
  release. All corrected.
- Scripted the ANONYMOUS/UNKNOWN authorship step
  (`add_anonymous_authorship.py`), which existed only as an ad-hoc shell command
  and was the last gap preventing a clean-room reproduction.
- **Ghost input removed**: `version_provenance_edges.csv` was read and hashed
  but its edges never written, while `query_api` queried a `SAME_WORK_EDITION`
  table no build created. Moved to `legacy/`; queries traverse
  `ProvenanceAssertion`. Input hash list 18 → 17, all genuinely used.
- Build report and `query_api.stats()` now **enumerate tables from the
  database** instead of hardcoded lists, which had silently omitted
  `PersonAlias`/`HAS_ALIAS`, `CONCEPT_LOCUS` and `RELATED_CONCEPT`.

### Fixed — release engineering
- **Checksum ordering bug.** `make_metadata.py` hashed
  `qa/validation_report.json`, then QA rewrote it, so the manifest was stale by
  construction every run. New `src/make_release.py` enforces
  build → QA → freeze → metadata → manifest → verify, and fails on any mismatch.
- Absolute `/Users/...` paths no longer emitted into `build_report.json` or
  `validation_report.json`.
- `requirements.txt` is now the single source of pins, recording a
  **tested environment** and a **minimum supported environment**; v1.1.0 shipped
  two disagreeing sets.
- Candidate scholarly claims moved to **`derived_unverified/`** with a README,
  so `data/` holds only facts, structure, evidence and flagged annotations.
- **QA is now tiered** — structural / semantic / expert-validation / rights /
  rebuild-smoke — instead of one pass count that invited reading the dataset as
  fully validated. Overall status: `NOT_READY_FOR_PUBLICATION`.
- Data dictionary expanded to 88 curated field definitions across 23 tables,
  covering every field the audit named as underspecified.

### Rights — NOT resolved
- New **`data/source_rights.csv`**: one row per resource with
  `redistribution_status`. **All 176 rows are `not_reviewed`; 0 cleared.**
- `LICENSE_DATA.md` rewritten to separate our annotations/code (CC BY 4.0 /
  see `LICENSE_CODE`) from the source transcriptions (undetermined), and the
  blanket `license: CC-BY-4.0` assertion was **removed** from `CITATION.cff`,
  which contradicted `LICENSE_DATA.md`.

### Open gates before publication
1. **Rights review** — complete `source_rights.csv`. I cannot determine
   redistribution rights for third-party digitizations.
2. **Expert validation** — no domain scholar has reviewed any label: 176
   `work_type`, 111 `node_type`, 67 concept relations, 75 person eras, 7
   alignment diagnoses all carry `reviewed = FALSE`.
3. Recovery of the 5 confirmed alignment failures (pending expert confirmation).
