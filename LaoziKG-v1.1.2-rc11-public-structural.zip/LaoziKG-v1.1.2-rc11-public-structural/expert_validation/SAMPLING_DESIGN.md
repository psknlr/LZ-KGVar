# SAMPLING_DESIGN — how each validation frame was drawn

Written for a Methods section. Every frame is regenerable:
`python src/make_validation_frames.py --data data --out expert_validation --seed 20260903`.
Seed **20260903** throughout. Nothing has been adjudicated
(0 of 1,816 items), so no estimate below has a value yet — this
document fixes the design in advance of the review.


## This copy is a filtered mirror, so the allocations below no longer hold here

The designs described in this document are the designs used to DRAW the frames, in
the full internal package. This distribution filters those frames afterwards,
removing every row belonging to a `reference_only` resource, which does not remove
rows evenly across strata. Two consequences:

- The equal-allocation claims are true of the draw and **not** of the sheets here.
  The mention frame was drawn at 250 per specificity tier and its packet sheet at
  50 per tier; in this copy the packet sheet holds 45 / 36 / 35.
- An estimate computed from the sheets here is therefore not the estimator these
  designs support. `priority_validation_set/mirror_allocation.csv` records the
  strata actually present, per sheet, so the imbalance is auditable.

Read this document for the design, the seed and the reasoning. Compute estimates
from the full internal package, where the allocations described below are the
allocations present.


## Summary

| Frame | Population | n | Scheme | Estimator it supports |
|---|---:|---:|---|---|
| `frame_commentary` | 2,635 gloss records | 329 | proportional-stratified, 19 strata, per-stratum floor of 5 | precision per stratum and per `text_provenance` marginal |
| `frame_mentions` | 58,619 default-set mention edges | 750 | equal allocation, 250 per `match_specificity` tier | precision per tier |
| `frame_variants` | 20,124 candidate events | 400 | equal allocation, 100 per detection-score bin | P(genuine \| score bin) |
| `frame_work_type` | 176 resources | 176 | **full population** | share of labels confirmed |
| `frame_node_type` | 111 concepts | 111 | **full population** | share confirmed |
| `frame_concept_relations` | 67 relations | 67 | **full population** | share confirmed |
| `frame_person_eras` | 75 named persons | 75 | **full population** | share confirmed |
| `frame_alignment_diagnosis` | 7 diagnosed witnesses | 7 | **full population** | accuracy of diagnosis and recovery |
| `frame_recovered_alignment` | 116 auto-recovered chapter instances | 116 | **full population** | chapter identification accuracy and boundary accuracy |


The nine frames above total 2,031 items — the whole protocol as it exists in the full internal package. This distribution ships a filtered mirror of 1,816 of them (see the note on the mirror below); the design is described here at full size because that is the design being audited.

## Commentary (TV4) — proportional-stratified

Strata are the cross of `text_provenance` × `reliability` × `extraction_method`
(19 non-empty cells). Allocation is proportional to stratum size with a floor of 5
records per cell, so the small cells that matter epistemically (the `not_located`
provenance class, the deterministic `direct_text_match` extractions) are estimable
rather than absent. Within each stratum, simple random sampling.

Methods sentence: *We stratified commentary records by quote-provenance class,
extraction reliability tier and extraction method, allocated the sample
proportionally with a minimum of five records per stratum, and sampled at random
within each stratum.* Per-cell allocation ships in `frame_commentary_strata.csv`.

Two questions are adjudicated independently per record: whether the concept
attribution is correct, and whether the gloss text is faithful to the cited source.

## Mentions (TV3) — equal allocation per specificity tier

250 records from each of the three `match_specificity` tiers, sampled at random
within tier, with the containing sentence shown to the annotator. Equal allocation
because the quantity of interest is precision *within* each tier: the tiers were
constructed to differ, and 82.24% of raw occurrences fall in the `low` tier, so a
proportional sample would be almost entirely single-character matches.

**Do not pool the three tiers into one precision figure** — the design does not
support it, and the tier mix of any downstream analysis differs from 1:1:1.

## Variants (TV5) — equal allocation per detection-score bin

| Score bin | Population | Sampled | Scheme |
|---|---:|---:|---|
| `0.15-0.25` | 5,397 | 100 | simple random within bin |
| `0.25-0.45` | 9,330 | 100 | simple random within bin |
| `0.45-0.65` | 2,492 | 100 | simple random within bin |
| `>=0.65` | 2,905 | 100 | simple random within bin |

`variant_detection_score` is a six-level heuristic from the v1.0.0 detector, not a
calibrated probability. The purpose of this frame is to find out whether it
discriminates at all, i.e. to estimate P(genuine variant | score bin). Equal
allocation gives every bin the same standard error; the population is heavily skewed
(the 0.25–0.45 bin alone holds 9,330 events), so a proportional draw would
have left the high-score bins at a few dozen records — which is what rc3 shipped.

Consequences for reporting: the per-bin rates are estimable; a corpus-wide
"proportion of candidates that are genuine" is **not** estimable from this frame
without reweighting by the population column above. Layer correctness
(`change_type`) is adjudicated only among records judged genuine.

## Ontology and metadata (TV6) — full population

436 labels in total, so these are reviewed exhaustively rather than sampled: no
sampling error, and the output is a corrected label set rather than an estimate.
Each frame carries a `corrected_*` column so a reviewer records the fix, not just
the verdict.

## Agreement

Every frame is double-annotated (`annotator_A_<q>`, `annotator_B_<q>`) with
independent adjudication (`adjudicated_<q>`). `src/score_validation.py` reports
Cohen's κ and Krippendorff's α per question alongside precision, and drops `NA`
answers from denominators. Report κ per question, not one figure for the frame.
