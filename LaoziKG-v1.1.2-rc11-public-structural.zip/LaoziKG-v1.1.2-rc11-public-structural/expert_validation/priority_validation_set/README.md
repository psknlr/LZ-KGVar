# Priority validation set — filtered mirror (356 items)

**This is not an independent sampling protocol, and it should not be described as
one.** It is the public mirror of the internal priority validation set: the same
drawn items, with every row belonging to a `reference_only` resource removed,
because this distribution keeps only witness-level records for those resources.

**356 of the internal packet's 400 items are here.** Nothing was
re-drawn to make up the difference — doing so would produce different items whose
ids no longer correspond to the internal packet's, which is precisely the
cross-reference that makes a public copy worth having.

| Sheet | Items here | In the internal packet | Strata present here |
|---|---:|---:|---|
| `commentary` | 93 | 100 | not_located|A|llm_assisted_batch_v1=2; not_located|A|minimax-m3=2; not_located|B|llm_assisted_batch_v1=2; not_located|B|minimax-m3=2; not_located|C|llm_assisted_batch_v1=2; not_located|C|minimax-m3=1; spliced_from_source|A|llm_assisted_batch_v1=8; spliced_from_source|A|minimax-m3=2; spliced_from_source|B|llm_assisted_batch_v1=22; spliced_from_source|B|minimax-m3=2; spliced_from_source|C|llm_assisted_batch_v1=3; spliced_from_source|C|minimax-m3=2; verbatim_contiguous|A|llm_assisted_batch_v1=9; verbatim_contiguous|A|minimax-m3=6; verbatim_contiguous|B|llm_assisted_batch_v1=15; verbatim_contiguous|B|minimax-m3=3; verbatim_contiguous|C|direct_text_match=2; verbatim_contiguous|C|llm_assisted_batch_v1=3; verbatim_contiguous|C|minimax-m3=5 |
| `concept_relations` | 50 | 50 | lexical_semantic=24; realization=4; semantic=18; symbolic=4 |
| `mentions` | 116 | 150 | high=45; low=36; medium=35 |
| `recovered_alignment` | 50 | 50 | PC2517=9; PC2577=4; PC3237=3; S02060=3; S06453=31 |
| `variants` | 47 | 50 | 0.15-0.25=12; 0.25-0.45=12; 0.45-0.65=11; >=0.65=12 |

## What this copy is for

- reading the **sampling design, the schema, the question wording and the scoring
  methodology**, and checking them against the code in `src/`;
- checking which records were selected, by id;
- running `src/score_validation.py` to see that the machinery works and reports
  `0 / 356`.

## What it is NOT for

- **Deriving a precision estimate.** The original design allocated equally across
  strata; filtering removed rows unevenly, so the strata here are no longer equal
  and a rate computed from them is not the estimator the design supports. The
  strata present are listed above so the imbalance is visible rather than implied.
- **Adjudication of record.** Judgements that depend on reading the source text
  cannot be made here — the text is withheld. The full internal package is the
  validation corpus of record; adjudicate there, and cite the result for both.

Re-derive this description with
`python src/make_priority_set.py --frames expert_validation --mirror --full-frames <full package>`.
It reads the sheets present and draws nothing.
