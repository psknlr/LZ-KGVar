# RIGHTS_WORKSHEET — what must be established before publication

**Status: no third-party bucket on this sheet has been answered.**
`data/source_rights.csv` carries `redistribution_allowed = unknown` on 175 of 176 rows
and `redistribution_status = not_reviewed` on those same 175. The remaining row is the
authors' own compilation, cleared under CC BY 4.0 because the authors hold the rights;
it needs nothing from this sheet. This is the single largest blocker to a
public Zenodo release, and it cannot be closed from inside the dataset: it needs each
provider's terms of use plus institutional (library / legal) sign-off.

## Why the age of the text is not enough

Three layers are separable, and only the first is settled:

- **A — the pre-modern work itself.** Out of copyright by age for 175 witnesses. Settled.
- **B — the digital surrogate.** The scan/database layer produced by the holding
  repository or platform. Governed by that provider's terms; may carry database or
  digitization rights depending on jurisdiction. **Not determined.**
- **C — the transcription / OCR / collation.** The labour embodied in the character
  stream we actually ingested. Often the platform's, not ours. **Not determined.**

`redistribution_allowed` is the conclusion from A+B+C. Until B and C are answered the
honest value is `unknown`, which is what ships.

## Work to do, per provider bucket (not per row)

| Provider bucket | Rows | Example version_id | Provider inference confidence |
|---|---:|---|---|
| 识典古籍 (Shidian Guji) platform transcriptions | 72 | DZ0003; DZ0678; DZ0773 | {'high': 62, 'medium': 10} |
| Pelliot chinois, Bibliothèque nationale de France | 32 | PC2004; PC2007; PC2255 | {'high': 32} |
| CADAL digital library | 26 | CADAL06030056; CADAL06030064; CADAL06030044 | {'high': 26} |
| Other / undetermined id series | 23 | 7651246717542596635; LSDZ0761; SDZJ0518 | {'low': 18, 'medium': 4, 'high': 1} |
| Stein collection, British Library | 22 | 7605901086959861812; 7606688523944460307; 7623197515248042010 | {'high': 22} |
| Dataset authors (modern derived resource) | 1 | WANGBI_TONGSHI_2026 | {'high': 1} |

For each bucket, establish and record:

1. **The governing terms.** URL and retrieval date of the provider's terms of use or
   licence page; whether they address bulk/derivative redistribution of transcriptions.
2. **Layer B.** Does the provider assert rights in the digital surrogate? Under which
   jurisdiction? → `digitization_rights`.
3. **Layer C.** Does the provider assert rights in the transcription itself (as opposed
   to the scan)? → `ocr_rights`.
4. **Conclusion.** May the transcription as ingested be redistributed, in what form
   (full text / derived annotations only / not at all)? → `redistribution_allowed`.
5. **Basis.** One or two sentences of reasoning, citing the terms → `license_basis`,
   and the licence that follows → `license`.
6. **Sign-off.** `reviewer`, `review_date`, and `redistribution_status` = `cleared`
   or `restricted`. Only then does QA's `rights_review` tier leave `PENDING`.

The 18 rows whose provider is inferred only at low confidence
(`provider_inference_confidence = low`) need the provider identified first — see
`provider_inference_basis` for what the id series suggests.

## Fallback if a bucket cannot be cleared

A release is still possible without clearing every bucket, by shipping the
dataset authors' own layers (annotations, graph, code, derived statistics) plus
identifiers and offsets into the source, and **omitting the transcribed character
streams** for the unclear buckets. That changes what the package contains, so decide
it deliberately rather than by default. `docs/schema.md` §7 already notes that the
tables are authoritative and the graph is a projection, which makes such a split
mechanically feasible.

## How to record the answers

Edit `data/source_rights.csv` directly (or a copy) and fill the columns named above.
`src/build_rights_ledger.py` preserves any row whose `reviewer` is non-empty when the
pipeline regenerates the ledger, so a completed review is not overwritten by a rebuild.
