# expert_validation/ — Technical Validation protocol (nothing adjudicated yet)

> **PUBLIC STRUCTURAL RELEASE — this directory is a filtered mirror.**
> It carries the validation *design*: the sampling scheme, the record ids, the
> question wording, the schema and the scorer. It is **1,816
> items** here rather than the internal package's 2,031,
> because rows belonging to `reference_only` resources are removed with those
> resources, and the source text every text-dependent judgement needs is withheld.
>
> **Adjudication of record happens in the full internal package.** Use this copy to
> audit the protocol and to see which records were selected; cite results obtained
> against the full package. `priority_validation_set/README.md` states the same for
> the packet, with the per-sheet effect.



**Status: 0 of 1,816 items adjudicated.** These frames make the review runnable
and scorable; they are not evidence that it has happened. Regenerate with
`python src/make_validation_frames.py --data data --out expert_validation --seed 20260903`;
score with `python src/score_validation.py --frames expert_validation --json expert_validation/scores.json`.

## Six validation layers

| Layer | Frame(s) | Design | Reported metric |
|---|---|---:|---|
| TV1 Structural integrity | `qa/validate_dataset.py` (automated) | all tables | PK/FK/enum/cross-table checks, checksums, EXECUTED clean-room regeneration |
| TV2 Text alignment | `frame_alignment_diagnosis.csv` (7) + `frame_recovered_alignment.csv` (116) + `S06453_review_dossier.csv` | full population of diagnosed cases and of the v1.1.2 auto-recovered instances (`chapter_id_correct`, `boundaries_correct`, both at a 100% threshold); per-segment sheet for S06453 | accuracy of diagnosis and of the 5 automatic recoveries |
| TV3 Concept extraction | `frame_mentions.csv` (600) | 250 simple-random per `match_specificity` tier as drawn (unequal here after filtering), sentence shown | precision per tier, Wilson 95% CI |
| TV4 Commentary | `frame_commentary.csv` (307) | proportional-stratified, 19 strata (`text_provenance × reliability × extraction_method`, min 5) | P_concept and P_faithfulness per stratum and per provenance marginal |
| TV5 Candidate variants | `frame_variants.csv` (375) | **drawn at equal allocation, 100 per detection-score bin** (as drawn, in the full package; filtering here left the strata unequal — see `SAMPLING_DESIGN.md`) (0.15-0.25, 0.25-0.45, 0.45-0.65, >=0.65); allocation in `frame_variants_strata.csv` | P(genuine \| score bin) — per bin, never pooled; class distribution; layer accuracy among genuine |
| TV6 Ontology / metadata | `frame_work_type` (158), `frame_node_type` (111), `frame_concept_relations` (67), `frame_person_eras` (75) | **full population**, not sampled | share confirmed + corrected labels, κ / α |

Sampling design (populations, schemes, seed, and which estimator each frame
supports) is stated in `SAMPLING_DESIGN.md`. Rights work, which is a separate gate,
is set out in `RIGHTS_WORKSHEET.md`.

## Protocol

Each frame has, **per question**, `annotator_A_<q>`, `annotator_B_<q>` and
`adjudicated_<q>` columns (the `q_<q>` column states the controlled vocabulary),
plus free-text notes. Two annotators work independently; a third party fills
`adjudicated_*`. Use `NA` where a question does not apply (e.g. layer correctness
of a non-genuine variant) — the scorer drops NA from denominators.

Reporting rule: quote precision **per tier / per stratum / per score level**,
never one pooled number — the strata were designed to differ. Do not compute
variant density over recovered chapters (`variant_detection_run = FALSE`).
