# S06453 — chapter-order review (for a Dunhuang specialist)

**What was done.** S06453 (Stein collection, British Library) is a scripture-only
Laozi copy in which the scribe wrote a character-count colophon after every
chapter. `src/recover_alignment.py` cut the text at those colophons and
identified each segment against the 81 Wang Bi chapters. **Nothing here has been
checked by a human.**

**Result.** 74 chapters identified; missing: [1, 2, 3, 4, 5, 6, 7]
(scroll head lost). Manuscript order in blocks: **8–36, 57–69, 37–56, 70–81**.

**Internal evidence.** Scribal counts agree with actual counts within ±2 on
68 of
78 colophon segments. Median identification
score 82.4;
runner-up scores are far lower on nearly every segment.

**Please look at in particular.**
1. Near-threshold identifications (score < 60): segment 0 → ch.8 (58.4), segment 68 → ch.74 (48.8).
2. The merged segment split into ch.36 + ch.57 (the scribe omitted 36's colophon).
3. The non-standard block order — is it a known 系师定本 / 河上公 arrangement or a rebound scroll?
4. The residual (`S06453_residual_sentences.csv`): dated colophon transmitted as 大唐天寶千載 歳次辛卯 正月乙酉朔 廿六日庚戌
   燉煌郡燉煌縣玉関鄉 — we read 千載 as 十載 (Tianbao 10 = 751 CE) because 辛卯 fits 751; please confirm — "五千文上下二合八十一章四千九百九十九字", and the title line
   太极左仙公序系师定河上真人章句. These are our reading of the text, not a catalogue
   determination.

**How to record.** Fill `reviewer_chapter` / `reviewer_verdict`
(confirm / correct / reject) / `reviewer_note` in `S06453_review_dossier.csv`.
Confirmed or corrected rows are then entered in `src/shipped_labels/alignment_review.csv`
(`expert_confirmed` / `expert_corrected`) and the pipeline flips those instances
into the default analysis set.
