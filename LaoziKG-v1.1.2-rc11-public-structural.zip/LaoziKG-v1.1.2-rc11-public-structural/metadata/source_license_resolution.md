# source_license_resolution — proposed per-source licence outcome

Companion to `expert_validation/RIGHTS_WORKSHEET.md` (what must be established)
and `data/source_rights.csv` (the machine-readable ledger). This document states
the **proposed** outcome per provider bucket and the evidence that would justify it.

**No third-party source is cleared.** `redistribution_status = not_reviewed` on
175 of 176 rows and `redistribution_allowed = unknown` on those same 175; every
disposition below carries `disposition_status = proposed_not_cleared`. The one
exception is `WANGBI_TONGSHI_2026`, the authors' own compilation, which is
`cleared` under CC BY 4.0 — settled because the authors are the rightsholders,
not by any determination about a provider. Nothing in this document is affected
by it: the buckets below are all third-party.

## Proposed outcome by provider bucket

| Provider bucket | Resources | Proposed outcome | Reasoning, and what would change it |
|---|---:|---|---|
| CADAL | 26 | metadata + offsets 26 | Digital library surrogate; database/digitization rights must be checked for the jurisdiction of supply. |
| Dataset authors | 1 | full text 1 | Authors' own compilation; the only resource whose transcription layer we own outright. |
| Pelliot chinois (BnF) | 32 | metadata + offsets 32 | Manuscript images are BnF/Gallica; the transcription we ingested is not ours and its origin must be traced before any text is published. Gallica's own reuse terms cover the images, not third-party transcriptions. |
| Stein collection (British Library) | 22 | metadata + offsets 22 | As above for the IDP/BL material: image rights and transcription rights are distinct, and only the latter matters for what we ship. |
| Undetermined id series | 23 | metadata + offsets 5 · reference only 18 | A mixed bucket: for the 18 rows whose provider cannot be identified above low confidence, neither layer B nor layer C can be attributed to anyone, so withdrawing the text is the only defensible option until the source is traced; the 5 rows identified at medium or high confidence follow the metadata-and-offsets policy. |
| 识典古籍 (Shidian Guji) | 72 | metadata + offsets 72 | Platform-supplied transcription. Its terms govern layers B and C and are not established. If the platform permits redistribution of transcriptions, these move to CC BY 4.0 full text; if it permits only non-commercial or no redistribution, they stay metadata-only. |

## The four-way classification, and what each means concretely

| Class | Ledger value | What ships | Count |
|---|---|---|---:|
| Authors' own transcription | `full_text` | everything, CC BY 4.0 | 1 |
| Third-party transcription, provider known | `metadata_and_offsets` | structure, identifiers, offsets, character counts, all derived annotations; character stream withheld | 157 |
| Provider unidentifiable | `reference_only` | the witness record in `versions.csv` only; rows dropped from the version-keyed tables | 18 |
| Cleared by review | `full_text` after sign-off | promoted from either class above once the worksheet is filled | 0 third-party so far |

## This is already actionable

`dist/public_structural_release/` is a generated distribution implementing exactly this policy
(`python src/make_public_profile.py`). It withholds every third-party
character stream while keeping 51,648 of the 58,619 default concept-mention edges
(the 6,971 belonging to the 18 `reference_only` witnesses are dropped with them),
2,386 of 2,635 commentary records' metadata, 18,334 of 20,124 variant positions and edit operations,
and the graph built from them — i.e. the dataset authors' entire contribution for
every witness that remains represented. **It is
publishable today without clearing a single third-party transcription.**

The audit's suggested target of ≥90% `cleared` is achievable only through the
worksheet: it requires each platform's terms and institutional sign-off, and
cannot be reached by any change to the pipeline. If clearance proves impossible
for the large 识典古籍 bucket, the restricted profile is the fallback that keeps
the dataset publishable rather than blocked.

## Sequence

1. Fill `expert_validation/RIGHTS_WORKSHEET.md` per bucket (terms + retrieval date, layer B, layer C, conclusion, basis).
2. Record the outcome in `data/source_rights.csv`; rows with a non-empty `reviewer` survive pipeline rebuilds.
3. Re-run `src/build_rights_ledger.py` and `src/make_public_profile.py`; dispositions and the restricted profile follow automatically.
4. Publish the full profile for cleared buckets and the restricted profile for the rest.
